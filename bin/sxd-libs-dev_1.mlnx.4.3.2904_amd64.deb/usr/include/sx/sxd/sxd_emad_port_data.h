/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2019 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_PORT_DATA_H__
#define __SXD_EMAD_PORT_DATA_H__

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_port.h>
#include <sx/sxd/sxd_vlan.h>
#include <sx/sxd/sxd_emad_common_data.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/


/**
 * sxd_emad_pspa_data_t structure is used to store PSPA register
 * data.
 */
typedef struct sxd_emad_pspa_data {
    sxd_emad_common_data_t common;
    struct ku_pspa_reg    *reg_data;
} sxd_emad_pspa_data_t;

/**
 * sxd_emad_spmcr_data_t structure is used to store SPMCR register
 * data.
 */
typedef struct sxd_emad_spmcr_data {
    sxd_emad_common_data_t common;
    struct ku_spmcr_reg   *reg_data;
} sxd_emad_spmcr_data_t;

/**
 * sxd_emad_pmcr_data_t structure is used to store PMCR register
 * data.
 */
typedef struct sxd_emad_pmcr_data {
    sxd_emad_common_data_t common;
    struct ku_pmcr_reg    *reg_data;
} sxd_emad_pmcr_data_t;

/**
 * sxd_emad_pfsc_data_t structure is used to store PFSC register
 * data.
 */
typedef struct sxd_emad_pfsc_data {
    sxd_emad_common_data_t common;
    struct ku_pfsc_reg    *reg_data;
} sxd_emad_pfsc_data_t;

/**
 * sxd_emad_pmmp_data_t structure is used to store PMMP register
 * data.
 */
typedef struct sxd_emad_pmmp_data {
    sxd_emad_common_data_t common;
    struct ku_pmmp_reg    *reg_data;
} sxd_emad_pmmp_data_t;

/**
 * sxd_emad_sbcm_data_t structure is used to store SBCM register
 * data.
 */
typedef struct sxd_emad_sbcm_data {
    sxd_emad_common_data_t common;
    struct ku_sbcm_reg    *reg_data;
} sxd_emad_sbcm_data_t;

/**
 * sxd_emad_sbpm_data_t structure is used to store SBPM register
 * data.
 */
typedef struct sxd_emad_sbpm_data {
    sxd_emad_common_data_t common;
    struct ku_sbpm_reg    *reg_data;
} sxd_emad_sbpm_data_t;

/**
 * sxd_emad_pplr_data_t structure is used to store PPLR register
 * data.
 */
typedef struct sxd_emad_pplr_data {
    sxd_emad_common_data_t common;
    struct ku_pplr_reg    *reg_data;
} sxd_emad_pplr_data_t;

/**
 * sxd_emad_ptys_data_t structure is used to store PTYS register
 * data.
 */
typedef struct sxd_emad_ptys_data {
    sxd_emad_common_data_t common;
    struct ku_ptys_reg    *reg_data;
} sxd_emad_ptys_data_t;

/**
 * sxd_emad_ppad_data_t structure is used to store PPAD register
 * data.
 */
typedef struct sxd_emad_ppad_data {
    sxd_emad_common_data_t common;
    struct ku_ppad_reg    *reg_data;
} sxd_emad_ppad_data_t;

/**
 * sxd_emad_pmaos_data_t structure is used to store PMAOS register
 * data.
 */
typedef struct sxd_emad_pmaos_data {
    sxd_emad_common_data_t common;
    struct ku_pmaos_reg   *reg_data;
} sxd_emad_pmaos_data_t;

/**
 * sxd_emad_plpc_data_t structure is used to store PLPC register
 * data.
 */
typedef struct sxd_emad_plpc_data {
    sxd_emad_common_data_t common;
    struct ku_plpc_reg    *reg_data;
} sxd_emad_plpc_data_t;

/**
 * sxd_emad_pplm_data_t structure is used to store PPLM register
 * data.
 */
typedef struct sxd_emad_pplm_data {
    sxd_emad_common_data_t common;
    struct ku_pplm_reg    *reg_data;
} sxd_emad_pplm_data_t;

/**
 * sxd_emad_pmpr_data_t structure is used to store PMPR register
 * data.
 */
typedef struct sxd_emad_pmpr_data {
    sxd_emad_common_data_t common;
    struct ku_pmpr_reg    *reg_data;
} sxd_emad_pmpr_data_t;

/**
 * sxd_emad_pbmc_data_t structure is used to store PBMC register
 * data.
 */
typedef struct sxd_emad_pbmc_data {
    sxd_emad_common_data_t common;
    struct ku_pbmc_reg    *reg_data;
} sxd_emad_pbmc_data_t;

/**
 * sxd_emad_sbpr_data_t structure is used to store SBPR register
 * data.
 */
typedef struct sxd_emad_sbpr_data {
    sxd_emad_common_data_t common;
    struct ku_sbpr_reg    *reg_data;
} sxd_emad_sbpr_data_t;

/**
 * sxd_emad_pmpc_data_t structure is used to store PMPC register
 * data.
 */
typedef struct sxd_emad_pmpc_data {
    sxd_emad_common_data_t common;
    struct ku_pmpc_reg    *reg_data;
} sxd_emad_pmpc_data_t;

/**
 * sxd_emad_pelc_data_t structure is used to store PELC register
 * data.
 */
typedef struct sxd_emad_pelc_data {
    sxd_emad_common_data_t common;
    struct ku_pelc_reg    *reg_data;
} sxd_emad_pelc_data_t;

/**
 * sxd_emad_ppcnt_reg_t structure is used to store PPCNT
 * register data.
 */
typedef struct sxd_emad_ppcnt_data {
    sxd_emad_common_data_t common;
    struct ku_ppcnt_reg   *reg_data;
} sxd_emad_ppcnt_data_t;

/**
 * sxd_emad_pptb_reg_t structure is used to store PPTB register
 * data.
 */
typedef struct sxd_emad_pptb_data {
    sxd_emad_common_data_t common;
    struct ku_pptb_reg    *reg_data;
} sxd_emad_pptb_data_t;

/**
 * sxd_emad_pcap_data_t structure is used to store PCAP register
 * data.
 */
typedef struct sxd_emad_pcap_data {
    sxd_emad_common_data_t common;
    struct ku_pcap_reg    *reg_data;
} sxd_emad_pcap_data_t;

/**
 * sxd_emad_pmlp_data_t structure is used to store PMLP register
 * data.
 */
typedef struct sxd_emad_pmlp_data {
    sxd_emad_common_data_t common;
    struct ku_pmlp_reg    *reg_data;
} sxd_emad_pmlp_data_t;

/**
 * sxd_emad_pfcc_data_t structure is used to store PFCC register
 * data.
 */
typedef struct sxd_emad_pfcc_data {
    sxd_emad_common_data_t common;
    struct ku_pfcc_reg    *reg_data;
} sxd_emad_pfcc_data_t;

/**
 * sxd_emad_pude_data_t structure is used to store PUDE register
 * data.
 */
typedef struct sxd_emad_pude_data {
    sxd_emad_common_data_t common;
    struct ku_pude_reg    *reg_data;
} sxd_emad_pude_data_t;

/**
 * sxd_emad_pmpe_data_t structure is used to store PMPE register
 * data.
 */
typedef struct sxd_emad_pmpe_data {
    sxd_emad_common_data_t common;
    struct ku_pmpe_reg    *reg_data;
} sxd_emad_pmpe_data_t;

/**
 * sxd_emad_plib_data_t structure is used to store PLIB register
 * data.
 */
typedef struct sxd_emad_plib_data {
    sxd_emad_common_data_t common;
    struct ku_plib_reg    *reg_data;
} sxd_emad_plib_data_t;

/**
 * sxd_emad_qpbr_data_t structure is used to store QPBR register
 * data.
 */
typedef struct sxd_emad_qpbr_data {
    sxd_emad_common_data_t common;
    struct ku_qpbr_reg    *reg_data;
} sxd_emad_qpbr_data_t;

/**
 * sxd_emad_plbf_data_t structure is used to store PLBF register
 * data.
 */
typedef struct sxd_emad_plbf_data {
    sxd_emad_common_data_t common;
    struct ku_plbf_reg    *reg_data;
} sxd_emad_plbf_data_t;

/**
 * sxd_emad_pifr_data_t structure is used to store PIFR register
 * data.
 */
typedef struct sxd_emad_pifr_data {
    sxd_emad_common_data_t common;
    struct ku_pifr_reg    *reg_data;
} sxd_emad_pifr_data_t;

/**
 * sxd_emad_mpsc_data_t structure is used to store MPSC register
 * data.
 */
typedef struct sxd_emad_mpsc_data {
    sxd_emad_common_data_t common;
    struct ku_mpsc_reg    *reg_data;
} sxd_emad_mpsc_data_t;

/**
 * sxd_emad_mlcr_data_t structure is used to store MLCR register
 * data.
 */
typedef struct sxd_emad_mlcr_data {
    sxd_emad_common_data_t common;
    struct ku_mlcr_reg    *reg_data;
} sxd_emad_mlcr_data_t;

/**
 * sxd_emad_mdri_data_t structure is used to store MDRI register
 * data.
 */
typedef struct sxd_emad_mdri_data {
    sxd_emad_common_data_t common;
    struct ku_mdri_reg    *reg_data;
} sxd_emad_mdri_data_t;

/**
 * sxd_emad_ppbme_data_t structure is used to store PPBME register
 * data.
 */
typedef struct sxd_emad_ppbme_data {
    sxd_emad_common_data_t common;
    struct ku_ppbme_reg   *reg_data;
} sxd_emad_ppbme_data_t;

/**
 * sxd_emad_pbsr_data_t structure is used to store PBSR register
 * data.
 */
typedef struct sxd_emad_pbsr_data {
    sxd_emad_common_data_t common;
    struct ku_pbsr_reg    *reg_data;
} sxd_emad_pbsr_data_t;

#endif /* __SXD_EMAD_PORT_DATA_H__ */
