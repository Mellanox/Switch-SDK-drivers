/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2020 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_ROUTER_REG_H__
#define __SXD_EMAD_ROUTER_REG_H__

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_emad_acl_reg.h>
#include <complib/cl_packon.h>
#include <sx/sxd/auto_registers/reg.h>

/************************************************
 *  Local Defines
 ***********************************************/


/************************************************
 *  Local Macros
 ***********************************************/


/************************************************
 *  Local Type definitions
 ***********************************************/


/************************************************
 *  Defines
 ***********************************************/
#define SXD_REG_DWORD_SIZE_IN_BIT         32
#define SXD_RMFTAD_ACTIVITIES_VECTOR_SIZE 128


/************************************************
 *  Macros
 ***********************************************/


/************************************************
 *  Type definitions
 ***********************************************/

/**
 * sxd_emad_rcap_reg_t structure is used to store RCAP register layout.
 */
typedef struct sxd_emad_rcap_reg {
    net16_t reserved;
    net16_t rif;
    uint8_t reserved2[3];
    uint8_t vir_router;
} PACK_SUFFIX sxd_emad_rcap_reg_t;

/**
 * sxd_emad_rgcr_reg_t structure is used to store RGCR register layout.
 */
typedef struct sxd_emad_rgcr_reg {
    uint8_t ipv4_ipv6_mpls;
    uint8_t reserved1[3];
    net16_t reserved2;
    net16_t max_vlan_router_interfaces;
    net16_t reserved3;
    net16_t max_port_router_interfaces;
    net16_t reserved4;
    net16_t max_pkey_router_interfaces;
    net16_t reserved5;
    net16_t max_router_interfaces;
    net16_t reserved6;
    net16_t max_virtual_routers;
    uint8_t reserved7;
    uint8_t usp_pcprw;
    uint8_t ipb_allr;
    uint8_t mcsi_rpf;
    uint8_t ipv6_op_type;
    uint8_t ipv6_packet_rate;
    uint8_t ipv4_op_type;
    uint8_t ipv4_packet_rate;
    uint8_t reserved8;
    uint8_t grh_hop_limit;
    uint8_t reserved9;
    uint8_t activity_dis;
    net32_t expected_irif_list_index_base;
} PACK_SUFFIX sxd_emad_rgcr_reg_t;


/**
 * The structs bellow are implemented in the RITR, one of them will be in use depending on the type field
 */

typedef struct router_vlan_interface_properties {
    uint8_t swid;
    uint8_t reserved1;
    net16_t vlan_id;
    net16_t reserved2;
    net16_t efid;
    net16_t reserved3;
    uint8_t router_interface_mac[6];
    net32_t reserved4;
    net16_t reserved5;
    uint8_t vrrp_id_ipv6;
    uint8_t vrrp_id_ipv4;
} PACK_SUFFIX router_vlan_interface_properties_t;

typedef struct router_fid_interface_properties {
    uint8_t swid;
    uint8_t reserved1;
    net16_t fid;
    net32_t reserved2;
    net16_t reserved3;
    uint8_t router_interface_mac[6];
    net32_t reserved4;
    net16_t reserved5;
    uint8_t vrrp_id_ipv6;
    uint8_t vrrp_id_ipv4;
} PACK_SUFFIX router_fid_interface_properties_t;

typedef struct router_sub_port_interface_properties {
    uint8_t lag;
    uint8_t reserved1;
    net16_t system_port;
    net16_t reserved2;
    net16_t efid;
    net16_t reserved3;
    uint8_t router_interface_mac[6];
    net16_t reserved4;
    net16_t vlan_id;
    net16_t reserved5;
    uint8_t vrrp_id_ipv6;
    uint8_t vrrp_id_ipv4;
} PACK_SUFFIX router_sub_port_interface_properties_t;

typedef struct router_l3_tunnel_interface_properties {
    uint8_t ipip_type;
    uint8_t options;
    net16_t uvr;
    net16_t reserved1;
    net16_t underlay_router_interface;
    net32_t usip[4];
    net32_t gre_key;
} PACK_SUFFIX router_l3_tunnel_interface_properties_t;

typedef struct router_loopback_interface_properties {
    uint8_t protocol;
    uint8_t reserved1[3];
    net32_t reserved2;
    union {
        router_l3_tunnel_interface_properties_t ipinip_tunnel_interface;
    } properties;
} PACK_SUFFIX router_loopback_interface_properties_t;

typedef struct router_port_interface_properties {
    uint8_t lag;
    uint8_t reserved1;
    net16_t system_port;
    net32_t reserved2;
    net16_t reserved3;
    uint8_t router_interface_mac[6];
    net16_t reserved4;
    net16_t vlan_id;
} PACK_SUFFIX router_port_interface_properties_t;

typedef struct router_pkey_interface_properties {
    uint8_t swid;
    uint8_t reserved1;
    net16_t pkey;
    uint8_t reserved2[3];
    uint8_t scope;
    net32_t reserved3;
    net32_t qkey;
    net32_t qpn;
} PACK_SUFFIX router_pkey_interface_properties_t;

typedef struct router_ib_swid_interface_properties {
    net32_t reserved1;
    uint8_t swid;
    uint8_t reserved2[3];
    net16_t reserved3;
    net16_t lid;
    uint8_t reserved4[3];
    uint8_t lmc;
    net64_t guid;
} PACK_SUFFIX router_ib_swid_interface_properties_t;

typedef union rif_properties {
    router_vlan_interface_properties_t     router_vlan_interface_properties;
    router_fid_interface_properties_t      router_fid_interface_properties;
    router_sub_port_interface_properties_t router_sub_port_interface_properties;
    router_loopback_interface_properties_t router_loopback_interface_properties;
    router_port_interface_properties_t     router_port_interface_properties;
    router_pkey_interface_properties_t     router_pkey_interface_properties;
    router_ib_swid_interface_properties_t  router_ib_swid_interface_properties;
    net32_t                                raw_reserved1[9];
} PACK_SUFFIX rif_properties_t;


/**
 * sxd_emad_ritr_reg_t structure is used to store RITR register layout.
 */
typedef struct sxd_emad_ritr_reg {
    net16_t          en_ipv4_ipv6_mc_type_op_mpls;
    net16_t          router_interface_index;
    net16_t          ipv4_ipv6_fe_urpf;
    net16_t          virtual_router;
    rif_properties_t rif_properties;
    net32_t          reserved1;
    net32_t          reserved2;
    uint8_t          ttl_threshold;
    uint8_t          reserved3;
    net16_t          mtu;
    net32_t          ingress_counter_set;
    net32_t          egress_counter_set;
} PACK_SUFFIX sxd_emad_ritr_reg_t;

/**
 * The structs bellow are implemented in the RIGR, one of them will be in use depending on the type field
 */

typedef struct eth_only_rif_list {
    net32_t rif_list[128];
} PACK_SUFFIX eth_only_rif_list_t;

typedef struct eth_pkey_adj_list {
    net16_t rif_table;
    net16_t adjacency_index;
} PACK_SUFFIX eth_pkey_adj_list_t;

typedef struct eth_pkey_rif_list {
    uint8_t             reserved1[3];
    uint8_t             size;
    eth_pkey_adj_list_t adj_list[127];
} PACK_SUFFIX eth_pkey_rif_list_t;

typedef union rif_list {
    eth_only_rif_list_t eth_only_rif_list;
    eth_pkey_rif_list_t eth_pkey_rif_list;
    net32_t             raw[128];
} PACK_SUFFIX rif_list_t;


/**
 * sxd_emad_rigr_reg_t structure is used to store RIGR register layout.
 */
typedef struct sxd_emad_rigr_reg {
    uint8_t    type_op;
    uint8_t    en;
    net16_t    offset;
    rif_list_t rif_list;
} PACK_SUFFIX sxd_emad_rigr_reg_t;

typedef struct sxd_emad_rigr_v2_erif_list_entry {
    uint8_t valid;
    uint8_t reserved;
    net16_t erif;
} PACK_SUFFIX sxd_emad_rigr_v2_erif_list_entry_t;

typedef struct sxd_emad_rigr_v2_erif_list {
    uint8_t                            vrmid;
    uint8_t                            reserved;
    net16_t                            rmid_index;
    sxd_emad_rigr_v2_erif_list_entry_t erif_list[32];
} PACK_SUFFIX sxd_emad_rigr_v2_erif_list_t;

typedef struct sxd_emad_rigr_v2_bit_vector {
    uint8_t vrmid;
    uint8_t reserved;
    net16_t rmid_index;
    uint8_t reserved2[3];
    uint8_t offset;
    net64_t erif_bit_vector;
} PACK_SUFFIX sxd_emad_rigr_v2_bit_vector_t;

typedef struct sxd_emad_rigr_v2_mpls_encap {
    net32_t nhlfe_ptr;
    uint8_t reserved[2];
    net16_t ecmp_size;
    uint8_t reserved2[2];
    net16_t egress_router_interface;
} PACK_SUFFIX sxd_emad_rigr_v2_mpls_encap_t;

typedef struct sxd_emad_rigr_v2_nve_decap {
    net16_t reserved;
    net16_t uerif;
} PACK_SUFFIX sxd_emad_rigr_v2_nve_decap_t;

typedef struct sxd_emad_rigr_v2_ipip_encap {
    uint8_t reserved;
    uint8_t ipip_type;
    uint8_t reserved2[2];
    net32_t reserved3;
    net32_t ipv4_udip;
    net32_t ipv6_ptr;
    uint8_t reserved4[2];
    net16_t egress_router_interface;
} PACK_SUFFIX sxd_emad_rigr_v2_ipip_encap_t;

typedef union sxd_emad_erif_list {
    sxd_emad_rigr_v2_erif_list_t  erif_list;
    sxd_emad_rigr_v2_bit_vector_t bit_vector;
    sxd_emad_rigr_v2_mpls_encap_t mpls_encap;
    sxd_emad_rigr_v2_nve_decap_t  nve_decap;
    sxd_emad_rigr_v2_ipip_encap_t ipip_encap;
} PACK_SUFFIX sxd_emad_erif_list_t;

/**
 * sxd_emad_rigr_v2_reg_t structure is used to store RIGRv2 register layout.
 */
typedef struct sxd_emad_rigr_v2_reg {
    uint8_t              reserved;
    uint8_t              list_type;
    uint8_t              reserved2[2];
    net32_t              rigr_index;
    net32_t              vnext_next_rigr_index;
    net32_t              reserved3[5];
    sxd_emad_erif_list_t erif_list;
} PACK_SUFFIX sxd_emad_rigr_v2_reg_t;

/**
 * sxd_emad_rtar_reg_t structure is used to store RTAR register layout.
 */
typedef struct sxd_emad_rtar_reg {
    uint8_t op;
    uint8_t reserved1[2];
    uint8_t key_type;
    net16_t reserved2;
    net16_t region_size;
    net32_t reserved3[6];
} PACK_SUFFIX sxd_emad_rtar_reg_t;

/**
 * sxd_emad_recr_reg_t structure is used to store RECR register layout.
 */
typedef struct sxd_emad_recr_reg {
    uint8_t reserved1[2];
    uint8_t sh;
    uint8_t type;
    net32_t ecmp_hash;
    net32_t seed;
    net32_t reserved2;
} PACK_SUFFIX sxd_emad_recr_reg_t;

/**
 * sxd_emad_recr_v2_reg_t structure is used to store RECRv2 register layout.
 */
typedef struct sxd_emad_recr_v2_reg {
    uint8_t pp;
    uint8_t local_port;
    uint8_t sh;
    uint8_t type;
    net32_t reserved;
    net32_t seed;
    net32_t general_fields;
    net16_t reserved2;
    net16_t outer_header_enables;
    net32_t outer_header_field_enables[5];
    uint8_t reserved3[6];
    net16_t inner_header_enables;
    net64_t inner_header_field_enables;
} PACK_SUFFIX sxd_emad_recr_v2_reg_t;

/**
 * sxd_emad_ruft_reg_t structure is used to store RUFT register layout.
 */
typedef struct sxd_emad_ruft_reg {
    uint8_t v_type;
    uint8_t op_a;
    net16_t offset;
    net16_t virtual_router;
    uint8_t reserved1[10];
    net32_t dip[4];
    net32_t dip_mask[4];
    net32_t reserved2[9];
    net32_t ecmp_hash;
    net32_t ecmp_hash_mask;
    net32_t reserved3;
    uint8_t trap;
    uint8_t trap_group;
    net16_t trap_id;
    uint8_t m_mirror_dst;
    uint8_t prio_qos;
    uint8_t reserved4[10];
    net16_t reserved5;
    net16_t reserved_rif;
    uint8_t ecmp_size;
    uint8_t table;
    net16_t adjacency_index;
} PACK_SUFFIX sxd_emad_ruft_reg_t;

/**
 * sxd_emad_ruht_reg_t structure is used to store RUHT register layout.
 */
typedef struct sxd_emad_ruht_reg {
    uint8_t  v_type;
    uint8_t  op_a;
    uint16_t offset;
    uint8_t  reserved1;
    uint8_t  virtual_router;
    uint8_t  reserved2[10];
    net32_t  dip[4];
    net32_t  reserved3[13];
    net32_t  ecmp_hash;
    net32_t  ecmp_hash_mask;
    net32_t  reserved4;
    uint8_t  trap;
    uint8_t  trap_group;
    net16_t  trap_id;
    uint8_t  m_mirror_dst;
    uint8_t  prio_qos;
    uint8_t  reserved5[10];
    net16_t  reserved6;
    net16_t  reserved_rif;
    uint8_t  reserved7;
    uint8_t  table;
    net16_t  adjacency_index;
} PACK_SUFFIX sxd_emad_ruht_reg_t;

/**
 * sxd_emad_rauht_reg_t structure is used to store RAUHT register layout.
 */
typedef struct sxd_emad_rauht_reg {
    uint8_t type;
    uint8_t op_a;
    net16_t rif;
    net32_t reserved1[3];
    net32_t dip[4];
    net32_t reserved2[16];
    uint8_t trap_action;
    uint8_t reserved3[2];
    uint8_t trap_id;
    net32_t reserved4;
    net32_t counter_set;
    net16_t reserved5;
    uint8_t mac_addr[6];
} PACK_SUFFIX sxd_emad_rauht_reg_t;

typedef struct rauhtd_ipv4_dump_record {
    uint8_t num_entries_type;
    uint8_t a0;
    net16_t rif0;
    net32_t dip0;
    uint8_t reserved1;
    uint8_t a1;
    net16_t rif1;
    net32_t dip1;
    uint8_t reserved2;
    uint8_t a2;
    net16_t rif2;
    net32_t dip2;
    uint8_t reserved3;
    uint8_t a3;
    net16_t rif3;
    net32_t dip3;
} PACK_SUFFIX rauhtd_ipv4_dump_record_t;

typedef struct rauhtd_ipv6_dump_record {
    uint8_t type;
    uint8_t a;
    net16_t rif;
    net32_t reserved1[3];
    net32_t dip[4];
} PACK_SUFFIX rauhtd_ipv6_dump_record_t;

typedef union rauhtd_dump_record {
    rauhtd_ipv4_dump_record_t ipv4_dump_record;
    rauhtd_ipv6_dump_record_t ipv6_dump_record;
    net32_t                   raw_reserved1[8];
} PACK_SUFFIX rauhtd_dump_record_t;

/**
 * sxd_emad_rauhtd_reg_t structure is used to store RAUHTD register layout.
 */
typedef struct sxd_emad_rauhtd_reg {
    uint8_t              reserved1[3];
    uint8_t              filter_fields;
    uint8_t              op;
    uint8_t              reserved2[2];
    uint8_t              num_rec;
    uint8_t              reserved3;
    uint8_t              entry_a;
    uint8_t              reserved4;
    uint8_t              entry_type;
    net16_t              reserved5;
    net16_t              entry_rif;
    net32_t              reserved6[4];
    rauhtd_dump_record_t dump_record[SXD_RAUHTD_MAX_REC_NUM];
} PACK_SUFFIX sxd_emad_rauhtd_reg_t;
/**
 * sxd_emad_rmft_reg_t structure is used to store RMFT register layout.
 */
typedef struct sxd_emad_rmft_reg {
    uint8_t v_type;
    uint8_t op_a;
    net16_t offset;
    uint8_t reserved2;
    uint8_t virtual_router;
    uint8_t reserved3[10];
    net32_t dip[4];
    net32_t dip_mask[4];
    net32_t sip[4];
    net32_t sip_mask[4];
    net32_t reserved4;
    net32_t ecmp_hash;
    net32_t ecmp_hash_mask;
    net32_t reserved5;
    uint8_t trap;
    uint8_t trap_group;
    net16_t trap_id;
    uint8_t m_mirror_dst;
    uint8_t prio_qos;
    uint8_t ttl_cmd;
    uint8_t ttl_value;
    uint8_t rpf_assert;
    uint8_t reserved6;
    net16_t expected_ingress_rif;
    net32_t reserved7;
} PACK_SUFFIX sxd_emad_rmft_reg_t;

/**
 * sxd_emad_rmft_v2_reg_t structure is used to store RMFTv2 register layout.
 */
typedef struct sxd_emad_rmft_v2_reg {
    uint8_t                        v_type;
    uint8_t                        op_a;
    net16_t                        offset;
    uint8_t                        reserved[2];
    net16_t                        virtual_router;
    uint8_t                        irif_mask;
    uint8_t                        reserved2;
    net16_t                        irif;
    net32_t                        reserved3;
    net32_t                        dip[4];
    net32_t                        dip_mask[4];
    net32_t                        sip[4];
    net32_t                        sip_mask[4];
    net32_t                        reserved4[12];
    sxd_emad_flex_action_set_reg_t flexible_action_set;
} PACK_SUFFIX sxd_emad_rmft_v2_reg_t;


/**
 * sxd_emad_rmftad_reg_t structure is used to store RMFTAD
 * register layout.
 */
typedef struct sxd_emad_rmftad_reg {
    char reg[MLXSW_RMFTAD_LEN];
} PACK_SUFFIX sxd_emad_rmftad_reg_t;

/**
 * sxd_emad_ptcead_reg_t structure is used to store PTCEAD
 * register layout.
 */
typedef struct sxd_emad_ptcead_reg {
    char reg[MLXSW_PTCEAD_LEN];
} PACK_SUFFIX sxd_emad_ptcead_reg_t;

/**
 * The structs bellow are implemented in the RATR, one of them will be in use depending on the type field
 */

typedef struct eth_adj_parameters {
    net16_t reserved1;
    uint8_t destination_mac[6];
} eth_adj_parameters_t;

typedef struct pkey_uni_without_grh_parameters {
    uint8_t reserved1;
    uint8_t sl;
    net16_t dlid;
    net32_t dqpn;
    uint8_t reserved2[3];
    uint8_t my_lid;
} pkey_uni_without_grh_parameters_t;

typedef struct pkey_uni_with_grh_parameters {
    uint8_t my_lid;
    uint8_t sl;
    net16_t dlid;
    net32_t dqpn;
    uint8_t dgid[16];
} pkey_uni_with_grh_parameters_t;

typedef struct pkey_multi_parameters {
    uint8_t reserved1;
    uint8_t sl;
    net16_t dlid;
    net16_t reserved2[3];
    uint8_t reserved;
    uint8_t tclass;
} pkey_multi_parameters_t;

typedef struct mpls_parameters {
    uint32_t nhlfe_ptr;
    net16_t  reserved;
    net16_t  ecmp_size;
    net16_t  underlay_router_interface;
} mpls_parameters_t;

typedef struct l3_tunnel_encap_parameters {
    net16_t  udip_type;
    net16_t  reserved;
    net32_t  reserved2;
    uint32_t ipv4_udip;
    uint32_t ipv6_ptr;
} l3_tunnel_encap_parameters_t;

typedef union adj_parameters {
    eth_adj_parameters_t              eth_adj_parameters;
    pkey_uni_without_grh_parameters_t pkey_uni_without_grh_parameters;
    pkey_uni_with_grh_parameters_t    pkey_uni_with_grh_parameters;
    pkey_multi_parameters_t           pkey_multi_parameters;
    mpls_parameters_t                 mpls_parameters;
    l3_tunnel_encap_parameters_t      l3_tunnel_encap_parameters;
    net32_t                           raw[6];
} adj_parameters_t;

/**
 * sxd_emad_ratr_reg_t structure is used to store RATR register layout.
 */
typedef struct sxd_emad_ratr_reg {
    uint8_t          op_valid;
    uint8_t          activity;
    net16_t          size;
    uint8_t          type;
    uint8_t          table;
    net16_t          adjacency_index;
    net16_t          reserved2;
    net16_t          egress_rif;
    uint8_t          trap_action;
    uint8_t          adj_idx_msb;
    uint16_t         trap_id;
    adj_parameters_t adj_parameters;
    uint32_t         counter_set;
} PACK_SUFFIX sxd_emad_ratr_reg_t;

/**
 * sxd_emad_ratrad_reg_t structure is used to store RATRAD register layout.
 */
typedef struct sxd_emad_ratrad_reg {
    uint8_t op;
    uint8_t reserved1;
    net16_t ecmp_size;
    net32_t adjacency_index;
    uint8_t reserved2[8];
    net32_t activity_vector[SXD_RATRAD_MAX_REC_NUM / 32];
} PACK_SUFFIX sxd_emad_ratrad_reg_t;

/**
 * sxd_emad_rdpm_reg_t structure is used to store RDPM register layout.
 */
typedef struct sxd_emad_rdpm_reg {
    uint8_t priority_update[64];
} PACK_SUFFIX sxd_emad_rdpm_reg_t;

/**
 * sxd_emad_rica_reg_t structure is used to store RICA register layout.
 */
typedef struct sxd_emad_rrcr_reg {
    uint8_t op;
    uint8_t reserved1;
    net16_t offset;
    net16_t reserved2;
    net16_t size;
    uint8_t reserved3[11];
    uint8_t key_type;
    uint8_t reserved4[14];
    net16_t dest_offset;
} PACK_SUFFIX sxd_emad_rrcr_reg_t;

/**
 * sxd_emad_rica_reg_t structure is used to store RICA register layout.
 */
typedef struct sxd_emad_rica_reg {
    uint8_t op;
    uint8_t reserved1[2];
    uint8_t index;
    net32_t reserved2;
    net32_t ingress_counter_set;
    net32_t egress_counter_set;
} PACK_SUFFIX sxd_emad_rica_reg_t;

/**
 * sxd_emad_ricnt_reg_t structure is used to store RICNT register layout.
 */
typedef struct sxd_emad_ricnt_reg {
    uint8_t clr_add_flush;
    uint8_t gl;
    net16_t reserved;
    net32_t counter_handle;
    net64_t counter_set[SXD_ROUTER_COUNTER_SET_MAX];
} PACK_SUFFIX sxd_emad_ricnt_reg_t;

/**
 * sxd_emad_rtca_reg_t structure is used to store RTCA register layout.
 */
typedef struct sxd_emad_rtca_reg {
    uint8_t swid;
    uint8_t lmc;
    net16_t lid;
    uint8_t gid[16];
    net32_t reserved[2];
} PACK_SUFFIX sxd_emad_rtca_reg_t;

/**
 * sxd_emad_rtps_reg_t structure is used to store RTPS register layout.
 */
typedef struct sxd_emad_rtps_reg {
    uint8_t swid;
    uint8_t reserved[2];
    uint8_t tca_log_phy_pstate;
    uint8_t reserved2[3];
    uint8_t switch_log_phy_pstate;
} PACK_SUFFIX sxd_emad_rtps_reg_t;

typedef struct sxd_emad_rmeir_bit_verctor {
    net32_t bit_vector[8];
} sxd_emad_rmeir_bit_verctor_t;

/**
 * sxd_emad_rmeir_reg_t structure is used to store RMEIR register layout.
 */
typedef struct sxd_emad_rmeir_reg {
    net32_t                      expected_irif_list_index;
    uint8_t                      reserved[3];
    uint8_t                      num_entries;
    net32_t                      reserved2[2];
    sxd_emad_rmeir_bit_verctor_t expected_irif_bit_vector[SXD_RMEIR_ENTRIES_NUM_MAX];
} PACK_SUFFIX sxd_emad_rmeir_reg_t;

/**
 * sxd_emad_rmid_reg_t structure is used to store RMID register layout.
 */
typedef struct sxd_emad_rmid_reg {
    uint8_t reserved[2];
    net16_t rmid_index;
    uint8_t reserved2[2];
    net16_t rmpe_index;
    net32_t reserved3[6];
    net32_t egress_port[8];
} PACK_SUFFIX sxd_emad_rmid_reg_t;

typedef struct sxd_emad_rmpu_entry {
    uint8_t reserved2[2];
    net16_t rmid_index;
} sxd_emad_rmpu_entry_t;

/**
 * sxd_emad_rmpu_reg_t structure is used to store RMPU register layout.
 */
typedef struct sxd_emad_rmpu_reg {
    uint8_t               reserved;
    uint8_t               local_port;
    uint8_t               reserved2[2];
    uint8_t               op;
    uint8_t               size;
    uint8_t               reserved3[2];
    net32_t               reserved4[2];
    sxd_emad_rmpu_entry_t entries[64];
} PACK_SUFFIX sxd_emad_rmpu_reg_t;

/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Function declarations
 ***********************************************/


#include <complib/cl_packoff.h>

#endif /* __SXD_EMAD_ROUTER_REG_H__ */
