/*
 *  Copyright (C) 2010-2019. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */


#ifndef __SX_CHECK_H__
#define __SX_CHECK_H__


/************************************************
 *  Macro definitions
 ***********************************************/

/**
 * Macro is used to test if value doesn't exceed its maximum.
 */
#ifndef     SX_CHECK_MAX
#define SX_CHECK_MAX(val, max) ((max) >= (val))
#endif  /*	SX_CHECK_MAX	*/

/**
 * Macro is used to test if value doesn't exceed its minimum.
 */
#ifndef     SX_CHECK_MIN
#define SX_CHECK_MIN(min, val) ((val) >= (min))
#endif  /*	SX_CHECK_MIN	*/

/**
 * Macro is used to test if value is within a valid range.
 */
#ifndef     SX_CHECK_RANGE
#define SX_CHECK_RANGE(min, val, max) (SX_CHECK_MIN((min), (val)) && SX_CHECK_MAX((val), (max)))
#endif  /*	SX_CHECK_RANGE	*/

/**
 * Macro is used to test if status isn't success.
 */
#ifndef     SX_CHECK_FAIL
#define SX_CHECK_FAIL(STATUS) (SX_STATUS_SUCCESS != (STATUS))
#endif  /*	SX_CHECK_FAIL	*/

/**
 * Macro is used to test if status is success.
 */
#ifndef     SX_CHECK_PASS
#define SX_CHECK_PASS(STATUS) (SX_STATUS_SUCCESS == (STATUS))
#endif  /*	SX_CHECK_PASS	*/

#ifndef SX_CHECK_RC
#define SX_CHECK_RC(STATUS, err_text)            \
    if (SX_CHECK_FAIL(STATUS)) {                 \
        SX_LOG_ERR("Failure - %s.\n", err_text); \
    }
#endif

#define SX_CHECK_ERROR(sx_rc, expression)                 \
    if (SX_CHECK_FAIL(sx_rc = expression)) {              \
        SX_LOG_ERR("Failure - %s.\n", sx_status_str(rc)); \
        return M_UTILS_SX_LOG_EXIT(rc);                   \
    }

#define SX_CHECK_RC_OUT(STATUS, err_text)        \
    if (SX_CHECK_FAIL(STATUS)) {                 \
        SX_LOG_ERR("Failure - %s.\n", err_text); \
        goto out;                                \
    }

#define SX_CHECK_BOOLEAN(val) SX_CHECK_RANGE(0, val, 1)

#endif /* __SX_CHECK_H__ */
