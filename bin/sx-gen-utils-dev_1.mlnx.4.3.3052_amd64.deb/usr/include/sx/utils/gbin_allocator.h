/*
 * Copyright (C) Mellanox Technologies, Ltd. 2015-2020 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __UTILS_GBIN_ALLOCATOR_H__
#define __UTILS_GBIN_ALLOCATOR_H__

#include <complib/cl_types.h>
#include <sx/utils/sx_utils_status.h>
#include "gc.h"

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

#define BIN_ALLOC_VERSION (1)

#define BIN_ALLOC_MAX_TYPES         (8)       /* Must be <= 254 */
#define BIN_ALLOC_MAX_ALLOC_SIZES   (68)
#define BIN_ALLOC_MAX_USERS         (32)
#define BIN_ALLOC_MAX_PHYS_MEMORY   (10)
#define BIN_ALLOC_MAX_PHYS_MEM_NAME (25)

#define GROUP_TYPE_FREE (0)

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

typedef uint32_t ba_logical_id_t;
typedef uint32_t ba_index_t;

typedef void *ba_handle_t;

/**
 * Per-template allocation alignment options
 *   - Default behavior is not to enforce any alignment restrictions
 */
typedef enum ba_alignment {
    ALIGN_NONE_E = 0,
    ALIGN_SIZE_E = 1,
    ALIGN_EVEN_E = 2,

    ALIGN_MAX_E = ALIGN_EVEN_E
} ba_alignment_e;

/**
 * Per-client connection allocation options
 *   - Default behavior is to NOT do any relocation
 */
typedef enum ba_option {
    RELOC_SYNC_E = (1 << 0),
    RELOC_ASYNC_E = (1 << 1),
    RELOC_ASYNC_GC_E = (1 << 2),
    ENABLE_TRACE_E = (1 << 3),

    RELOC_VALID_E = RELOC_SYNC_E | RELOC_ASYNC_E | RELOC_ASYNC_GC_E | ENABLE_TRACE_E
} ba_option_e;


/**
 * ba_group_t
 *   When the bin allocator needs memory it calls the client provided
 * callback to get a group.
 *
 * type      - Client provided non-zero type identifier.
 * grp_index - Zero based index of group given/returned.:w
 *
 */
typedef struct ba_group {
    /* Initialized by client, unmodified by bin allocator */
    uint32_t type;
    uint32_t grp_index;
} ba_group_t;


/**
 * Relocation callback
 *   This callback is called when the bin allocator relocates a block.  It
 * is up to the user provided handler to decide if it needs to do anything
 * based on the logical ID.
 *
 * @param[in] handle - The client handle that owns the lid
 * @param[in] lid  - The logical ID of the counter being relocated
 * @param[in] cntx - Current value of user context associated with this lid
 * @param[in] old_id  - The old PRM counter ID associated with lid
 * @param[in] new_id  - The new relocated PRM counter id
 * @param[in] relocate_cntx  - Current value of relocate context
 *
 * @return SX_UTILS_STATUS_SUCCESS - Operation completed successfully
 * @return SX_UTILS_STATUS_PARAM_ERROR - At least one parameter was invalid
 * @return SX_UTILS_STATUS_ERROR - Callback was unable to update HW
 * @return SX_UTILS_STATUS_PARTIALLY_COMPLETE - Cleanup failed; keep both
 *
 * NOTE:
 *   The callback will never be called while any user holds a lock on the
 * block.  While all the callbacks for a block are being called, the counter
 * linear manager will not grant any user lock for the block so the callback
 * handlers MUST NOT attempt to get the lock.
 */
typedef sx_utils_status_t
(*ba_cb_relocate_t)(ba_handle_t     handle,
                    ba_logical_id_t lid,
                    uint32_t        cntx,
                    ba_index_t      old_id,
                    ba_index_t      new_id,
                    void          * relocate_cntx);


/**
 * Allocate group callback
 *   When the bin allocator needs resource to satisfy a block allocation
 * request or to use for defragmentation, it requests the memory from
 * the client.
 *
 * @param[in] handle - The client handle
 * @param[in] type - The requested type for the new group
 * @param[out] group_p - Location to store a group pointer
 *
 * @return SX_UTILS_STATUS_SUCCESS - Operation completed successfully
 * @return SX_UTILS_STATUS_CMD_UNSUPPORTED - lid not supported by callback
 * @return SX_UTILS_STATUS_PARAM_ERROR - Unsupported type or group_p is NULL
 * @return SX_UTILS_STATUS_NO_RESOURCES - No group available
 */
typedef sx_utils_status_t
(*ba_cb_alloc_group_t)(ba_handle_t        handle,
                       uint32_t           type,
                       const ba_group_t **group_p);

/**
 * Free group callback
 *   When the last allocation in a group is freed, either from an explicit
 * ba_free() call from the client or as a side effect of defragmentation
 * the bin allocator calls this callback with the now empty group.  Once
 * the callback returns, the bin allocator is no longer allowed to reference
 * group.
 *
 * @param[in] handle - The client handle
 * @param[in] group - Pointer to the group that is not empty.
 *
 * @return SX_UTILS_STATUS_SUCCESS - Operation completed successfully
 * @return SX_UTILS_STATUS_CMD_UNSUPPORTED - handle not supported by callback
 * @return SX_UTILS_STATUS_PARAM_ERROR - Invalid or NULL type or group
 */
typedef sx_utils_status_t
(*ba_cb_free_group_t)(ba_handle_t handle, ba_group_t *group);


/**
 * ba_template_t
 *   The bin allocator can subdivide the full register space into a small
 * number of groups.  Each group has a client defined 'type'.  Client
 * allocation requests are by 'type', and any group with the same 'type'
 * can be used to satisfy the request.
 *
 *   Initially groups are unallocated and have no associated type.  When
 * a client allocation request is received for a type, and either no group
 * of that type exists or there is no space in any existing group with that
 * type, an unallocated group is allocated, initialized to the requested
 * type, and used to satisfy the allocation request.
 *
 *   A background defragmentation thread attempts to coalesce multiple
 * sparsely allocated groups and create one (or more) unallocated groups.
 *
 * type        - Client provided non-zero type identifier.  When type=0,
 *               this template is not active.
 * length      - The number of available lines in the group instantiated
 *               using this template.  This value must be <= alignment,
 *               and allocation starts at 0.
 * alloc_sizes - Array of up to BIN_ALLOC_MAX_ALLOC_SIZES non-zero
 *               allocation sizes supported by this type.  Sizes should
 *               be sorted smallest first.  Unused entries at the end of
 *               the array are marked with 0.
 * align       - Allocation alignment restrictions for this type
 * cb_relocate - Relocate logical ID from index_old to index_new
 * cb_alloc    - Provide bin allocator with a new group
 * cb_free     - Release an now empty group
 */
typedef struct ba_template {
    /* Client provided geometry information */
    uint32_t       type;
    uint32_t       length;
    uint16_t       alloc_sizes[BIN_ALLOC_MAX_ALLOC_SIZES];
    ba_alignment_e align;

    /* Callback handlers - NULL if not supported */
    ba_cb_relocate_t    cb_relocate;
    ba_cb_alloc_group_t cb_alloc;
    ba_cb_free_group_t  cb_free;
} ba_template_t;

/**
 * ba_phys_init_t
 *   Init structure used to initialize a physical memory space mapped to a user.
 * If passed NULL, a physical memory space will be created by the bin allocator
 * at the size of the entire memory space. Otherwise, if the name passed doesn't
 * exist yet, the bin allocator will initialize a new memory space at the the
 * requested size. If the name does exist, the bin allocator will map this
 * user to the existing memory space.
 */
typedef struct ba_phys_init {
    char     phys_mem_name[BIN_ALLOC_MAX_PHYS_MEM_NAME];
    uint32_t phys_mem_size;
} ba_phys_init_t;

/**
 * ba_param_t
 *   This structure is used to initialize every connection with the bin
 * allocator.  The structure contains information about the total size
 * and allocation geometry of the managed register array.
 *
 * version    - Client initializes this to BIN_ALLOC_VERSION to potentially
 *              allow for bin_manager upgrades that are that are binary
 *              compatible with older clients.
 * array_size - Number of entries in the total register space being managed
 * group_cnt  - The maximum number of type specific contiguous sub allocation
 *              regions for this register space.
 * alignment  - The alignment for each of the max_group valid suballocation
 *              regions.  Note that (array_size / group_cnt) == alignment.
 *
 * options    - A bitmask of options that can be enabled on a per-client
 *              basis.
 *
 * r_thresh   - Threshold in percent [0..100] of packing efficiency that
 *              triggers relocation in a group.
 * r_count    - The maximum number of blocks to reallocate every time
 *              the background relocation thread dispatches.
 *
 * templates  - Initialized by client to describe allocation geometry for
 *              all supported 'types'.  Up to BIN_ALLOC_MAX_TYPES entries
 *              are in the array.  Active entries first followed by unused
 *              (type=0) entries.
 *
 * phys_init  - Physical memory initialization parameters. Pass a NULL pointer
 *              if this is the only client using this memory space, and the
 *              physical memory space is equal to the virtual memory space.
 *
 * NOTES:
 *   1. It should be the case that max_group * alignment == size.
 */
typedef struct ba_param {
    uint8_t version;

    /* Client register geometry initialization parameters */
    uint16_t group_cnt;          /* Max is MAX_GROUPS */
    uint32_t array_size;
    uint32_t alignment;

    /* Options to control allocation and debug from ba_option_e */
    uint32_t options;

    /*
     * r_thresh in [0..100]:
     *   - max_free = size of largest contiguous block in group
     *   - total_free = total number of free lines in group
     *   - eff = (100 * max_free) / total_free
     *   - if (eff < r_thresh) do_defragmentation(group)
     */
    uint8_t r_thresh;
    uint8_t r_count;

    /* Garbage collector data */
    gc_object_type_t              gc_object_type;
    gc_object_subtype_t           gc_subtype;
    gc_object_type_attributes_t   gc_attr;
    gc_object_post_completion_pfn gc_post_completion_cb;

    /* One entry per-type */
    ba_template_t templates[BIN_ALLOC_MAX_TYPES];

    /* Physical memory parameters */
    ba_phys_init_t *phys_init;

    /* Total size not used when equal 0.
     * Must be larger then array_size.
     * when used will make sure BA will not override valid indices.*/
    uint32_t total_size;
} ba_param_t;

typedef struct ba_post_completion_context {
    uint32_t            start_index;
    uint32_t            obj_size;
    uint32_t            table_size;
    gc_object_type_t    gc_object_type;
    gc_object_subtype_t gc_subtype;
} ba_post_completion_context_t;
/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Function declarations
 ***********************************************/


/**
 * Initialize Bin Allocator service
 *
 * @return SX_UTILS_STATUS_SUCCESS - Subsystem initialized
 * @return SX_UTILS_STATUS_ALREADY_INITIALIZED - Subsystem already initialized
 * @return SX_UTILS_STATUS_NO_RESOURCES - Not enough memory to initialize
 */
sx_utils_status_t ba_init(void);

/**
 * Deinitialize Bin Allocator service
 *
 * @return SX_UTILS_STATUS_SUCCESS - Subsystem shutdown ok
 * @return SX_UTILS_STATUS_NOT_INITIALIZED - Not initialized
 * @return SX_UTILS_STATUS_RESOURCE_IN_USE - At least one client still active
 * @return SX_UTILS_STATUS_ERROR - Something prevented shutdown
 */
sx_utils_status_t ba_deinit(void);

/**
 * Initialize a bin_allocator client
 *
 * @param handle[out] - Pointer to location to return handle
 * @param param[in] - Pointer to initialization parameters
 *
 * @return SX_UTILS_STATUS_SUCCESS - Client initialized
 * @return SX_UTILS_STATUS_NOT_INITIALIZED - Not initialized
 * @return SX_UTILS_STATUS_PARAM_NULL - Handle pointer is NULL
 * @return SX_UTILS_STATUS_PARAM_EXCEEDS_RANGE - Version not supported
 * @return SX_UTILS_STATUS_PARAM_ERROR - Invalid parameter in init params
 * @return SX_UTILS_STATUS_NO_RESOURCES - Not enough memory to initialize
 */
sx_utils_status_t ba_client_init(ba_handle_t *handle_p, ba_param_t *param);


/**
 * Free all allocated resources.
 *
 * @param handle - Pointer to active set of initialization and runtime data
 *
 * @return SX_UTILS_STATUS_SUCCESS - Client connection closed
 * @return SX_UTILS_STATUS_NOT_INITIALIZED - Handle not active
 * @return SX_UTILS_STATUS_PARAM_NULL - Handle pointer is NULL
 * @return SX_UTILS_STATUS_RESOURCE_IN_USE - At least one register allocated
 */
sx_utils_status_t ba_client_deinit(ba_handle_t handle);


/**
 * Allocate a set of contiguous table entries
 *
 * @param[in] handle - Pointer to initialized client handle
 * @param[in] type   - Type of entry to allocate
 * @param[in] size   - Number of contiguous entries needed
 * @param[in] cntx   - Initial value of user context associated with this lid
 * @param[out] group_p - Pointer to where to store logical ID for allocation
 *
 * @return SX_UTILS_STATUS_SUCCESS - Allocation successful
 * @return SX_UTILS_STATUS_NOT_INITIALIZED - Client not initialized
 * @return SX_UTILS_STATUS_PARAM_NULL - handle or lid_p pointer is NULL
 * @return SX_UTILS_STATUS_PARAM_ERROR - type not supported
 * @return SX_UTILS_STATUS_PARAM_EXCEEDS_RANGE - Size not supported by type
 * @return SX_UTILS_STATUS_ERROR - Internal error
 * @return SX_UTILS_STATUS_NO_RESOURCES - No space available for allocation
 */
sx_utils_status_t ba_allocate(ba_handle_t      handle,
                              uint32_t         type,
                              uint32_t         size,
                              uint32_t         cntx,
                              ba_logical_id_t *lid_p);


/**
 * Free a previously allocated set of contiguous table entries
 *
 * @param[in] handle - Pointer to initialized client handle
 * @param[in] lid    - The logical ID to free
 *
 * @return SX_UTILS_STATUS_SUCCESS - Deallocation successful
 * @return SX_UTILS_STATUS_NOT_INITIALIZED - Client not initialized
 * @return SX_UTILS_STATUS_PARAM_NULL - handle is NULL
 * @return SX_UTILS_STATUS_PARAM_ERROR - handle or lid not valid
 * @return SX_UTILS_STATUS_ERROR - Internal error
 * @return SX_UTILS_STATUS_RESOURCE_IN_USE - lid is locked
 * @return SX_UTILS_STATUS_DB_NOT_EMPTY - The reference count was > 1
 */
sx_utils_status_t ba_free(ba_handle_t handle, ba_logical_id_t lid);

/**
 * Free a previously allocated set of contiguous table entries asynchronous
 *
 * @param[in] handle - Pointer to initialized client handle
 * @param[in] context    - Relocate context
 *
 * @return SX_UTILS_STATUS_SUCCESS - Deallocation successful
 * @return SX_UTILS_STATUS_NOT_INITIALIZED - Client not initialized
 * @return SX_UTILS_STATUS_PARAM_NULL - handle is NULL
 * @return SX_UTILS_STATUS_PARAM_ERROR - handle or lid not valid
 * @return SX_UTILS_STATUS_ERROR - Internal error
 * @return SX_UTILS_STATUS_RESOURCE_IN_USE - lid is locked
 * @return SX_UTILS_STATUS_DB_NOT_EMPTY - The reference count was > 1
 */
sx_utils_status_t ba_free_async(ba_handle_t handle, const void *context);

/**
 * Increment reference count on previously allocated set of table entries
 *
 * @param[in] handle - Pointer to initialized client handle
 * @param[in] lid    - The logical ID to increment reference count on
 *
 * @return SX_UTILS_STATUS_SUCCESS - Increment successful
 * @return SX_UTILS_STATUS_NOT_INITIALIZED - Client not initialized
 * @return SX_UTILS_STATUS_PARAM_NULL - handle is NULL
 * @return SX_UTILS_STATUS_PARAM_ERROR - handle or lid not valid
 * @return SX_UTILS_STATUS_PARAM_EXCEEDS_RANGE - Reference count would
 *                                               exceed max count.
 * @return SX_UTILS_STATUS_ERROR - Internal error
 */
sx_utils_status_t ba_ref_inc(ba_handle_t handle, ba_logical_id_t lid);


/**
 * Decrement reference count on previously allocated set of table entries
 *
 * @param[in] handle - Pointer to initialized client handle
 * @param[in] lid    - The logical ID to increment reference count on
 *
 * @return SX_UTILS_STATUS_SUCCESS - Increment successful
 * @return SX_UTILS_STATUS_NOT_INITIALIZED - Client not initialized
 * @return SX_UTILS_STATUS_PARAM_NULL - handle is NULL
 * @return SX_UTILS_STATUS_PARAM_ERROR - handle or lid not valid
 * @return SX_UTILS_STATUS_RESOURCE_IN_USE - Reference count was 1
 * @return SX_UTILS_STATUS_ERROR - Internal error
 */
sx_utils_status_t ba_ref_dec(ba_handle_t handle, ba_logical_id_t lid);

/**
 * Lock a set of table entries
 *
 * @param[in] handle   - Pointer to initialized client handle
 * @param[in] lid      - The logical ID to increment reference count on
 * @param[out] index_p - Pointer to where to store current index for LID
 * @param[out] cntx_p  - Pointer to were to store client provided context
 *
 * @return SX_UTILS_STATUS_SUCCESS - Lock successful
 * @return SX_UTILS_STATUS_NOT_INITIALIZED - Client not initialized
 * @return SX_UTILS_STATUS_PARAM_NULL - handle or index_p is NULL
 * @return SX_UTILS_STATUS_PARAM_ERROR - handle or lid not valid
 * @return SX_UTILS_STATUS_RESOURCE_IN_USE - logical ID already locked
 * @return SX_UTILS_STATUS_ERROR - Internal error
 */
sx_utils_status_t ba_lock(ba_handle_t     handle,
                          ba_logical_id_t lid,
                          ba_index_t     *index_p,
                          uint32_t       *cntx_p);


/**
 * Unlock a set of table entries
 *
 * @param[in] handle  - Pointer to initialized client handle
 * @param[in] lid     - The logical ID to increment reference count on
 *
 * @return SX_UTILS_STATUS_SUCCESS - Unlock successful
 * @return SX_UTILS_STATUS_NOT_INITIALIZED - Client not initialized
 * @return SX_UTILS_STATUS_PARAM_NULL - handle or lid is NULL
 * @return SX_UTILS_STATUS_PARAM_ERROR - handle or lid not valid
 * @return SX_UTILS_STATUS_NO_RESOURCES - logical ID not locked
 * @return SX_UTILS_STATUS_ERROR - Internal error
 */
sx_utils_status_t ba_unlock(ba_handle_t handle, ba_logical_id_t lid);

/**
 * Lock operation on handle to protect multi thread access
 *
 * @param[in] handle   - Pointer to initialized client handle
 *
 * @return SX_UTILS_STATUS_SUCCESS - Lock successful
 * @return SX_UTILS_STATUS_NOT_INITIALIZED - Client not initialized
 * @return SX_UTILS_STATUS_PARAM_NULL - handle or index_p is NULL
 * @return SX_UTILS_STATUS_PARAM_ERROR - handle or lid not valid
 * @return SX_UTILS_STATUS_RESOURCE_IN_USE - logical ID already locked
 * @return SX_UTILS_STATUS_ERROR - Internal error
 */
sx_utils_status_t ba_thread_lock(ba_handle_t handle);

/**
 * UnLock operation on handle to protect multi thread access
 *
 * @param[in] handle   - Pointer to initialized client handle
 *
 * @return SX_UTILS_STATUS_SUCCESS - Lock successful
 * @return SX_UTILS_STATUS_NOT_INITIALIZED - Client not initialized
 * @return SX_UTILS_STATUS_PARAM_NULL - handle or index_p is NULL
 * @return SX_UTILS_STATUS_PARAM_ERROR - handle or lid not valid
 * @return SX_UTILS_STATUS_RESOURCE_IN_USE - logical ID already locked
 * @return SX_UTILS_STATUS_ERROR - Internal error
 */
sx_utils_status_t ba_thread_unlock(ba_handle_t handle);

/**
 * Associate a client context pointer with a logical ID
 *
 * @param[in] handle - Pointer to initialized client handle
 * @param[in] lid    - The logical ID to to save context data against
 * @param[in] cntx   - Client provided context
 *
 * @return SX_UTILS_STATUS_SUCCESS - Client context handle saved
 * @return SX_UTILS_STATUS_NOT_INITIALIZED - Client not initialized
 * @return SX_UTILS_STATUS_PARAM_NULL - handle is NULL
 * @return SX_UTILS_STATUS_PARAM_ERROR - handle or lid not valid
 */
sx_utils_status_t ba_client_cntx_set(ba_handle_t handle, ba_logical_id_t lid,
                                     uint32_t cntx);


/**
 * Retrieve client context pointer and reference count
 *
 * @param[in] handle  - Pointer to initialized client handle
 * @param[in] lid     - The logical ID to read the context data from
 * @param[out] cntx_p - Pointer to a location to save  context (or NULL)
 * @param[out] ref_p  - Pointer to location to save reference count (or NULL)
 *
 * @return SX_UTILS_STATUS_SUCCESS - Request succeeded
 * @return SX_UTILS_STATUS_NOT_INITIALIZED - Client not initialized
 * @return SX_UTILS_STATUS_PARAM_NULL - handle is NULL
 * @return SX_UTILS_STATUS_PARAM_ERROR - handle or lid not valid
 */
sx_utils_status_t ba_client_cntx_get(ba_handle_t     handle,
                                     ba_logical_id_t lid,
                                     uint32_t       *cntx_p,
                                     uint32_t       *ref_p);

/**
 * Swap Bin Allocator meta-data between two LIDs
 *   In support of managing linked lists of blocks, we need to be able to
 * insert or remove a block from the front of the linked list.  Multiple
 * users of a linked list add references to only the first block, so when
 * it moves the reference counts need to move.
 *
 * @param[in] handle  - Pointer to initialized client handle
 * @param[in] lid1    - One logical ID
 * @param[in] lid2    - The other logical ID
 *
 * @return SX_UTILS_STATUS_SUCCESS - Request succeeded
 * @return SX_UTILS_STATUS_NOT_INITIALIZED - Client not initialized
 * @return SX_UTILS_STATUS_PARAM_NULL - handle is NULL
 * @return SX_UTILS_STATUS_PARAM_ERROR - handle or lid not valid
 */
sx_utils_status_t ba_swap_metadata(ba_handle_t     handle,
                                   ba_logical_id_t lid1,
                                   ba_logical_id_t lid2);


/**
 * Modify reference count on previously allocated set of table entries
 *
 * @param[in] handle - Pointer to initialized client handle
 * @param[in] lid    - The logical ID to modify count on
 * @param[in] val    - The increment/decrement value
 *
 * @return SX_UTILS_STATUS_SUCCESS - Increment successful
 * @return SX_UTILS_STATUS_NOT_INITIALIZED - Client not initialized
 * @return SX_UTILS_STATUS_PARAM_NULL - handle is NULL
 * @return SX_UTILS_STATUS_PARAM_ERROR - handle or lid not valid
 * @return SX_UTILS_STATUS_PARAM_EXCEEDS_RANGE - Reference count would
 *                                               exceed max count.
 * @return SX_UTILS_STATUS_ERROR - Internal error
 */
sx_utils_status_t ba_ref_modify(ba_handle_t     handle,
                                ba_logical_id_t lid,
                                int32_t         val);

/**
 * Timer function used to drive async relocation
 */
void ba_timer_handler(void);


/**
 * Output a dump
 *
 * @param[in] stream - File stream to output dump to
 *
 * @return SX_UTILS_STATUS_SUCCESS - successful
 * @return SX_UTILS_STATUS_NOT_INITIALIZED - Client not initialized
 * @return SX_UTILS_STATUS_SDK_ERROR - Internal error
 */
sx_utils_status_t ba_dump(FILE *stream);

#ifdef UNITTESTS
/**
 * Execute code coverage tests
 *   This function runs a set of tests to provide code coverage on various
 * internal functions.
 *
 * @param test[in] - 0 run all tests, 1-n run specific test
 * @param trace_file[in] - Optional pointer to formatted trace output file
 */
sx_utils_status_t ba_test_internal(int test, FILE *trace_file);

#endif /* UNITTESTS */
#endif /* __UTILS_GBIN_ALLOCATOR_H__ */
