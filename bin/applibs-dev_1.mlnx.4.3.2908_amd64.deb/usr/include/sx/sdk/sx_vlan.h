/*
 *  Copyright (C) 2010-2019. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */

#ifndef __SX_VLAN_H__
#define __SX_VLAN_H__

#include <sx/sxd/sxd_vlan.h>

#include <sx/sdk/sx_port_id.h>
#include <sx/sdk/sx_check.h>
#include <sx/sdk/sx_swid.h>

/************************************************
 *  Type definitions
 ***********************************************/

/**
 * VLAN ID.
 */
typedef sxd_vid_t sx_vid_t;
typedef sx_vid_t sx_vlan_id_t;
/**
 * Default VLAN ID.
 */

/**
 * VLAN ID maximum/minimum values.
 */
#define SX_VLAN_DEFAULT_VID 1

/**
 * sx_untagged_member_state_t ENUM is used to define the egress transmission un/tagged frames.
 */
typedef enum {
    SX_TAGGED_MEMBER, /**< Egress transmission TAGGED */
    SX_UNTAGGED_MEMBER, /**< Egress transmission UNTAGGED */
} sx_untagged_member_state_t;

/**
 * sx_untagged_prio_state_t ENUM is used to define the egress
 * transmission state of a port, priority-tagged or untagged
 * frames.
 */
typedef enum {
    SX_UNTAGGED_STATE = 1, /**< Egress transmission UNTAGGED */
    SX_PRIO_TAGGED_STATE = 2, /**< Egress transmission PRIORITY-TAGGED */
    SX_MAX_UNTAGGED_PRIO_STATE,
} sx_untagged_prio_state_t;

/**
 * sx_port_vlan_pass_state_e ENUM is used to define
 * VLAN membership filtering state, INGRESS/EGRESS/BOTH.
 */
typedef enum sx_port_vlan_pass_state {
    SX_PORT_VLAN_BOTH_PASS_E,
    SX_PORT_VLAN_INGRESS_PASS_E,
    SX_PORT_VLAN_EGRESS_PASS_E
} sx_port_vlan_pass_state_e;

#define SX_VLAN_PASS_STATE_CHECK_RANGE(val)  \
    SX_CHECK_RANGE(SX_PORT_VLAN_BOTH_PASS_E, \
                   (int)val,                 \
                   SX_PORT_VLAN_EGRESS_PASS_E)
/**
 * sx_vlan_ports_t structure is used to define filter type of log_port.
 */
typedef struct sx_vlan_ports {
    sx_port_log_id_t           log_port;
    sx_untagged_member_state_t is_untagged;
    sx_port_vlan_pass_state_e  pass_state;
} sx_vlan_ports_t;

/**
 * sx_port_vlans_t structure is used to define tagged membership
 * type .
 */
typedef struct sx_port_vlans {
    sx_vlan_id_t               vid;
    sx_untagged_member_state_t is_untagged;
    sx_port_vlan_pass_state_e  pass_state;
} sx_port_vlans_t;

/**
 * sx_vlan_ports_member_t structure is used to define filter type of log_port.
 */
typedef struct sx_vlan_ports_member {
    sx_port_log_id_t          log_port;
    boolean_t                 is_untagged;
    boolean_t                 is_memberof;
    sx_port_vlan_pass_state_e pass_state;
} sx_vlan_ports_member_t;

/**
 * sx_vlan_frame_types_t structure is used to define allowed packets.
 */
typedef struct sx_vlan_frame_types {
    boolean_t allow_untagged;
    boolean_t allow_priotagged;
    boolean_t allow_tagged;
} sx_vlan_frame_types_t;

/**
 * sx_ingr_filter_mode_t structure is used to store Port Ingress
 * filtering mode.
 */

typedef enum sx_ingr_filter_mode {
    SX_INGR_FILTER_DISABLE = 0, SX_INGR_FILTER_ENABLE
} sx_ingr_filter_mode_t;

typedef struct sx_vlan_info {
    sx_vlan_id_t id;
} sx_vlan_info_t;

typedef enum {
    SX_VLAN_UNREG_MC_FLOOD = 1,
    SX_VLAN_UNREG_MC_PRUNE = 2,
    SX_VLAN_UNREG_FLOOD_MODE_MIN = SX_VLAN_UNREG_MC_FLOOD,
    SX_VLAN_UNREG_FLOOD_MODE_MAX = SX_VLAN_UNREG_MC_PRUNE,
} sx_vlan_unreg_flood_mode_t;

/**
 * sx_vlan_qinq_prio_tag_mode_t is used to define whether priority-based VLAN tag
 * is overwritten or pushed during Q-in-Q ingress processing
 */
#define FOREACH_SX_VLAN_QINQ_PRIO_TAG_MODE(F)                               \
    F(SX_VLAN_QINQ_PRIO_TAG_MODE_PUSH = 0,  "Push")                         \
    F(SX_VLAN_QINQ_PRIO_TAG_MODE_OVERWRITE, "Overwrite")                    \
    F(SX_VLAN_QINQ_PRIO_TAG_MODE_MIN = SX_VLAN_QINQ_PRIO_TAG_MODE_PUSH, "") \
    F(SX_VLAN_QINQ_PRIO_TAG_MODE_MAX = SX_VLAN_QINQ_PRIO_TAG_MODE_OVERWRITE, "")

typedef enum SX_VLAN_QINQ_PRIO_TAG_MODE {
    FOREACH_SX_VLAN_QINQ_PRIO_TAG_MODE(SX_GENERATE_ENUM)
} sx_vlan_qinq_prio_tag_mode_t;

#define SX_VLAN_QINQ_PRIO_TAG_MODE_CHECK_RANGE(param) \
    SX_CHECK_RANGE(SX_VLAN_QINQ_PRIO_TAG_MODE_MIN,    \
                   (int)param,                        \
                   SX_VLAN_QINQ_PRIO_TAG_MODE_MAX)

/**
 * sx_vlan_params_t structure is used to store initialization parameters of
 * VLAN Library.
 */
typedef struct sx_vlan_params {
    sx_vid_t                     def_vid;
    uint8_t                      max_swid_id;
    uint32_t                     num_of_active_vlans; /** Supported devices: Spectrum */
    sx_vlan_qinq_prio_tag_mode_t qinq_prio_tag_mode;   /**<Q-in-Q priority-tagged traffic mode. Supported devices: Spectrum */
    uint32_t                     flow_counter_max_number; /** Max number of flow counters */
} sx_vlan_params_t;

/**
 * sx_vport_vlans_t structure is used to store the VLAN ID and egress mode
 * (Tagged/Untagged) of a vPort
 */
typedef struct sx_vport_vlans {
    sx_vlan_id_t               vid;
    sx_untagged_member_state_t egress_mode;
} sx_vport_vlans_t;

/**
 * sx_qinq_mode_t ENUM is used to define the vlan stacking mode of the port
 */
typedef enum sx_qinq_mode {
    SX_QINQ_MODE_802_1Q = 0,
    SX_QINQ_MODE_QINQ = 1,
    SX_QINQ_MODE_802_1AD = 2,
    SX_QINQ_MODE_MIN = SX_QINQ_MODE_802_1Q,
    SX_QINQ_MODE_MAX = SX_QINQ_MODE_802_1AD
} sx_qinq_mode_t;

#define SX_QINQ_MODE_CHECK_RANGE(val) SX_CHECK_MAX(val, SX_QINQ_MODE_MAX)

#define SX_QINQ_MODE_DEFAULT SX_QINQ_MODE_802_1Q

/**
 * sx_qinq_outer_prio_mode_t is used to define which priority
 * should be taken for the outer tag
 */
typedef enum sx_qinq_outer_prio_mode {
    SX_QINQ_OUTER_PRIO_MODE_PORT = 0,
    SX_QINQ_OUTER_PRIO_MODE_CVLAN = 1,
    SX_QINQ_OUTER_PRIO_MODE_MIN = SX_QINQ_OUTER_PRIO_MODE_PORT,
    SX_QINQ_OUTER_PRIO_MODE_MAX = SX_QINQ_OUTER_PRIO_MODE_CVLAN
} sx_qinq_outer_prio_mode_t;

#define SX_QINQ_OUTER_PRIO_MODE_CHECK_RANGE(val) SX_CHECK_MAX(val, SX_QINQ_OUTER_PRIO_MODE_MAX)

#define SX_QINQ_OUTER_PRIO_MODE_DEFAULT SX_QINQ_OUTER_PRIO_MODE_PORT

#define SX_VLAN_UNREG_FLOOD_MODE_CHECK_RANGE(val) \
    SX_CHECK_RANGE(SX_VLAN_UNREG_FLOOD_MODE_MIN,  \
                   val,                           \
                   SX_VLAN_UNREG_FLOOD_MODE_MAX)


/*
 * sx_ether_type_t is used to define Vlan Ethertypes for
 * parsing and pushing
 */
typedef uint16_t sx_ether_type_t;


/*
 * sx_vlan_ethertype_function_t is used to define the functionality
 * of the Ethertype being defined for VLan parsing and pushing
 */

typedef enum sx_vlan_ethertype_function {
    SX_VLAN_ETHERTYPE_OUTER = 0,
    SX_VLAN_ETHERTYPE_MIN = SX_VLAN_ETHERTYPE_OUTER,
    SX_VLAN_ETHERTYPE_MAX = SX_VLAN_ETHERTYPE_OUTER
} sx_vlan_ethertype_function_t;

typedef struct sx_vlan_ethertype {
    sx_ether_type_t              ethertype;
    sx_vlan_ethertype_function_t ethertype_function;
} sx_vlan_ethertype_t;


/*
 * sx_vlan_attrib_t is used to set/get VLAN attributes.
 */
typedef struct sx_vlan_attrib {
    boolean_t flood_to_router;
} sx_vlan_attrib_t;

#endif /* __SX_VLAN_H__ */
