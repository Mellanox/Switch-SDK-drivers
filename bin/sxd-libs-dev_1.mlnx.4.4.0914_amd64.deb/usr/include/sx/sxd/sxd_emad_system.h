/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2020 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_SYSTEM_H__
#define __SXD_EMAD_SYSTEM_H__

#include <complib/sx_log.h>

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_emad_system_data.h>
#include <sx/sxd/sxd_emad_port_data.h>
#include <sx/sxd/sxd_emad_mpls_data.h>


/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/**
 * This function sets the log verbosity level of EMAD SYSTEM MODULE
 * @param[in] cmd               - SET / GET
 * @param[in] verbosity_level_p - verbosity level
 *
 * @return SX_STATUS_SUCCESS operation completes successfully
 *          SX_STATUS_ERROR   general error
 */
sxd_status_t sxd_emad_system_log_verbosity_level(IN sxd_access_cmd_t      cmd,
                                                 IN sx_verbosity_level_t *verbosity_level_p);

/**
 *  This function sets the Switch Capabilities Register (SCAR).
 *
 * @param[in] scar_data_arr - Pointer to allocated structure
 *       contained the parameters to be configured.
 * @param[in] scar_data_num - Number of data blocks to be gets
 * @param[in] handler - Completion handler
 * @param[in,out] context - Completion handler context
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS      - Success
 * @return SXD_STATUS_PARAM_ERROR  - Input parameters validation
 *         error
 * @return SXD_STATUS_NO_MEMORY    - Memory allocation error
 * @return SXD_STATUS_NO_RESOURCES - Transaction could not be
 *  completed. emad_transaction_init() should be called
 */
sxd_status_t sxd_emad_scar_get(sxd_emad_scar_data_t         *scar_data_arr,
                               uint32_t                      scar_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 * This function Sets the SPAD Switch Descriptor fields.
 *
 * @param[in,out]	spad_data_arr - SPAD EMAD array
 * @param[in]		spad_data_num - Number of SPAD EMAD data
 * @param[in]		handler - Sender ID
 * @param[in,out]	context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_spad_set(sxd_emad_spad_data_t         *spad_data_arr,
                               uint32_t                      spad_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function gets the Switch Capabilities Register (SPAD).
 *
 * @param[in] spad_data_arr - Pointer to allocated structure
 *       contained the parameters to be configured.
 * @param[in] spad_data_num - Number of data blocks to be gets
 * @param[in] handler - Completion handler
 * @param[in,out] context - Completion handler context
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS      - Success
 * @return SXD_STATUS_PARAM_ERROR  - Input parameters validation
 *         error
 * @return SXD_STATUS_NO_MEMORY    - Memory allocation error
 * @return SXD_STATUS_NO_RESOURCES - Transaction could not be
 *  completed. emad_transaction_init() should be called
 */
sxd_status_t sxd_emad_spad_get(sxd_emad_spad_data_t         *spad_data_arr,
                               uint32_t                      spad_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 * This function Sets the PPSC Switch Descriptor fields.
 *
 * @param[in,out]	ppsc_data_arr - PPSC EMAD array
 * @param[in]		ppsc_data_num - Number of PPAD EMAD data
 * This function Sets the MJTAG Switch Descriptor fields.
 *
 * @param[in,out]	mjtag_data_arr - MJTAG EMAD array
 * @param[in]		mjtag_data_num - Number of MJTAG EMAD data
 * @param[in]		handler - Sender ID
 * @param[in,out]	context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_ppsc_set(sxd_emad_ppsc_data_t         *ppsc_data_arr,
                               uint32_t                      ppsc_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

sxd_status_t sxd_emad_mjtag_set(sxd_emad_mjtag_data_t        *mjtag_data_arr,
                                uint32_t                      mjtag_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 * This function Retrieves the PPSC Switch Descriptor fields.
 *
 * @param[in,out]	ppsc_data_arr - PPSC EMAD array
 * @param[in]		ppsc_data_num - Number of PPSC EMAD data
 * @param[in]		handler - Sender ID
 * @param[in,out]	context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_ppsc_get(sxd_emad_ppsc_data_t         *ppsc_data_arr,
                               uint32_t                      ppsc_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**  This  function  sets  the  Switch System Port Record
 *  This function gets the Switch Capabilities Register (MJTAG).
 *
 * @param[in] mjtag_data_arr - Pointer to allocated structure
 *       contained the parameters to be configured.
 * @param[in] mjtag_data_num - Number of data blocks to be gets
 * @param[in] handler - Completion handler
 * @param[in,out] context - Completion handler context
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS      - Success
 * @return SXD_STATUS_PARAM_ERROR  - Input parameters validation
 *         error
 * @return SXD_STATUS_NO_MEMORY    - Memory allocation error
 * @return SXD_STATUS_NO_RESOURCES - Transaction could not be
 *  completed. emad_transaction_init() should be called
 */
sxd_status_t sxd_emad_mjtag_get(sxd_emad_mjtag_data_t        *mjtag_data_arr,
                                uint32_t                      mjtag_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This  function  sets  the  Switch System Port Record
 *  Register (SSPR).
 *
 * @param[in] sspr_data_arr - Pointer to allocated structure
 *       contained the parameters to be configured.
 * @param[in] sspr_data_num - Number of data blocks to be gets
 * @param[in] handler - Completion handler
 * @param[in,out] context - Completion handler context
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS      - Success
 * @return SXD_STATUS_PARAM_ERROR  - Input parameters validation
 *         error
 * @return SXD_STATUS_NO_MEMORY    - Memory allocation error
 * @return SXD_STATUS_NO_RESOURCES - Transaction could not be
 *  completed. emad_transaction_init() should be called
 */
sxd_status_t sxd_emad_sspr_set(sxd_emad_sspr_data_t         *sspr_data_arr,
                               uint32_t                      sspr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This  function  gets  the  Switch System Port Record
 *  Register (SSPR).
 *
 * @param[in] sspr_data_arr - Pointer to allocated structure
 *       contained the parameters to be configured.
 * @param[in] sspr_data_num - Number of data blocks to be gets
 * @param[in] handler - Completion handler
 * @param[in,out] context - Completion handler context
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS      - Success
 * @return SXD_STATUS_PARAM_ERROR  - Input parameters validation
 *         error
 * @return SXD_STATUS_NO_MEMORY    - Memory allocation error
 * @return SXD_STATUS_NO_RESOURCES - Transaction could not be
 *  completed. emad_transaction_init() should be called
 */
sxd_status_t sxd_emad_sspr_get(sxd_emad_sspr_data_t         *sspr_data_arr,
                               uint32_t                      sspr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This  function  sets  MFBA Register.
 *
 * @param[in] mfba_data_arr - Pointer to allocated structure
 *       contained the parameters to be configured.
 * @param[in] mfba_data_num - Number of data blocks to be gets
 * @param[in] handler - Completion handler
 * @param[in,out] context - Completion handler context
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS      - Success
 * @return SXD_STATUS_PARAM_ERROR  - Input parameters validation
 *         error
 * @return SXD_STATUS_NO_MEMORY    - Memory allocation error
 * @return SXD_STATUS_NO_RESOURCES - Transaction could not be
 *  completed. emad_transaction_init() should be called
 */
sxd_status_t sxd_emad_mfba_set(sxd_emad_mfba_data_t         *mfba_data_arr,
                               uint32_t                      mfba_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This  function gets  MFBA Register.
 *
 * @param[in] mfba_data_arr - Pointer to allocated structure
 *       contained the parameters to be configured.
 * @param[in] mfba_data_num - Number of data blocks to be gets
 * @param[in] handler - Completion handler
 * @param[in,out] context - Completion handler context
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS      - Success
 * @return SXD_STATUS_PARAM_ERROR  - Input parameters validation
 *         error
 * @return SXD_STATUS_NO_MEMORY    - Memory allocation error
 * @return SXD_STATUS_NO_RESOURCES - Transaction could not be
 *  completed. emad_transaction_init() should be called
 */
sxd_status_t sxd_emad_mfba_get(sxd_emad_mfba_data_t         *mfba_data_arr,
                               uint32_t                      mfba_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This  function  sets  MFBE Register.
 *
 * @param[in] mfbe_data_arr - Pointer to allocated structure
 *       contained the parameters to be configured.
 * @param[in] mfbe_data_num - Number of data blocks to be gets
 * @param[in] handler - Completion handler
 * @param[in,out] context - Completion handler context
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS      - Success
 * @return SXD_STATUS_PARAM_ERROR  - Input parameters validation
 *         error
 * @return SXD_STATUS_NO_MEMORY    - Memory allocation error
 * @return SXD_STATUS_NO_RESOURCES - Transaction could not be
 *  completed. emad_transaction_init() should be called
 */
sxd_status_t sxd_emad_mfbe_set(sxd_emad_mfbe_data_t         *mfbe_data_arr,
                               uint32_t                      mfbe_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This  function gets  MFBE Register.
 *
 * @param[in] mfbe_data_arr - Pointer to allocated structure
 *       contained the parameters to be configured.
 * @param[in] mfbe_data_num - Number of data blocks to be gets
 * @param[in] handler - Completion handler
 * @param[in,out] context - Completion handler context
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS      - Success
 * @return SXD_STATUS_PARAM_ERROR  - Input parameters validation
 *         error
 * @return SXD_STATUS_NO_MEMORY    - Memory allocation error
 * @return SXD_STATUS_NO_RESOURCES - Transaction could not be
 *  completed. emad_transaction_init() should be called
 */
sxd_status_t sxd_emad_mfbe_get(sxd_emad_mfbe_data_t         *mfbe_data_arr,
                               uint32_t                      mfbe_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This  function  sets  MFPA Register.
 *
 * @param[in] mfpa_data_arr - Pointer to allocated structure
 *       contained the parameters to be configured.
 * @param[in] mfpa_data_num - Number of data blocks to be gets
 * @param[in] handler - Completion handler
 * @param[in,out] context - Completion handler context
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS      - Success
 * @return SXD_STATUS_PARAM_ERROR  - Input parameters validation
 *         error
 * @return SXD_STATUS_NO_MEMORY    - Memory allocation error
 * @return SXD_STATUS_NO_RESOURCES - Transaction could not be
 *  completed. emad_transaction_init() should be called
 */
sxd_status_t sxd_emad_mfpa_set(sxd_emad_mfpa_data_t         *mfpa_data_arr,
                               uint32_t                      mfpa_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This  function gets  MFPA Register.
 *
 * @param[in] mfpa_data_arr - Pointer to allocated structure
 *       contained the parameters to be configured.
 * @param[in] mfpa_data_num - Number of data blocks to be gets
 * @param[in] handler - Completion handler
 * @param[in,out] context - Completion handler context
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS      - Success
 * @return SXD_STATUS_PARAM_ERROR  - Input parameters validation
 *         error
 * @return SXD_STATUS_NO_MEMORY    - Memory allocation error
 * @return SXD_STATUS_NO_RESOURCES - Transaction could not be
 *  completed. emad_transaction_init() should be called
 */
sxd_status_t sxd_emad_mfpa_get(sxd_emad_mfpa_data_t         *mfpa_data_arr,
                               uint32_t                      mfpa_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 * This function Sets the MSCI Switch Descriptor fields.
 *
 * @param[in,out]	msci_data_arr - MSCI EMAD array
 * @param[in]		msci_data_num - Number of MSCI EMAD data
 * @param[in]		handler - Sender ID
 * @param[in,out]	context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_msci_set(sxd_emad_msci_data_t         *msci_data_arr,
                               uint32_t                      msci_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function gets the Switch Capabilities Register (MSCI).
 *
 * @param[in] msci_data_arr - Pointer to allocated structure
 *       contained the parameters to be configured.
 * @param[in] msci_data_num - Number of data blocks to be gets
 * @param[in] handler - Completion handler
 * @param[in,out] context - Completion handler context
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS      - Success
 * @return SXD_STATUS_PARAM_ERROR  - Input parameters validation
 *         error
 * @return SXD_STATUS_NO_MEMORY    - Memory allocation error
 * @return SXD_STATUS_NO_RESOURCES - Transaction could not be
 *  completed. emad_transaction_init() should be called
 */
sxd_status_t sxd_emad_msci_get(sxd_emad_msci_data_t         *msci_data_arr,
                               uint32_t                      msci_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 * This function Sets the MTBR register.
 *
 * @param[in,out]       mtbr_data_arr - MTBR EMAD array
 * @param[in]           mtbr_data_num - Number of MTBR EMAD data
 * @param[in]           handler - Sender ID
 * @param[in,out]       context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_mtbr_set(sxd_emad_mtbr_data_t         *mtbr_data_arr,
                               uint32_t                      mtbr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 * This function gets the MTBR Register.
 *
 * @param[in] mtbr_data_arr - Pointer to allocated structure
 *        contained the parameters to be configured.
 * @param[in] mtbr_data_num - Number of data blocks to be gets
 * @param[in] handler - Completion handler
 * @param[in,out] context - Completion handler context
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS      - Success
 * @return SXD_STATUS_PARAM_ERROR  - Input parameters validation
 *  error
 * @return SXD_STATUS_NO_MEMORY    - Memory allocation error
 * @return SXD_STATUS_NO_RESOURCES - Transaction could not be
 *  completed. emad_transaction_init() should be called
 */
sxd_status_t sxd_emad_mtbr_get(sxd_emad_mtbr_data_t         *mtbr_data_arr,
                               uint32_t                      mtbr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function sets the SBPR Register.
 *
 * @param[in] sbpr_data_arr - Pointer to allocated structure
 *       contained the parameters to be configured.
 * @param[in] sbpr_data_num - Number of data blocks to be sets
 * @param[in] handler - Completion handler
 * @param[in,out] context - Completion handler context
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS      - Success
 * @return SXD_STATUS_PARAM_ERROR  - Input parameters validation
 *         error
 * @return SXD_STATUS_NO_MEMORY    - Memory allocation error
 * @return SXD_STATUS_NO_RESOURCES - Transaction could not be
 *  completed. emad_transaction_init() should be called
 */
sxd_status_t sxd_emad_sbpr_set(sxd_emad_sbpr_data_t         *sbpr_data_arr,
                               uint32_t                      sbpr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function gets the SBPR Register.
 *
 * @param[in] sbpr_data_arr - Pointer to allocated structure
 *       contained the parameters to be configured.
 * @param[in] sbpr_data_num - Number of data blocks to be gets
 * @param[in] handler - Completion handler
 * @param[in,out] context - Completion handler context
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS      - Success
 * @return SXD_STATUS_PARAM_ERROR  - Input parameters validation
 *         error
 * @return SXD_STATUS_NO_MEMORY    - Memory allocation error
 * @return SXD_STATUS_NO_RESOURCES - Transaction could not be
 *  completed. emad_transaction_init() should be called
 */
sxd_status_t sxd_emad_sbpr_get(sxd_emad_sbpr_data_t         *sbpr_data_arr,
                               uint32_t                      sbpr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 * This function Sets/gets the SGCR Switch Descriptor fields.
 *
 * @param[in,out]       sgcr_data_arr - SGCR EMAD array
 * @param[in]           sgcr_data_num - Number of SGCR EMAD data
 * @param[in]           handler - Sender ID
 * @param[in,out]       context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_sgcr_access(sxd_emad_sgcr_data_t         *sgcr_data_arr,
                                  uint32_t                      sgcr_data_num,
                                  sxd_emad_completion_handler_t handler,
                                  void                         *context);

/**
 * This function Sets the RAW register.
 *
 * @param[in,out]	raw_data_arr - RAW EMAD array
 * @param[in]		raw_data_num - Number of RAW EMAD data
 * @param[in]		handler - Sender ID
 * @param[in,out]	context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_raw_set(sxd_emad_raw_data_t          *raw_data_arr,
                              uint32_t                      raw_data_num,
                              sxd_emad_completion_handler_t handler,
                              void                         *context);

/**
 *  This function gets the RAW Register.
 *
 * @param[in] raw_data_arr - Pointer to allocated structure
 *       contained the parameters to be configured.
 * @param[in] raw_data_num - Number of data blocks to be gets
 * @param[in] handler - Completion handler
 * @param[in,out] context - Completion handler context
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS      - Success
 * @return SXD_STATUS_PARAM_ERROR  - Input parameters validation
 *         error
 * @return SXD_STATUS_NO_MEMORY    - Memory allocation error
 * @return SXD_STATUS_NO_RESOURCES - Transaction could not be
 *  completed. emad_transaction_init() should be called
 */
sxd_status_t sxd_emad_raw_get(sxd_emad_raw_data_t          *raw_data_arr,
                              uint32_t                      raw_data_num,
                              sxd_emad_completion_handler_t handler,
                              void                         *context);

/**
 * This function sets the MRSR register Descriptor fields.
 *
 * @param[in,out]	mrsr_data_arr - MRSR EMAD array
 * @param[in]		mrsr_data_num - Number of MRSR EMAD data
 * @param[in]		handler - Sender ID
 * @param[in,out]	context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_mrsr_set(sxd_emad_mrsr_data_t         *mrsr_data_arr,
                               uint32_t                      mrsr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 * This function Retrieves the MGIR Switch Descriptor fields.
 *
 * @param[in,out]   mgir_data_arr - MGIR EMAD array
 * @param[in]       mgir_data_num - Number of MGIR EMAD data
 * @param[in]       handler - Sender ID
 * @param[in,out]   context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_mgir_get(sxd_emad_mgir_data_t         *mgir_data_arr,
                               uint32_t                      mgir_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 * This function sets the MCION register.
 *
 * @param[in,out]	mcion_data_arr - MCION EMAD array
 * @param[in]		mcion_data_num - Number of MCION EMAD data
 * @param[in]		handler - Sender ID
 * @param[in,out]	context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_mcion_set(sxd_emad_mcion_data_t        *mcion_data_arr,
                                uint32_t                      mcion_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function gets the MCION Register.
 *
 * @param[in] mcion_data_arr - Pointer to allocated structure
 *       contained the parameters to be configured.
 * @param[in] mcion_data_num - Number of data blocks to be gets
 * @param[in] handler - Completion handler
 * @param[in,out] context - Completion handler context
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS      - Success
 * @return SXD_STATUS_PARAM_ERROR  - Input parameters validation
 *         error
 * @return SXD_STATUS_NO_MEMORY    - Memory allocation error
 * @return SXD_STATUS_NO_RESOURCES - Transaction could not be
 *  completed. emad_transaction_init() should be called
 */
sxd_status_t sxd_emad_mcion_get(sxd_emad_mcion_data_t        *mcion_data_arr,
                                uint32_t                      mcion_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);


#endif /* __SXD_EMAD_SYSTEM_H__ */
