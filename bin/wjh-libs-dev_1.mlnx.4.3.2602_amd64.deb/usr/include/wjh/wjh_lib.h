/*
 * Copyright (C) Mellanox Technologies, Ltd. 2001-2019 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */


#ifndef WJH_LIB_H_
#define WJH_LIB_H_

#include "wjh_lib_types.h"

/************************************************
 *  API functions
 ***********************************************/

/**
 * This API sets the log verbosity level.
 *
 * @param[in] level    - verbosity level
 *
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_log_verbosity_level_set(const wjh_verbosity_level_t level);

/**
 * This API gets the log verbosity level.
 *
 * @param[out] level    - verbosity level
 *
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_log_verbosity_level_get(wjh_verbosity_level_t *level_p);

/**
 * This API init WJH service lib.
 * Note: During initialization, shared memory file /dev/shm/wjh_libs_shm will be created for synchronization,
 *       it must be accessible (read and write) among any WJH clients.
 *
 * @param[in] param_p    - init param
 *
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_NULL if an input parameter is NULL
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_init(const wjh_init_param_t *param_p);

/**
 * This API deinit WJH service lib.
 *
 *
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_deinit(void);

/**
 * This API init drop reason group.
 *
 * @param[in] drop_reason_group    - drop reason group
 * @param[in] attr_p               - drop reason group attribute
 * @param[in] callbacks_p          - callbacks for the drop packets of input drop reason group
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_PARAM_NULL if an input parameter is NULL
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_drop_reason_group_init(const wjh_drop_reason_group_e       drop_reason_group,
                                        const wjh_drop_reason_group_attr_t *attr_p,
                                        const wjh_drop_callbacks_t         *callbacks_p);

/**
 * This API deinit drop reason group.
 *
 * @param[in] drop_reason_group    - drop reason group
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_drop_reason_group_deinit(const wjh_drop_reason_group_e drop_reason_group);

/**
 * This API create user channel.
 *
 * @param[in] channel_type          - user channel type
 * @param[out] channel_id_p         - user channel id
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_PARAM_NULL if an input parameter is NULL
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_user_channel_create(const wjh_user_channel_type_e channel_type,
                                     wjh_user_channel_id_t        *channel_id_p);

/**
 * This API set the wjh user channel attributes.
 * Supported channel types: cyclic and aggregation.
 *
 * @param[in] channel_id          - user channel id
 * @param[in] channel_attr_p      - user channel attributes
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_PARAM_NULL if an input parameter is NULL
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_user_channel_set(const wjh_user_channel_id_t    channel_id,
                                  const wjh_user_channel_attr_t *channel_attr_p);

/**
 * This API pulls the user channel which is in pull mode.
 * Supported channel types: cyclic and aggregation.
 *
 * @param[in] channel_id          - user channel id
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_PARAM_NULL if an input parameter is NULL
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_user_channel_pull(const wjh_user_channel_id_t channel_id);

/**
 * This API destroy wjh user channel.
 *
 * @param[in] channel_id         - user channel id
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_ENTRY_NOT_FOUND if channel id is not found
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_user_channel_destroy(const wjh_user_channel_id_t channel_id);

/**
 * This API flush user channel.
 *
 * @param[in] channel_id         - user channel id
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_UNSUPPORTED if operation unsupported
 * @return WJH_STATUS_ENTRY_NOT_FOUND if channel id is not found
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_user_channel_flush(const wjh_user_channel_id_t channel_id);

/**
 * This API bind drop reason group to user channel.
 *
 * @param[in] drop_reason_group  - drop reason group
 * @param[in] channel_id         - user channel id
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_ENTRY_NOT_FOUND if channel id is not found
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_drop_reason_group_bind(const wjh_drop_reason_group_e drop_reason_group,
                                        const wjh_user_channel_id_t   channel_id);

/**
 * This API unbind drop reason group from user channel.
 *
 * @param[in] drop_reason_group  - drop reason group
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_drop_reason_group_unbind(const wjh_drop_reason_group_e drop_reason_group);

/**
 * This API enable drop reason group to get dropped packets via callbacks.
 *
 * @param[in] drop_reason_group  - drop reason group
 * @param[in] severity           - severity level
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_drop_reason_group_enable(const wjh_drop_reason_group_e drop_reason_group,
                                          const wjh_severity_e          severity);

/**
 * This API disable drop reason group to stop getting dropped packets.
 *
 * @param[in] drop_reason_group  - drop reason group
 * @param[in] severity           - severity level
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_drop_reason_group_disable(const wjh_drop_reason_group_e drop_reason_group,
                                           const wjh_severity_e          severity);

/**
 * This API get counter per user channel.
 *
 * @param[in] channel_id         - user channel id
 * @param[out] counter_p         - drop counter
 * @param[in] clear              - clear drop counter
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_PARAM_NULL if an input parameter is NULL
 * @return WJH_STATUS_ENTRY_NOT_FOUND if channel id is not found
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_counter_get(const wjh_user_channel_id_t channel_id,
                             wjh_drop_counter_t         *counter_p,
                             const uint8_t               clear);

/**
 * This API get global counter of all user channel.
 *
 * @param[in] channel_id         - user channel id
 * @param[out] counter_p         - drop counter
 * @param[in] clear              - clear drop counter
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_PARAM_NULL if an input parameter is NULL
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_global_counter_get(wjh_drop_counter_t *counter_p,
                                    const uint8_t       clear);

/**
 * This API generate the debug dump to file stream.
 *
 * @param[in] stream_p         - file stream
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_PARAM_NULL if an input parameter is NULL
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_dbg_generate_dump(FILE* stream_p);

#endif /* WJH_LIB_H_ */
