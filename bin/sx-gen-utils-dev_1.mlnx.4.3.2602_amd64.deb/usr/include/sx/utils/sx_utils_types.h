/*
 * Copyright (C) Mellanox Technologies, Ltd. 2013-2019 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SX_UTILS_TYPES_H__
#define __SX_UTILS_TYPES_H__

#include <stdint.h>
#include <stddef.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/select.h>

#include <sx/utils/sx_utils_status.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/
/**
 * Macro is used to test if value doesn't exceed its maximum.
 */
#ifndef     SX_CHECK_MAX
#define SX_CHECK_MAX(val, max) ((max) >= (val))
#endif  /*  SX_CHECK_MAX    */

/**
 * Macro is used to test if value doesn't exceed its minimum.
 */
#ifndef     SX_CHECK_MIN
#define SX_CHECK_MIN(min, val) ((val) >= (min))
#endif  /*  SX_CHECK_MIN    */

/**
 * Macro is used to test if value is within a valid range.
 */
#ifndef     SX_CHECK_RANGE
#define SX_CHECK_RANGE(min, val, max) (SX_CHECK_MIN((min), (val)) && SX_CHECK_MAX((val), (max)))
#endif  /*  SX_CHECK_RANGE  */

#define SX_UTILS_CMD_STR(cmd)                           \
    (SX_CHECK_RANGE(0, (int)cmd, sx_utils_cmd_str_len - \
                    1) ? sx_utils_cmd_str[cmd] : "UNKNOWN")

/************************************************
 *  Type definitions
 ***********************************************/
typedef enum sx_utils_command {
    SX_UTILS_CMD_ADD,
    SX_UTILS_CMD_MODIFY,
    /*SX_UTILS_CMD_MODIFY_STRICT,*/
    SX_UTILS_CMD_DELETE,
    /*SX_UTILS_CMD_DELETE_STRICT,*/
    SX_UTILS_CMD_SET,
    SX_UTILS_CMD_GET,

    SX_UTILS_CMD_MIN = SX_UTILS_CMD_ADD,
    SX_UTILS_CMD_MAX = SX_UTILS_CMD_GET,
} sx_utils_command_t;

/************************************************
 *  Global variables
 ***********************************************/
static const char *sx_utils_cmd_str[] = {
    "NONE",
    "ADD",
    "MODIFY",
    "DELETE",
    "SET",
    "GET",
};
static const int   sx_utils_cmd_str_len = sizeof(sx_utils_cmd_str) / sizeof(char*);

/************************************************
 *  Function declarations
 ***********************************************/


#endif /* __SX_UTILS_TYPES_H__ */
