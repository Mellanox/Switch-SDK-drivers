/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2021 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_COS_H__
#define __SXD_EMAD_COS_H__

#include <complib/sx_log.h>

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_emad_cos_data.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/**
 * This function sets the log verbosity level of EMAD COS MODULE
 * @param[in] cmd               - SET / GET
 * @param[in] verbosity_level_p - verbosity level
 *
 * @return SX_STATUS_SUCCESS operation completes successfully
 *          SX_STATUS_ERROR   general error
 */
sxd_status_t sxd_emad_cos_log_verbosity_level(IN sxd_access_cmd_t      cmd,
                                              IN sx_verbosity_level_t *verbosity_level_p);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_qpdp_set(sxd_emad_qpdp_data_t         *qpdp_data_arr,
                               uint32_t                      qpdp_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_qpdp_get(sxd_emad_qpdp_data_t         *qpdp_data_arr,
                               uint32_t                      qpdp_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_qprt_set(sxd_emad_qprt_data_t         *qprt_data_arr,
                               uint32_t                      qprt_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_qprt_get(sxd_emad_qprt_data_t         *qprt_data_arr,
                               uint32_t                      qprt_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_qsptc_set(sxd_emad_qsptc_data_t        *qsptc_data_arr,
                                uint32_t                      qsptc_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_qsptc_get(sxd_emad_qsptc_data_t        *qsptc_data_arr,
                                uint32_t                      qsptc_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_qtct_set(sxd_emad_qtct_data_t         *qtct_data_arr,
                               uint32_t                      qtct_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_qtct_get(sxd_emad_qtct_data_t         *qtct_data_arr,
                               uint32_t                      qtct_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_qstct_set(sxd_emad_qstct_data_t        *qstct_data_arr,
                                uint32_t                      qstct_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_qstct_get(sxd_emad_qstct_data_t        *qstct_data_arr,
                                uint32_t                      qstct_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_qcap_set(sxd_emad_qcap_data_t         *qcap_data_arr,
                               uint32_t                      qcap_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_qcap_get(sxd_emad_qcap_data_t         *qcap_data_arr,
                               uint32_t                      qcap_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_qpts_set(sxd_emad_qpts_data_t         *qpts_data_arr,
                               uint32_t                      qpts_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_qpts_get(sxd_emad_qpts_data_t         *qpts_data_arr,
                               uint32_t                      qpts_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 * This function Sets the SBMM Switch Descriptor fields.
 *
 * @param[in,out]   sbmm_data_arr - SBMM EMAD array
 * @param[in]       sbmm_data_num - Number of SBMM EMAD data
 * @param[in]       handler - Sender ID
 * @param[in,out]   context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_sbmm_set(sxd_emad_sbmm_data_t         *sbmm_data_arr,
                               uint32_t                      sbmm_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**  This function sets the SBSR Register.
 *
 * @param[in] sbsr_data_arr - Pointer to allocated structure
 *       contained the parameters to be configured.
 * @param[in] sbsr_data_num - Number of data blocks to be sets
 * @param[in] handler - Completion handler
 * @param[in,out] context - Completion handler context
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS      - Success
 * @return SXD_STATUS_PARAM_ERROR  - Input parameters validation
 *         error
 * @return SXD_STATUS_NO_MEMORY    - Memory allocation error
 * @return SXD_STATUS_NO_RESOURCES - Transaction could not be
 *  completed. emad_transaction_init() should be called
 */
sxd_status_t sxd_emad_sbsr_set(sxd_emad_sbsr_data_t         *sbsr_data_arr,
                               uint32_t                      sbsr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 * This function Retrieves the SBMM Switch Descriptor fields.
 *
 * @param[in,out]   sbmm_data_arr - SBMM EMAD array
 * @param[in]       sbmm_data_num - Number of SBMM EMAD data
 * @param[in]       handler - Sender ID
 * @param[in,out]   context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_sbmm_get(sxd_emad_sbmm_data_t         *sbmm_data_arr,
                               uint32_t                      sbmm_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**  This function gets the SBSR Register.
 *
 * @param[in] sbsr_data_arr - Pointer to allocated structure
 *       contained the parameters to be configured.
 * @param[in] sbsr_data_num - Number of data blocks to be gets
 * @param[in] handler - Completion handler
 * @param[in,out] context - Completion handler context
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS      - Success
 * @return SXD_STATUS_PARAM_ERROR  - Input parameters validation
 *         error
 * @return SXD_STATUS_NO_MEMORY    - Memory allocation error
 * @return SXD_STATUS_NO_RESOURCES - Transaction could not be
 *  completed. emad_transaction_init() should be called
 */
sxd_status_t sxd_emad_sbsr_get(sxd_emad_sbsr_data_t         *sbsr_data_arr,
                               uint32_t                      sbsr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_qpdpm_set(sxd_emad_qpdpm_data_t        *qpdpm_data_arr,
                                uint32_t                      qpdpm_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_qpdpm_get(sxd_emad_qpdpm_data_t        *qpdpm_data_arr,
                                uint32_t                      qpdpm_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);


/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_qepm_set(sxd_emad_qepm_data_t         *qepm_data_arr,
                               uint32_t                      qepm_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_qepm_get(sxd_emad_qepm_data_t         *qepm_data_arr,
                               uint32_t                      qepm_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_qeec_set(sxd_emad_qeec_data_t         *qeec_data_arr,
                               uint32_t                      qeec_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_qeec_get(sxd_emad_qeec_data_t         *qeec_data_arr,
                               uint32_t                      qeec_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_qpdpc_set(sxd_emad_qpdpc_data_t        *qpdpc_data_arr,
                                uint32_t                      qpdpc_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_qpdpc_get(sxd_emad_qpdpc_data_t        *qpdpc_data_arr,
                                uint32_t                      qpdpc_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_qtctm_set(sxd_emad_qtctm_data_t        *qtctm_data_arr,
                                uint32_t                      qtctm_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_qtctm_get(sxd_emad_qtctm_data_t        *qtctm_data_arr,
                                uint32_t                      qtctm_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_qspip_set(sxd_emad_qspip_data_t        *qspip_data_arr,
                                uint32_t                      qspip_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_qspip_get(sxd_emad_qspip_data_t        *qspip_data_arr,
                                uint32_t                      qspip_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_qspcp_set(sxd_emad_qspcp_data_t        *qspcp_data_arr,
                                uint32_t                      qspcp_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_qspcp_get(sxd_emad_qspcp_data_t        *qspcp_data_arr,
                                uint32_t                      qspcp_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_qrwe_set(sxd_emad_qrwe_data_t         *qrwe_data_arr,
                               uint32_t                      qrwe_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_qrwe_get(sxd_emad_qrwe_data_t         *qrwe_data_arr,
                               uint32_t                      qrwe_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_qpem_set(sxd_emad_qpem_data_t         *qpem_data_arr,
                               uint32_t                      qpem_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_qpem_get(sxd_emad_qpem_data_t         *qpem_data_arr,
                               uint32_t                      qepm_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_qpdsm_set(sxd_emad_qpdsm_data_t        *qpdsm_data_arr,
                                uint32_t                      qpdsm_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_qpdsm_get(sxd_emad_qpdsm_data_t        *qpdsm_data_arr,
                                uint32_t                      qpdsm_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_qppm_set(sxd_emad_qppm_data_t         *qppm_data_arr,
                               uint32_t                      qppm_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_qppm_get(sxd_emad_qppm_data_t         *qppm_data_arr,
                               uint32_t                      qppm_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

#endif /* __SXD_EMAD_COS_H__ */
