/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2021 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */


#ifndef __SXDEV_H__
#define __SXDEV_H__

#include <sys/types.h>
#include <stdlib.h>
#include <stdint.h>
#include <sx/sxd/kernel_user.h>
#include <sx/sxd/sxd_dev.h>
/************************************************
 *  Local Macros
 ***********************************************/

#define     SYSFS_CDEV_CORE "sxcdev"

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/*
 * sxd_ctrl_pack_t structure is used to pack ioctl code and data.
 */
typedef struct sxd_ctrl_pack {
    int                               ctrl_cmd; /*<! command from ku_ctrl_cmd or ku_ctrl_cmd_access_reg */
    void __attribute__((aligned(8))) *cmd_body;  /*<! command body */
} sxd_ctrl_pack_t;

typedef int sxd_handle;

/************************************************
 *  Local Defines
 ***********************************************/

/*
 * the number of retries to perform in case of fw_busy error .
 * or timeout.                                                          .
 */
#define NUM_OF_RETRIES 5

/*
 * the period of time to wait between retries.
 */
#define RETRY_WAIT_TIME 200000

/*
 * max supported device number.
 */
#define MAX_SX_DEVS 1

/*
 * max name assigned to a device or driver version.
 * The caller must provide room for \0 to terminate the string.
 */
#define MAX_NAME_LEN 32

/************************************************
 *  Macros
 ***********************************************/

/**
 * CTRL_CMD_ACCESS_REG:
 * Check the validity of the supplied CTRL CMD
 * CTRL CMD - control command to be checked
 */
#define CTRL_CMD_ACCESS_REG_CHECK_RANGE(CMD) SXD_CHECK_RANGE(CTRL_CMD_ACCESS_REG_MIN, CMD, CTRL_CMD_ACCESS_REG_MAX)

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/
/*
 * sxd_get_dev_list - get list of available devices
 * @param[output] devs_p - array of char pointers to contain the list of available devices by their names
 * @param[output] num_p  - size of the array. On successful return the actual number of devices it holds
 * Note the caller must provide room for device names up to MAX_DEV_NAME_LEN.
 *
 * @return: 0 success
 *          >0 array was too small. The returned value denotes the required size.
 *          <0 error
 */
int sxd_get_dev_list(char *devs_p[], uint32_t *num_p);

/*
 * sxd_open_device - open a device and get a handle for it
 * @param[input]  dev_name - the device to be opened
 * @param[output] handle_p - pointer to handle to the device
 *
 * Only one application can open the handle for a device and it can do it only
 * once.
 *
 * returns: 0      - success
 *          ENOENT - file not found
 *          EBUSY  - device already used
 *          EINVAL - invalid parameter
 */
int sxd_open_device(const char * dev_name, sxd_handle *handle_p);

/*
 * sxd_close_device - close the handle to the device
 * @param[input] handle - handle to the device that should be closed
 *
 * returns: EINVAL - device not found
 *          EBUSY  - device is in use and cannot be closed
 */
int sxd_close_device(sxd_handle handle);

/*
 * sxd_send - send a packet to the network
 * @param[input] handle    - handle to the device that should send the packet
 * @param[input] pack_p    - a pointer to a struct containing the packet and control information
 * @param[input] pack_size - pack size
 *
 * returns: 0       - packet queued for transmission
 *          EAGAIN  - packet could not be queued, try again
 *          EACCESS - cannot send packet due to e.g. link is down
 */
int sxd_send(sxd_handle handle, struct ku_write *pack_p, uint32_t pack_size);

/*
 * sxd_recv - receive a packet form the network
 * @param[input]  handle        -  handle to the device which should receive a packet
 * @param[output] buffer_p      -  pointer to a buffer containing one/multiple packets
 * @param[in/out] size_read_p   -  sizeof buffer / number of bytes read
 *
 * returns: > 0 packet received - buffer_p field contains the packet/s.
 *          EAGAIN - no packet received - can happen when the BX_FLAG_RCV_NBLOCK was set
 *                   in the flags field of pack and no packet was pending
 *          ENOMEM - buffer size was too small
 *          EINTR  - signal delivered
 *          EBUSY  - another call to receive is pending
 */
int sxd_recv(sxd_handle handle, char *buffer_p, int *size_read_p);

/*
 * sxd_ioctl - configure the device and retrieve information from the driver
 * @param[input] handle - handle to the device which should send/receive the packet
 * @param[input] pack_p - information packed for configuring or retrieved from the device
 *
 * returns: 0      - success
 *          EINVAL - invalid operation
 */
int sxd_ioctl(sxd_handle handle, sxd_ctrl_pack_t *pack_p);

/*
 * sxd_memory_map - maps a memory in driver that is shared with the user application
 * @param[input] handle - handle to the device which should run this function
 * @param[input] length - the length of the new mapping
 * @param[output] ret   - pointer to the new mapped area
 *
 * returns: 0      - success
 *          EINVAL - invalid operation
 */
int sxd_memory_map(sxd_handle handle, size_t length, void **ret);

/*
 * sxd_memory_unmap - unmap a memory in driver the is shared with user application
 * @param[input] addr   - the starting address of the mapping (as returned from sxd_mmap())
 * @param[input] length - the length of the mapping (as passed to sxd_mmap())
 *
 * returns: 0      - success
 *          EINVAL - invalid operation
 */
int sxd_memory_unmap(void *addr, size_t length);

/*
 * sxd_fd_get - retrieve the file descriptor used by 'handle'
 * @param[input] handle - handle to the device which should send/receive the packet
 * @param[input] fd_p   - file descriptor
 *
 * returns: 0      - success
 *          ENODEV - can't retrieve file descriptor
 */
int sxd_fd_get(sxd_handle handle, int *fd_p);

/*
 * sxd_get_driver_version - get sx driver version
 *
 * @return: driver version string
 *	    empty string in case of error
 */
const char * sxd_get_driver_version(void);

/*
 * sxd_open_device_ext - Open the device and get a file descriptor.
 *
 * @param[input] dev_name  - the device to open
 * @param[output] fd_p     - file descriptor to device
 *
 * @return: 0      - success
 *          EINVAL - invalid operation
 *          ENOENT - file not found
 *          EBUSY  - device already used
 */
int sxd_open_device_ext(const char * dev_name, int *fd_p);

/*
 * sxd_get_new_handle - Get a new handle for an open file descriptor to device.
 *
 * @param[input] fd - file descriptor to device
 * @param[output] handle_p - new handle
 *
 * @return: 0      - success
 *          EINVAL - invalid operation
 *          ENOMEM - no memory
 *          any other value  - general error
 */
int sxd_get_new_handle(int fd, sxd_handle *handle_p);

/*
 * sxd_close_device_ext - Close a file descriptor to device
 *
 * @param[input] fd - file descriptor to device
 *
 * @return: 0      - success
 *          any other value  - general error
 */
int sxd_close_device_ext(int fd);

/*
 * sxd_put_handle - Return a device handle
 *
 * @param[input] handle - handle to return
 *
 * @return: 0 - success
 *          EINVAL - invalid operation
 */
int sxd_put_handle(sxd_handle handle);

#endif /* __SXDEV_H__ */
