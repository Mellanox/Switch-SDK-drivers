/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2021 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_FLOW_COUNTER_REG_H__
#define __SXD_EMAD_FLOW_COUNTER_REG_H__

#include <sx/sxd/sxd_types.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

#include <complib/cl_packon.h>

/**
 * emad_pfca_reg_t structure is used to store PFCA register
 * layout.
 */
typedef struct sxd_emad_pfca_reg {
    uint8_t op_type;
    uint8_t reserved1[2];
    uint8_t index;
    net32_t reserved2;
    net32_t flow_counter_handle;
} PACK_SUFFIX sxd_emad_pfca_reg_t;


/**
 * emad_pfcnt_reg_t structure is used to store PFCNT register
 * layout.
 */
typedef struct sxd_emad_pfcnt_reg {
    net32_t flow_counter_handle;
    uint8_t clr;
    uint8_t reserved1[3];
    net64_t flow_counter;
} PACK_SUFFIX sxd_emad_pfcnt_reg_t;

/**
 * emad_mgpc_reg_t structure is used to store MGPC register
 * layout.
 */
typedef struct sxd_emad_mgpc_reg {
    net32_t counter_set;
    uint8_t counter_opcode;
    uint8_t reserved1[3];
    net64_t byte_counter;
    net64_t packet_counter;
} PACK_SUFFIX sxd_emad_mgpc_reg_t;

#include <complib/cl_packoff.h>

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

#endif /* ifndef __SXD_EMAD_FLOW_COUNTER_REG_H__ */
