/*
 * Copyright (C) 2010-2021 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __PSORT_H_INCL__
#define __PSORT_H_INCL__

#include <sx/utils/sx_utils_status.h>
#include <sx/utils/sx_utils_types.h>
#include <complib/cl_types.h>


#ifdef PSORT_C_

/************************************************
 *  Local Defines
 ***********************************************/


/************************************************
 *  Local Macros
 ***********************************************/


/************************************************
 *  Local Type definitions
 ***********************************************/


#endif

/************************************************
 *  Defines
 ***********************************************/

#define MAX_PSORT_CLIENTS 10


/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

typedef enum psort_notification_type {
    PSORT_TABLE_ALMOST_FULL_E = 0,
    PSORT_TABLE_ALMOST_EMPTY_E,
    PSORT_TABLE_SHIFT_E
} psort_notification_type_e;

/**
 * pSort handle.
 */
typedef uint64_t psort_handle_t;


/**
 * Priority Sort Notification Callback
 */
typedef sx_utils_status_t (*psort_notification_func_ptr_t)(psort_notification_type_e notif_type, void* data,
                                                           void *cookie);

/**
 * psort_param_t is used to store the pSort
 * move notification parameters.
 */
typedef struct psort_param {
    uint64_t key;
    uint32_t old_index;
    uint32_t new_index;
    uint32_t size;
} psort_shift_param_t;


/**
 * psort_param_t is used to store the pSort
 * init configuration parameters.
 */
typedef struct psort_init_param {
    uint32_t                      table_size;
    uint32_t                      delta_size;
    int                           max_priority;
    int                           min_priority;
    uint32_t                      table_almost_full_precentage_threshold;
    uint32_t                      table_almost_empty_precentage_threshold;
    void                         *cookie;
    psort_notification_func_ptr_t notif_callback;
} psort_init_param_t;

/**
 * psort_set_param_t is used set pSort
 * configuration parameters.
 */
typedef struct psort_set_param {
    uint32_t background_move_block_size; /* background worker move block size */
    uint32_t foreground_move_block_size; /* foreground move block size */
    uint32_t decrease_size_threshold; /* background worker decrease region by delta when region empty space bigger than [decrease_size_threshold]*delta */
    uint32_t expand_at_empty_space_size; /* background worker expand region by delta when region empty space less than [expand_at_empty_space_size] */
    uint32_t hole_min_size_factor; /* background worker make sure that hole size at least [hole_min_size_factor]*delta */
} psort_set_param_t;


/**
 * psort_entry_t struct type is used to note an pSort Entry
 */
typedef struct {
    uint64_t key;
    int      priority;
    uint32_t index;
} psort_entry_t;


/* psort info and statistics */
typedef struct psort_info_stats {
    uint32_t num_of_shifts;
    uint32_t total_regions_size;
    uint32_t num_of_regions;
    uint32_t total_region_hole_num;
} psort_info_stats_t;


/**
 * psort_entry_info_t struct type is used to note an pSort Entry information
 */
typedef struct {
    uint8_t       valid;
    psort_entry_t entry;
} psort_entry_info_t;


/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Function declarations
 ***********************************************/

sx_utils_status_t psort_init(psort_handle_t           *handle,
                             const psort_init_param_t *params);

sx_utils_status_t psort_params_set(psort_handle_t          *handle,
                                   const psort_set_param_t *params);

/* register to background checker */
sx_utils_status_t psort_background_register(const psort_handle_t handle,
                                            sx_utils_command_t   cmd);

/* Check all background clients */
sx_utils_status_t psort_background_checker(boolean_t *is_complete_p);

sx_utils_status_t psort_entry_set(const psort_handle_t handle,
                                  sx_utils_command_t   cmd,
                                  psort_entry_t       *entry_p);


sx_utils_status_t psort_get_table_free_space(const psort_handle_t handle,
                                             uint32_t            *size);

sx_utils_status_t psort_prio_change(const psort_handle_t handle,
                                    uint32_t             min_prio,
                                    uint32_t             max_prio,
                                    int32_t              prio_change);

sx_utils_status_t psort_get_table_used_space(const psort_handle_t handle,
                                             uint32_t            *size);


sx_utils_status_t psort_table_resize(const psort_handle_t handle,
                                     uint32_t             new_size,
                                     boolean_t            is_background,
                                     uint32_t           * shift_count_p);

/* Background worker . Used for defragment and reorder of the table */
sx_utils_status_t psort_background_worker(const psort_handle_t handle, boolean_t *is_complete_p);


/* Free resources and destroy table*/
sx_utils_status_t psort_clear_table(const psort_handle_t handle);

/* Dump pSort Table */
sx_utils_status_t psort_dump_table(const psort_handle_t handle,
                                   psort_entry_info_t  *entries_p,
                                   uint32_t            *num_of_entries_p);

/* Debug Dump */
sx_utils_status_t psort_debug_dump(const psort_handle_t handle, FILE* stream);

/* Get info and statisticsCounters */
sx_utils_status_t psort_info_stats_get(const psort_handle_t handle, psort_info_stats_t* info_stats_p);

#endif /* ifndef __PSORT_H_INCL__ */
