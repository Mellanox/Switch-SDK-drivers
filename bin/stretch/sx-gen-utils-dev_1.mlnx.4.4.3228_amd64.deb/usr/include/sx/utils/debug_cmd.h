/*
 * Copyright (C) 2001-2021 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __DEBUG_CMD_H__
#define __DEBUG_CMD_H__

#include <sx/utils/sx_utils_types.h>

#define SX_UTILS_DBG_CMD_PATH        "/var/run/dbg_cmd.sock"
#define SX_UTILS_DBG_CMD_BUFFER_SIZE (1024)

typedef void (*sx_utils_debug_cmd_cb_t)(FILE       *stream,
                                        int         argc,
                                        const char *argv[],
                                        void       *handler_context);

sx_utils_status_t sx_utils_debug_cmd_init(void);

sx_utils_status_t sx_utils_debug_cmd_deinit(void);

sx_utils_status_t sx_utils_debug_cmd_get_fd(int *fd);

sx_utils_status_t sx_utils_debug_cmd_register_path(const char             *path,
                                                   sx_utils_debug_cmd_cb_t handler_cb,
                                                   void                   *handler_context);

sx_utils_status_t sx_utils_debug_cmd_unregister_path(const char *path);

sx_utils_status_t sx_utils_debug_cmd_handle_command(void);

#endif /* __DEBUG_CMD_H__ */
