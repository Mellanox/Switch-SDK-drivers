/*
 * Copyright (C) 2010-2021 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef     __DBG_UTILS_H__
#define     __DBG_UTILS_H__

#include <complib/cl_types.h>
#include <stdio.h>
#include "sx_json.h"

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/
#define DBG_UTILS_DATA_STR_WIDTH          40
#define DBG_UTILS_DATA_STR_PRECISION      65
#define DBG_UTILS_VAL_STR_PRECISION       65
#define DBG_UTILS_CHEAT_SHEET_BUFFER_SIZE 4096
#define DBG_UTILS_JSON_BUF_SIZE           1024

#define DBG_UTILS_SCRN_WIDTH_MAX 200
#define DBG_UTILS_NODES_MAX      129

#define DBG_UTILS_DEFAULT_SEPARATOR_CHAR '-'

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

typedef enum dbg_utils_param_type {
    PARAM_UINT8_E,
    PARAM_UINT16_E,
    PARAM_UINT32_E,
    PARAM_UINT64_E,
    PARAM_HEX_E,
    PARAM_STRING_E,
    PARAM_EXT_STRING_E,
    PARAM_BOOL_E,
    PARAM_MAC_ADDR_E,
    PARAM_IPV4_E,
    PARAM_IPV4_MASK_E,
    PARAM_IPV6_E,
    PARAM_FC_ADDR_E,
    PARAM_DOUBLE_E,
    PARAM_INT_E,
    PARAM_HEX16_E,
    PARAM_HEX_STRING_E,
    PARAM_PORT_ID_E,
    PARAM_HEX64_E,
    PARAM_LAST_E
} dbg_utils_param_type_e;

typedef enum dbg_utils_level {
    DBG_UTILS_LEVEL_ROOT_E,
    DBG_UTILS_LEVEL_MODULE_E,
    DBG_UTILS_LEVEL_GENERAL_E,
    DBG_UTILS_LEVEL_USER_DEFINED_1_E,
    DBG_UTILS_LEVEL_USER_DEFINED_2_E,
    DBG_UTILS_LEVEL_USER_DEFINED_3_E,
    DBG_UTILS_LEVEL_USER_DEFINED_4_E,
    DBG_UTILS_LEVEL_SECONDARY_E,
    DBG_UTILS_LEVEL_HEADER_E,
    DBG_UTILS_LEVEL_SUB_HEADER_E,
    DBG_UTILS_LEVEL_DATA_E,
    DBG_UTILS_LEVEL_USER_DEFINED_MIN_E = DBG_UTILS_LEVEL_USER_DEFINED_1_E,
    DBG_UTILS_LEVEL_USER_DEFINED_MAX_E = DBG_UTILS_LEVEL_USER_DEFINED_4_E,
    DBG_UTILS_LEVEL_MIN_E              = DBG_UTILS_LEVEL_ROOT_E,
    DBG_UTILS_LEVEL_MAX_E              = DBG_UTILS_LEVEL_DATA_E,
} dbg_utils_level_e;

typedef struct dbg_utils_table_columns {
    char                 * name;
    int                    width;
    dbg_utils_param_type_e type;
    const void            *data;
} dbg_utils_table_columns_t;

/* Following struct is used as "data" in dbg_utils_table_columns_t for
 * specific types, which require explicit data length.
 */
typedef struct dbg_utils_table_tlv_field {
    unsigned int data_len;              /* Length */
    const void  *data;                  /* Value */
} dbg_utils_table_tlv_field_t;

typedef struct dbg_utils_tree_node {
    uint32_t  left_child;
    uint32_t  right_child;
    boolean_t is_predefined;
} dbg_utils_tree_node_t;

typedef struct dbg_utils_tree {
    uint32_t              root;
    uint32_t              node_count;
    dbg_utils_tree_node_t nodes[DBG_UTILS_NODES_MAX];
} dbg_utils_tree_t;

typedef enum dbg_utils_json_type {
    DBG_UTILS_JSON_TYPE_BOOL_E,
    DBG_UTILS_JSON_TYPE_NULL_E,
    DBG_UTILS_JSON_TYPE_NUMBER_E,
    DBG_UTILS_JSON_TYPE_STRING_E,
    DBG_UTILS_JSON_TYPE_ARRAY_E,
    DBG_UTILS_JSON_TYPE_OBJECT_E,
    DBG_UTILS_JSON_TYPE_RAW_E,
    DBG_UTILS_JSON_TYPE_MIN_E = DBG_UTILS_JSON_TYPE_BOOL_E,
    DBG_UTILS_JSON_TYPE_MAX_E = DBG_UTILS_JSON_TYPE_RAW_E,
} dbg_utils_json_type_e;

/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Function declarations
 ***********************************************/

void dbg_utils_cheat_sheet_init();

void dbg_utils_print_cheat_sheet(FILE *stream);

void dbg_utils_print(FILE *stream, const char *fmt, ...) __attribute__ ((format(printf, 2, 3)));

/*
 * prints field name and value in a fixed alignment
 */
void dbg_utils_print_field(FILE                  *stream,
                           const char            *name,
                           const void            *data,
                           dbg_utils_param_type_e type);

void dbg_utils_print_field_w_len(FILE                  *stream,
                                 const char            *name,
                                 const void            *data,
                                 dbg_utils_param_type_e type,
                                 unsigned int           data_len);

/*
 * Capitalizes strings for headers and titles ("this is an example" -> "This Is An Example")
 */
void dbg_utils_capitalize_string(const char *string,
                                 char       *capitalized_string);

/*
 * prints module header
 * Use for SDK module: Router, Tunnel, Bridge etc.
 * Will be add to cheat sheet as main module.
 */
void dbg_utils_print_module_header(FILE       *stream,
                                   const char *module_name);

/*
 * prints table headline
 * tables with row width greater than DBG_UTILS_SCRN_WIDTH_MAX
 * will be printed as a series of fields with separator line.
 */
void dbg_utils_print_table_headline(FILE                      *stream,
                                    dbg_utils_table_columns_t *columns);

/*
 * prints table data line with line separator
 * tables with row width greater than DBG_UTILS_SCRN_WIDTH_MAX
 * will be printed as a series of fields with separator line.
 * Returns: total line width
 */
int dbg_utils_print_table_data_line(FILE                      *stream,
                                    dbg_utils_table_columns_t *columns);

/*
 * prints counters group header with port ID info
 */
void dbg_utils_print_counters_group_header(FILE       *stream,
                                           const char *cntr_grp_name,
                                           uint32_t    port_id);

/*
 * prints counters group sub-header
 */
void dbg_utils_print_counters_group_sub_header(FILE *stream,
                                               const char *headline_fmt, ...) __attribute__ ((format(printf, 2, 3)));

/*
 * prints counter name and value
 * calls print field function
 */
void dbg_utils_print_counter(FILE       *stream,
                             const char *cntr_name,
                             uint64_t    cntr_value);

/*
 * prints general purpose header.
 * Will be add to cheat sheet as sub-module.
 */
void dbg_utils_print_general_header(FILE       *stream,
                                    const char *general_header);

/*
 * prints secondary header only to plain text mode, compatible
 * to those legacy non-json dump print case.
 */
void dbg_utils_print_plain_text_secondary_header(FILE *stream,
                                                 const char *headline_fmt, ...) __attribute__ ((format(printf, 2, 3)));

/*
 * prints user defined head with levels between DBG_UTILS_LEVEL_GENERAL_E
 * and DBG_UTILS_LEVEL_SECONDARY_E.
 */
void dbg_utils_print_user_defined_header(FILE *stream,
                                         dbg_utils_level_e user_defined_level,
                                         const char *headline_fmt, ...) __attribute__ ((format(printf, 3, 4)));

/*
 * clears json node tree from specified user level to highest header
 * level if there is user defined header starting from input level.
 */
void dbg_utils_clear_user_defined_header(dbg_utils_level_e user_defined_level);

/*
 * prints secondary header
 * provides headers hierarchy.
 * Secondary header will not be include in cheat sheet.
 */
void dbg_utils_print_secondary_header(FILE *stream,
                                      const char *headline, ...) __attribute__ ((format(printf, 2, 3)));

void dbg_utils_draw_binary_tree(FILE                   *stream,
                                const dbg_utils_tree_t* tree);

/*
 * prints current time stamp
 */
void dbg_utils_print_time_stamp(FILE *stream);

/*
 * Print table data line without line separator.
 * Returns total line width
 */
int dbg_utils_print_table_data_line_nosep(FILE *stream, dbg_utils_table_columns_t *columns);

/*
 * Print separator line in table with custom character
 */
void dbg_utils_print_separator_line(FILE *stream, int total_width, char separator_char);


/*
 * Prints error message "Data is currently unavailable".
 */
void dbg_utils_print_data_unavailable(FILE *stream);

/*
 * Clear the children of a json object.
 */
void dbg_utils_clear_json_children(sx_json_t *parent);

/*
 * Set json dump name of the table before printing table headline.
 * It could be called before dbg_utils_print_table_headline(..),
 * but not mandatory. If being called, it could provide clearer
 * structure for json dump.
 */
void dbg_utils_set_json_table_name(char *table_name);

/*
 * Get the JSON object pointer which was latest pushed into the stack.
 * Return NULL if the stack is empty.
 */
sx_json_t * dbg_utils_get_stack_json_top(void);

/*
 * Find the first non-NULL JSON object pointer from json_objects_g[..],
 * starting from 'start_from' level high to lowest level.
 * It should always return a non-NULL pointer after json ROOT is created.
 */
sx_json_t * dbg_utils_get_last_json(dbg_utils_level_e start_from);

/*
 * Push the json object pointer to the stack, so as to be accessed
 * elsewhere and used as a temporary parent object.
 */
int dbg_utils_push_json_to_stack(sx_json_t *object_p);

/*
 * Pop the json object pointer which was latest pushed to the stack.
 */
sx_json_t * dbg_utils_pop_json_from_stack(void);

/*
 * Generate a JSON array object, with a specific array name,
 * for JSON dump only.
 */
int dbg_utils_gen_json_array(sx_json_t  * parent,
                             const char * array_name,
                             sx_json_t ** array_pp);
/*
 * Generate a JSON array element object, with a specific type,
 * for JSON dump only.
 */
int dbg_utils_gen_json_array_elem(sx_json_t           * parent_array,
                                  sx_json_t          ** elem_pp,
                                  dbg_utils_json_type_e data_type,
                                  void                 *value);
#endif /* __DBG_UTILS__ */
