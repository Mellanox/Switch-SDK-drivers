/*
 * Copyright (C) 2013-2021 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SX_UTILS_STATUS_H__
#define __SX_UTILS_STATUS_H__

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/
#define SX_UTILS_CHECK_RANGE(MIN, VAL, MAX) \
    ((MIN <= VAL) && (VAL <= MAX))

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/


/**
 * sx_utils_status_t
 * Enumerated type - Provides functions' return values.
 */
typedef enum sx_utils_status {
    SX_UTILS_STATUS_SUCCESS                    = 0,
    SX_UTILS_STATUS_ERROR                      = 1,
    SX_UTILS_STATUS_SDK_ERROR                  = 2,
    SX_UTILS_STATUS_ALREADY_INITIALIZED        = 3,
    SX_UTILS_STATUS_NOT_INITIALIZED            = 4,
    SX_UTILS_STATUS_ENTRY_NOT_FOUND            = 5,
    SX_UTILS_STATUS_CMD_UNSUPPORTED            = 6,
    SX_UTILS_STATUS_PARAM_ERROR                = 7,
    SX_UTILS_STATUS_PARAM_NULL                 = 8,
    SX_UTILS_STATUS_PARAM_EXCEEDS_RANGE        = 9,
    SX_UTILS_STATUS_NO_RESOURCES               = 10,
    SX_UTILS_STATUS_NO_MEMORY                  = 11,
    SX_UTILS_STATUS_MESSAGE_SIZE_ZERO          = 12,
    SX_UTILS_STATUS_MESSAGE_SIZE_EXCEEDS_LIMIT = 13,
    SX_UTILS_STATUS_ENTRY_ALREADY_EXISTS       = 14,
    SX_UTILS_STATUS_DB_NOT_EMPTY               = 15,
    SX_UTILS_STATUS_MEMORY_ERROR               = 16,
    SX_UTILS_STATUS_PARTIALLY_COMPLETE         = 17,
    SX_UTILS_STATUS_RESOURCE_IN_USE            = 18,
    SX_UTILS_STATUS_MIN                        = SX_UTILS_STATUS_SUCCESS,
    SX_UTILS_STATUS_MAX                        = SX_UTILS_STATUS_RESOURCE_IN_USE,
} sx_utils_status_t;

#define SX_UTILS_STATUS_CHECK_RANGE(STATUS) \
    SX_UTILS_CHECK_RANGE(SX_UTILS_STATUS_MIN, (int)STATUS, SX_UTILS_STATUS_MAX)

/**
 * Macro is used to test if status isn't success.
 */
#ifndef     SX_UTILS_CHECK_FAIL
#define SX_UTILS_CHECK_FAIL(STATUS) (SX_UTILS_STATUS_SUCCESS != (STATUS))
#endif  /*	SX_UTILS_CHECK_FAIL	*/

#ifndef SX_UTILS_CHECK_RC
#define SX_UTILS_CHECK_RC(STATUS, err_text)      \
    if (SX_UTILS_CHECK_FAIL(STATUS)) {           \
        SX_LOG_ERR("Failure - %s.\n", err_text); \
    }
#endif


static __attribute__((__used__)) const char *sx_utils_status2str_arr[] = {
    /* SX_UTILS_STATUS_SUCCESS = 0 */
    "Success",
    /* SX_UTILS_STATUS_ERROR = 1 */
    "Internal Error",
    /* SX_UTILS_STATUS_SDK_ERROR = 2 */
    "SDK Error",
    /* SX_UTILS_STATUS_ALREADY_INITIALIZED = 3 */
    "SwitchX Utils Library already Initialized",
    /* SX_UTILS_STATUS_NOT_INITIALIZED = 4 */
    "SwitchX Utils wasn't Initialized",
    /* SX_UTILS_STATUS_ENTRY_NOT_FOUND = 5 */
    "Entry not found",
    /* SX_UTILS_STATUS_CMD_UNSUPPORTED = 6 */
    "Command unsupported",
    /* SX_UTILS_STATUS_PARAM_ERROR = 7 */
    "Parameter Error",
    /* SX_UTILS_STATUS_PARAM_NULL = 8 */
    "NULL parameter",
    /* SX_UTILS_STATUS_PARAM_EXCEEDS_RANGE = 9 */
    "Parameter exceeds range",
    /*SX_UTILS_STATUS_NO_RESOURCES = 10 */
    "No resource",
    /*SX_UTILS_STATUS_NO_MEMORY = 11*/
    "No More Memory",
    /*SX_UTILS_STATUS_MESSAGE_SIZE_ZERO = 12*/
    "Message Size Exceeds Limit",
    /*SX_UTILS_STATUS_MESSAGE_SIZE_EXCEEDS_LIMIT = 13*/
    "Message Size Exceeds Limit",
    /*SX_UTILS_STATUS_ENTRY_ALREADY_EXISTS = 14*/
    "Entry Already Exists",
    /*SX_UTILS_STATUS_DB_NOT_EMPTY = 15*/
    "Database Not Empty",
    /*SX_UTILS_STATUS_MEMORY_ERROR = 16*/
    "Memory Error",
    /*SX_UTILS_STATUS_PARTIALLY_COMPLETE = 17 */
    "Partially complete",
    /*SX_UTILS_STATUS_RESOURCE_IN_USE = 18 */
    "Resource in use"
};

#define SX_UTILS_STATUS_MSG(STATUS)       \
    SX_UTILS_STATUS_CHECK_RANGE(STATUS) ? \
    sx_utils_status2str_arr[STATUS] : "Unknown return code"

#endif /* __SX_UTILS_STATUS_H__ */
