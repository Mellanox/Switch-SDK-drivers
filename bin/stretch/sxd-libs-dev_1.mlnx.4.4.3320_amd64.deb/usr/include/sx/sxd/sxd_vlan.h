/*
 * Copyright (C) 2010-2021 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_VLAN_H__
#define __SXD_VLAN_H__

#include <complib/cl_types.h>
#include <sx/sxd/sxd_check.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/**
 * VLAN ID.
 */
typedef uint16_t sxd_vid_t;

/************************************************
 *  Macros
 ***********************************************/

/**
 * VLAN ID maximum/minimum values.
 */
#define SXD_VID_MIN   (1)
#define SXD_VID_MAX   (4095)
#define SXD_VID_COUNT (4096)           /* 0 is the default vlan */

#define SXD_VID_CHECK_RANGE(VID) SXD_CHECK_RANGE(SXD_VID_MIN, VID, SXD_VID_MAX)

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

#endif /* __SXD_VLAN_H__ */
