/*
 *  Copyright (C) 2010-2020. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */

#ifndef __SX_ACL_H__
#define __SX_ACL_H__

#include <stdlib.h>
#include <sx/sdk/sx_port.h>
#include <sx/sdk/sx_flow_counter.h>
#include <sx/sdk/sx_policer.h>
#include <resource_manager/resource_manager.h>
#include <sx/sdk/sx_ip.h>
#include <sx/sdk/sx_span.h>
#include <sx/sdk/sx_bridge.h>
#include <sx/sdk/sx_router.h>
#include <sx/sdk/sx_mpls_ilm.h>
#include <sx/sdk/sx_register.h>

#include "sx/sdk/auto_headers/sx_acl_auto.h"

#define GET_NUM_OF_KEYS(key_handle) ((key_handle & FLEX_ACL_KEY_HANDLE_BIT_MASK) >> KEY_HANDLE_MASK_OFFSET)

/**
 * This Macro clears sx_acl_rule_t action to be a NOP
 */
#define CLR_SX_ACL_RULE_ACTION(rule)                                          \
    memset(&rule.action, 0, sizeof(rule.action));                             \
    rule.action.action_type = SX_ACL_ACTION_TYPE_BASIC;                       \
    rule.action.basic_action.terminate_lookup = FALSE;                        \
    rule.action.basic_action.priority = 0;                                    \
    rule.action.basic_action.trap_action = SX_ACL_TRAP_ACTION_PERMIT;         \
    rule.action.basic_action.vlan_prio_action = SX_ACL_VLAN_PRIO_ACTION_NOP;  \
    rule.action.basic_action.flow_counter_id = SX_FLOW_COUNTER_ID_INVALID;    \
    rule.action.basic_action.policer_id = SX_POLICER_ID_INVALID;              \
    rule.action.basic_action.no_ip_routing = SX_ACL_ACTION_ROUTING_ENABLED;   \
    rule.action.basic_action.dont_learn = SX_ACL_ACTION_FDB_LEARNING_ENABLED; \
    rule.action.extended_action.pbs_id = SX_ACL_PBS_ID_INVALID;

#define CLR_SX_ACL_RULE_KEY(key_type, rule) \
    rule.key.type = key_type;               \
    memset(&rule.key.fields, 0, sizeof(rule.key.fields));

#define CLR_SX_ACL_RULE_MASK(key_type, rule) \
    rule.mask.type = key_type;               \
    memset(&rule.mask.fields, 0, sizeof(rule.mask.fields));

typedef struct {
    cl_plock_t                   p_lock;
    sx_acl_pkt_drop_attributes_t acl_drp_trap_mapping[SX_ACL_USER_ID_MAX + 1];
} sx_acl_drop_wjh_trap_index_t;

#endif /* __SX_ACL_H__ */
