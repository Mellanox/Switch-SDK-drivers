/*
 *  Copyright (C) 2010-2021. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */

#ifndef __SWITCH_QUANTUM2_H__
#define __SWITCH_QUANTUM2_H__
/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/


#define QUANTUM2_ACL_INGRESS_GROUPS_MAX                       0
#define QUANTUM2_ACL_ENGRESS_GROUPS_MAX                       0
#define QUANTUM2_ACL_GROUPS_SIZE_MAX                          0
#define QUANTUM2_ACL_GROUPS_NUM_MIN                           0
#define QUANTUM2_ACL_GROUPS_NUM_MAX                           0
#define QUANTUM2_ACL_RULES_BLOCK_MAX                          0
#define QUANTUM2_ACL_RULES_NUM_MIN                            0
#define QUANTUM2_ACL_RULES_NUM_MAX                            0
#define QUANTUM2_ACL_PBS_ENTRIES_MAX                          0
#define QUANTUM2_ACL_PORT_RANGES_MAX                          0
#define QUANTUM2_ACL_REGIONS_MAX                              0
#define QUANTUM2_ACL_INGRESS_TABLES_MAX                       0
#define QUANTUM2_ACL_EGRESS_TABLES_MAX                        0
#define QUANTUM2_ACL_TABLES_MAX                               0
#define QUANTUM2_ACL_VLAN_GROUPS_MAX                          0
#define QUANTUM2_ACL_TRAP_GROUPS_MAX                          0
#define QUANTUM2_ACL_MAX_ACTIONS_PER_RULE                     0
#define QUANTUM2_ACL_MAX_ACTIONS_PER_BASIC_SET                0
#define QUANTUM2_ACL_MAX_ACTIONS_PER_EXTENDED_SET             0
#define QUANTUM2_ACL_EXTENDED_ACTIONS_NUM_MIN                 0
#define QUANTUM2_ACL_EXTENDED_ACTIONS_NUM_MAX                 0
#define QUANTUM2_ACL_PARSING_DEPTH                            0
#define QUANTUM2_ACL_CUSTOM_BYTES_SET_MAX                     0
#define QUANTUM2_ACL_CUSTOM_BYTES_SET_SIZE_MAX                0
#define QUANTUM2_ACL_CUSTOM_BYTES_EXTRACTION_POINT_OFFSET_MAX 0
#define QUANTUM2_ACL_PBILM_ENTRIES_MAX                        0
#define QUANTUM2_ACL_KEY_BLOCKS_MAX                           0
#define QUANTUM2_ACL_ACLS_IN_GROUPS                           0
#define QUANTUM2_ACL_REGION_SIZE_MAX                          0

#define QUANTUM2_ROUTER_RIFS_MAX                      0
#define QUANTUM2_ROUTER_RIFS_DONTCARE                 0
#define QUANTUM2_ROUTER_SUB_PORT_FID_START_INDEX      0
#define QUANTUM2_ROUTER_IPV4_UC_MAX                   0
#define QUANTUM2_ROUTER_IPV4_MC_MAX                   0
#define QUANTUM2_ROUTER_IPV6_UC_MAX                   0
#define QUANTUM2_ROUTER_IPV6_MC_MAX                   0
#define QUANTUM2_ROUTER_ECMP_MAX                      0
#define QUANTUM2_ROUTER_ECMP_HASH_MAX                 0
#define QUANTUM2_ROUTER_NEIGHS_MAX                    0
#define QUANTUM2_ROUTER_ADJ_MAX                       0
#define QUANTUM2_ROUTER_VRID_MAX                      0
#define QUANTUM2_ROUTER_COUNTERS_ID_MAX               0
#define QUANTUM2_ROUTER_NEXT_HOP_MAX                  0
#define QUANTUM2_ROUTER_ECMP_CONTAINER_TOT_WEIGHT_MAX 0
#define QUANTUM2_ROUTER_MAC_PROFILES_MAX              0
#define QUANTUM2_ROUTER_MAC_PREFIX_SIZE               0
#define QUANTUM2_SHSPM_TREE_MAX                       0
#define QUANTUM2_SHSPM_ENTRY_MAX                      0
#define QUANTUM2_MC_RPF_GROUP_MAX                     0
#define QUANTUM2_MC_RPF_GROUP_SIZE                    0
#define QUANTUM2_MC_CONTAINERS_MAX                    0

#define QUANTUM2_IB_ROUTER_LIDS_MAX        49152
#define QUANTUM2_IB_ROUTER_MC_LIDS_NUM_MAX 0x4000   /*16k*/
#define QUANTUM2_IB_ROUTER_UC_LID_NUM_MAX  0xc000   /*48k*/
#define QUANTUM2_IB_PKEYS_TABLE_SIZE       32

#define QUANTUM2_FCF_PORT_DENSITY_MAX 0
#define QUANTUM2_FCF_ZONES_PAIRS_MAX  0
#define QUANTUM2_FCF_ZONES_GROUPS_MAX 0
#define QUANTUM2_FCF_GATEWAY_MAX      0
#define QUANTUM2_FCF_RULES_MAX        0

#define QUANTUM2_PORT_LCL_NUM_MAX             136
#define QUANTUM2_PORT_EXT_NUM_MAX             128    /* Please note the current value must not be greater than the 'MAX_PHYPORT_NUM' and 'MAX_SWITCHX_PORTS' defines */
#define QUANTUM2_PORT_LOG_NUM_MAX             4096
#define QUANTUM2_PORT_MTU_MAX                 KU_CAP_MAX_MTU_SWITCH_IB
#define QUANTUM2_PORT_MTU_MIN                 68
#define QUANTUM2_PORT_STORM_CONTROL_ID_MAX    4
#define QUANTUM2_PORT_VEPA_CHANNELS_NUM_MAX   0
#define QUANTUM2_PORT_SYSTEM_PORTS_MAX        128
#define QUANTUM2_PORT_SYSTEM_PORT_MODULES_MAX 128
#define QUANTUM2_PORT_MAP_WIDTH_MAX           4
#define QUANTUM2_IB_PORTS_MAX                 128 /* in case of 2x we may have 80 ports, for 4x - only 40 */

#define QUANTUM2_LAG_NUM_MAX          0
#define QUANTUM2_LAG_PORT_MEMBERS_MAX 0
#define QUANTUM2_LAG_VECTORS_NUM_MAX  0

#define QUANTUM2_SPAN_SESSION_ID_MAX            6
#define QUANTUM2_SPAN_TRUNCATE_SIZE_MIN         48
#define QUANTUM2_SPAN_TRUNCATE_SIZE_MAX         4088
#define QUANTUM2_SPAN_TRUNCATE_SIZE_GRANULARITY 4

#define QUANTUM2_FDB_MID_MAX         0
#define QUANTUM2_FDB_MID_START_INDEX 0
#define QUANTUM2_FDB_PGT_MAX         0
#define QUANTUM2_FDB_UC_ADDRESS_MAX  0
#define QUANTUM2_FDB_MC_ADDRESS_MAX  0

#define QUANTUM2_FLOODING_TABLE_MAX         2
#define QUANTUM2_FLOODING_TABLE_PER_VID_MAX 1

#define QUANTUM2_SWID_ID_MAX 7

#define QUANTUM2_POLICER_POOL_SIZE               0
#define QUANTUM2_POLICER_HOST_IFC_POOL_SIZE      56
#define QUANTUM2_POLICER_STORM_CONTROL_POOL_SIZE 0
#define QUANTUM2_POLICER_SPAN_POOL_SIZE          0
#define QUANTUM2_POLICER_BS_MIN_VALUE_PACKETS    0
#define QUANTUM2_POLICER_BS_MIN_VALUE_BYTES      0
#define QUANTUM2_POLICER_BS_MAX_VALUE            0

#define QUANTUM2_COS_TRAFFIC_CLASS_MAX             0
#define QUANTUM2_COS_PORT_ETS_SUB_GROUP_MAX        0
#define QUANTUM2_COS_PORT_ETS_GROUP_MAX            0
#define QUANTUM2_COS_PORT_PRIO_MAX                 0
#define QUANTUM2_COS_PORT_COLOR_MAX                0
#define QUANTUM2_COS_PORT_ETS_ELEMENTS_NUM         0
#define QUANTUM2_COS_BUFFER_64K_SIZE_MAX           0
#define QUANTUM2_COS_BUFFER_128K_SIZE_MAX          0
#define QUANTUM2_COS_REDECN_DEFAULT_AQS_WEIGHT     0
#define QUANTUM2_COS_REDECN_RED_DROP_ENABLED       FALSE
#define QUANTUM2_COS_REDECN_SCD                    FALSE
#define QUANTUM2_COS_REDECN_PROFILES_MAX           0
#define QUANTUM2_COS_REDECN_CELL_MULTIPLIER        0
#define QUANTUM2_COS_REDECN_DEFAULT_TC_RED_ENABLED FALSE
#define QUANTUM2_COS_REDECN_DEFAULT_TC_ECN_ENABLED FALSE
#define QUANTUM2_BRIDGE_NUM_MAX                    0

#define QUANTUM2_TOTAL_TCAM                  0
#define QUANTUM2_TOTAL_L3_REPLICATION_MATRIX 0

/*SW TABLE -> HW TABLE MAPPING */

#define QUANTUM2_FDB_UC_MAC_HW_TABLE_TYPE /*sfd*/ RM_HW_TABLE_TYPE_TCAM_E
#define QUANTUM2_FDB_MC_MAC_HW_TABLE_TYPE /*sfd*/ RM_HW_TABLE_TYPE_TCAM_E

#define QUANTUM2_ROUTER_IPV4_UC_HW_TABLE_TYPE/*ruft*/ RM_HW_TABLE_TYPE_TCAM_E
#define QUANTUM2_ROUTER_IPV6_UC_HW_TABLE_TYPE/*ruft*/ RM_HW_TABLE_TYPE_TCAM_E
#define QUANTUM2_ROUTER_IPV4_MC_HW_TABLE_TYPE/*rmft*/ RM_HW_TABLE_TYPE_TCAM_E
#define QUANTUM2_ROUTER_IPV6_MC_HW_TABLE_TYPE/*rmft*/ RM_HW_TABLE_TYPE_TCAM_E

#define QUANTUM2_ROUTER_ARP_IPV4_HW_TABLE_TYPE/*ruht*/ RM_HW_TABLE_TYPE_TCAM_E
#define QUANTUM2_ROUTER_ARP_IPV6_HW_TABLE_TYPE/*ruht*/ RM_HW_TABLE_TYPE_TCAM_E

#define QUANTUM2_ROUTER_MC_REPLICATIONS_HW_TABLE_TYPE/*rigr*/ RM_HW_TABLE_TYPE_REPLICATION_MATRIX_E

#define QUANTUM2_ROUTER_ADJACENCY_HW_TABLE_TYPE/*ratr*/ RM_HW_TABLE_TYPE_ADJACENCY_E

#define QUANTUM2_L2_MC_MIDS_HW_TABLE_TYPE/*smid*/ RM_HW_TABLE_TYPE_TCAM_E

#define QUANTUM2_LAG_VECTORS_HW_TABLE_TYPE/*sldr*/ RM_HW_TABLE_TYPE_TCAM_E

#define QUANTUM2_L2_MC_FLOODING_HW_TABLE_TYPE/*sftr*/ RM_HW_TABLE_TYPE_TCAM_E

#define QUANTUM2_FCF_FORWORDING_HW_TABLE_TYPE/*fftr*/ RM_HW_TABLE_TYPE_TCAM_E

#define QUANTUM2_ACL_RULES_HW_TABLE_TYPE /*ptce*/ RM_HW_TABLE_TYPE_TCAM_E

#define QUANTUM2_ACL_GROUPS_HW_TABLE_TYPE RM_HW_TABLE_TYPE_ACL_GROUP_TABLE_E

#define QUANTUM2_ACL_EXTENDED_ACTIONS_HW_TABLE_TYPE RM_HW_TABLE_TYPE_INVALID


/*phy_entry_cost per table */

#define QUANTUM2_FDB_UC_MAC_HW_ENTRY_COST 1
#define QUANTUM2_FDB_MC_MAC_HW_ENTRY_COST 1

#define QUANTUM2_ROUTER_IPV4_UC_HW_ENTRY_COST/*ruft*/ 1
#define QUANTUM2_ROUTER_IPV6_UC_HW_ENTRY_COST/*ruft*/ 1
#define QUANTUM2_ROUTER_IPV4_MC_HW_ENTRY_COST/*rmft*/ 1
#define QUANTUM2_ROUTER_IPV6_MC_HW_ENTRY_COST/*rmft*/ 1

#define QUANTUM2_ROUTER_ARP_IPV4_HW_ENTRY_COST/*ruft*/ 1
#define QUANTUM2_ROUTER_ARP_IPV6_HW_ENTRY_COST/*ruft*/ 1

#define QUANTUM2_ROUTER_MC_REPLICATIONS_HW_ENTRY_COST/*rigr*/ 1

#define QUANTUM2_ROUTER_ADJACENCY_HW_ENTRY_COST/*ratr*/ 1

#define QUANTUM2_L2_MC_MIDS_HW_ENTRY_COST/*smid*/ 1

#define QUANTUM2_LAG_VECTORS_ENTRY_COST 1

#define QUANTUM2_L2_MC_FLOODING_HW_ENTRY_COST/*sftr*/ 1

#define QUANTUM2_FCF_FORWORDING_HW_ENTRY_COST/*fftr*/ 1

#define QUANTUM2_ACL_RULES_HW_ENTRY_COST /*ptce*/ 1

#define QUANTUM2_ACL_GROUPS_HW_ENTRY_COST           1
#define QUANTUM2_ACL_EXTENDED_ACTIONS_HW_ENTRY_COST 0

#define QUANTUM2_BUFFERS_TOTAL_MEMORY            0
#define QUANTUM2_DESCRIPTOR_BUFFERS_TOTAL_MEMORY 0
#define QUANTUM2_MAX_TOTAL_HEADROOM_SIZE         0
#define QUANTUM2_HEADROOM_NUM_BUFF_PER_PORT      9
/* Shared buffers - QUANTUM2 */
#define QUANTUM2_SHARED_BUFF_NUM_ING_POOL_PER_PORT 0
#define QUANTUM2_SHARED_BUFF_NUM_EGR_POOL_PER_PORT 0
#define QUANTUM2_SHARED_BUFF_NUM_MC_POOL_PER_PORT  0
#define QUANTUM2_SHARED_BUFF_NUM_ING_DESC_PER_PORT 0
#define QUANTUM2_SHARED_BUFF_NUM_EGR_DESC_PER_PORT 0
#define QUANTUM2_SHARED_BUFF_NUM_MANAGMENT_POOL    0
#define QUANTUM2_SHARED_BUFF_TOTAL_NUM_POOL        0
#define QUANTUM2_SHARED_HEADROOM_NUM_POOL          0
#define QUANTUM2_SHARED_BUFF_NUM_EGR_BUFF_PER_PORT 0
#define QUANTUM2_SHARED_BUFF_NUM_ING_BUFF_PER_PORT 0
#define QUANTUM2_SHARED_BUFF_MAX_POOL_SIZE         0

#define QUANTUM2_SHARED_BUFF_DEF_ING_DATA_POOL_SIZE QUANTUM2_SHARED_BUFF_MAX_POOL_SIZE
#define QUANTUM2_SHARED_BUFF_DEF_EGR_DATA_POOL_SIZE QUANTUM2_SHARED_BUFF_MAX_POOL_SIZE
#define QUANTUM2_SHARED_BUFF_DEF_ING_MGMT_POOL_SIZE (0)
#define QUANTUM2_SHARED_BUFF_DEF_EGR_MGMT_POOL_SIZE (0)
#define QUANTUM2_SHARED_BUFF_DEF_ING_DESC_POOL_SIZE (0)           /* 32 banks, 4280 descriptors per bank */
#define QUANTUM2_SHARED_BUFF_DEF_EGR_DESC_POOL_SIZE (0)           /* 32 banks, 4280 descriptors per bank */

#define QUANTUM2_SHARED_BUFF_PORT_NUM_MAX           0
#define QUANTUM2_SHARED_BUFF_TCLASS_NUM_MAX         0
#define QUANTUM2_SHARED_BUFF_RET_STATISTICS_NUM_MAX 0
#define QUANTUM2_BUFF_UNIT_SIZE                     96
#define QUANTUM2_SHARED_BUFF_MC_MAX_NUM_PRIO        0

/* COS SB port buffers profile defines */
#define QUANTUM2_SHARED_BUFF_MAX_ALPHA_0_E        0x00
#define QUANTUM2_SHARED_BUFF_MAX_ALPHA_1_4_E      0x06
#define QUANTUM2_SHARED_BUFF_MAX_ALPHA_8_E        0x0B
#define QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E 0xFF
#define QUANTUM2_SHARED_BUFF_FULL_POOL            100

#define QUANTUM2_KVD_SIZE           0
#define QUANTUM2_KVD_MAX_BLOCK_SIZE 0

#define QUANTUM2_NUM_HW_CPU_INGRESS_TCLASS_MAX 32
#define QUANTUM2_NUM_HW_DR_PATHS_MAX           0
#define QUANTUM2_NUM_HW_TRAP_GROUPS_MAX        5
#define QUANTUM2_NUM_HW_TOTAL_TRAP_GROUPS_MAX  5
#define QUANTUM2_TRAP_GROUP_PRIORITY_MIN       0
#define QUANTUM2_TRAP_GROUP_PRIORITY_MAX       4
#define QUANTUM2_NUM_RDQS_MAX                  32
#define QUANTUM2_NUM_CPU_TCLASS                4
#define QUANTUM2_KVD_HASH_SINGLE_MIN_SIZE      0
#define QUANTUM2_KVD_HASH_DOUBLE_MIN_SIZE      0
#define QUANTUM2_KVD_GUARANTEED_CAPACITY       0
#define QUANTUM2_KVD_LINEAR_VIRTUAL_TABLE_SIZE 0

#define QUANTUM2_RESERVED_EMPTY_MID 0
#define QUANTUM2_PGT_SIZE           0
#define QUANTUM2_RMPE_SIZE          0
#define QUANTUM_FIDS_MAX            0

/* SW Counter Allocation - Only used on some chips */
#define QUANTUM2_CNTR_BANK_PAIRS         0
#define QUANTUM2_CNTR_LINES_PER_BANK     0
#define QUANTUM2_CNTR_LINES_FLOW_PKT     0
#define QUANTUM2_CNTR_TYPE_FLOW_PKT      0
#define QUANTUM2_CNTR_LINES_FLOW_BYTE    0
#define QUANTUM2_CNTR_TYPE_FLOW_BYTE     0
#define QUANTUM2_CNTR_LINES_FLOW_BOTH    0
#define QUANTUM2_CNTR_TYPE_FLOW_BOTH     0
#define QUANTUM2_CNTR_LINES_RIF_BASIC    0
#define QUANTUM2_CNTR_TYPE_RIF_BASIC     0
#define QUANTUM2_CNTR_LINES_RIF_MIXED_1  0
#define QUANTUM2_CNTR_TYPE_RIF_MIXED_1   0
#define QUANTUM2_CNTR_LINES_RIF_MIXED_2  0
#define QUANTUM2_CNTR_TYPE_RIF_MIXED_2   0
#define QUANTUM2_CNTR_LINES_RIF_ENHANCED 0
#define QUANTUM2_CNTR_TYPE_RIF_ENHANCED  0


/* Tunnel */
#define QUANTUM2_NUM_MAX_TUNNEL_IPINIP         0   /* Not supported */
#define QUANTUM2_NUM_MAX_TUNNEL_NVE            0   /* Not supported */
#define QUANTUM2_TUNNEL_NVE_GS_FLOOD_MAX       0   /* Not supported */
#define QUANTUM2_TUNNEL_NVE_GS_MC_MAX          0 /* Not supported */
#define QUANTUM2_TUNNEL_TNUMT_IPV6_RECORDS_MAX 0   /* Not supported */

/* IGMP V3 */
#define QUANTUM2_IGMP_V3_NUM_MAX_ENTRIES 0        /* Not supported */

/* Telemetry */
#define QUANTUM2_TELE_HISTOGRAM_NUM_MAX                                      0
#define QUANTUM2_TELE_HISTOGRAM_QUEUE_DEPTH_BINS                             0
#define QUANTUM2_TELE_HISTOGRAM_SAMPLE_TIME_RESOLUTION_MAX                   0
#define QUANTUM2_TELE_HISTOGRAM_BIN_SIZE_RESOLUTION_LINEAR_MIN               0
#define QUANTUM2_TELE_HISTOGRAM_BIN_SIZE_RESOLUTION_EXPONENT_MIN             0
#define QUANTUM2_TELE_HISTOGRAM_BIN_SIZE_RESOLUTION_QUEUE_DEPTH_LINEAR_MAX   0
#define QUANTUM2_TELE_HISTOGRAM_BIN_SIZE_RESOLUTION_QUEUE_DEPTH_EXPONENT_MAX 0
#define QUANTUM2_TELE_HISTOGRAM_BIN_SIZE_RESOLUTION_LATENCY_LINEAR_MAX       0
#define QUANTUM2_TELE_HISTOGRAM_BIN_SIZE_RESOLUTION_LATENCY_EXPONENT_MAX     0
#define QUANTUM2_TELE_HISTOGRAM_BIN_SIZE_RESOLUTION_MAX                      0
#define QUANTUM2_TELE_HISTOGRAM_DATA_BIN_BITS_MAX                            23
#define QUANTUM2_TELE_HISTOGRAM_MIN_BOUNDARY_MIN                             1
#define QUANTUM2_TELE_THRESHOLD_NUM_MAX \
    (QUANTUM2_LAG_NUM_MAX +             \
     QUANTUM2_PORT_EXT_NUM_MAX) *       \
    QUANTUM2_COS_TRAFFIC_CLASS_MAX
#define QUANTUM2_TELE_THRESHOLD_THR_MAX            0xFFFFFF
#define QUANTUM2_TELE_THRESHOLD_LATENCY_THR_MAX    0
#define QUANTUM2_TELE_THRESHOLD_LATENCY_TABLE_SIZE 0

/* BFD */
#define QUANTUM2_BFD_SESSION_NUM_MAX 0

/* Register module */
#define QUANTUM2_GP_REGISTER_NUM_MAX 0

#define QUANTUM2_INVALID_SW_TABLE_TYPE RM_SDK_TABLE_TYPE_INVALID_E

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

static const rm_resources_t rm_resource_quantum2 = {
    /*23*/
    QUANTUM2_ACL_INGRESS_GROUPS_MAX,
    QUANTUM2_ACL_ENGRESS_GROUPS_MAX,
    QUANTUM2_ACL_GROUPS_SIZE_MAX,
    QUANTUM2_ACL_GROUPS_NUM_MAX,
    QUANTUM2_ACL_RULES_BLOCK_MAX,
    QUANTUM2_ACL_PBS_ENTRIES_MAX,
    QUANTUM2_ACL_PORT_RANGES_MAX,
    QUANTUM2_ACL_REGIONS_MAX,
    QUANTUM2_ACL_INGRESS_TABLES_MAX,
    QUANTUM2_ACL_EGRESS_TABLES_MAX,
    QUANTUM2_ACL_TABLES_MAX,
    QUANTUM2_ACL_VLAN_GROUPS_MAX,
    QUANTUM2_ACL_TRAP_GROUPS_MAX,
    QUANTUM2_ACL_MAX_ACTIONS_PER_RULE,
    QUANTUM2_ACL_MAX_ACTIONS_PER_BASIC_SET,
    QUANTUM2_ACL_MAX_ACTIONS_PER_EXTENDED_SET,
    QUANTUM2_ACL_PARSING_DEPTH,
    QUANTUM2_ACL_CUSTOM_BYTES_SET_MAX,
    QUANTUM2_ACL_CUSTOM_BYTES_SET_SIZE_MAX,
    QUANTUM2_ACL_CUSTOM_BYTES_EXTRACTION_POINT_OFFSET_MAX,
    QUANTUM2_ACL_PBILM_ENTRIES_MAX,
    QUANTUM2_ACL_KEY_BLOCKS_MAX,
    QUANTUM2_ACL_ACLS_IN_GROUPS,
    QUANTUM2_ACL_REGION_SIZE_MAX,

    /*26*/
    QUANTUM2_ROUTER_RIFS_MAX,
    QUANTUM2_ROUTER_RIFS_DONTCARE,
    QUANTUM2_ROUTER_SUB_PORT_FID_START_INDEX,
    QUANTUM2_ROUTER_IPV4_UC_MAX,
    QUANTUM2_ROUTER_IPV4_MC_MAX,
    QUANTUM2_ROUTER_IPV6_UC_MAX,
    QUANTUM2_ROUTER_IPV6_MC_MAX,
    QUANTUM2_ROUTER_ECMP_MAX,
    QUANTUM2_ROUTER_ECMP_HASH_MAX,
    QUANTUM2_ROUTER_ADJ_MAX,
    QUANTUM2_ROUTER_NEIGHS_MAX,
    QUANTUM2_ROUTER_VRID_MAX,
    QUANTUM2_ROUTER_COUNTERS_ID_MAX,
    QUANTUM2_ROUTER_NEXT_HOP_MAX,
    QUANTUM2_ROUTER_ECMP_CONTAINER_TOT_WEIGHT_MAX,
    QUANTUM2_ROUTER_MAC_PROFILES_MAX,
    QUANTUM2_ROUTER_MAC_PREFIX_SIZE,
    QUANTUM2_SHSPM_TREE_MAX,
    QUANTUM2_SHSPM_ENTRY_MAX,
    QUANTUM2_MC_RPF_GROUP_MAX,
    QUANTUM2_MC_RPF_GROUP_SIZE,
    QUANTUM2_MC_CONTAINERS_MAX,
    {
        .rash_ecmp_valid_size_arr = {0},
    },

    /*5*/
    QUANTUM2_FCF_PORT_DENSITY_MAX,
    QUANTUM2_FCF_ZONES_PAIRS_MAX,
    QUANTUM2_FCF_ZONES_GROUPS_MAX,
    QUANTUM2_FCF_GATEWAY_MAX,
    QUANTUM2_FCF_RULES_MAX,

    /*10*/
    QUANTUM2_PORT_LCL_NUM_MAX,
    QUANTUM2_PORT_EXT_NUM_MAX,
    QUANTUM2_PORT_LOG_NUM_MAX,
    QUANTUM2_PORT_MTU_MAX,
    QUANTUM2_PORT_MTU_MIN,
    QUANTUM2_PORT_STORM_CONTROL_ID_MAX,
    QUANTUM2_PORT_VEPA_CHANNELS_NUM_MAX,
    QUANTUM2_PORT_SYSTEM_PORTS_MAX,
    QUANTUM2_PORT_SYSTEM_PORT_MODULES_MAX,
    QUANTUM2_PORT_MAP_WIDTH_MAX,

    /*6*/
    QUANTUM2_LAG_NUM_MAX,
    QUANTUM2_LAG_PORT_MEMBERS_MAX,

    QUANTUM2_SPAN_SESSION_ID_MAX,
    QUANTUM2_SPAN_SESSION_ID_MAX,
    QUANTUM2_SPAN_TRUNCATE_SIZE_MIN,
    QUANTUM2_SPAN_TRUNCATE_SIZE_MAX,
    QUANTUM2_SPAN_TRUNCATE_SIZE_GRANULARITY,

    QUANTUM2_FDB_MID_MAX,
    QUANTUM2_FDB_MID_START_INDEX,
    QUANTUM2_FDB_PGT_MAX,
    QUANTUM2_FDB_UC_ADDRESS_MAX,
    QUANTUM2_FDB_MC_ADDRESS_MAX,

    QUANTUM2_FLOODING_TABLE_MAX,
    QUANTUM2_FLOODING_TABLE_PER_VID_MAX,

    QUANTUM2_COS_TRAFFIC_CLASS_MAX,
    QUANTUM2_COS_PORT_ETS_SUB_GROUP_MAX,
    QUANTUM2_COS_PORT_ETS_GROUP_MAX,
    QUANTUM2_COS_PORT_PRIO_MAX,
    QUANTUM2_COS_PORT_COLOR_MAX,
    QUANTUM2_COS_PORT_ETS_ELEMENTS_NUM,

    QUANTUM2_COS_BUFFER_64K_SIZE_MAX,
    QUANTUM2_COS_BUFFER_128K_SIZE_MAX,

    QUANTUM2_COS_REDECN_DEFAULT_AQS_WEIGHT,
    QUANTUM2_COS_REDECN_RED_DROP_ENABLED,
    QUANTUM2_COS_REDECN_SCD,
    QUANTUM2_COS_REDECN_PROFILES_MAX,
    QUANTUM2_COS_REDECN_CELL_MULTIPLIER,
    QUANTUM2_COS_REDECN_DEFAULT_TC_RED_ENABLED,
    QUANTUM2_COS_REDECN_DEFAULT_TC_ECN_ENABLED,

    QUANTUM2_SWID_ID_MAX,

    QUANTUM2_POLICER_POOL_SIZE,
    QUANTUM2_POLICER_HOST_IFC_POOL_SIZE,
    QUANTUM2_POLICER_STORM_CONTROL_POOL_SIZE,
    QUANTUM2_POLICER_SPAN_POOL_SIZE,
    QUANTUM2_POLICER_BS_MIN_VALUE_PACKETS,
    QUANTUM2_POLICER_BS_MIN_VALUE_BYTES,
    QUANTUM2_POLICER_BS_MAX_VALUE,
    QUANTUM2_POLICER_BS_MAX_VALUE,

    QUANTUM2_KVD_SIZE,
    QUANTUM2_KVD_MAX_BLOCK_SIZE,
    QUANTUM2_KVD_HASH_SINGLE_MIN_SIZE,
    QUANTUM2_KVD_HASH_DOUBLE_MIN_SIZE,
    QUANTUM2_KVD_GUARANTEED_CAPACITY,
    QUANTUM2_KVD_LINEAR_VIRTUAL_TABLE_SIZE,

    QUANTUM2_RESERVED_EMPTY_MID,
    QUANTUM2_PGT_SIZE,
    QUANTUM2_RMPE_SIZE,
    QUANTUM_FIDS_MAX,

    QUANTUM2_BRIDGE_NUM_MAX,

    /* Shared buffer */
    QUANTUM2_BUFFERS_TOTAL_MEMORY,
    QUANTUM2_DESCRIPTOR_BUFFERS_TOTAL_MEMORY,
    QUANTUM2_MAX_TOTAL_HEADROOM_SIZE,
    QUANTUM2_HEADROOM_NUM_BUFF_PER_PORT,

    /* Shared buffers - Condor */
    QUANTUM2_SHARED_BUFF_NUM_ING_POOL_PER_PORT,
    QUANTUM2_SHARED_BUFF_NUM_EGR_POOL_PER_PORT,
    QUANTUM2_SHARED_BUFF_NUM_MC_POOL_PER_PORT,
    QUANTUM2_SHARED_BUFF_NUM_ING_DESC_PER_PORT,
    QUANTUM2_SHARED_BUFF_NUM_EGR_DESC_PER_PORT,
    QUANTUM2_SHARED_BUFF_NUM_MANAGMENT_POOL,
    QUANTUM2_SHARED_BUFF_TOTAL_NUM_POOL,
    QUANTUM2_SHARED_HEADROOM_NUM_POOL,
    QUANTUM2_SHARED_BUFF_NUM_EGR_BUFF_PER_PORT,
    QUANTUM2_SHARED_BUFF_NUM_ING_BUFF_PER_PORT,
    QUANTUM2_SHARED_BUFF_MAX_POOL_SIZE,
    QUANTUM2_SHARED_BUFF_DEF_ING_DATA_POOL_SIZE,
    QUANTUM2_SHARED_BUFF_DEF_EGR_DATA_POOL_SIZE,
    QUANTUM2_SHARED_BUFF_DEF_ING_MGMT_POOL_SIZE,
    QUANTUM2_SHARED_BUFF_DEF_EGR_MGMT_POOL_SIZE,
    QUANTUM2_SHARED_BUFF_DEF_ING_DESC_POOL_SIZE,
    QUANTUM2_SHARED_BUFF_DEF_EGR_DESC_POOL_SIZE,

    /*** COS SB profile ***/
    {
        /** ingress data pool **/

        /* iPort.pool MIN Configuration */
        (10 * 1024),

        /* iPort.pool MAX Configuration */
        QUANTUM2_SHARED_BUFF_MAX_ALPHA_8_E,

        /* iPort.PGs MIN Configuration */
        {
            /* { size, is_lossy, xon, xoff, override_headroom, headroom (in jumbo frames) } */
            { 0, TRUE, 0, 0, FALSE, 0 },                 /* PG 0*/
            { 0, TRUE, 0, 0, TRUE, 0 },                  /* PG 1*/
            { 0, TRUE, 0, 0, TRUE, 0 },                  /* PG 2*/
            { 0, TRUE, 0, 0, TRUE, 0 },                  /* PG 3*/
            { 0, TRUE, 0, 0, TRUE, 0 },                  /* PG 4*/
            { 0, TRUE, 0, 0, TRUE, 0 },                  /* PG 5*/
            { 0, TRUE, 0, 0, TRUE, 0 },                  /* PG 6*/
            { 0, TRUE, 0, 0, TRUE, 0 },                  /* PG 7*/
            { 0, 0, 0, 0, 0, 0 },                        /* reserved */
            { (10 * 1024), TRUE, 0, 0, TRUE, 1 },        /* PG 9 - Control */
        },

        /* iPort.PGs MAX Configuration */
        {
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_8_E,       /* PG 0*/
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_0_E,       /* PG 1*/
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_0_E,       /* PG 2*/
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_0_E,       /* PG 3*/
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_0_E,       /* PG 4*/
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_0_E,       /* PG 5*/
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_0_E,       /* PG 6*/
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_0_E,       /* PG 7*/
            0,                                         /* reserved*/
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_8_E        /* PG 9 - Control*/
        },

        /** egress data pool **/

        /* ePort.pool MIN Configuration */
        (10 * 1024),

        /* ePort.pool MAX Configuration */
        QUANTUM2_SHARED_BUFF_MAX_ALPHA_8_E,

        /* ePort.TCs MIN Configuration */
        {
            (1 * 1024),       /* TC 0 */
            (1 * 1024),       /* TC 1 */
            (1 * 1024),       /* TC 2 */
            (1 * 1024),       /* TC 3 */
            (1 * 1024),       /* TC 4 */
            (1 * 1024),       /* TC 5 */
            (1 * 1024),       /* TC 6 */
            (1 * 1024),       /* TC 7 */
            (1 * 1024),       /* TC 8 */
            (1 * 1024),       /* TC 9 */
            (1 * 1024),       /* TC 10 */
            (1 * 1024),       /* TC 11 */
            (1 * 1024),       /* TC 12 */
            (1 * 1024),       /* TC 13 */
            (1 * 1024),       /* TC 14 */
            (1 * 1024),       /* TC 15 */
            (1 * 1024)        /* TC 16 - Control */
        },

        /* ePort.TCs MAX Configuration */
        {
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_8_E,       /* TC 0 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_8_E,       /* TC 1 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_8_E,       /* TC 2 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_8_E,       /* TC 3 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_8_E,       /* TC 4 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_8_E,       /* TC 5 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_8_E,       /* TC 6 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_8_E,       /* TC 7 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_8_E,       /* TC 8 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_8_E,       /* TC 9 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_8_E,       /* TC 10 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_8_E,       /* TC 11 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_8_E,       /* TC 12 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_8_E,       /* TC 13 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_8_E,       /* TC 14 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_8_E,       /* TC 15 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_8_E        /* TC 16 - control*/
        },

        /* MC.SPs MIN Configuration */
        {
            0,       /* SP 0 */
            0,       /* SP 1 */
            0,       /* SP 2 */
            0,       /* SP 3 */
            0,       /* SP 4 */
            0,       /* SP 5 */
            0,       /* SP 6 */
            0,       /* SP 7 */
            0,       /* SP 8 */
            0,       /* SP 9 */
            0,       /* SP 10 */
            0,       /* SP 11 */
            0,       /* SP 12 */
            0,       /* SP 13 */
            0        /* SP 14 */
        },

        /* MC.SPs MAX Configuration */
        {
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_1_4_E,       /* SP 0 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_1_4_E,       /* SP 1 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_1_4_E,       /* SP 2 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_1_4_E,       /* SP 3 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_1_4_E,       /* SP 4 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_1_4_E,       /* SP 5 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_1_4_E,       /* SP 6 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_1_4_E,       /* SP 7 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_1_4_E,       /* SP 8 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_1_4_E,       /* SP 9 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_1_4_E,       /* SP 10 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_1_4_E,       /* SP 11 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_1_4_E,       /* SP 12 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_1_4_E,       /* SP 13 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_1_4_E        /* SP 14 */
        },

        /** ingress management pool **/

        /* iPort_mgmt.pool MIN Configuration */
        0,

        /* iPort_mgmt.pool MAX Configuration */
        QUANTUM2_SHARED_BUFF_MAX_ALPHA_8_E,

        /** egress management pool **/

        /* ePort_mgmt.pool MIN Configuration */
        0,

        /* ePort_mgmt.pool MAX Configuration */
        QUANTUM2_SHARED_BUFF_MAX_ALPHA_8_E,

        /* CPU_port.TCs (0-6) MIN Configuration */
        (1 * 1024),

        /* CPU_port.TCs (0-6) MAX Configuration */
        QUANTUM2_SHARED_BUFF_MAX_ALPHA_8_E,

        /** multicast pool **/

        /* ePort.MC_pool MIN Configuration */
        (10 * 1024),

        /* ePort.MC_pool MAX Configuration */
        (90 * 1024),

        /* ePort.MC_pool MIN Configuration (MC aware == TRUE) */
        {
            0,       /* TC 8 */
            0,       /* TC 9 */
            0,       /* TC 10 */
            0,       /* TC 11 */
            0,       /* TC 12 */
            0,       /* TC 13 */
            0,       /* TC 14 */
            0        /* TC 15 */
        },

        /* ePort.MC_pool MAX Configuration (MC aware == TRUE): size is taken from pool properties (100%) */
        {
            QUANTUM2_SHARED_BUFF_FULL_POOL,       /* TC 8 */
            QUANTUM2_SHARED_BUFF_FULL_POOL,       /* TC 9 */
            QUANTUM2_SHARED_BUFF_FULL_POOL,       /* TC 10 */
            QUANTUM2_SHARED_BUFF_FULL_POOL,       /* TC 11 */
            QUANTUM2_SHARED_BUFF_FULL_POOL,       /* TC 12 */
            QUANTUM2_SHARED_BUFF_FULL_POOL,       /* TC 13 */
            QUANTUM2_SHARED_BUFF_FULL_POOL,       /* TC 14 */
            QUANTUM2_SHARED_BUFF_FULL_POOL        /* TC 15 */
        },

        /** ingress descriptor pool (1 lane) **/

        /* iPort_desc.pool MIN Configuration */
        5,

        /* iPort_desc.pool MAX Configuration */
        QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E,

        /* iPort_desc.PGs MIN Configuration */
        {
            1,       /* PG 0*/
            1,       /* PG 1*/
            1,       /* PG 2*/
            1,       /* PG 3*/
            1,       /* PG 4*/
            1,       /* PG 5*/
            1,       /* PG 6*/
            1,       /* PG 7*/
            0,       /* reserved*/
            1        /* PG 9 - Control*/
        },

        /* iPort_desc.PGs MAX Configuration */
        {
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* PG 0*/
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* PG 1*/
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* PG 2*/
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* PG 3*/
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* PG 4*/
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* PG 5*/
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* PG 6*/
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* PG 7*/
            0,                                                /* reserved*/
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E        /* PG 9 - Control*/
        },

        /** egress descriptor pool (1 lane) **/

        /* ePort_desc.pool MIN Configuration */
        48,

        /* ePort_desc.pool MAX Configuration */
        QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E,

        /* ePort_desc.TCs MIN Configuration */
        {
            5,       /* TC 0 */
            5,       /* TC 1 */
            5,       /* TC 2 */
            5,       /* TC 3 */
            5,       /* TC 4 */
            5,       /* TC 5 */
            5,       /* TC 6 */
            5,       /* TC 7 */
            5,       /* TC 8 */
            5,       /* TC 9 */
            5,       /* TC 10 */
            5,       /* TC 11 */
            5,       /* TC 12 */
            5,       /* TC 13 */
            5,       /* TC 14 */
            5,       /* TC 15 */
            5        /* TC 16 - control*/
        },

        /* ePort_desc.TCs MAX Configuration */
        {
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 0 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 1 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 2 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 3 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 4 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 5 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 6 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 7 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 8 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 9 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 10 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 11 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 12 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 13 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 14 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 15 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E        /* TC 16 - control*/
        },

        /** ingress descriptor pool (4 lanes) **/

        /* iPort_desc.pool MIN Configuration */
        5,

        /* iPort_desc.pool MAX Configuration */
        QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E,

        /* iPort_desc.PGs MIN Configuration */
        {
            1,       /* PG 0*/
            1,       /* PG 1*/
            1,       /* PG 2*/
            1,       /* PG 3*/
            1,       /* PG 4*/
            1,       /* PG 5*/
            1,       /* PG 6*/
            1,       /* PG 7*/
            0,       /* reserved*/
            1        /* PG 9 - Control*/
        },

        /* iPort_desc.PGs MAX Configuration */
        {
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* PG 0*/
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* PG 1*/
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* PG 2*/
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* PG 3*/
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* PG 4*/
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* PG 5*/
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* PG 6*/
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* PG 7*/
            0,                                                /* reserved*/
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E        /* PG 9 - Control*/
        },

        /** egress descriptor pool (4 lanes) **/

        /* ePort_desc.pool MIN Configuration */
        96,

        /* ePort_desc.pool MAX Configuration */
        QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E,

        /* ePort_desc.TCs MIN Configuration */
        {
            5,       /* TC 0 */
            5,       /* TC 1 */
            5,       /* TC 2 */
            5,       /* TC 3 */
            5,       /* TC 4 */
            5,       /* TC 5 */
            5,       /* TC 6 */
            5,       /* TC 7 */
            5,       /* TC 8 */
            5,       /* TC 9 */
            5,       /* TC 10 */
            5,       /* TC 11 */
            5,       /* TC 12 */
            5,       /* TC 13 */
            5,       /* TC 14 */
            5,       /* TC 15 */
            5        /* TC 16 - control*/
        },

        /* ePort_desc.TCs MAX Configuration */
        {
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 0 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 1 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 2 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 3 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 4 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 5 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 6 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 7 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 8 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 9 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 10 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 11 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 12 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 13 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 14 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 15 */
            QUANTUM2_SHARED_BUFF_MAX_ALPHA_INFINITY_E        /* TC 16 - control*/
        }
    },

    QUANTUM2_SHARED_BUFF_PORT_NUM_MAX,
    QUANTUM2_SHARED_BUFF_TCLASS_NUM_MAX,
    QUANTUM2_SHARED_BUFF_RET_STATISTICS_NUM_MAX,
    QUANTUM2_BUFF_UNIT_SIZE,
    QUANTUM2_SHARED_BUFF_MC_MAX_NUM_PRIO,

    {
        /* RM_SDK_TABLE_TYPE_UC_MAC_E = 0 */
        {QUANTUM2_FDB_UC_ADDRESS_MAX,
         QUANTUM2_FDB_UC_ADDRESS_MAX,
         QUANTUM2_FDB_UC_MAC_HW_ENTRY_COST,
         QUANTUM2_FDB_UC_MAC_HW_TABLE_TYPE,
         QUANTUM2_INVALID_SW_TABLE_TYPE,
         FALSE},

        /* RM_SDK_TABLE_TYPE_MC_MAC_E = 1 */
        {QUANTUM2_FDB_MC_ADDRESS_MAX,
         QUANTUM2_FDB_MC_ADDRESS_MAX,
         QUANTUM2_FDB_MC_MAC_HW_ENTRY_COST,
         QUANTUM2_FDB_MC_MAC_HW_TABLE_TYPE,
         QUANTUM2_INVALID_SW_TABLE_TYPE,
         FALSE},

        /* RM_SDK_TABLE_TYPE_FIB_IPV4_UC_E = 2 */
        {QUANTUM2_ROUTER_IPV4_UC_MAX,
         QUANTUM2_ROUTER_IPV4_UC_MAX,
         QUANTUM2_ROUTER_IPV4_UC_HW_ENTRY_COST,
         QUANTUM2_ROUTER_IPV4_UC_HW_TABLE_TYPE,
         QUANTUM2_INVALID_SW_TABLE_TYPE,
         FALSE},

        /* RM_SDK_TABLE_TYPE_FIB_IPV6_UC_E = 3 */
        {QUANTUM2_ROUTER_IPV6_UC_MAX,
         QUANTUM2_ROUTER_IPV6_UC_MAX,
         QUANTUM2_ROUTER_IPV6_UC_HW_ENTRY_COST,
         QUANTUM2_ROUTER_IPV6_UC_HW_TABLE_TYPE,
         QUANTUM2_INVALID_SW_TABLE_TYPE,
         FALSE},

        /* RM_SDK_TABLE_TYPE_FIB_IPV4_MC_E = 4 */
        {QUANTUM2_ROUTER_IPV4_MC_MAX,
         QUANTUM2_ROUTER_IPV4_MC_MAX,
         QUANTUM2_ROUTER_IPV4_MC_HW_ENTRY_COST,
         QUANTUM2_ROUTER_IPV4_MC_HW_TABLE_TYPE,
         QUANTUM2_INVALID_SW_TABLE_TYPE,
         FALSE},

        /* RM_SDK_TABLE_TYPE_FIB_IPV6_MC_E = 5 */
        {QUANTUM2_ROUTER_IPV6_MC_MAX,
         QUANTUM2_ROUTER_IPV6_MC_MAX,
         QUANTUM2_ROUTER_IPV6_MC_HW_ENTRY_COST,
         QUANTUM2_ROUTER_IPV6_MC_HW_TABLE_TYPE,
         QUANTUM2_INVALID_SW_TABLE_TYPE,
         FALSE},

        /* RM_SDK_TABLE_TYPE_ARP_IPV4_E = 6 */
        {QUANTUM2_ROUTER_NEIGHS_MAX,
         QUANTUM2_ROUTER_NEIGHS_MAX,
         QUANTUM2_ROUTER_ARP_IPV4_HW_ENTRY_COST,
         QUANTUM2_ROUTER_ARP_IPV4_HW_TABLE_TYPE,
         QUANTUM2_INVALID_SW_TABLE_TYPE,
         FALSE},

        /* RM_SDK_TABLE_TYPE_ARP_IPV6_E = 7 */
        {QUANTUM2_ROUTER_NEIGHS_MAX,
         QUANTUM2_ROUTER_NEIGHS_MAX,
         QUANTUM2_ROUTER_ARP_IPV6_HW_ENTRY_COST,
         QUANTUM2_ROUTER_ARP_IPV6_HW_TABLE_TYPE,
         QUANTUM2_INVALID_SW_TABLE_TYPE,
         FALSE},

        /* RM_SDK_TABLE_TYPE_L3_MC_REPLICATIONS_E = 8 */
        {QUANTUM2_TOTAL_L3_REPLICATION_MATRIX,
         QUANTUM2_TOTAL_L3_REPLICATION_MATRIX,
         QUANTUM2_ROUTER_MC_REPLICATIONS_HW_ENTRY_COST,
         QUANTUM2_ROUTER_MC_REPLICATIONS_HW_TABLE_TYPE,
         QUANTUM2_INVALID_SW_TABLE_TYPE,
         FALSE},

        /* RM_SDK_TABLE_TYPE_ADJACENCY_E = 9 */
        {QUANTUM2_ROUTER_ADJ_MAX,
         QUANTUM2_ROUTER_ADJ_MAX,
         QUANTUM2_ROUTER_ADJACENCY_HW_ENTRY_COST,
         QUANTUM2_ROUTER_ADJACENCY_HW_TABLE_TYPE,
         QUANTUM2_INVALID_SW_TABLE_TYPE,
         FALSE},

        /* RM_SDK_TABLE_TYPE_L2_MC_VECTORS_E = 10 */
        {QUANTUM2_FDB_MID_MAX,
         QUANTUM2_FDB_MID_MAX,
         QUANTUM2_L2_MC_MIDS_HW_ENTRY_COST,
         QUANTUM2_L2_MC_MIDS_HW_TABLE_TYPE,
         QUANTUM2_INVALID_SW_TABLE_TYPE,
         FALSE},

        /* RM_SDK_TABLE_TYPE_LAG_VECTORS_E = 11 */
        {QUANTUM2_LAG_VECTORS_NUM_MAX,
         QUANTUM2_LAG_VECTORS_NUM_MAX,
         QUANTUM2_LAG_VECTORS_ENTRY_COST,
         QUANTUM2_LAG_VECTORS_HW_TABLE_TYPE,
         QUANTUM2_INVALID_SW_TABLE_TYPE,
         FALSE},

        /* RM_SDK_TABLE_TYPE_FLOOD_VECTORS_E = 12 */
        {QUANTUM2_FLOODING_TABLE_MAX,
         QUANTUM2_FLOODING_TABLE_MAX,
         QUANTUM2_L2_MC_FLOODING_HW_ENTRY_COST,
         QUANTUM2_L2_MC_FLOODING_HW_TABLE_TYPE,
         QUANTUM2_INVALID_SW_TABLE_TYPE,
         FALSE},


        /* RM_SDK_TABLE_TYPE_ACL_EXTENDED_ACTIONS_E = 13 */
        {QUANTUM2_ACL_EXTENDED_ACTIONS_NUM_MIN,
         QUANTUM2_ACL_EXTENDED_ACTIONS_NUM_MAX,
         QUANTUM2_ACL_EXTENDED_ACTIONS_HW_ENTRY_COST,
         QUANTUM2_ACL_EXTENDED_ACTIONS_HW_TABLE_TYPE,
         QUANTUM2_INVALID_SW_TABLE_TYPE,
         FALSE},

        /* RM_SDK_TABLE_TYPE_ACL_PBS_E = 14 */
        {0, 0, 0, 0, QUANTUM2_INVALID_SW_TABLE_TYPE, FALSE},

        /* RM_SDK_TABLE_TYPE_ERIF_LIST_E = 15 */
        {0, 0, 0, 0, QUANTUM2_INVALID_SW_TABLE_TYPE, FALSE},

        /* RM_SDK_TABLE_TYPE_TUNNEL_RTDP_E = 16 */
        {0, 0, 0, 0, QUANTUM2_INVALID_SW_TABLE_TYPE, FALSE},


        /* RM_SDK_TABLE_TYPE_ILM_E = 17 */
        {0, 0, 0, 0, QUANTUM2_INVALID_SW_TABLE_TYPE, FALSE},

        /* RM_SDK_TABLE_TYPE_RPF_GROUP_E = 18 */
        {0, 0, 0, 0, QUANTUM2_INVALID_SW_TABLE_TYPE, FALSE},

        /* RM_SDK_TABLE_TYPE_VLAN_E = 19 */
        {0, 0, 0, 0, QUANTUM2_INVALID_SW_TABLE_TYPE, FALSE},

        /* RM_SDK_TABLE_TYPE_VPORTS_E = 20 */
        {0, 0, 0, 0, QUANTUM2_INVALID_SW_TABLE_TYPE, FALSE},

        /* RM_SDK_TABLE_TYPE_FID_E = 21 */
        {0, 0, 0, 0, QUANTUM2_INVALID_SW_TABLE_TYPE, FALSE},

        /* RM_SDK_TABLE_TYPE_VNI_E = 22 */
        {0, 0, 0, 0, QUANTUM2_INVALID_SW_TABLE_TYPE, FALSE},

        /* RM_SDK_TABLE_TYPE_TUNNEL_IPV6_FDB_E = 23 */
        {0, 0, 0, 0, QUANTUM2_INVALID_SW_TABLE_TYPE, FALSE},

        /* RM_SDK_TABLE_TYPE_MPLS_NHLFE_E = 24 */
        {0, 0, 0, 0, QUANTUM2_INVALID_SW_TABLE_TYPE, FALSE},

        /* RM_SDK_TABLE_TYPE_PB_MPLS_ILM_E = 25 */
        {0, 0, 0, 0, QUANTUM2_INVALID_SW_TABLE_TYPE, FALSE},

        /* RM_SDK_TABLE_TYPE_NVE_IPV6_LIST_E = 26 */
        {0, 0, 0, 0, QUANTUM2_INVALID_SW_TABLE_TYPE, FALSE},

        /* RM_SDK_TABLE_TYPE_ACL_E = 27 */
        {0, 0, 0, 0, QUANTUM2_INVALID_SW_TABLE_TYPE, FALSE},

        /* RM_SDK_TABLE_TYPE_RIPS_E = 28 */
        {0, 0, 0, 0, QUANTUM2_INVALID_SW_TABLE_TYPE, FALSE},

        /* RM_SDK_TABLE_TYPE_IGMP_V3_IPv4_E = 29 */
        {0, 0, 0, 0, QUANTUM2_INVALID_SW_TABLE_TYPE, FALSE},

        /* RM_SDK_TABLE_TYPE_IGMP_V3_IPv6_E = 30 */
        {0, 0, 0, 0, QUANTUM2_INVALID_SW_TABLE_TYPE, FALSE},

        /* RM_SDK_TABLE_TYPE_DECAP_RULES_IPv4_E = 31 */
        {0, 0, 0, 0, QUANTUM2_INVALID_SW_TABLE_TYPE, FALSE},

        /* RM_SDK_TABLE_TYPE_DECAP_RULES_IPv6_E = 32 */
        {0, 0, 0, 0, QUANTUM2_INVALID_SW_TABLE_TYPE, FALSE},

        /* RM_SDK_TABLE_TYPE_ACL_RULES_TWO_KEY_BLOCK_E = 33 */
        {0, 0, 0, 0, QUANTUM2_INVALID_SW_TABLE_TYPE, FALSE},

        /* RM_SDK_TABLE_TYPE_ACL_RULES_FOUR_KEY_BLOCK_E = 34 */
        {0, 0, 0, 0, QUANTUM2_INVALID_SW_TABLE_TYPE, FALSE},

        /* RM_SDK_TABLE_TYPE_ACL_RULES_SIX_KEY_BLOCK_E = 35 */
        {0, 0, 0, 0, QUANTUM2_INVALID_SW_TABLE_TYPE, FALSE},

        /* RM_SDK_TABLE_TYPE_RIF_COUNTER_BASIC_E = 36 */
        {0, 0, 0, 0, QUANTUM2_INVALID_SW_TABLE_TYPE, FALSE},

        /* RM_SDK_TABLE_TYPE_RIF_COUNTER_MIXED_E = 37 */
        {0, 0, 0, 0, QUANTUM2_INVALID_SW_TABLE_TYPE, FALSE},

        /* RM_SDK_TABLE_TYPE_RIF_COUNTER_ENHANCED_E = 38 */
        {0, 0, 0, 0, QUANTUM2_INVALID_SW_TABLE_TYPE, FALSE},

        /* RM_SDK_TABLE_TYPE_FLOW_COUNTER_E = 39 */
        {0, 0, 0, 0, QUANTUM2_INVALID_SW_TABLE_TYPE, FALSE},

        /* RM_SDK_TABLE_TYPE_ACL_GROUPS_E = 40 */
        {QUANTUM2_ACL_GROUPS_NUM_MIN,
         QUANTUM2_ACL_GROUPS_NUM_MAX,
         QUANTUM2_ACL_GROUPS_HW_ENTRY_COST,
         QUANTUM2_ACL_GROUPS_HW_TABLE_TYPE,
         QUANTUM2_INVALID_SW_TABLE_TYPE,
         FALSE},

        /* RM_SDK_TABLE_TYPE_FLEX_PARSER_TRANSITION_E */
        {0, 0, 0, 0, QUANTUM2_INVALID_SW_TABLE_TYPE, FALSE},

        /* RM_SDK_TABLE_TYPE_FLEX_PARSER_PROGRAM_E */
        {0, 0, 0, 0, QUANTUM2_INVALID_SW_TABLE_TYPE, FALSE},

        /* RM_SDK_TABLE_TYPE_INTERNAL_E = 41 Divider between int & ext*/
        {0, 0, 0, 0, QUANTUM2_INVALID_SW_TABLE_TYPE, FALSE},

        /* RM_SDK_TABLE_TYPE_ACL_RULES_E = 42 */
        {QUANTUM2_ACL_RULES_NUM_MIN,
         QUANTUM2_ACL_RULES_NUM_MAX,
         QUANTUM2_ACL_RULES_HW_ENTRY_COST,
         QUANTUM2_ACL_RULES_HW_TABLE_TYPE,
         QUANTUM2_INVALID_SW_TABLE_TYPE,
         FALSE},

        /* RM_SDK_TABLE_TYPE_DECAP_RULES_E = 43 */
        {0, 0, 0, 0, QUANTUM2_INVALID_SW_TABLE_TYPE, FALSE},

        /* RM_SDK_TABLE_TYPE_IGMP_V3_E = 44 */
        {0, 0, 0, 0, QUANTUM2_INVALID_SW_TABLE_TYPE, FALSE},

        /* RM_SDK_TABLE_TYPE_A_TCAM_ONE_KEY_BLOCK_E = 45 */
        {0, 0, 0, 0, QUANTUM2_INVALID_SW_TABLE_TYPE, FALSE},

        /* RM_SDK_TABLE_TYPE_A_TCAM_TWO_KEYS_BLOCK_E = 46 */
        {0, 0, 0, 0, QUANTUM2_INVALID_SW_TABLE_TYPE, FALSE},

        /* RM_SDK_TABLE_TYPE_A_TCAM_FOUR_KEYS_BLOCK_E = 47 */
        {0, 0, 0, 0, QUANTUM2_INVALID_SW_TABLE_TYPE, FALSE},

        /* RM_SDK_TABLE_TYPE_A_TCAM_SIX_KEYS_BLOCK_E = 48 */
        {0, 0, 0, 0, QUANTUM2_INVALID_SW_TABLE_TYPE, FALSE},

        /* RM_SDK_TABLE_TYPE_FCF_FORWORDING_E = 49 */
        {QUANTUM2_FCF_RULES_MAX,
         QUANTUM2_FCF_RULES_MAX,
         QUANTUM2_FCF_FORWORDING_HW_ENTRY_COST,
         QUANTUM2_FCF_FORWORDING_HW_TABLE_TYPE,
         QUANTUM2_INVALID_SW_TABLE_TYPE,
         FALSE},

        /* RM_SDK_TABLE_TYPE_RMID_MANAGER_E = 50 */
        {0, 0, 0, 0, QUANTUM2_INVALID_SW_TABLE_TYPE, FALSE},

        /* RM_SDK_TABLE_TYPE_NVE_MC_LIST_E = 51 */
        {0, 0, 0, 0, QUANTUM2_INVALID_SW_TABLE_TYPE, FALSE},

        /* RM_SDK_TABLE_TYPE_SMID_MANAGER_E = 52 */
        {0, 0, 0, 0, QUANTUM2_INVALID_SW_TABLE_TYPE, FALSE},

        /* RM_SDK_TABLE_TYPE_FIB_IPV4_MC_SYSTEM_E = 53 */
        {0, 0, 0, 0, QUANTUM2_INVALID_SW_TABLE_TYPE, FALSE},

        /* RM_SDK_TABLE_TYPE_FIB_IPV6_MC_SYSTEM_E = 54 */
        {0, 0, 0, 0, QUANTUM2_INVALID_SW_TABLE_TYPE, FALSE},

        /* RM_SDK_TABLE_TYPE_RIF_COUNTER_E = 55 */
        {0, 0, 0, 0, QUANTUM2_INVALID_SW_TABLE_TYPE, FALSE},

        /* RM_SDK_TABLE_TYPE_IGMP_V3_PRUNE_E = 56 */
        {0, 0, 0, 0, QUANTUM2_INVALID_SW_TABLE_TYPE, FALSE},

        /* RM_SDK_TABLE_TYPE_ACLS_IN_GROUPS_E = 57 */
        {0, 0, 0, 0, QUANTUM2_INVALID_SW_TABLE_TYPE, FALSE},
    },

    {
        {TRUE, QUANTUM2_TOTAL_TCAM},
        {FALSE, 0},
        {FALSE, 0},
        {FALSE, 0},
        {TRUE, QUANTUM2_ROUTER_ADJ_MAX},
        {TRUE, QUANTUM2_TOTAL_L3_REPLICATION_MATRIX},
        {TRUE, QUANTUM2_ACL_GROUPS_NUM_MAX},
        {FALSE, 0},
        {FALSE, 0},
        {FALSE, 0},
        {FALSE, 0},
        {FALSE, 0},
        {FALSE, 0},
    },

    /*16*/
    QUANTUM2_CNTR_BANK_PAIRS,
    QUANTUM2_CNTR_LINES_PER_BANK,
    QUANTUM2_CNTR_LINES_FLOW_PKT,
    QUANTUM2_CNTR_TYPE_FLOW_PKT,
    QUANTUM2_CNTR_LINES_FLOW_BYTE,
    QUANTUM2_CNTR_TYPE_FLOW_BYTE,
    QUANTUM2_CNTR_LINES_FLOW_BOTH,
    QUANTUM2_CNTR_TYPE_FLOW_BOTH,
    QUANTUM2_CNTR_LINES_RIF_BASIC,
    QUANTUM2_CNTR_TYPE_RIF_BASIC,
    QUANTUM2_CNTR_LINES_RIF_MIXED_1,
    QUANTUM2_CNTR_TYPE_RIF_MIXED_1,
    QUANTUM2_CNTR_LINES_RIF_MIXED_2,
    QUANTUM2_CNTR_TYPE_RIF_MIXED_2,
    QUANTUM2_CNTR_LINES_RIF_ENHANCED,
    QUANTUM2_CNTR_TYPE_RIF_ENHANCED,

    /*10*/
    QUANTUM2_IB_PKEYS_TABLE_SIZE,


    QUANTUM2_IB_ROUTER_LIDS_MAX,
    QUANTUM2_IB_ROUTER_MC_LIDS_NUM_MAX,
    QUANTUM2_IB_ROUTER_UC_LID_NUM_MAX,

    /*1*/
    QUANTUM2_IB_PORTS_MAX,

    /*5*/
    QUANTUM2_NUM_HW_CPU_INGRESS_TCLASS_MAX,
    QUANTUM2_NUM_HW_DR_PATHS_MAX,
    QUANTUM2_NUM_HW_TRAP_GROUPS_MAX,
    QUANTUM2_NUM_HW_TOTAL_TRAP_GROUPS_MAX,
    QUANTUM2_TRAP_GROUP_PRIORITY_MIN,
    QUANTUM2_TRAP_GROUP_PRIORITY_MAX,
    QUANTUM2_NUM_RDQS_MAX,
    QUANTUM2_NUM_CPU_TCLASS,

    /* Tunnel */
    QUANTUM2_NUM_MAX_TUNNEL_IPINIP,
    QUANTUM2_NUM_MAX_TUNNEL_NVE,
    QUANTUM2_TUNNEL_NVE_GS_FLOOD_MAX,
    QUANTUM2_TUNNEL_NVE_GS_MC_MAX,
    QUANTUM2_TUNNEL_TNUMT_IPV6_RECORDS_MAX,

    /* IGMP V3 */
    QUANTUM2_IGMP_V3_NUM_MAX_ENTRIES,

    /* Telemetry */
    QUANTUM2_TELE_HISTOGRAM_NUM_MAX,
    QUANTUM2_TELE_HISTOGRAM_QUEUE_DEPTH_BINS,
    QUANTUM2_TELE_HISTOGRAM_SAMPLE_TIME_RESOLUTION_MAX,
    QUANTUM2_TELE_HISTOGRAM_BIN_SIZE_RESOLUTION_LINEAR_MIN,
    QUANTUM2_TELE_HISTOGRAM_BIN_SIZE_RESOLUTION_EXPONENT_MIN,
    QUANTUM2_TELE_HISTOGRAM_BIN_SIZE_RESOLUTION_QUEUE_DEPTH_LINEAR_MAX,
    QUANTUM2_TELE_HISTOGRAM_BIN_SIZE_RESOLUTION_QUEUE_DEPTH_EXPONENT_MAX,
    QUANTUM2_TELE_HISTOGRAM_BIN_SIZE_RESOLUTION_LATENCY_LINEAR_MAX,
    QUANTUM2_TELE_HISTOGRAM_BIN_SIZE_RESOLUTION_LATENCY_EXPONENT_MAX,
    QUANTUM2_TELE_HISTOGRAM_DATA_BIN_BITS_MAX,
    QUANTUM2_TELE_HISTOGRAM_MIN_BOUNDARY_MIN,
    QUANTUM2_TELE_THRESHOLD_THR_MAX,
    QUANTUM2_TELE_THRESHOLD_LATENCY_THR_MAX,
    QUANTUM2_TELE_THRESHOLD_LATENCY_TABLE_SIZE,

    /* BFD */
    QUANTUM2_BFD_SESSION_NUM_MAX,

    /* Register module */
    QUANTUM2_GP_REGISTER_NUM_MAX,
};
/************************************************
 *  Function declarations
 ***********************************************/


#endif /*__SWITCH_QUANTUM2_H__*/
