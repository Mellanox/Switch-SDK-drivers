/*
 *  Copyright (C) 2010-2021. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */


#ifndef SX_EVENT_ID_H_
#define SX_EVENT_ID_H_

#include <sx/sdk/sx_check.h>
#include <sx/sdk/sx_port.h>
#include <sx/sdk/sx_ip.h>
#include <sx/sdk/sx_router.h>
#include <resource_manager/resource_manager.h>
#include <sx/sdk/sx_tele.h>
#include <sx/sdk/sx_dbg.h>
#include <sx/sxd/sx_bfd_ctrl_cmds.h>
#include <sx/sdk/sx_tunnel_id.h>
#include <sx/sdk/sx_tunnel.h>
#include <sx/sdk/sx_mgmt.h>
#include "sx/sdk/auto_headers/sx_event_id_auto.h"

#define SX_OBJECT_TYPE_CHECK_RANGE(OBJECT_TYPE) \
    SX_CHECK_RANGE(SX_OBJECT_TYPE_MIN,          \
                   OBJECT_TYPE,                 \
                   SX_OBJECT_TYPE_MAX)          \

/**
 * sx_event_info_t union is used to store events data
 */
typedef union sx_event_info {
    sx_event_pude_t                            pude;                                  /**< pude event data */
    sx_event_pmpe_t                            pmpe;                                  /**< pmpe event data */
    sx_event_flae_t                            flae;                                  /**< flae event data */
    sx_event_ferr_t                            ferr;                                  /**< ferr event data */
    sx_event_tmpw_t                            tmpw;                                  /**< tmpw event data */
    sx_event_health_notification_t             sdk_health; /**< FW mfde event data */
    sx_event_need_to_resolve_arp_t             need_to_resolve_arp;
    sx_event_no_need_to_resolve_arp_t          no_need_to_resolve_arp;
    sx_rm_sdk_table_notification_t             rm_sdk_table_notification;
    sx_rm_hw_table_notification_t              rm_hw_table_notification;
    sx_router_neigh_activity_notification_t    router_neigh_activity_notification;
    sx_router_mc_route_activity_notification_t router_mc_route_activity_notification;
    sx_fdb_mc_ip_addr_activity_notification_t  fdb_mc_ip_addr_activity_notification;
    sx_event_queue_threshold_crossed_t         queue_threshold_crossed;
    sx_event_ber_monitor_t                     ber_monitor;
    sx_event_bfd_timeout_t                     bfd_timeout;
    sx_event_ibfmr_t                           ibfmr;                                 /**< ibfmr event data */
    sx_event_port_lag_changes_t                port_lag_changes;
    sx_event_port_added_deleted_t              port_added_or_deleted;
    sx_event_deleted_object_t                  deleted_object;
    sx_event_api_logger_t                      api_logger_info;
    sx_event_mocs_done_t                       mocs_done_info;
    sx_bulk_cntr_done_notification_t           bulk_cntr_done_info;
    sx_event_tsde_t                            tsde;
    sx_event_pmlpe_t                           pmlpe;
    sx_event_dsdsc_t                           dsdsc;
} sx_event_info_t;

#endif /* SX_EVENT_ID_H_ */
