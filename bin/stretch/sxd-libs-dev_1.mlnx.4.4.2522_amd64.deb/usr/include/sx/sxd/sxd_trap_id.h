/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2021 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_TRAP_ID_H__
#define __SXD_TRAP_ID_H__

#include <sx/sxd/kernel_user.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

typedef enum sxd_trap_action {
    SXD_TRAP_ACTION_IGNORE = 0,
    SXD_TRAP_ACTION_TRAP_2_CPU = 1,
    SXD_TRAP_ACTION_MIRROR_2_CPU = 2,
    SXD_TRAP_ACTION_DISCARD = 3,
    SXD_TRAP_ACTION_SOFT_DISCARD = 4,
    SXD_TRAP_ACTION_TRAP_SOFT_DISCARD = 5,
    SXD_TRAP_ACTION_EXCEPTION_TRAP = 6,
    SXD_TRAP_ACTION_FWD_DISCARD_ERROR = 7,
    SXD_TRAP_ACTION_SET_FW_DEFAULT = 15,

    SXD_TRAP_ACTION_MIN = SXD_TRAP_ACTION_IGNORE,
    SXD_TRAP_ACTION_MAX = SXD_TRAP_ACTION_SET_FW_DEFAULT
} sxd_trap_action_t;

typedef enum sxd_trap_group {
    SXD_TRAP_GROUP_0 = 0,
    SXD_TRAP_GROUP_1 = 1,
    SXD_TRAP_GROUP_2 = 2,
    SXD_TRAP_GROUP_3 = 3,
    SXD_TRAP_GROUP_4 = 4, /* EMADs only */
    SXD_TRAP_GROUP_DISABLE = 0xff,

    SXD_TRAP_GROUP_MIN = SXD_TRAP_GROUP_0,
    SXD_TRAP_GROUP_MAX = SXD_TRAP_GROUP_4
} sxd_trap_group_t;

/************************************************
 *  Macros
 ***********************************************/

#define SXD_TRAP_ID_COUNT SXD_TRAP_ID_MAX - SXD_TRAP_ID_MIN + 1

#define SXD_TRAPS_NUM SXD_TRAP_ID_COUNT

#define SXD_TRAP_GROUP_COUNT SXD_TRAP_GROUP_MAX - SXD_TRAP_GROUP_MIN + 1

#define SXD_TRAP_CHECK_TRAP_RANGE(TRAP_ID) SXD_CHECK_RANGE(SXD_TRAP_ID_MIN, TRAP_ID, SXD_TRAP_ID_MAX)
#define SXD_TRAP_CHECK_TRAP_ACTION_RANGE(TRAP_ACTION) \
    SXD_CHECK_RANGE(SXD_TRAP_ACTION_MIN,              \
                    TRAP_ACTION,                      \
                    SXD_TRAP_ACTION_MAX)
#define SXD_TRAP_CHECK_TRAP_GROUP_RANGE(TRAP_GROUP) \
    SXD_CHECK_RANGE(SXD_TRAP_GROUP_MIN,             \
                    TRAP_GROUP,                     \
                    SXD_TRAP_GROUP_MAX)

#define SXD_TRAP_CHECK_TRAP_IPTRAP_RANGE(TRAP_ID) \
    SXD_CHECK_RANGE(SXD_TRAP_ID_IPTRAP_MIN,       \
                    TRAP_ID,                      \
                    SXD_TRAP_ID_IPTRAP_MAX)
#define SXD_TRAP_CHECK_TRAP_ACL_RANGE(TRAP_ID) SXD_CHECK_RANGE(SXD_TRAP_ID_ACL_MIN, TRAP_ID, SXD_TRAP_ID_ACL_MAX)

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

#endif /* __SXD_TRAP_ID_H__ */
