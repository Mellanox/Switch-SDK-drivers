/*
 * Copyright (C) Mellanox Technologies, Ltd. 2008-2020 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */
/*
 * THIS FILE IS AUTO GENERATED.
 * DO NOT MAKE ANY CHANGES!
 * They will be erased with next update.

 */

/**
 *  This function performs access register ICSR operations.
 *
 * @param[in] icsr_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_icsr(struct ku_icsr_reg       *icsr_reg_data,
                                 sxd_reg_meta_t           *reg_meta,
                                 uint32_t                  data_num,
                                 sxd_completion_handler_t  handler,
                                 void                     *context);

/**
 *  This function performs access register IICR operations.
 *
 * @param[in] iicr_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_iicr(struct ku_iicr_reg       *iicr_reg_data,
                                 sxd_reg_meta_t           *reg_meta,
                                 uint32_t                  data_num,
                                 sxd_completion_handler_t  handler,
                                 void                     *context);

/**
 *  This function performs access register IGCR operations.
 *
 * @param[in] igcr_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_igcr(struct ku_igcr_reg       *igcr_reg_data,
                                 sxd_reg_meta_t           *reg_meta,
                                 uint32_t                  data_num,
                                 sxd_completion_handler_t  handler,
                                 void                     *context);

/**
 *  This function performs access register PEMRBT operations.
 *
 * @param[in] pemrbt_reg_data - The registers data
 * @param[in] reg_meta        - The registers meta data
 * @param[in] data_num        - Number of access operations to perform
 * @param[in] handler         - Handler function for calling when the operation completes
 * @param[in] context         - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_pemrbt(struct ku_pemrbt_reg     *pemrbt_reg_data,
                                   sxd_reg_meta_t           *reg_meta,
                                   uint32_t                  data_num,
                                   sxd_completion_handler_t  handler,
                                   void                     *context);

/**
 *  This function performs access register PECNEE operations.
 *
 * @param[in] pecnee_reg_data - The registers data
 * @param[in] reg_meta        - The registers meta data
 * @param[in] data_num        - Number of access operations to perform
 * @param[in] handler         - Handler function for calling when the operation completes
 * @param[in] context         - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_pecnee(struct ku_pecnee_reg     *pecnee_reg_data,
                                   sxd_reg_meta_t           *reg_meta,
                                   uint32_t                  data_num,
                                   sxd_completion_handler_t  handler,
                                   void                     *context);

/**
 *  This function performs access register MTMP operations.
 *
 * @param[in] mtmp_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_mtmp(struct ku_mtmp_reg       *mtmp_reg_data,
                                 sxd_reg_meta_t           *reg_meta,
                                 uint32_t                  data_num,
                                 sxd_completion_handler_t  handler,
                                 void                     *context);

/**
 *  This function performs access register TIEEM operations.
 *
 * @param[in] tieem_reg_data - The registers data
 * @param[in] reg_meta       - The registers meta data
 * @param[in] data_num       - Number of access operations to perform
 * @param[in] handler        - Handler function for calling when the operation completes
 * @param[in] context        - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_tieem(struct ku_tieem_reg      *tieem_reg_data,
                                  sxd_reg_meta_t           *reg_meta,
                                  uint32_t                  data_num,
                                  sxd_completion_handler_t  handler,
                                  void                     *context);

/**
 *  This function performs access register MOGCR operations.
 *
 * @param[in] mogcr_reg_data - The registers data
 * @param[in] reg_meta       - The registers meta data
 * @param[in] data_num       - Number of access operations to perform
 * @param[in] handler        - Handler function for calling when the operation completes
 * @param[in] context        - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_mogcr(struct ku_mogcr_reg      *mogcr_reg_data,
                                  sxd_reg_meta_t           *reg_meta,
                                  uint32_t                  data_num,
                                  sxd_completion_handler_t  handler,
                                  void                     *context);

/**
 *  This function performs access register RTDP operations.
 *
 * @param[in] rtdp_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_rtdp(struct ku_rtdp_reg       *rtdp_reg_data,
                                 sxd_reg_meta_t           *reg_meta,
                                 uint32_t                  data_num,
                                 sxd_completion_handler_t  handler,
                                 void                     *context);

/**
 *  This function performs access register PECNER operations.
 *
 * @param[in] pecner_reg_data - The registers data
 * @param[in] reg_meta        - The registers meta data
 * @param[in] data_num        - Number of access operations to perform
 * @param[in] handler         - Handler function for calling when the operation completes
 * @param[in] context         - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_pecner(struct ku_pecner_reg     *pecner_reg_data,
                                   sxd_reg_meta_t           *reg_meta,
                                   uint32_t                  data_num,
                                   sxd_completion_handler_t  handler,
                                   void                     *context);

/**
 *  This function performs access register TNEEM operations.
 *
 * @param[in] tneem_reg_data - The registers data
 * @param[in] reg_meta       - The registers meta data
 * @param[in] data_num       - Number of access operations to perform
 * @param[in] handler        - Handler function for calling when the operation completes
 * @param[in] context        - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_tneem(struct ku_tneem_reg      *tneem_reg_data,
                                  sxd_reg_meta_t           *reg_meta,
                                  uint32_t                  data_num,
                                  sxd_completion_handler_t  handler,
                                  void                     *context);

/**
 *  This function performs access register TNIFR operations.
 *
 * @param[in] tnifr_reg_data - The registers data
 * @param[in] reg_meta       - The registers meta data
 * @param[in] data_num       - Number of access operations to perform
 * @param[in] handler        - Handler function for calling when the operation completes
 * @param[in] context        - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_tnifr(struct ku_tnifr_reg      *tnifr_reg_data,
                                  sxd_reg_meta_t           *reg_meta,
                                  uint32_t                  data_num,
                                  sxd_completion_handler_t  handler,
                                  void                     *context);

/**
 *  This function performs access register PEAPS operations.
 *
 * @param[in] peaps_reg_data - The registers data
 * @param[in] reg_meta       - The registers meta data
 * @param[in] data_num       - Number of access operations to perform
 * @param[in] handler        - Handler function for calling when the operation completes
 * @param[in] context        - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_peaps(struct ku_peaps_reg      *peaps_reg_data,
                                  sxd_reg_meta_t           *reg_meta,
                                  uint32_t                  data_num,
                                  sxd_completion_handler_t  handler,
                                  void                     *context);

/**
 *  This function performs access register HCOT operations.
 *
 * @param[in] hcot_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_hcot(struct ku_hcot_reg       *hcot_reg_data,
                                 sxd_reg_meta_t           *reg_meta,
                                 uint32_t                  data_num,
                                 sxd_completion_handler_t  handler,
                                 void                     *context);

/**
 *  This function performs access register CHLTM operations.
 *
 * @param[in] chltm_reg_data - The registers data
 * @param[in] reg_meta       - The registers meta data
 * @param[in] data_num       - Number of access operations to perform
 * @param[in] handler        - Handler function for calling when the operation completes
 * @param[in] context        - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_chltm(struct ku_chltm_reg      *chltm_reg_data,
                                  sxd_reg_meta_t           *reg_meta,
                                  uint32_t                  data_num,
                                  sxd_completion_handler_t  handler,
                                  void                     *context);

/**
 *  This function performs access register HMON operations.
 *
 * @param[in] hmon_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_hmon(struct ku_hmon_reg       *hmon_reg_data,
                                 sxd_reg_meta_t           *reg_meta,
                                 uint32_t                  data_num,
                                 sxd_completion_handler_t  handler,
                                 void                     *context);

/**
 *  This function performs access register MGPIR operations.
 *
 * @param[in] mgpir_reg_data - The registers data
 * @param[in] reg_meta       - The registers meta data
 * @param[in] data_num       - Number of access operations to perform
 * @param[in] handler        - Handler function for calling when the operation completes
 * @param[in] context        - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_mgpir(struct ku_mgpir_reg      *mgpir_reg_data,
                                  sxd_reg_meta_t           *reg_meta,
                                  uint32_t                  data_num,
                                  sxd_completion_handler_t  handler,
                                  void                     *context);

/**
 *  This function performs access register TNQDR operations.
 *
 * @param[in] tnqdr_reg_data - The registers data
 * @param[in] reg_meta       - The registers meta data
 * @param[in] data_num       - Number of access operations to perform
 * @param[in] handler        - Handler function for calling when the operation completes
 * @param[in] context        - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_tnqdr(struct ku_tnqdr_reg      *tnqdr_reg_data,
                                  sxd_reg_meta_t           *reg_meta,
                                  uint32_t                  data_num,
                                  sxd_completion_handler_t  handler,
                                  void                     *context);

/**
 *  This function performs access register SFFP operations.
 *
 * @param[in] sffp_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_sffp(struct ku_sffp_reg       *sffp_reg_data,
                                 sxd_reg_meta_t           *reg_meta,
                                 uint32_t                  data_num,
                                 sxd_completion_handler_t  handler,
                                 void                     *context);

/**
 *  This function performs access register MPCIR operations.
 *
 * @param[in] mpcir_reg_data - The registers data
 * @param[in] reg_meta       - The registers meta data
 * @param[in] data_num       - Number of access operations to perform
 * @param[in] handler        - Handler function for calling when the operation completes
 * @param[in] context        - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_mpcir(struct ku_mpcir_reg      *mpcir_reg_data,
                                  sxd_reg_meta_t           *reg_meta,
                                  uint32_t                  data_num,
                                  sxd_completion_handler_t  handler,
                                  void                     *context);

/**
 *  This function performs access register PTER operations.
 *
 * @param[in] pter_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_pter(struct ku_pter_reg       *pter_reg_data,
                                 sxd_reg_meta_t           *reg_meta,
                                 uint32_t                  data_num,
                                 sxd_completion_handler_t  handler,
                                 void                     *context);

/**
 *  This function performs access register SMPU operations.
 *
 * @param[in] smpu_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_smpu(struct ku_smpu_reg       *smpu_reg_data,
                                 sxd_reg_meta_t           *reg_meta,
                                 uint32_t                  data_num,
                                 sxd_completion_handler_t  handler,
                                 void                     *context);

/**
 *  This function performs access register PMMP operations.
 *
 * @param[in] pmmp_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_pmmp(struct ku_pmmp_reg       *pmmp_reg_data,
                                 sxd_reg_meta_t           *reg_meta,
                                 uint32_t                  data_num,
                                 sxd_completion_handler_t  handler,
                                 void                     *context);

/**
 *  This function performs access register PECNRR operations.
 *
 * @param[in] pecnrr_reg_data - The registers data
 * @param[in] reg_meta        - The registers meta data
 * @param[in] data_num        - Number of access operations to perform
 * @param[in] handler         - Handler function for calling when the operation completes
 * @param[in] context         - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_pecnrr(struct ku_pecnrr_reg     *pecnrr_reg_data,
                                   sxd_reg_meta_t           *reg_meta,
                                   uint32_t                  data_num,
                                   sxd_completion_handler_t  handler,
                                   void                     *context);

/**
 *  This function performs access register TNPC operations.
 *
 * @param[in] tnpc_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_tnpc(struct ku_tnpc_reg       *tnpc_reg_data,
                                 sxd_reg_meta_t           *reg_meta,
                                 uint32_t                  data_num,
                                 sxd_completion_handler_t  handler,
                                 void                     *context);

/**
 *  This function performs access register PECNRE operations.
 *
 * @param[in] pecnre_reg_data - The registers data
 * @param[in] reg_meta        - The registers meta data
 * @param[in] data_num        - Number of access operations to perform
 * @param[in] handler         - Handler function for calling when the operation completes
 * @param[in] context         - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_pecnre(struct ku_pecnre_reg     *pecnre_reg_data,
                                   sxd_reg_meta_t           *reg_meta,
                                   uint32_t                  data_num,
                                   sxd_completion_handler_t  handler,
                                   void                     *context);

/**
 *  This function performs access register RALCM operations.
 *
 * @param[in] ralcm_reg_data - The registers data
 * @param[in] reg_meta       - The registers meta data
 * @param[in] data_num       - Number of access operations to perform
 * @param[in] handler        - Handler function for calling when the operation completes
 * @param[in] context        - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_ralcm(struct ku_ralcm_reg      *ralcm_reg_data,
                                  sxd_reg_meta_t           *reg_meta,
                                  uint32_t                  data_num,
                                  sxd_completion_handler_t  handler,
                                  void                     *context);

/**
 *  This function performs access register MGIR operations.
 *
 * @param[in] mgir_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_mgir(struct ku_mgir_reg       *mgir_reg_data,
                                 sxd_reg_meta_t           *reg_meta,
                                 uint32_t                  data_num,
                                 sxd_completion_handler_t  handler,
                                 void                     *context);

/**
 *  This function performs access register TIDEM operations.
 *
 * @param[in] tidem_reg_data - The registers data
 * @param[in] reg_meta       - The registers meta data
 * @param[in] data_num       - Number of access operations to perform
 * @param[in] handler        - Handler function for calling when the operation completes
 * @param[in] context        - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_tidem(struct ku_tidem_reg      *tidem_reg_data,
                                  sxd_reg_meta_t           *reg_meta,
                                  uint32_t                  data_num,
                                  sxd_completion_handler_t  handler,
                                  void                     *context);

/**
 *  This function performs access register TIGCR operations.
 *
 * @param[in] tigcr_reg_data - The registers data
 * @param[in] reg_meta       - The registers meta data
 * @param[in] data_num       - Number of access operations to perform
 * @param[in] handler        - Handler function for calling when the operation completes
 * @param[in] context        - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_tigcr(struct ku_tigcr_reg      *tigcr_reg_data,
                                  sxd_reg_meta_t           *reg_meta,
                                  uint32_t                  data_num,
                                  sxd_completion_handler_t  handler,
                                  void                     *context);

/**
 *  This function performs access register RLCMLD operations.
 *
 * @param[in] rlcmld_reg_data - The registers data
 * @param[in] reg_meta        - The registers meta data
 * @param[in] data_num        - Number of access operations to perform
 * @param[in] handler         - Handler function for calling when the operation completes
 * @param[in] context         - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_rlcmld(struct ku_rlcmld_reg     *rlcmld_reg_data,
                                   sxd_reg_meta_t           *reg_meta,
                                   uint32_t                  data_num,
                                   sxd_completion_handler_t  handler,
                                   void                     *context);

/**
 *  This function performs access register IFBF operations.
 *
 * @param[in] ifbf_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_ifbf(struct ku_ifbf_reg       *ifbf_reg_data,
                                 sxd_reg_meta_t           *reg_meta,
                                 uint32_t                  data_num,
                                 sxd_completion_handler_t  handler,
                                 void                     *context);

/**
 *  This function performs access register IBFMRC operations.
 *
 * @param[in] ibfmrc_reg_data - The registers data
 * @param[in] reg_meta        - The registers meta data
 * @param[in] data_num        - Number of access operations to perform
 * @param[in] handler         - Handler function for calling when the operation completes
 * @param[in] context         - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_ibfmrc(struct ku_ibfmrc_reg     *ibfmrc_reg_data,
                                   sxd_reg_meta_t           *reg_meta,
                                   uint32_t                  data_num,
                                   sxd_completion_handler_t  handler,
                                   void                     *context);

/**
 *  This function performs access register XRALTA operations.
 *
 * @param[in] xralta_reg_data - The registers data
 * @param[in] reg_meta        - The registers meta data
 * @param[in] data_num        - Number of access operations to perform
 * @param[in] handler         - Handler function for calling when the operation completes
 * @param[in] context         - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_xralta(struct ku_xralta_reg     *xralta_reg_data,
                                   sxd_reg_meta_t           *reg_meta,
                                   uint32_t                  data_num,
                                   sxd_completion_handler_t  handler,
                                   void                     *context);

/**
 *  This function performs access register MPAGR operations.
 *
 * @param[in] mpagr_reg_data - The registers data
 * @param[in] reg_meta       - The registers meta data
 * @param[in] data_num       - Number of access operations to perform
 * @param[in] handler        - Handler function for calling when the operation completes
 * @param[in] context        - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_mpagr(struct ku_mpagr_reg      *mpagr_reg_data,
                                  sxd_reg_meta_t           *reg_meta,
                                  uint32_t                  data_num,
                                  sxd_completion_handler_t  handler,
                                  void                     *context);

/**
 *  This function performs access register XLTQ operations.
 *
 * @param[in] xltq_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_xltq(struct ku_xltq_reg       *xltq_reg_data,
                                 sxd_reg_meta_t           *reg_meta,
                                 uint32_t                  data_num,
                                 sxd_completion_handler_t  handler,
                                 void                     *context);

/**
 *  This function performs access register PPCNT operations.
 *
 * @param[in] ppcnt_reg_data - The registers data
 * @param[in] reg_meta       - The registers meta data
 * @param[in] data_num       - Number of access operations to perform
 * @param[in] handler        - Handler function for calling when the operation completes
 * @param[in] context        - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_ppcnt(struct ku_ppcnt_reg      *ppcnt_reg_data,
                                  sxd_reg_meta_t           *reg_meta,
                                  uint32_t                  data_num,
                                  sxd_completion_handler_t  handler,
                                  void                     *context);

/**
 *  This function performs access register PEFAAD operations.
 *
 * @param[in] pefaad_reg_data - The registers data
 * @param[in] reg_meta        - The registers meta data
 * @param[in] data_num        - Number of access operations to perform
 * @param[in] handler         - Handler function for calling when the operation completes
 * @param[in] context         - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_pefaad(struct ku_pefaad_reg     *pefaad_reg_data,
                                   sxd_reg_meta_t           *reg_meta,
                                   uint32_t                  data_num,
                                   sxd_completion_handler_t  handler,
                                   void                     *context);

/**
 *  This function performs access register CHLMM operations.
 *
 * @param[in] chlmm_reg_data - The registers data
 * @param[in] reg_meta       - The registers meta data
 * @param[in] data_num       - Number of access operations to perform
 * @param[in] handler        - Handler function for calling when the operation completes
 * @param[in] context        - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_chlmm(struct ku_chlmm_reg      *chlmm_reg_data,
                                  sxd_reg_meta_t           *reg_meta,
                                  uint32_t                  data_num,
                                  sxd_completion_handler_t  handler,
                                  void                     *context);

/**
 *  This function performs access register TNCR operations.
 *
 * @param[in] tncr_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_tncr(struct ku_tncr_reg       *tncr_reg_data,
                                 sxd_reg_meta_t           *reg_meta,
                                 uint32_t                  data_num,
                                 sxd_completion_handler_t  handler,
                                 void                     *context);

/**
 *  This function performs access register XMDR operations.
 *
 * @param[in] xmdr_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_xmdr(struct ku_xmdr_reg       *xmdr_reg_data,
                                 sxd_reg_meta_t           *reg_meta,
                                 uint32_t                  data_num,
                                 sxd_completion_handler_t  handler,
                                 void                     *context);

/**
 *  This function performs access register MDFCR operations.
 *
 * @param[in] mdfcr_reg_data - The registers data
 * @param[in] reg_meta       - The registers meta data
 * @param[in] data_num       - Number of access operations to perform
 * @param[in] handler        - Handler function for calling when the operation completes
 * @param[in] context        - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_mdfcr(struct ku_mdfcr_reg      *mdfcr_reg_data,
                                  sxd_reg_meta_t           *reg_meta,
                                  uint32_t                  data_num,
                                  sxd_completion_handler_t  handler,
                                  void                     *context);

/**
 *  This function performs access register PAOS operations.
 *
 * @param[in] paos_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_paos(struct ku_paos_reg       *paos_reg_data,
                                 sxd_reg_meta_t           *reg_meta,
                                 uint32_t                  data_num,
                                 sxd_completion_handler_t  handler,
                                 void                     *context);

/**
 *  This function performs access register MTUTC operations.
 *
 * @param[in] mtutc_reg_data - The registers data
 * @param[in] reg_meta       - The registers meta data
 * @param[in] data_num       - Number of access operations to perform
 * @param[in] handler        - Handler function for calling when the operation completes
 * @param[in] context        - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_mtutc(struct ku_mtutc_reg      *mtutc_reg_data,
                                  sxd_reg_meta_t           *reg_meta,
                                  uint32_t                  data_num,
                                  sxd_completion_handler_t  handler,
                                  void                     *context);

/**
 *  This function performs access register SFMR operations.
 *
 * @param[in] sfmr_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_sfmr(struct ku_sfmr_reg       *sfmr_reg_data,
                                 sxd_reg_meta_t           *reg_meta,
                                 uint32_t                  data_num,
                                 sxd_completion_handler_t  handler,
                                 void                     *context);

/**
 *  This function performs access register SMPE operations.
 *
 * @param[in] smpe_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_smpe(struct ku_smpe_reg       *smpe_reg_data,
                                 sxd_reg_meta_t           *reg_meta,
                                 uint32_t                  data_num,
                                 sxd_completion_handler_t  handler,
                                 void                     *context);

/**
 *  This function performs access register TIQDR operations.
 *
 * @param[in] tiqdr_reg_data - The registers data
 * @param[in] reg_meta       - The registers meta data
 * @param[in] data_num       - Number of access operations to perform
 * @param[in] handler        - Handler function for calling when the operation completes
 * @param[in] context        - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_tiqdr(struct ku_tiqdr_reg      *tiqdr_reg_data,
                                  sxd_reg_meta_t           *reg_meta,
                                  uint32_t                  data_num,
                                  sxd_completion_handler_t  handler,
                                  void                     *context);

/**
 *  This function performs access register XRALTB operations.
 *
 * @param[in] xraltb_reg_data - The registers data
 * @param[in] reg_meta        - The registers meta data
 * @param[in] data_num        - Number of access operations to perform
 * @param[in] handler         - Handler function for calling when the operation completes
 * @param[in] context         - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_xraltb(struct ku_xraltb_reg     *xraltb_reg_data,
                                   sxd_reg_meta_t           *reg_meta,
                                   uint32_t                  data_num,
                                   sxd_completion_handler_t  handler,
                                   void                     *context);

/**
 *  This function performs access register TNGEE operations.
 *
 * @param[in] tngee_reg_data - The registers data
 * @param[in] reg_meta       - The registers meta data
 * @param[in] data_num       - Number of access operations to perform
 * @param[in] handler        - Handler function for calling when the operation completes
 * @param[in] context        - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_tngee(struct ku_tngee_reg      *tngee_reg_data,
                                  sxd_reg_meta_t           *reg_meta,
                                  uint32_t                  data_num,
                                  sxd_completion_handler_t  handler,
                                  void                     *context);

/**
 *  This function performs access register SMPEB operations.
 *
 * @param[in] smpeb_reg_data - The registers data
 * @param[in] reg_meta       - The registers meta data
 * @param[in] data_num       - Number of access operations to perform
 * @param[in] handler        - Handler function for calling when the operation completes
 * @param[in] context        - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_smpeb(struct ku_smpeb_reg      *smpeb_reg_data,
                                  sxd_reg_meta_t           *reg_meta,
                                  uint32_t                  data_num,
                                  sxd_completion_handler_t  handler,
                                  void                     *context);

/**
 *  This function performs access register IBFMR operations.
 *
 * @param[in] ibfmr_reg_data - The registers data
 * @param[in] reg_meta       - The registers meta data
 * @param[in] data_num       - Number of access operations to perform
 * @param[in] handler        - Handler function for calling when the operation completes
 * @param[in] context        - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_ibfmr(struct ku_ibfmr_reg      *ibfmr_reg_data,
                                  sxd_reg_meta_t           *reg_meta,
                                  uint32_t                  data_num,
                                  sxd_completion_handler_t  handler,
                                  void                     *context);

/**
 *  This function performs access register PPBS operations.
 *
 * @param[in] ppbs_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_ppbs(struct ku_ppbs_reg       *ppbs_reg_data,
                                 sxd_reg_meta_t           *reg_meta,
                                 uint32_t                  data_num,
                                 sxd_completion_handler_t  handler,
                                 void                     *context);

/**
 *  This function performs access register XLKBU operations.
 *
 * @param[in] xlkbu_reg_data - The registers data
 * @param[in] reg_meta       - The registers meta data
 * @param[in] data_num       - Number of access operations to perform
 * @param[in] handler        - Handler function for calling when the operation completes
 * @param[in] context        - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_xlkbu(struct ku_xlkbu_reg      *xlkbu_reg_data,
                                  sxd_reg_meta_t           *reg_meta,
                                  uint32_t                  data_num,
                                  sxd_completion_handler_t  handler,
                                  void                     *context);

/**
 *  This function performs access register XRMT operations.
 *
 * @param[in] xrmt_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_xrmt(struct ku_xrmt_reg       *xrmt_reg_data,
                                 sxd_reg_meta_t           *reg_meta,
                                 uint32_t                  data_num,
                                 sxd_completion_handler_t  handler,
                                 void                     *context);

/**
 *  This function performs access register REIV operations.
 *
 * @param[in] reiv_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_reiv(struct ku_reiv_reg       *reiv_reg_data,
                                 sxd_reg_meta_t           *reg_meta,
                                 uint32_t                  data_num,
                                 sxd_completion_handler_t  handler,
                                 void                     *context);

/**
 *  This function performs access register PPAD operations.
 *
 * @param[in] ppad_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_ppad(struct ku_ppad_reg       *ppad_reg_data,
                                 sxd_reg_meta_t           *reg_meta,
                                 uint32_t                  data_num,
                                 sxd_completion_handler_t  handler,
                                 void                     *context);

/**
 *  This function performs access register RLCMLE operations.
 *
 * @param[in] rlcmle_reg_data - The registers data
 * @param[in] reg_meta        - The registers meta data
 * @param[in] data_num        - Number of access operations to perform
 * @param[in] handler         - Handler function for calling when the operation completes
 * @param[in] context         - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_rlcmle(struct ku_rlcmle_reg     *rlcmle_reg_data,
                                   sxd_reg_meta_t           *reg_meta,
                                   uint32_t                  data_num,
                                   sxd_completion_handler_t  handler,
                                   void                     *context);

/**
 *  This function performs access register MCQI operations.
 *
 * @param[in] mcqi_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_mcqi(struct ku_mcqi_reg       *mcqi_reg_data,
                                 sxd_reg_meta_t           *reg_meta,
                                 uint32_t                  data_num,
                                 sxd_completion_handler_t  handler,
                                 void                     *context);

/**
 *  This function performs access register CHLTR operations.
 *
 * @param[in] chltr_reg_data - The registers data
 * @param[in] reg_meta       - The registers meta data
 * @param[in] data_num       - Number of access operations to perform
 * @param[in] handler        - Handler function for calling when the operation completes
 * @param[in] context        - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_chltr(struct ku_chltr_reg      *chltr_reg_data,
                                  sxd_reg_meta_t           *reg_meta,
                                  uint32_t                  data_num,
                                  sxd_completion_handler_t  handler,
                                  void                     *context);

/**
 *  This function performs access register TNGCR operations.
 *
 * @param[in] tngcr_reg_data - The registers data
 * @param[in] reg_meta       - The registers meta data
 * @param[in] data_num       - Number of access operations to perform
 * @param[in] handler        - Handler function for calling when the operation completes
 * @param[in] context        - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_tngcr(struct ku_tngcr_reg      *tngcr_reg_data,
                                  sxd_reg_meta_t           *reg_meta,
                                  uint32_t                  data_num,
                                  sxd_completion_handler_t  handler,
                                  void                     *context);

/**
 *  This function performs access register RIPS operations.
 *
 * @param[in] rips_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_rips(struct ku_rips_reg       *rips_reg_data,
                                 sxd_reg_meta_t           *reg_meta,
                                 uint32_t                  data_num,
                                 sxd_completion_handler_t  handler,
                                 void                     *context);

/**
 *  This function performs access register TNDEM operations.
 *
 * @param[in] tndem_reg_data - The registers data
 * @param[in] reg_meta       - The registers meta data
 * @param[in] data_num       - Number of access operations to perform
 * @param[in] handler        - Handler function for calling when the operation completes
 * @param[in] context        - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_tndem(struct ku_tndem_reg      *tndem_reg_data,
                                  sxd_reg_meta_t           *reg_meta,
                                  uint32_t                  data_num,
                                  sxd_completion_handler_t  handler,
                                  void                     *context);

/**
 *  This function performs access register TNUMT operations.
 *
 * @param[in] tnumt_reg_data - The registers data
 * @param[in] reg_meta       - The registers meta data
 * @param[in] data_num       - Number of access operations to perform
 * @param[in] handler        - Handler function for calling when the operation completes
 * @param[in] context        - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_tnumt(struct ku_tnumt_reg      *tnumt_reg_data,
                                  sxd_reg_meta_t           *reg_meta,
                                  uint32_t                  data_num,
                                  sxd_completion_handler_t  handler,
                                  void                     *context);

/**
 *  This function performs access register RLCME operations.
 *
 * @param[in] rlcme_reg_data - The registers data
 * @param[in] reg_meta       - The registers meta data
 * @param[in] data_num       - Number of access operations to perform
 * @param[in] handler        - Handler function for calling when the operation completes
 * @param[in] context        - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_rlcme(struct ku_rlcme_reg      *rlcme_reg_data,
                                  sxd_reg_meta_t           *reg_meta,
                                  uint32_t                  data_num,
                                  sxd_completion_handler_t  handler,
                                  void                     *context);

/**
 *  This function performs access register PEVPB operations.
 *
 * @param[in] pevpb_reg_data - The registers data
 * @param[in] reg_meta       - The registers meta data
 * @param[in] data_num       - Number of access operations to perform
 * @param[in] handler        - Handler function for calling when the operation completes
 * @param[in] context        - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_pevpb(struct ku_pevpb_reg      *pevpb_reg_data,
                                  sxd_reg_meta_t           *reg_meta,
                                  uint32_t                  data_num,
                                  sxd_completion_handler_t  handler,
                                  void                     *context);

/**
 *  This function performs access register SFGC operations.
 *
 * @param[in] sfgc_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_sfgc(struct ku_sfgc_reg       *sfgc_reg_data,
                                 sxd_reg_meta_t           *reg_meta,
                                 uint32_t                  data_num,
                                 sxd_completion_handler_t  handler,
                                 void                     *context);

/**
 *  This function performs access register MCION operations.
 *
 * @param[in] mcion_reg_data - The registers data
 * @param[in] reg_meta       - The registers meta data
 * @param[in] data_num       - Number of access operations to perform
 * @param[in] handler        - Handler function for calling when the operation completes
 * @param[in] context        - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_mcion(struct ku_mcion_reg      *mcion_reg_data,
                                  sxd_reg_meta_t           *reg_meta,
                                  uint32_t                  data_num,
                                  sxd_completion_handler_t  handler,
                                  void                     *context);

/**
 *  This function performs access register TIQCR operations.
 *
 * @param[in] tiqcr_reg_data - The registers data
 * @param[in] reg_meta       - The registers meta data
 * @param[in] data_num       - Number of access operations to perform
 * @param[in] handler        - Handler function for calling when the operation completes
 * @param[in] context        - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_tiqcr(struct ku_tiqcr_reg      *tiqcr_reg_data,
                                  sxd_reg_meta_t           *reg_meta,
                                  uint32_t                  data_num,
                                  sxd_completion_handler_t  handler,
                                  void                     *context);

/**
 *  This function performs access register TNCR_V2 operations.
 *
 * @param[in] tncr_v2_reg_data - The registers data
 * @param[in] reg_meta         - The registers meta data
 * @param[in] data_num         - Number of access operations to perform
 * @param[in] handler          - Handler function for calling when the operation completes
 * @param[in] context          - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_tncr_v2(struct ku_tncr_v2_reg    *tncr_v2_reg_data,
                                    sxd_reg_meta_t           *reg_meta,
                                    uint32_t                  data_num,
                                    sxd_completion_handler_t  handler,
                                    void                     *context);

/**
 *  This function performs access register XRALST operations.
 *
 * @param[in] xralst_reg_data - The registers data
 * @param[in] reg_meta        - The registers meta data
 * @param[in] data_num        - Number of access operations to perform
 * @param[in] handler         - Handler function for calling when the operation completes
 * @param[in] context         - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_xralst(struct ku_xralst_reg     *xralst_reg_data,
                                   sxd_reg_meta_t           *reg_meta,
                                   uint32_t                  data_num,
                                   sxd_completion_handler_t  handler,
                                   void                     *context);

/**
 *  This function performs access register IDDD operations.
 *
 * @param[in] iddd_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_iddd(struct ku_iddd_reg       *iddd_reg_data,
                                 sxd_reg_meta_t           *reg_meta,
                                 uint32_t                  data_num,
                                 sxd_completion_handler_t  handler,
                                 void                     *context);

/**
 *  This function performs access register IEDR operations.
 *
 * @param[in] iedr_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_iedr(struct ku_iedr_reg       *iedr_reg_data,
                                 sxd_reg_meta_t           *reg_meta,
                                 uint32_t                  data_num,
                                 sxd_completion_handler_t  handler,
                                 void                     *context);

/**
 *  This function performs access register IEDS operations.
 *
 * @param[in] ieds_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_ieds(struct ku_ieds_reg       *ieds_reg_data,
                                 sxd_reg_meta_t           *reg_meta,
                                 uint32_t                  data_num,
                                 sxd_completion_handler_t  handler,
                                 void                     *context);

/**
 *  This function performs access register PMAOS operations.
 *
 * @param[in] pmaos_reg_data - The registers data
 * @param[in] reg_meta       - The registers meta data
 * @param[in] data_num       - Number of access operations to perform
 * @param[in] handler        - Handler function for calling when the operation completes
 * @param[in] context        - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_pmaos(struct ku_pmaos_reg      *pmaos_reg_data,
                                  sxd_reg_meta_t           *reg_meta,
                                  uint32_t                  data_num,
                                  sxd_completion_handler_t  handler,
                                  void                     *context);

/**
 *  This function performs access register RXLTE operations.
 *
 * @param[in] rxlte_reg_data - The registers data
 * @param[in] reg_meta       - The registers meta data
 * @param[in] data_num       - Number of access operations to perform
 * @param[in] handler        - Handler function for calling when the operation completes
 * @param[in] context        - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_rxlte(struct ku_rxlte_reg      *rxlte_reg_data,
                                  sxd_reg_meta_t           *reg_meta,
                                  uint32_t                  data_num,
                                  sxd_completion_handler_t  handler,
                                  void                     *context);

/**
 *  This function performs access register SBHBR_V2 operations.
 *
 * @param[in] sbhbr_v2_reg_data - The registers data
 * @param[in] reg_meta          - The registers meta data
 * @param[in] data_num          - Number of access operations to perform
 * @param[in] handler           - Handler function for calling when the operation completes
 * @param[in] context           - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_sbhbr_v2(struct ku_sbhbr_v2_reg   *sbhbr_v2_reg_data,
                                     sxd_reg_meta_t           *reg_meta,
                                     uint32_t                  data_num,
                                     sxd_completion_handler_t  handler,
                                     void                     *context);

/**
 *  This function performs access register TNQCR operations.
 *
 * @param[in] tnqcr_reg_data - The registers data
 * @param[in] reg_meta       - The registers meta data
 * @param[in] data_num       - Number of access operations to perform
 * @param[in] handler        - Handler function for calling when the operation completes
 * @param[in] context        - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_tnqcr(struct ku_tnqcr_reg      *tnqcr_reg_data,
                                  sxd_reg_meta_t           *reg_meta,
                                  uint32_t                  data_num,
                                  sxd_completion_handler_t  handler,
                                  void                     *context);

/**
 *  This function performs access register SBHRR_V2 operations.
 *
 * @param[in] sbhrr_v2_reg_data - The registers data
 * @param[in] reg_meta          - The registers meta data
 * @param[in] data_num          - Number of access operations to perform
 * @param[in] handler           - Handler function for calling when the operation completes
 * @param[in] context           - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_sbhrr_v2(struct ku_sbhrr_v2_reg   *sbhrr_v2_reg_data,
                                     sxd_reg_meta_t           *reg_meta,
                                     uint32_t                  data_num,
                                     sxd_completion_handler_t  handler,
                                     void                     *context);

/**
 *  This function performs access register RXLTM operations.
 *
 * @param[in] rxltm_reg_data - The registers data
 * @param[in] reg_meta       - The registers meta data
 * @param[in] data_num       - Number of access operations to perform
 * @param[in] handler        - Handler function for calling when the operation completes
 * @param[in] context        - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_rxltm(struct ku_rxltm_reg      *rxltm_reg_data,
                                  sxd_reg_meta_t           *reg_meta,
                                  uint32_t                  data_num,
                                  sxd_completion_handler_t  handler,
                                  void                     *context);

/**
 *  This function performs access register MOMTE operations.
 *
 * @param[in] momte_reg_data - The registers data
 * @param[in] reg_meta       - The registers meta data
 * @param[in] data_num       - Number of access operations to perform
 * @param[in] handler        - Handler function for calling when the operation completes
 * @param[in] context        - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_momte(struct ku_momte_reg      *momte_reg_data,
                                  sxd_reg_meta_t           *reg_meta,
                                  uint32_t                  data_num,
                                  sxd_completion_handler_t  handler,
                                  void                     *context);

/**
 *  This function performs access register RMPE operations.
 *
 * @param[in] rmpe_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_rmpe(struct ku_rmpe_reg       *rmpe_reg_data,
                                 sxd_reg_meta_t           *reg_meta,
                                 uint32_t                  data_num,
                                 sxd_completion_handler_t  handler,
                                 void                     *context);

/**
 *  This function performs access register SVFA operations.
 *
 * @param[in] svfa_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_svfa(struct ku_svfa_reg       *svfa_reg_data,
                                 sxd_reg_meta_t           *reg_meta,
                                 uint32_t                  data_num,
                                 sxd_completion_handler_t  handler,
                                 void                     *context);

/**
 *  This function performs access register MCC operations.
 *
 * @param[in] mcc_reg_data - The registers data
 * @param[in] reg_meta     - The registers meta data
 * @param[in] data_num     - Number of access operations to perform
 * @param[in] handler      - Handler function for calling when the operation completes
 * @param[in] context      - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_mcc(struct ku_mcc_reg        *mcc_reg_data,
                                sxd_reg_meta_t           *reg_meta,
                                uint32_t                  data_num,
                                sxd_completion_handler_t  handler,
                                void                     *context);

/**
 *  This function performs access register SFDB operations.
 *
 * @param[in] sfdb_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_sfdb(struct ku_sfdb_reg       *sfdb_reg_data,
                                 sxd_reg_meta_t           *reg_meta,
                                 uint32_t                  data_num,
                                 sxd_completion_handler_t  handler,
                                 void                     *context);

/**
 *  This function performs access register PMTPS operations.
 *
 * @param[in] pmtps_reg_data - The registers data
 * @param[in] reg_meta       - The registers meta data
 * @param[in] data_num       - Number of access operations to perform
 * @param[in] handler        - Handler function for calling when the operation completes
 * @param[in] context        - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_pmtps(struct ku_pmtps_reg      *pmtps_reg_data,
                                  sxd_reg_meta_t           *reg_meta,
                                  uint32_t                  data_num,
                                  sxd_completion_handler_t  handler,
                                  void                     *context);

/**
 *  This function performs access register RXLTCC operations.
 *
 * @param[in] rxltcc_reg_data - The registers data
 * @param[in] reg_meta        - The registers meta data
 * @param[in] data_num        - Number of access operations to perform
 * @param[in] handler         - Handler function for calling when the operation completes
 * @param[in] context         - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_rxltcc(struct ku_rxltcc_reg     *rxltcc_reg_data,
                                   sxd_reg_meta_t           *reg_meta,
                                   uint32_t                  data_num,
                                   sxd_completion_handler_t  handler,
                                   void                     *context);

/**
 *  This function performs access register MCDA operations.
 *
 * @param[in] mcda_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_mcda(struct ku_mcda_reg       *mcda_reg_data,
                                 sxd_reg_meta_t           *reg_meta,
                                 uint32_t                  data_num,
                                 sxd_completion_handler_t  handler,
                                 void                     *context);
