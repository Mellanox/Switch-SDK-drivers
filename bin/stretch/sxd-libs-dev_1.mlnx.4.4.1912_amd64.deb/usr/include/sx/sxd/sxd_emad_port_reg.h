/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2020 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_PORT_REG_H__
#define __SXD_EMAD_PORT_REG_H__

#include <sx/sxd/sxd_types.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

#include <complib/cl_packon.h>

/**
 * sxd_emad_pspa_reg_t structure is used to store PSPA register
 * layout.
 */
typedef struct sxd_emad_pspa_reg {
    uint8_t swid;
    uint8_t local_port;
    uint8_t sub_port;
    uint8_t reserved1[5];
} PACK_SUFFIX sxd_emad_pspa_reg_t;

/**
 * sxd_emad_spmcr_reg_t structure is used to store SPMCR register
 * layout.
 */
typedef struct sxd_emad_spmcr_reg {
    uint8_t swid;
    uint8_t local_port;
    uint8_t max_sub_port;
    uint8_t reserved1[3];
    net16_t base_stag_vid;
} PACK_SUFFIX sxd_emad_spmcr_reg_t;

/**
 * sxd_emad_pmtu_reg_t structure is used to store PMTU register
 * layout.
 */
typedef struct sxd_emad_pmtu_reg {
    uint8_t reserved1;
    uint8_t local_port;
    net16_t reserved2;
    net16_t max_mtu;
    net16_t reserved3;
    net16_t admin_mtu;
    net16_t reserved4;
    net16_t oper_mtu;
    net16_t reserved5;
} PACK_SUFFIX sxd_emad_pmtu_reg_t;

/**
 * sxd_emad_pcnr_reg_t structure is used to store PCNR register
 * layout.
 */
typedef struct sxd_emad_pcnr_reg {
    uint8_t reserved1;
    uint8_t local_port;
    uint8_t reserved2;
    uint8_t tuning_override;
    net32_t reserved3[2];
} PACK_SUFFIX sxd_emad_pcnr_reg_t;

/**
 * sxd_emad_pcmr_reg_t structure is used to store PCMR register
 * layout.
 */
enum pcmr_bits {
    PCMR_BIT_FCS = 1,
    PCMR_BIT_RX_TS_OVER_CRC = 13,
    PCMR_BIT_RX_FCS_DROP = 14,
    PCMR_BIT_TX_FCS_RECALC = 15,
    PCMR_BIT_TX_TS_OVER_CRC = 16
};

typedef struct sxd_emad_pcmr_reg {
    uint8_t reserved1;
    uint8_t local_port;
    net16_t reserved2;
    net32_t capabilities;
    net32_t config;
} PACK_SUFFIX sxd_emad_pcmr_reg_t;

/**
 * sxd_emad_pmcr_reg_t structure is used to store PMCR register
 * layout.
 */
typedef struct sxd_emad_pmcr_reg {
    uint8_t reserved1;
    uint8_t local_port;
    net16_t reserved2;
    uint8_t tx_disable_override_value;
    uint8_t tx_disable_override_cntl;
    uint8_t cdr_override_value;
    uint8_t cdr_override_cntl;
    net16_t reserved4;
    uint8_t rx_amp_override_value;
    uint8_t rx_amp_override_cntl;
    net16_t reserved5;
    uint8_t rx_emp_override_value;
    uint8_t rx_emp_override_cntl;
    net16_t reserved6;
    uint8_t tx_equ_override_value;
    uint8_t tx_equ_override_cntl;
    net32_t reserved7;
    net32_t reserved8;
    net32_t reserved9;
} PACK_SUFFIX sxd_emad_pmcr_reg_t;

/**
 * sxd_emad_pfsc_reg_t structure is used to store PFSC register
 * layout.
 */
typedef struct sxd_emad_pfsc_reg {
    uint8_t reserved1;
    uint8_t local_port;
    uint8_t reserved2[5];
    uint8_t fwd_admin;
    uint8_t reserved3[3];
    uint8_t fwd_oper;
    net32_t reserved4;
} PACK_SUFFIX sxd_emad_pfsc_reg_t;

/**
 * sxd_emad_sbcm_reg_t structure is used to store SBCM register
 * layout.
 */
typedef struct sxd_emad_sbcm_reg {
    uint8_t desc;
    uint8_t local_port;
    uint8_t pg_buff;
    uint8_t dir;
    uint8_t reserved2[12];
    net32_t buff_occupancy;
    net32_t clr_max_buff_occupancy;
    net32_t min_buff;
    net32_t infinite_size_max_buff;
    uint8_t reserved3[7];
    uint8_t pool;
} PACK_SUFFIX sxd_emad_sbcm_reg_t;

/**
 * sxd_emad_sbpm_reg_t structure is used to store SBPM register
 * layout.
 */
typedef struct sxd_emad_sbpm_reg {
    uint8_t desc;
    uint8_t local_port;
    uint8_t pool;
    uint8_t dir;
    uint8_t reserved2[12];
    net32_t buff_occupancy;
    net32_t clr_max_buff_occupancy;
    net32_t min_buff;
    net32_t infinite_size_max_buff;
    uint8_t reserved3[8];
} PACK_SUFFIX sxd_emad_sbpm_reg_t;

/**
 * sxd_emad_pplr_reg_t structure is used to store PPLR register
 * layout.
 */
typedef struct sxd_emad_pplr_reg {
    uint8_t reserved1;
    uint8_t local_port;
    uint8_t reserved2;
    uint8_t port_type;
    uint8_t reserved3[3];
    uint8_t el_il;
} PACK_SUFFIX sxd_emad_pplr_reg_t;

/**
 * sxd_emad_pmpr_reg_t structure is used to store PMPR register
 * layout.
 */
typedef struct sxd_emad_pmpr_reg {
    uint8_t reserved1;
    uint8_t module;
    uint8_t reserved2[5];
    uint8_t attenuation5g;
    uint8_t reserved3[3];
    uint8_t attenuation7g;
    uint8_t reserved4[3];
    uint8_t attenuation12g;
} PACK_SUFFIX sxd_emad_pmpr_reg_t;

/**
 * sxd_emad_ptys_reg_t structure is used to store PTYS register
 * layout.
 */
typedef struct sxd_emad_ptys_reg {
    uint8_t an_disable_and_tx_aba;
    uint8_t local_port;
    uint8_t reserved1;
    uint8_t proto_mask;
    uint8_t an_status;
    uint8_t reserved2;
    net16_t data_rate_oper;
    net32_t ext_eth_proto_capability;
    net32_t eth_proto_capability;
    net16_t ib_link_width_capability;
    net16_t ib_proto_capability;
    net32_t ext_eth_proto_admin;
    net32_t eth_proto_admin;
    net16_t ib_link_width_admin;
    net16_t ib_proto_admin;
    net32_t ext_eth_proto_oper;
    net32_t eth_proto_oper;
    net16_t ib_link_width_oper;
    net16_t ib_proto_oper;
    uint8_t reserved4[3];
    uint8_t connector_type;
    net32_t eth_proto_lp_advertise;
    net32_t reserved5[3];
} PACK_SUFFIX sxd_emad_ptys_reg_t;

/**
 * sxd_emad_pmtps_reg_t structure is used to store PMTPS
 * register layout.
 */
typedef struct sxd_emad_pmtps_reg {
/*
 *  Need to have this struct till register auto generated engine is not ready.
 *
 *   uint8_t module;
 *   uint16_t module_type_admin;
 *   uint16_t module_type_connected;
 *   uint32_t eth_module_c2m;
 */
} PACK_SUFFIX sxd_emad_pmtps_reg_t;

/**
 * sxd_emad_ppaos_reg_t structure is used to store PPAOS register
 * layout.
 */
typedef struct sxd_emad_ppaos_reg {
    uint8_t swid;
    uint8_t local_port;
    uint8_t phy_test_mode_admin;
    uint8_t phy_test_mode_status;
    net32_t reserved3[3];
} PACK_SUFFIX sxd_emad_ppaos_reg_t;

/**
 * sxd_emad_pptt_reg_t structure is used to store PPTT register
 * layout.
 */
typedef struct sxd_emad_pptt_reg {
    uint8_t e;
    uint8_t local_port;
    uint8_t pnat;
    uint8_t reserved;
    net32_t prbs_modes_cap;
    uint8_t prbs_mode_admin;
    uint8_t reserved2[3];
    net16_t lane_rate_cap;
    uint8_t reserved3[2];
    net16_t lane_rate_admin;
    uint8_t reserved4[2];
    net32_t reserved5[2];
} PACK_SUFFIX sxd_emad_pptt_reg_t;

/**
 * sxd_emad_pprt_reg_t structure is used to store PPRT register
 * layout.
 */
typedef struct sxd_emad_pprt_reg {
    uint8_t e_s;
    uint8_t local_port;
    uint8_t pnat;
    uint8_t reserved;
    net32_t prbs_modes_cap;
    uint8_t prbs_mode_admin;
    uint8_t reserved2[3];
    net16_t lane_rate_cap;
    uint8_t reserved3[2];
    net16_t lane_rate_oper;
    uint8_t reserved4[2];
    uint8_t prbs_rx_lock_status;
    uint8_t reserved5[3];
    net32_t reserved6[2];
} PACK_SUFFIX sxd_emad_pprt_reg_t;

/**
 * sxd_emad_pcap_reg_t structure is used to store PCAP register
 * layout.
 */
typedef struct sxd_emad_pcap_reg {
    uint8_t reserved1;
    uint8_t local_port;
    uint8_t reserved2[2];
    net32_t port_capability_mask[4];
} PACK_SUFFIX sxd_emad_pcap_reg_t;

/**
 * sxd_emad_pplm_reg_t structure is used to store PPLM register
 * layout.
 */
typedef struct sxd_emad_pplm_reg {
    uint8_t reserved1;
    uint8_t local_port;
    uint8_t reserved2[2];
    net32_t reserved3;
    uint8_t port_profile_mode;
    uint8_t static_port_profile;
    uint8_t active_port_profile;
    uint8_t reserved4;
    net32_t retransmission_active_fec_mode_active;
    uint8_t rs_fec_correction_bypass_cap_reserved;
    uint8_t reserved_fec_override_cap_56g;
    uint8_t fec_override_cap_100g_fec_override_cap_50g;
    uint8_t fec_override_cap_25g_fec_override_cap_10g_40g;
    uint8_t rs_fec_correction_bypass_admin_reserved;
    uint8_t reserved_fec_override_admin_56g;
    uint8_t fec_override_admin_100g_fec_override_admin_50g;
    uint8_t fec_override_admin_25g_fec_override_admin_10g_40g;
    net16_t fec_override_cap_400g_8x;
    net16_t fec_override_cap_200g_4x;
    net16_t fec_override_cap_100g_2x;
    net16_t fec_override_cap_50g_1x;
    net16_t fec_override_admin_400g_8x;
    net16_t fec_override_admin_200g_4x;
    net16_t fec_override_admin_100g_2x;
    net16_t fec_override_admin_50g_1x;
} PACK_SUFFIX sxd_emad_pplm_reg_t;

/**
 * sxd_emad_pbmc_reg_t structure is used to store PER BUFFER
 * register layout.
 */
typedef struct sxd_emad_pbrl_reg {
    uint8_t  lossy_epsb;
    uint8_t  reserved1;
    uint16_t size;
    uint16_t xof_threshold;
    uint16_t xon_threshold;
} PACK_SUFFIX sxd_emad_pbrl_reg_t;

/**
 * sxd_emad_pbmc_reg_t structure is used to store PBMC register
 * layout.
 */
typedef struct sxd_emad_pbmc_reg {
    uint8_t             reserved1;
    uint8_t             local_port;
    net16_t             reserved2;
    uint16_t            xof_timer_value;
    uint16_t            xof_refresh;
    net16_t             reserved3;
    net16_t             port_buffer_size;
    sxd_emad_pbrl_reg_t buffer[SXD_PORT_PBMC_NUM_BUFF];
    uint8_t             reserved4[16];
    sxd_emad_pbrl_reg_t port_shared_buffer;
} PACK_SUFFIX sxd_emad_pbmc_reg_t;

typedef struct sxd_emad_pelc_reg {
    uint8_t op;
    uint8_t local_port;
    net16_t reserved1;
    uint8_t op_admin;
    uint8_t op_capability;
    uint8_t op_request;
    uint8_t op_active;
    net64_t admin;
    net64_t capability;
    net64_t request;
    net64_t active;
} PACK_SUFFIX sxd_emad_pelc_reg_t;

/**
 * sxd_emad_sbpr_reg_t structure is used to store SBPR register
 * layout.
 */
typedef struct sxd_emad_sbpr_reg {
    uint8_t  desc_and_dir;
    uint16_t reserved1;
    uint8_t  pool_id;
    uint32_t infi_size_and_size;
    uint8_t  reserved2[3];
    uint8_t  mode;
    uint32_t curr_buff_occupancy;
    uint32_t clr_and_max_buff_occupancy;
} PACK_SUFFIX sxd_emad_sbpr_reg_t;

/**
 * sxd_emad_pmlp_reg_t structure is used to store PMLP register
 * layout.
 */
typedef struct sxd_emad_pmlp_reg {
    uint8_t use_different_rx_tx;
    uint8_t local_port;
    uint8_t reserved1;
    uint8_t width;
    uint8_t rx_lane0;
    uint8_t lane0;
    uint8_t reserved2;
    uint8_t module0;
    uint8_t rx_lane1;
    uint8_t lane1;
    uint8_t reserved3;
    uint8_t module1;
    uint8_t rx_lane2;
    uint8_t lane2;
    uint8_t reserved4;
    uint8_t module2;
    uint8_t rx_lane3;
    uint8_t lane3;
    uint8_t reserved5;
    uint8_t module3;
    uint8_t rx_lane4;
    uint8_t lane4;
    uint8_t reserved6;
    uint8_t module4;
    uint8_t rx_lane5;
    uint8_t lane5;
    uint8_t reserved7;
    uint8_t module5;
    uint8_t rx_lane6;
    uint8_t lane6;
    uint8_t reserved8;
    uint8_t module6;
    uint8_t rx_lane7;
    uint8_t lane7;
    uint8_t reserved9;
    uint8_t module7;
    net32_t reserved10[7];
} PACK_SUFFIX sxd_emad_pmlp_reg_t;

/**
 * sxd_emad_pfcc_reg_t structure is used to store PFCC register
 * layout.
 */
typedef struct sxd_emad_pfcc_reg {
    uint8_t reserved1;
    uint8_t local_port;
    uint8_t reserved2[2];
    uint8_t reserved3_1;
    uint8_t prio_mask_tx;
    uint8_t reserved3_2;
    uint8_t prio_mask_rx;
    uint8_t pptx;
    uint8_t pcftx;
    uint8_t reserved4;
    uint8_t cbftx;
    uint8_t pprx;
    uint8_t pcfrx;
    uint8_t reserved5;
    uint8_t cbfrx;
    net32_t reserved6[4];
} PACK_SUFFIX sxd_emad_pfcc_reg_t;

/**
 * sxd_emad_pude_reg_t structure is used to store PUDE register
 * layout.
 */
typedef struct sxd_emad_pude_reg {
    uint8_t swid;
    uint8_t local_port;
    uint8_t admin_status;
    uint8_t oper_status;
    net32_t reserved[3];
} PACK_SUFFIX sxd_emad_pude_reg_t;

/**
 * sxd_emad_pmpe_reg_t structure is used to store PMPE register
 * layout.
 */
typedef struct sxd_emad_pmpe_reg {
    uint8_t  reserved1;
    uint8_t  module_id;
    uint8_t  reserved2;
    uint8_t  oper_status;
    uint16_t reserved3;
    uint8_t  error_type;
    uint8_t  reserved4[9];
} PACK_SUFFIX sxd_emad_pmpe_reg_t;

/**
 * sxd_emad_plib_reg_t structure is used to store PLIB register
 * layout.
 */
typedef struct sxd_emad_plib_reg {
    uint8_t m;
    uint8_t local_port;
    uint8_t reserved1;
    uint8_t ib_port;
    uint8_t reserved2[3];
    uint8_t split_num;
    net32_t reserved3[2];
} PACK_SUFFIX sxd_emad_plib_reg_t;

/**
 * sxd_emad_pptb_reg_t structure is used to store PPTB register
 * layout.
 */
typedef struct sxd_emad_pptb_reg {
    uint8_t mapping_mode;
    uint8_t local_port;
    uint8_t cm_um;
    uint8_t pm;
    uint8_t prio_7_6_buff;
    uint8_t prio_5_4_buff;
    uint8_t prio_3_2_buff;
    uint8_t prio_1_0_buff;
    uint8_t prio_buff_msb;
    uint8_t reserved1[2];
    uint8_t ctrl_untagged_buff;
    uint8_t prio_15_14_buff;
    uint8_t prio_13_12_buff;
    uint8_t prio_11_10_buff;
    uint8_t prio_9_8_buff;
} PACK_SUFFIX sxd_emad_pptb_reg_t;

/**
 * sxd_emad_qpbr_reg_t structure is used to store QPBR register
 * layout.
 */
typedef struct sxd_emad_qpbr_reg {
    uint8_t  op;
    uint8_t  port;
    uint16_t g_pid;
    uint8_t  reserved1[3];
    uint8_t  flow_metering_buff;
    uint8_t  reserved2[8];
} PACK_SUFFIX sxd_emad_qpbr_reg_t;

/**
 * sxd_emad_pifr_reg_t structure is used to store PIFR register
 * layout.
 */
typedef struct sxd_emad_pifr_reg {
    uint8_t  reserved1;
    uint8_t  local_port;
    uint8_t  reserved2[2];
    uint32_t reserved3[7];
    net32_t  ports_bitmap[8];
    net32_t  mask_bitmap[8];
} PACK_SUFFIX sxd_emad_pifr_reg_t;

/**
 * sxd_emad_pmpc_reg_t structure is used to store PMPC register
 * layout.
 */
typedef struct sxd_emad_pmpc_reg {
    net32_t module_state_updated_bitmap[8];
} PACK_SUFFIX sxd_emad_pmpc_reg_t;


/**
 * sxd_emad_plbf_reg_t structure is used to store PLBF register
 * layout.
 */
typedef struct sxd_emad_plbf_reg {
    uint8_t  reserved1;
    uint8_t  port;
    uint8_t  reserved2;
    uint8_t  lbf_mode;
    uint32_t reserved3;
} PACK_SUFFIX sxd_emad_plbf_reg_t;

/**
 * sxd_emad_mpsc_reg_t structure is used to store MPSC register
 * layout.
 */
typedef struct sxd_emad_mpsc_reg {
    uint8_t  reserved1;
    uint8_t  port;
    uint8_t  reserved2[2];
    uint8_t  c_e;
    uint8_t  reserved3[3];
    uint32_t rate;
    net64_t  count_sample_drops;
} PACK_SUFFIX sxd_emad_mpsc_reg_t;

/**
 * sxd_emad_mprs_reg_t structure is used to store MPRS register
 * layout.
 */
typedef struct sxd_emad_mprs_reg {
    uint16_t reserved1;
    uint16_t parsing_depth;
    uint16_t reserved2;
    uint16_t parsing_en;
    uint16_t reserved3;
    uint8_t  ctipl;
    uint8_t  ctipl_l2_length;
    uint32_t reserved4;
    uint16_t reserved5;
    uint16_t vxlan_udp_dport;
} PACK_SUFFIX sxd_emad_mprs_reg_t;

/**
 * sxd_emad_mlcr_reg_t structure is used to store MLCR register
 * layout.
 */
typedef struct sxd_emad_mlcr_reg {
    uint8_t reserved1;
    uint8_t local_port;
    uint8_t reserved2;
    uint8_t cap_local_led_type;
    net16_t reserved3;
    net16_t beacon_duration;
    net16_t reserved4;
    net16_t beacon_remain;
} PACK_SUFFIX sxd_emad_mlcr_reg_t;

/**
 * sxd_emad_mdri_reg_t structure is used to store MDRI register
 * layout.
 */
typedef struct sxd_emad_mdri_reg {
    uint8_t reserved1[3];
    uint8_t clear;
    uint8_t reserved2[3];
    uint8_t read;
    uint8_t reserved3[24];
    net32_t global_reasons[8];
    net32_t port_reasons[8];
    net32_t buffer_reasons[8];
    net32_t ethernet_reasons[8];
    net32_t ip_reasons[8];
    net32_t mpls_reasons[8];
    net32_t tunnel_reasons[8];
    net32_t host_reasons[8];
} PACK_SUFFIX sxd_emad_mdri_reg_t;

/**
 * sxd_emad_pddr_reg_t structure is used to request port diagnostic info.
 */

typedef struct sxd_emad_pddr_reg {
    uint8_t  reserved1;
    uint8_t  local_port;
    uint8_t  pnat;
    uint8_t  reserved2;
    uint16_t reserved3;
    uint8_t  reserved4;
    uint8_t  page_select;
    uint32_t page_data[(0x100 - 0x8) / sizeof(uint32_t)];
} PACK_SUFFIX sxd_emad_pddr_reg_t;

/**
 * sxd_emad_pvlc_reg_t structure is used to store PVLC register
 * layout.
 */
typedef struct sxd_emad_pvlc_reg {
    uint8_t  reserved1;
    uint8_t  local_port;
    uint16_t reserved2;
    uint8_t  reserved3[3];
    uint8_t  vl_hw_cap;
    uint8_t  reserved4[3];
    uint8_t  vl_admin;
    uint8_t  reserved5[3];
    uint8_t  vl_operational;
} PACK_SUFFIX sxd_emad_pvlc_reg_t;

/**
 * sxd_emad_ppbmc_reg structure is used to config BER monitor control.
 * */
typedef struct sxd_emad_ppbmc_reg {
    uint8_t  reserved1;
    uint8_t  local_port;
    uint8_t  pnat_monitor_type;
    uint8_t  reserved2;
    uint8_t  e_event_ctrl;
    uint8_t  monitor_ctrl;
    uint8_t  reserved3;
    uint8_t  monitor_state;
    uint64_t reserved4;
} sxd_emad_ppbmc_reg_t;

/**
 * sxd_emad_ppbmp_reg structure is used to config BER monitor parameters.
 * */
typedef struct sxd_emad_ppbmp_reg {
    uint8_t  reserved1;
    uint8_t  local_port;
    uint8_t  pnat;
    uint8_t  monitor_group;
    uint8_t  alarm_th_mantissa;
    uint8_t  alarm_th_exp;
    uint8_t  warning_th_mantissa;
    uint8_t  warning_th_exp;
    uint8_t  normal_th_mantissa;
    uint8_t  normal_th_exp;
    uint16_t reserved2;
} sxd_emad_ppbmp_reg_t;

/**
 * sxd_emad_ppbme_reg structure is used to query BER monitor status.
 * */
typedef struct sxd_emad_ppbme_reg {
    uint8_t  reserved1;
    uint8_t  local_port;
    uint8_t  pnat_monitor_type;
    uint8_t  reserved2;
    uint8_t  reserved3[3];
    uint8_t  monitor_state;
    uint64_t reserved4;
} sxd_emad_ppbme_reg_t;

/**
 * sxd_emad_pbsr_stat structure is used to query Headroom buffer usage.
 */
typedef struct sxd_emad_pbsr_stat {
    uint8_t reserved1[2];
    net16_t watermark;
    uint8_t reserved2[2];
    net16_t used_buffer;
} sxd_emad_pbsr_stat_t;

/**
 * sxd_emad_pbsr_reg structure is used to query Headroom buffer usage.
 * */
typedef struct sxd_emad_pbsr_reg {
    uint8_t              reserved1;
    uint8_t              local_port;
    uint8_t              reserved2;
    uint8_t              buffer_type;
    net32_t              reserved3;
    uint8_t              clear_wm;
    uint8_t              reserved4;
    net16_t              used_shared_headroom_buffer;
    sxd_emad_pbsr_stat_t stat_buffer[10];
    net64_t              reserved5;
} sxd_emad_pbsr_reg_t;

/**
 * sxd_emad_mtpppc_reg_t structure is used to store MTPPPC register
 * layout.
 */
typedef struct sxd_emad_mtpppc_reg {
    uint8_t reserved1[3];
    uint8_t we;
    uint8_t reserved2[6];
    net16_t egr_timestape_message_type;
    uint8_t reserved3[2];
    net16_t ing_timestape_message_type;
    uint8_t reserved4[19];
    uint8_t gm_local_port_0;
    uint8_t reserved5[3];
    uint8_t gm_local_port_1;
} PACK_SUFFIX sxd_emad_mtpppc_reg_t;

/**
 * sxd_emad_spzr_reg_t structure is used to store SPZR register
 * layout.
 */
typedef struct sxd_emad_spzr_reg {
    uint8_t  swid;
    uint8_t  cm2;
    uint8_t  ndm_sp0mask_cm_vk_mp_sig_ng_g0;
    uint8_t  enh_sw_p0;
    uint32_t capability_mask;
    uint64_t system_image_guid;
    uint64_t guid0;
    uint64_t node_guid;
    uint64_t vkey;
    uint32_t capability_mask2;
    uint16_t max_pkey;
    uint16_t reserved1;
    uint8_t  node_description[64];
    uint32_t reserved2[36];
} PACK_SUFFIX sxd_emad_spzr_reg_t;

#include <complib/cl_packoff.h>

#endif /* __SXD_EMAD_PORT_REG_H__ */
