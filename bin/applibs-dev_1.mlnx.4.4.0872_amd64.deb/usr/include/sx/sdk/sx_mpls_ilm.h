/*
 *  Copyright (C) 2010-2020. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */
#ifndef __SX_MPLS_ILM_H__
#define __SX_MPLS_ILM_H__

#include <sx/sdk/sx_mpls.h>
#include <sx/sdk/sx_router_next_hop_base.h>

#include "sx/sdk/auto_headers/sx_mpls_ilm_auto.h"


#define SX_MPLS_ILM_TABLE_ID_VALID     0x0
#define MAX_IN_SEGMENT_GET_ALL_ENTRIES 20

/**
 * ILM key
 * ILM key with more than one label will be implemented by ACL.
 * One use case to use the match on two labels is entropy label
 */
typedef struct sx_mpls_in_segment_key {
    sx_mpls_ilm_table_id_t ilm_table; /**< ILM table to create in_segment (label space) */
    sx_mpls_label_t        in_label[SX_MPLS_MAX_LABELS_TO_MATCH]; /**< incoming label value */
    uint8_t                label_cnt; /**< # of labels to match */
} sx_mpls_in_segment_key_t;

#define SX_MPLS_IN_SEGMENT_LABEL_COUNT_RANGE(label_count) \
    SX_CHECK_MAX(label_count, SX_MPLS_MAX_SUPPORTED_LABELS_TO_MATCH)

/**
 * ILM forward actions
 */
typedef enum sx_mpls_ilm_forward_action {
    SX_MPLS_ILM_CONTINUE_LOOKUP,
    SX_MPLS_ILM_GOTO_ROUTER,
    SX_MPLS_ILM_GOTO_ECMP,
    SX_MPLS_ILM_MIN = SX_MPLS_ILM_CONTINUE_LOOKUP,
    SX_MPLS_ILM_MAX = SX_MPLS_ILM_GOTO_ECMP,
} sx_mpls_ilm_forward_action_e;

#define SX_MPLS_ILM_FORWARD_ACTION_CHECK_RANGE(ACTION) \
    SX_CHECK_MAX(ACTION, SX_MPLS_ILM_MAX)

typedef struct sx_mpls_ilm_goto_router_params {
    sx_router_interface_t irif; /**< ingress RIF or invalid */
    sx_mpls_qos_params_t  qos_params;
    boolean_t             use_egress_rif; /**< indicates whether eRIF will be used. In case of False - the backward compatible flow will be executed */
    sx_router_interface_t erif; /**< egress RIF or invalid. Used only when use_egress_rif is set to True. Supported devices: Spectrum2, Spectrum3 */
} sx_mpls_ilm_goto_router_params_t;

typedef struct sx_mpls_ilm_continue_lookup_params {
    sx_router_interface_t irif; /**< ingress RIF or invalid */
    sx_mpls_qos_params_t  qos_params;
    boolean_t             use_egress_rif; /**< indicates whether eRIF will be used. In case of False - the backward compatible flow will be executed */
    sx_router_interface_t erif; /**< egress RIF or invalid. Used only when use_egress_rif is set to True. Supported devices: Spectrum2, Spectrum3 */
} sx_mpls_ilm_continue_lookup_params_t;

typedef union sx_mpls_in_segment_fwd_actions_params {
    sx_mpls_ilm_goto_router_params_t     goto_router_params; /**< if tunnel is terminated, go to IP router lookup */
    sx_mpls_ilm_continue_lookup_params_t continue_lookup_params; /**< if tunnel is terminated, perform new ILM/IP lookup */
    sx_ecmp_id_t                         ecmp_id; /**< next hop container */
} sx_mpls_in_segment_fwd_actions_params_t;

/**
 * In segment params
 */
typedef struct sx_mpls_in_segment_params {
    sx_router_action_t                          action; /**< in_segment entry action */
    sx_trap_attributes_t                        trap_attr;
    uint8_t                                     number_of_pops; /**< number of pop to do (0 = no pop) */
    sx_mpls_ilm_forward_action_e                ilm_fwd_action;
    union sx_mpls_in_segment_fwd_actions_params fwd_actions_params;
} sx_mpls_in_segment_params_t;

typedef struct sx_in_segment_key_filter {
    /* empty for now */
} sx_in_segment_key_filter_t;

typedef struct sx_in_segment_get_entry {
    sx_mpls_in_segment_key_t    in_segment_key;
    sx_mpls_in_segment_params_t in_segment_params;
} sx_in_segment_get_entry_t;


/**
 * The following callback is used to display ILM action forward
 * information is correct format for different chip types. For
 * example for Spectrum2 will be displayed in the following
 * format:
 * [iRIF/use_eRIF/eRIF/qos_from_inner_dscp/qos_from_inner_exp]
 */
typedef void (*hwd_ilm_fwd_action_dump_cb)(const sx_mpls_in_segment_params_t *in_segment_params, char *fwd_params,
                                           int fwd_params_len);


#endif /* __SX_MPLS_ILM__H__ */
