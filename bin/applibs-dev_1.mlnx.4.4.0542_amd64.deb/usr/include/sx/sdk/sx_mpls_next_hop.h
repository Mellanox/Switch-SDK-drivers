/*
 *  Copyright (C) 2010-2020. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */
#ifndef __SX_MPLS_NEXT_HOP_H__
#define __SX_MPLS_NEXT_HOP_H__

#include <sx/sdk/sx_mpls.h>
#include <sx/sdk/sx_router_next_hop_base.h>

#include "sx/sdk/auto_headers/sx_mpls_next_hop_auto.h"


#define SX_MPLS_MAX_LABELS_TO_PUSH (6)

#define SX_MAX_ECMP_MPLS_NEXT_HOPS (64)  /* The maximum number of mpls next hops in an ECMP container */

/**
 * MPLS next hops types
 */
typedef enum sx_mpls_next_hop_type_ {
    SX_MPLS_IP_NEXT_HOP_TYPE, /**< point to IP adjacency next hop */
    SX_MPLS_ECMP_NEXT_HOP_TYPE, /**< point to ECMP container of MPLS next hops */
    SX_MPLS_NEXT_HOP_TYPE_MIN = SX_MPLS_IP_NEXT_HOP_TYPE,
    SX_MPLS_NEXT_HOP_TYPE_MAX = SX_MPLS_ECMP_NEXT_HOP_TYPE
} sx_mpls_next_hop_type_e;

typedef struct sx_mpls_label_stack_entry {
    sx_mpls_label_t label;
    boolean_t       push_entropy_label_first;
} sx_mpls_label_stack_entry_t;

typedef struct sx_mpls_ip_next_hop_data {
    sx_ip_next_hop_t     ip_next_hop; /**< The IP of next hop */
    sx_mpls_qos_params_t qos_params;
} sx_mpls_ip_next_hop_data_t;

typedef union sx_mpls_next_hop_entry {
    sx_mpls_ip_next_hop_data_t ip_next_hop_data; /**< the IP of next hop */
    sx_ecmp_id_t               ecmp_id; /**< ECMP container id of NHLFEs */
} sx_mpls_next_hop_entry_t;

/**
 * MPLS next hop
 * Note: label_list[0] will be adjacent to the layer 2 and label_list[N] will be adjacent to the IP.
 */
typedef struct sx_mpls_next_hop_ {
    sx_mpls_next_hop_type_e      type;
    sx_mpls_label_stack_entry_t  label_list[SX_MPLS_MAX_LABELS_TO_PUSH]; /**< list of labels in label stack */
    uint32_t                     label_cnt; /**< number of labels in the label stack */
    union sx_mpls_next_hop_entry mpls_next_hop_entry;
} sx_mpls_next_hop_t;

typedef union sx_mpls_ingress_ler_next_hop_entry {
    sx_mpls_ip_next_hop_data_t ip_next_hop_data; /**< the IP of next hop */
    sx_ecmp_id_t               ecmp_id;          /**< ECMP container id of NHLFEs */
} sx_mpls_ingress_ler_next_hop_entry_t;

/**
 * MPLS next hop with ingress LER
 * Note: label_list[0] will be adjacent to the layer 2 and label_list[N] will be adjacent to the IP.
 */
typedef struct sx_mpls_ingress_ler_next_hop {
    sx_mpls_next_hop_type_e                  type;
    sx_mpls_label_stack_entry_t              label_list[SX_MPLS_MAX_LABELS_TO_PUSH]; /**< list of labels in label stack */
    uint32_t                                 label_cnt;                 /**< number of labels in the label stack */
    sx_router_interface_t                    mpls_ingress_rif;          /**< MPLS router ingress RIF */
    sx_router_interface_t                    ip_router_egress_rif;      /**< IP router egress RIF */
    union sx_mpls_ingress_ler_next_hop_entry mpls_next_hop_entry;
} sx_mpls_ingress_ler_next_hop_t;


#endif /* __SX_MPLS_NEXT_HOP__H__ */
