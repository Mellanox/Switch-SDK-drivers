/*
 *  Copyright (C) 2010-2020. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */

#ifndef __SX_FDB_H__
#define __SX_FDB_H__

#include <sx/sxd/sxd_fdb.h>
#include <sx/sxd/sxd_emad_fdb_data.h>

#include <sx/sdk/sx_mac.h>
#include <sx/sdk/sx_mc.h>
#include <sx/sdk/sx_vlan.h>
#include <sx/sdk/sx_trap_id.h>
#include <sx/sdk/sx_next_hop.h>

#include "sx/sdk/auto_headers/sx_fdb_auto.h"


/***********************************************
*  Types definition
***********************************************/

#define SX_GENERATE_ENUM(ENUM, STR) ENUM,

/**
 * FDB ID.
 */
typedef sxd_fid_t sx_fid_t;
typedef sx_fid_t sx_fdb_id_t;

/**
 * Maximum number of MAC entries in the FDB (60K)
 */
#define SX_FDB_MAX_ENTRIES 0x0FFFFFFF

#define SX_FDB_UC_NO_LIMIT SX_FDB_MAX_ENTRIES

#define SX_FDB_IS_LIMIT_EXIST(val) SX_FDB_UC_NO_LIMIT != val

#define SX_FDB_UC_LIMIT_CHECK_RANGE(val) SX_CHECK_MAX(val, SX_FDB_MAX_ENTRIES)

#define SX_FDB_IS_PORT_REDUNDANT(type, action) \
    (SX_FDB_UC_STATIC == type &&               \
     (SX_FDB_ACTION_TRAP == action || SX_FDB_ACTION_DISCARD == action || SX_FDB_ACTION_FORWARD_TO_ROUTER == action))

#define SX_FDB_IS_PORT_REDUNDANT_MASK(type, action) \
    ((0 != (type & SX_FDB_UC_TYPE_STATIC)) &&       \
     (SX_FDB_ACTION_TRAP == action || SX_FDB_ACTION_DISCARD == action || SX_FDB_ACTION_FORWARD_TO_ROUTER == action))

/**
 * I/G bit mask For Validity check
 */
#define SX_FDB_GROUP_ADDRESS_MASK 0x01

/**
 * Determine if the Ethernet address is multicast
 * @addr: Pointer to a six-byte array containing the Ethernet address
 *
 * Return true if the address is the multicast address.
 */
static inline int is_multicast_ether_addr(const u_int8_t *addr)
{
    return (SX_FDB_GROUP_ADDRESS_MASK & addr[0]);
}

/**
 * Determine if the Ethernet address is broadcast
 * @addr: Pointer to a six-byte array containing the Ethernet address
 *
 * Return true if the address is the broadcast address.
 */
static inline int is_broadcast_ether_addr(const u_int8_t *addr)
{
    return (addr[0] & addr[1] & addr[2] & addr[3] & addr[4] & addr[5]) == 0xff;
}

/**
 * Default FID.
 */
#define SX_FDB_DEFAULT_FID SXD_FDB_DEFAULT_FID

/**
 * FDB age time.
 */
typedef uint32_t sx_fdb_age_time_t;

/**
 * FDB polling rate.
 */
typedef uint32_t sx_fdb_polling_interval_t;

/**
 * Default FDB age time.
 */
#define SX_FDB_DEFAULT_AGE_TIME SXD_FDB_DEFAULT_AGE_TIME

/**
 * FDB maximum/minimum age time values.
 */
#define SX_FDB_AGE_TIME_MIN SXD_FDB_AGE_TIME_MIN
#define SX_FDB_AGE_TIME_MAX SXD_FDB_AGE_TIME_MAX

#define SX_FDB_AGE_TIME_CHECK_RANGE(FDB_AGE_TIME) \
    SX_CHECK_RANGE(SX_FDB_AGE_TIME_MIN,           \
                   FDB_AGE_TIME,                  \
                   SX_FDB_AGE_TIME_MAX)

/**
 * FDB maximum/minimum poll interval time values.
 */
#define SX_FDB_POLL_INTERVAL_DECISEC_MIN 1
#define SX_FDB_POLL_INTERVAL_DECISEC_MAX (10 * 60 * 60)

#define SX_FDB_POLL_INTERVAL_CHECK_RANGE(INTERVAL) \
    SX_CHECK_RANGE(SX_FDB_POLL_INTERVAL_DECISEC_MIN, INTERVAL, SX_FDB_POLL_INTERVAL_DECISEC_MAX)
/**
 * FDB max allowed polling entries.
 */
#define SX_FDB_MAX_GET_ENTRIES 64

#define SX_FDB_CHECK_GET_UC_RANGE(time) SX_CHECK_RANGE(1, time, SX_FDB_MAX_GET_ENTRIES)

/**
 * sx_fdb_flush_type_t enumerated type is used to note FDB flush
 * type.
 */
typedef enum sx_fdb_flush_type {
    SX_FDB_FLUSH_TYPE_SWID = SXD_FDB_FLUSH_TYPE_SWID,
    SX_FDB_FLUSH_TYPE_FID = SXD_FDB_FLUSH_TYPE_FID,
    SX_FDB_FLUSH_TYPE_PORT = SXD_FDB_FLUSH_TYPE_PORT,
    SX_FDB_FLUSH_TYPE_PORT_FID = SXD_FDB_FLUSH_TYPE_PORT_FID,
    SX_FDB_FLUSH_TYPE_LAG = SXD_FDB_FLUSH_TYPE_LAG,             /** Used for notification only */
    SX_FDB_FLUSH_TYPE_LAG_FID = SXD_FDB_FLUSH_TYPE_LAG_FID      /** Used for notification only */
} sx_fdb_flush_type_t;


/******************************************************************************
 *                      Adjust code below                                     *
 *****************************************************************************/

/**
 * Port group identifier
 */
typedef uint16_t sx_pgi_t;
typedef sx_pgi_t sx_fdb_pgi_t;

/*
 * system port ranges:
 * 0x0000-0xafff :external  ports system port
 * Struct {device_id[15-10]in ORCA we will have 36),phy port[9-4],mlp[3-2].vepa[1-0]}( up to 42 devices ,64 external ports,4 MLP and 4 VEPA)
 *
 * 0xafff-0xbffff :CPU/FW  system ports
 * Struct {prefix[15-12]=0xb,device_id[11-6],mlp [5-1],0}(64 devices ,32 MLP  )
 *
 * 0xc000-0xdfff-multicast MID
 * Struct {prefix[15-12]=0xC,0xD,[13-0]MID}(8K)
 * 0xe000-0xefff :flood,BC  groups MID
 * Struct {prefix[15-12]=0xE,[11-0]vlan} (4K)
 */

/**
 * Max number of MID identifiers
 */
#define SX_FDB_MID_FLOOD_DEFAULT (0xc000)
#define SX_FDB_MID_BASE          (0xc000)

/**
 * Max number of SPGT records
 */
#define SX_FDB_INVALID_PGI       0xffff
#define SX_FDB_PGI_FLOOD_DEFAULT SX_FDB_MID_FLOOD_DEFAULT
#define SX_FDB_PGI_FLOOD_MIN_MAX (0), (SX_FDB_PGI_FLOOD_DEFAULT)
#define SX_FDB_PGI_CHECK_RANGE(pgi) SX_CHECK_MAX(pgi, SX_FDB_PGI_MAX)


/**
 * Multicast identifier
 */
typedef uint16_t sx_fdb_mid_t;

#define FOREACH_FDB_LEARN_MODE(F)                               \
    F(SX_FDB_LEARN_MODE_DONT_LEARN = 0, "DONT LEARN")           \
    F(SX_FDB_LEARN_MODE_AUTO_LEARN, "AUTO LEARN")               \
    F(SX_FDB_LEARN_MODE_CONTROL_LEARN, "CONTROL LEARN")         \
    F(SX_FDB_LEARN_MODE_MIN = SX_FDB_LEARN_MODE_DONT_LEARN, "") \
    F(SX_FDB_LEARN_MODE_MAX = SX_FDB_LEARN_MODE_CONTROL_LEARN, "")
/**
 * FDB learn modes
 */
typedef enum sx_fdb_learn_mode {
    FOREACH_FDB_LEARN_MODE(SX_GENERATE_ENUM)
} sx_fdb_learn_mode_t;

#define SX_FDB_LEARN_MODE_CHECK_RANGE(mode) \
    SX_CHECK_MAX(mode, SX_FDB_LEARN_MODE_MAX)

/**
 * FDB learn dependency modes
 */
typedef enum sx_fdb_learn_svl_mode {
    SX_FDB_SHARED_VLAN_LEARNING = 0,
    SX_FDB_INDEPENDENT_VLAN_LEARNING,
    SX_FDB_LEARN_SVL_MODE_MIN = SX_FDB_SHARED_VLAN_LEARNING,
    SX_FDB_LEARN_SVL_MODE_MAX = SX_FDB_INDEPENDENT_VLAN_LEARNING,
} sx_fdb_learn_svl_mode_t;

/**
 * FDB learn roam modes
 */
typedef enum sx_fdb_learn_roam_mode {
    SX_FDB_LEARN_ROAM_MODE_DONT_LEARN = 0,
    SX_FDB_LEARN_ROAM_MODE_LEARN,
    SX_FDB_LEARN_ROAM_MODE_MIN = SX_FDB_LEARN_ROAM_MODE_DONT_LEARN,
    SX_FDB_LEARN_ROAM_MODE_MAX = SX_FDB_LEARN_ROAM_MODE_LEARN,
} sx_fdb_learn_roam_mode_t;

/**
 * FDB learn limit setup commands
 */
typedef enum sx_fdb_learn_limit_cmd {
    SX_FDB_LEARN_LIMIT_CMD_LIMIT_VLAN = 0,
    SX_FDB_LEARN_LIMIT_CMD_LIMIT_PORT,
    SX_FDB_LEARN_LIMIT_CMD_MIN = SX_FDB_LEARN_LIMIT_CMD_LIMIT_VLAN,
    SX_FDB_LEARN_LIMIT_CMD_MAX = SX_FDB_LEARN_LIMIT_CMD_LIMIT_PORT,
} sx_fdb_learn_limit_cmd_t;

/**
 * FDB (Record) Type ID
 */
typedef enum sx_fdb_record_type {
    SX_FDB_RECORD_TYPE_NONE = -1,
    SX_FDB_RECORD_TYPE_UNICAST = 0,
    SX_FDB_RECORD_TYPE_UNICAST_LAG,
    SX_FDB_RECORD_TYPE_MC_MAC_ADDR,
    SX_FDB_RECORD_TYPE_SPORT,
    SX_FDB_RECORD_TYPE_MC_ID,
    SX_FDB_RECORD_TYPE_LEARNT_MAC,
    SX_FDB_RECORD_TYPE_LEARNT_MAC_LAG,
    SX_FDB_RECORD_TYPE_AGED_OUT_MAC,
    SX_FDB_RECORD_TYPE_AGED_OUT_MAC_LAG,
    SX_FDB_RECORD_TYPE_MIN = SX_FDB_RECORD_TYPE_UNICAST,
    SX_FDB_RECORD_TYPE_MAX = SX_FDB_RECORD_TYPE_AGED_OUT_MAC_LAG,
} sx_fdb_record_type_t;

/**
 * FDB Policy ID
 */
typedef enum sx_fdb_policy {
    /* Static entry                                             */
    SX_FDB_POLICY_IRREPLACEABLE_NONAGEABLE,         /* = 00     */
    SX_FDB_POLICY_IRREPLACEABLE_AGEABLE,            /* = 01     */
    /* Dynamic entry (non-ingress device)                       */
    SX_FDB_POLICY_REPLACEABLE_NONAGEABLE,           /* = 10     */
    /* Dynamic entry (ingress device)                           */
    SX_FDB_POLICY_REPLACEABLE_AGEABLE,              /* = 11     */
    SX_FDB_POLICY_MIN = SX_FDB_POLICY_IRREPLACEABLE_NONAGEABLE,
    SX_FDB_POLICY_MAX = SX_FDB_POLICY_REPLACEABLE_AGEABLE,
} sx_fdb_policy_t;

#define SX_FDB_FLOOD_FID_MODE_DEFAULT SX_FDB_FLOOD_FID_MODE_NONE
#define SX_FDB_FLOOD_FID_MODE_MIN_MAX SX_FDB_FLOOD_FID_MODE_MIN, SX_FDB_FLOOD_FID_MODE_MAX
#define SX_FDB_FLOOD_FID_MODE_CHECK_RANGE(type) \
    SX_CHECK_RANGE(SX_FDB_FLOOD_FID_MODE_MIN,   \
                   type,                        \
                   SX_FDB_FLOOD_FID_MODE_MAX)

/**
 * MC Edit sub commands
 */
typedef enum sx_mc_edit_cmd {
    SX_FDB_MC_EDIT_ADD_PORTS = 0,
    SX_FDB_MC_EDIT_DELETE_PORTS,
    SX_FDB_MC_EDIT_DELETE_ALL_PORTS,
    SX_FDB_MC_EDIT_MIN = SX_FDB_MC_EDIT_ADD_PORTS,
    SX_FDB_MC_EDIT_MAX = SX_FDB_MC_EDIT_DELETE_ALL_PORTS,
} sx_mc_edit_cmd_t;

/**
 * VID to FID mapping initialization policy
 */
typedef enum sx_vid_fid_init_policy {
    SX_INIT_ALL_VLAN_FOR_INDEPENDENT_LEARNING = 0,
    SX_INIT_ALL_VLAN_FOR_SHARED_LEARNING_ON_FID
} sx_vid_fid_init_policy_t;

typedef struct sx_fdb_info {
    sx_fdb_id_t id;
} sx_fdb_info_t;

/**
 * FDB uc supported notification types
 */
typedef enum sx_fdb_poll_data_type {
    SX_FDB_POLL_DATA_LEARNT_MAC = 0,
    SX_FDB_POLL_DATA_AGED_MAC,
    SX_FDB_POLL_DATA_LEARNT_MAC_LAG,
    SX_FDB_POLL_DATA_AGED_MAC_LAG
} sx_fdb_poll_data_type_t;

/** FDB learning/aging data **/
typedef struct sx_fdb_poll_data {
    uint8_t data_type;      /* sx_fdb_poll_data_type_t      *
                            * uint8_t - to optimize space  */
    sx_fid_t         fid;
    sx_mac_addr_t    mac;
    sx_port_log_id_t log_port;
} sx_fdb_poll_data_t;

/**
 * FDB get filtering types
 */
typedef enum sx_fdb_uc_mac_entry_type {
    SX_FDB_UC_STATIC = SFD_POLICY_STATIC,
    SX_FDB_UC_REMOTE = SFD_POLICY_DYNAMIC_REMOTE,
    SX_FDB_UC_AGEABLE = SFD_POLICY_DYNAMIC_AGEABLE,
    SX_FDB_UC_ALL, /**< Valid only in sx_api_fdb_uc_mac_addr_get */
    SX_FDB_UC_AGED, /**< Valid only in sx_api_fdb_uc_mac_addr_get */
    SX_FDB_UC_NONAGED, /**< Valid only in sx_api_fdb_uc_mac_addr_get */
    SX_POLICY_INVALID = SFD_POLICY_INVALID,     /*Invalid = -1*/
    SX_FDB_UC_ENTRY_TYPE_MIN = SX_FDB_UC_STATIC,
    SX_FDB_UC_ENTRY_TYPE_MAX = SX_FDB_UC_AGEABLE,
} sx_fdb_uc_mac_entry_type_t;

#define SX_FDB_UC_MAC_ENTRY_CHECK_RANGE(type) \
    SX_CHECK_RANGE(SX_FDB_UC_ENTRY_TYPE_MIN, (int)type, SX_FDB_UC_ENTRY_TYPE_MAX)

#define IS_MAC_ENTRY_DYNAMIC(type) \
    (type == SX_FDB_UC_REMOTE ||   \
     type == SX_FDB_UC_AGEABLE)

static __attribute__((__used__)) enum sfd_policy sfd_policy_arr[] = {
    SFD_POLICY_STATIC,
    SFD_POLICY_DYNAMIC_REMOTE,
    SFD_POLICY_INVALID,
    SFD_POLICY_DYNAMIC_AGEABLE
};

#define MAC_TYPE_TO_POLICY(mac_type) sfd_policy_arr[mac_type];

static __attribute__((__used__)) sx_fdb_uc_mac_entry_type_t mac_type_arr[] = {
    SX_FDB_UC_STATIC,
    SX_FDB_UC_REMOTE,
    SX_POLICY_INVALID,
    SX_FDB_UC_AGEABLE
};

#define POLICY_TO_MAC_TYPE(policy) mac_type_arr[policy];


/**
 * FDB get action types
 */
typedef enum sx_fdb_action {
    SX_FDB_ACTION_FORWARD = SFD_ACTION_FORWARD_ONLY,
    SX_FDB_ACTION_TRAP = SFD_ACTION_TRAP_ONLY,
    SX_FDB_ACTION_MIRROR_TO_CPU = SFD_ACTION_FORWARD_AND_TRAP,
    SX_FDB_ACTION_FORWARD_TO_ROUTER = SFD_ACTION_FORWARD_TO_IP_ROUTER,
    SX_FDB_ACTION_DISCARD = SFD_ACTION_DISCARD,
    SX_FDB_ACTION_INVALID = SFD_ACTION_INVALID,            /*Invalid = -1*/
    SX_FDB_ACTION_MIN = SX_FDB_ACTION_FORWARD,
    SX_FDB_ACTION_MAX = SX_FDB_ACTION_DISCARD
} sx_fdb_action_t;

typedef enum sx_fdb_igmp_fid_found_state {
    SX_FDB_IGMP_NONE_FOUND_STATE,
    SX_FDB_IGMP_VLAN_FOUND_STATE,
    SX_FDB_IGMP_BRIDGE_FOUND_STATE,
    SX_FDB_IGMP_FID_STATE_MIN = SX_FDB_IGMP_NONE_FOUND_STATE,
    SX_FDB_IGMP_FID_STATE_MAX = SX_FDB_IGMP_BRIDGE_FOUND_STATE
} sx_fdb_igmp_fid_found_state_t;

#define SX_FDB_ACTION_CHECK_RANGE(type)           \
    ((type == SX_FDB_ACTION_FORWARD) ||           \
     (type == SX_FDB_ACTION_TRAP) ||              \
     (type == SX_FDB_ACTION_MIRROR_TO_CPU) ||     \
     (type == SX_FDB_ACTION_FORWARD_TO_ROUTER) || \
     (type == SX_FDB_ACTION_DISCARD) ||           \
     (type == SX_FDB_ACTION_INVALID))

static __attribute__((__used__)) enum sfd_action sfd_action_arr[] = {
    SFD_ACTION_FORWARD_ONLY,     /* 0 */
    SFD_ACTION_FORWARD_AND_TRAP,     /* 1 */
    SFD_ACTION_TRAP_ONLY,     /* 2 */
    SFD_ACTION_FORWARD_TO_IP_ROUTER,     /* 3 */
    SFD_ACTION_INVALID,     /* 4 */
    SFD_ACTION_INVALID,     /* 5 */
    SFD_ACTION_INVALID,     /* 6 */
    SFD_ACTION_INVALID,     /* 7 */
    SFD_ACTION_INVALID,     /* 8 */
    SFD_ACTION_INVALID,     /* 9 */
    SFD_ACTION_INVALID,     /* 10 */
    SFD_ACTION_INVALID,     /* 11 */
    SFD_ACTION_INVALID,     /* 12 */
    SFD_ACTION_INVALID,     /* 13 */
    SFD_ACTION_INVALID,     /* 14 */
    SFD_ACTION_DISCARD     /* 15 */
};

#define FDB_ACTION_TO_SFD_ACTION(action) sfd_action_arr[action];

/* Dynamic entries can only be configured with NOP(Forward) action. */
#define IS_FDB_ACTION_VALID_FOR_NVE(action_type, entry_type) \
    (((action_type == SX_FDB_ACTION_FORWARD) ||              \
      ((action_type == SX_FDB_ACTION_MIRROR_TO_CPU) &&       \
       (entry_type == SX_FDB_UC_STATIC))))

/**
 * sx_fdb_key_filter_field_valid enumerated type is set key filter field valid or no valid
 *
 */
typedef enum sx_fdb_key_filter_field_valid {
    SX_FDB_KEY_FILTER_FIELD_NOT_VALID = SXD_FDB_KEY_FILTER_FIELD_NOT_VALID_E,
    SX_FDB_KEY_FILTER_FIELD_VALID = SXD_FDB_KEY_FILTER_FIELD_VALID_E,
} sx_fdb_key_filter_field_valid_t;

/**
 * FDB MAC address destination type
 */
typedef enum sx_fdb_uc_mac_addr_dest_type {
    SX_FDB_UC_MAC_ADDR_DEST_TYPE_LOGICAL_PORT = 0, /**< Destination MAC is on logical port */
    SX_FDB_UC_MAC_ADDR_DEST_TYPE_NEXT_HOP,         /**< Destination MAC is on remote tenant through tunnel */
    SX_FDB_UC_MAC_ADDR_DEST_TYPE_MIN = SX_FDB_UC_MAC_ADDR_DEST_TYPE_LOGICAL_PORT,
    SX_FDB_UC_MAC_ADDR_DEST_TYPE_MAX = SX_FDB_UC_MAC_ADDR_DEST_TYPE_NEXT_HOP,
} sx_fdb_uc_mac_addr_dest_type_e;

typedef union sx_fdb_uc_mac_addr_params_dest {
    sx_next_hop_t next_hop;                 /**< Next Hop */
} sx_fdb_uc_mac_addr_params_dest_t;

/**
 * FDB get/set record structure
 */
typedef struct sx_fdb_uc_mac_addr_params {
    sx_fid_t                             fid_vid; /**< Filtering Identifier, VID for static MAC */
    sx_mac_addr_t                        mac_addr; /**< MAC address */
    sx_port_id_t                         log_port; /**< Logical port */
    sx_fdb_uc_mac_entry_type_t           entry_type; /**< FDB Entry Type */
    sx_fdb_action_t                      action; /**< FDB action */
    sx_fdb_uc_mac_addr_dest_type_e       dest_type; /**< Destination type */
    union sx_fdb_uc_mac_addr_params_dest dest;
} sx_fdb_uc_mac_addr_params_t;

/**
 * FDB get key filter structure
 */
typedef struct sx_fdb_uc_key_filter {
    sx_fdb_key_filter_field_valid_t filter_by_fid;        /**< If key field is valid then filter by fid*/
    sx_fid_t                        fid;                  /**< Filtering Identifier */
    sx_fdb_key_filter_field_valid_t filter_by_mac_addr;    /**< If key field is valid then filter by MAC Address*/
    sx_mac_addr_t                   mac_addr;             /**< MAC address */
    sx_fdb_key_filter_field_valid_t filter_by_log_port;    /**< If key field is valid then filter by logical port*/
    sx_port_id_t                    log_port;             /**< Logical port */
} sx_fdb_uc_key_filter_t;

/* FDB multicast mac structure */
typedef struct sx_fdb_mac_key {
    sx_fid_t      fid;
    sx_mac_addr_t addr;
} sx_fdb_mac_key_t;

typedef struct sx_fdb_mac_event_data {
    sx_fdb_mac_key_t mac_fid_list[SFD_MAX_RECORDS];
    uint8_t          num_records;
} sx_fdb_mac_event_data_t;

typedef struct sx_fdb_mac_data {
    sx_fdb_action_t      action;
    sx_mc_container_id_t mc_container_id;
} sx_fdb_mac_data_t;

/** FDB learning control **/
typedef struct sx_fdb_learn_ctrl {
    sx_fdb_learn_svl_mode_t  svl_mode;
    sx_fdb_learn_roam_mode_t roam_mode;
} sx_fdb_learn_ctrl_t;

typedef enum {
    SX_FLOOD_MODE_PER_FID = 0,  /**< Flood per FID (Only MC supported on SX) */
    SX_FLOOD_MODE_SINGLE_GROUP, /**< Always flood per port and not per fid (Not support for EN) */
    FLOOD_PER_VLAN = SX_FLOOD_MODE_PER_FID,
    SINGLE_FLOOD_GROUP = SX_FLOOD_MODE_SINGLE_GROUP,
} sx_flood_mode;

typedef enum {
    SX_FLOOD_TYPE_BC_E = (1 << 0),
    SX_FLOOD_TYPE_UC_E = (1 << 1),
    SX_FLOOD_TYPE_MC_IPv4_E = (1 << 2),
    SX_FLOOD_TYPE_MC_IPv6_E = (1 << 3),
    SX_FLOOD_TYPE_MC_NON_IP_E = (1 << 4),
} sx_flood_type_t;

typedef struct sx_fdb_params {
    uint16_t      max_mc_group;
    sx_flood_mode flood_mode;
    uint8_t       is_multi_flood_grp_supported;
    uint16_t      rsvd_mc_group;
    uint8_t       async_mode;
} sx_fdb_params_t;

#define SX_FDB_MAX_MC_GROUPS 5124

typedef struct sx_flood_table {
    uint8_t                  table_id;
    enum sxd_sfgc_table_type table_type;
} sx_flood_table_t;

/**
 * sx_flood_counters_t is used to retrieve the flooding counters
 */
typedef struct {
    uint64_t unicast;
    uint64_t unicast_octet;
    uint64_t broadcast;
    uint64_t broadcast_octet;
    uint64_t multicast;
    uint64_t multicast_octet;
} sx_flood_counters_t;

#define SX_FLOOD_TABLES_EQUAL(t1, t2)    \
    ((t1)->table_id == (t2)->table_id && \
     (t1)->table_type == (t2)->table_type)

/**
 * FDB notification parameters structure for controlled learning
 *
 * interval_units: The maximum elapsed time between two FDB events in units of
 * polling interval (set by sx_api_fdb_polling_interval_set). Must be a positive integer
 * example: interval_units==3, polling interval==0.2: every 0.6 seconds (3*0.2)
 * FDB event will be sent.
 * size_threshold: The maximum amount of FDB entries to aggregate. When aggregated
 * size achieves size_threshold, FDB event will be generated. Valid range: [1 - SX_FDB_NOTIFY_SIZE_MAX]
 */
typedef struct sx_fdb_notify_params {
    uint32_t interval_units;
    uint32_t size_threshold;
} sx_fdb_notify_params_t;

#define SX_FDB_NOTIFY_SIZE_MAX                 \
    (int)((SX_HOST_EVENT_BUFFER_SIZE_MAX - 2 * \
           sizeof(uint32_t)) / sizeof(sx_fdb_notify_record_t))
#define SX_FDB_NOTIFY_SIZE_MIN 1
#define SX_FDB_NOTIFY_SIZE_THRESHOLD_CHECK_RANGE(SIZE) \
    SX_CHECK_RANGE(SX_FDB_NOTIFY_SIZE_MIN,             \
                   SIZE,                               \
                   SX_FDB_NOTIFY_SIZE_MAX)

#define FOREACH_FDB_NOTIFY_TYPE(F)                                                                                \
    F(SX_FDB_NOTIFY_TYPE_INVALID = 0, "N/A")                                                                      \
    F(SX_FDB_NOTIFY_TYPE_NEW_MAC_LAG = 1, "New MAC LAG")                                                          \
    F(SX_FDB_NOTIFY_TYPE_NEW_MAC_PORT, "New MAC Port")                                                            \
    F(SX_FDB_NOTIFY_TYPE_AGED_MAC_LAG, "Aged MAC LAG")                                                            \
    F(SX_FDB_NOTIFY_TYPE_AGED_MAC_PORT, "Aged MAC Port")                                                          \
    F(SX_FDB_NOTIFY_TYPE_FLUSH_ALL, "Flush All")                                                                  \
    F(SX_FDB_NOTIFY_TYPE_FLUSH_LAG, "Flush LAG")                                                                  \
    F(SX_FDB_NOTIFY_TYPE_FLUSH_PORT, "Flush Port")                                                                \
    F(SX_FDB_NOTIFY_TYPE_FLUSH_FID, "Flush FID")                                                                  \
    F(SX_FDB_NOTIFY_TYPE_FLUSH_LAG_FID, "Flush LAG FID")                                                          \
    F(SX_FDB_NOTIFY_TYPE_FLUSH_PORT_FID, "Flush Port FID")                                                        \
    F(SX_FDB_NOTIFY_TYPE_NEW_MAC_TUNNEL, "New MAC Tunnel")                                                        \
    F(SX_FDB_NOTIFY_TYPE_AGED_MAC_TUNNEL, "Aged MAC Tunnel")                                                      \
    F(SX_FDB_NOTIFY_TYPE_RENEW_MAC_LAG, "Renew MAC LAG") /* RENEW - Aged entry is learned again due to traffic */ \
    F(SX_FDB_NOTIFY_TYPE_RENEW_MAC_PORT, "Renew MAC Port")                                                        \
    F(SX_FDB_NOTIFY_TYPE_RENEW_MAC_TUNNEL, "Renew MAC Tunnel")                                                    \
    F(SX_FDB_NOTIFY_TYPE_MIN = SX_FDB_NOTIFY_TYPE_NEW_MAC_LAG, "")                                                \
    F(SX_FDB_NOTIFY_TYPE_MAX = SX_FDB_NOTIFY_TYPE_RENEW_MAC_TUNNEL, "")

typedef enum sx_fdb_notify_type {
    FOREACH_FDB_NOTIFY_TYPE(SX_GENERATE_ENUM)
} sx_fdb_notify_type_t;

#define SX_FDB_NOTIFY_TYPE_CHECK_RANGE(TYPE) SX_CHECK_RANGE(SX_FDB_NOTIFY_TYPE_MIN, (int)TYPE, SX_FDB_NOTIFY_TYPE_MAX)

typedef union sx_fdb_notify_record_dest {
    sx_next_hop_t next_hop_key;
} sx_fdb_notify_record_dest_t;

typedef struct sx_fdb_notify_record {
    sx_fdb_notify_type_t            type;
    sx_fid_t                        fid;
    sx_mac_addr_t                   mac_addr;
    sx_port_log_id_t                log_port;
    union sx_fdb_notify_record_dest dest;
} sx_fdb_notify_record_t;

typedef struct sx_fdb_notify_data {
    sx_swid_id_t           swid;
    uint32_t               records_num;
    sx_fdb_notify_record_t records_arr[SX_FDB_NOTIFY_SIZE_MAX];
} sx_fdb_notify_data_t;

/**
 * sx_flood_control_type_t is used to enumerate the flooding types
 * for flood control.
 */
typedef enum {
    SX_FLOOD_CONTROL_TYPE_UNICAST_E = 0,
    SX_FLOOD_CONTROL_TYPE_BROADCAST_E,
} sx_flood_control_type_t;

typedef enum sx_fdb_igmpv3_state {
    SX_FDB_IGMPV3_STATE_DISABLE_E = 0,
    SX_FDB_IGMPV3_STATE_ENABLE_E = 1,
} sx_fdb_igmpv3_state_t;

typedef struct sx_fdb_mc_ip_key {
    sx_fid_t       fid;
    sx_ip_prefix_t source_ip_addr;
    sx_ip_prefix_t destination_ip_addr;
} sx_fdb_mc_ip_key_t;

typedef struct sx_fdb_mc_ip_action {
    sx_fdb_action_t      action;
    sx_mc_container_id_t container_id;
    sx_trap_attributes_t trap_attr;
} sx_fdb_mc_ip_action_t;

typedef struct sx_fdb_mc_mac_filter {
    sx_fdb_key_filter_field_valid_t filter_by_vid;        /**< If key field is valid then filter by vid*/
    sx_vid_t                        vid;                  /**< VLAN ID */
    sx_fdb_key_filter_field_valid_t filter_by_mac_addr;    /**< If key field is valid then filter by MAC Address*/
    sx_mac_addr_t                   mac_addr;             /**< MAC address */
} sx_fdb_mc_mac_filter_t;

typedef struct sx_fdb_mc_mac_key {
    sx_vid_t      vid;
    sx_mac_addr_t mc_mac_addr;
} sx_fdb_mc_mac_key_t;

typedef struct sx_fdb_mc_ip_filter {
    sx_fdb_key_filter_field_valid_t filter_by_vid;  /** If key field is valid then filter by vid */
    sx_vid_t                        vid;            /** VLAN ID */
    sx_fdb_key_filter_field_valid_t filter_by_group;
    sx_ip_prefix_t                  group;
} sx_fdb_mc_ip_filter_t;

typedef struct sx_fdb_ip_addr_activity_notify_entry {
    sx_fdb_mc_ip_key_t key;
} sx_fdb_ip_addr_activity_notify_entry_t;

typedef struct sx_fdb_mc_ip_addr_activity_notification {
    uint32_t                               entry_cnt;
    sx_fdb_ip_addr_activity_notify_entry_t notify_entry[SX_FDB_IGMPV3_ACTIVITY_NOTIFY_CNT_MAX];
} sx_fdb_mc_ip_addr_activity_notification_t;

typedef enum {
    SX_FDB_UNREG_MC_FLOOD = 1,
    SX_FDB_UNREG_MC_PRUNE = 2,
    SX_FDB_UNREG_FLOOD_MODE_MIN = SX_FDB_UNREG_MC_FLOOD,
    SX_FDB_UNREG_FLOOD_MODE_MAX = SX_FDB_UNREG_MC_PRUNE,
} sx_fdb_unreg_flood_mode_t;


#define SX_FDB_UNREG_FLOOD_MODE_CHECK_RANGE(val) \
    SX_CHECK_RANGE(SX_FDB_UNREG_FLOOD_MODE_MIN,  \
                   val,                          \
                   SX_FDB_UNREG_FLOOD_MODE_MAX)

typedef enum sx_fdb_igmpv3_flow_context {
    SX_FDB_IGMPV3_FLOW_CONTEXT_ENABLE_DISABLE_E = 0,
    SX_FDB_IGMPV3_FLOW_CONTEXT_ERIF_E
} sx_fdb_igmpv3_flow_context_e;

typedef struct sx_port_fid {
    sx_port_log_id_t log_port;  /** Logical port (used for flush type */
    sx_fid_t         fid;       /** bridge or VID (used for flush */
} sx_port_fid_t;

typedef struct sx_flush_data {
    sx_fdb_flush_type_t flush_type;
    union {
        sx_port_log_id_t log_port;
        sx_fid_t         fid;
        sx_port_fid_t    port_fid;
    } data;
    boolean_t exclude_nve;
} sx_flush_data_t;

#endif /* __SX_FDB_H__ */
