/*
 *  Copyright (C) 2010-2020. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */


#ifndef __SX_TELE_H__
#define __SX_TELE_H__

#include "sx/sdk/auto_headers/sx_tele_auto.h"


/************************************************
 *  Type definitions
 ***********************************************/

#define SX_GENERATE_ENUM(ENUM, STR) ENUM,

/****  Histograms definitions	****/

#define SX_TELE_HIST_MAX_BINS 10 /* should be the max between RM tele_histogram_queue_depth_max_bins for all chips */

/* sx_tele_histogram_type_e specifies the type of the histogram
 * * Supported devices:
 *                      SX_TELE_HISTOGRAM_TYPE_QUEUE_DEPTH_E - Spectrum, Spectrum2.
 *                      SX_TELE_HISTOGRAM_TYPE_PORT_TC_QUEUE_DEPTH_E - Spectrum2.
 *                      SX_TELE_HISTOGRAM_TYPE_PORT_PG_QUEUE_DEPTH_E - Spectrum2.
 *                      SX_TELE_HISTOGRAM_TYPE_PORT_TC_LATENCY_E - Currently not supported.
 */
#define FOREACH_TELE_HISTOGRAM_TYPE(F)                                             \
    F(SX_TELE_HISTOGRAM_TYPE_INVALID = 0, "N/A")                                   \
    F(SX_TELE_HISTOGRAM_TYPE_QUEUE_DEPTH_E = 1, "Port Queue Depth")                \
    F(SX_TELE_HISTOGRAM_TYPE_PORT_TC_QUEUE_DEPTH_E = 2, "Port TC Queue Depth")     \
    F(SX_TELE_HISTOGRAM_TYPE_PORT_PG_QUEUE_DEPTH_E = 3, "Port PG Queue Depth")     \
    F(SX_TELE_HISTOGRAM_TYPE_PORT_TC_LATENCY_E = 4, "Port TC Latency")             \
    F(SX_TELE_HISTOGRAM_TYPE_MIN_E = SX_TELE_HISTOGRAM_TYPE_QUEUE_DEPTH_E, "")     \
    F(SX_TELE_HISTOGRAM_TYPE_MAX_E = SX_TELE_HISTOGRAM_TYPE_PORT_TC_LATENCY_E, "") \

typedef enum sx_tele_histogram_type {
    FOREACH_TELE_HISTOGRAM_TYPE(SX_GENERATE_ENUM)
} sx_tele_histogram_type_e;

#define SX_TELE_HISTOGRAM_TYPE_NUM (SX_TELE_HISTOGRAM_TYPE_MAX_E + 1)

#define SX_TELE_HISTOGRAM_TYPE_CHECK_RANGE(TYPE) \
    (SX_CHECK_RANGE(SX_TELE_HISTOGRAM_TYPE_MIN_E, (TYPE), SX_TELE_HISTOGRAM_TYPE_MAX_E))

/* sx_tele_histogram_mode_e specifies histogram bins division method: linear or exponential.
 * Supported devices: Spectrum2.
 */
#define FOREACH_TELE_HISTOGRAM_MODE(F)                                      \
    F(SX_TELE_HISTOGRAM_MODE_LINEAR_E = 0, "Linear")                        \
    F(SX_TELE_HISTOGRAM_MODE_EXPONENT_E = 1, "Exponential")                 \
    F(SX_TELE_HISTOGRAM_MODE_MIN_E = SX_TELE_HISTOGRAM_MODE_LINEAR_E, "")   \
    F(SX_TELE_HISTOGRAM_MODE_MAX_E = SX_TELE_HISTOGRAM_MODE_EXPONENT_E, "") \

typedef enum sx_tele_histogram_mode {
    FOREACH_TELE_HISTOGRAM_MODE(SX_GENERATE_ENUM)
} sx_tele_histogram_mode_e;

/* sx_tele_histogram_queue_depth_key_t is used for histogram types:
 * SX_TELE_HISTOGRAM_TYPE_QUEUE_DEPTH_E
 * \deprecated This type is deprecated and will be removed in the future. Please use sx_tele_histogram_port_tc_key_t in its place.
 */
typedef struct sx_tele_histogram_queue_depth_key {
    sx_port_log_id_t       network_port; /**< Network port. Only network ports are supported */
    sx_cos_traffic_class_t traffic_class; /**< Traffic class */
} sx_tele_histogram_queue_depth_key_t;

/* sx_tele_histogram_port_tc_key is used for histogram types:
 * SX_TELE_HISTOGRAM_TYPE_PORT_TC_QUEUE_DEPTH_E
 * SX_TELE_HISTOGRAM_TYPE_PORT_TC_LATENCY_E
 */
typedef struct sx_tele_histogram_port_tc_key {
    sx_port_log_id_t       log_port;    /**< Logical Port */
    sx_cos_traffic_class_t tc;          /**< Traffic class */
} sx_tele_histogram_port_tc_key_t;

/* sx_tele_histogram_port_pg_key_t is used for histogram types:
 * SX_TELE_HISTOGRAM_TYPE_PORT_PG_QUEUE_DEPTH_E
 */
typedef struct sx_tele_histogram_port_pg_key {
    sx_port_log_id_t        log_port;   /**< Logical Port. Only network ports are supported */
    sx_cos_priority_group_t pg;         /**< Priority Group */
} sx_tele_histogram_port_pg_key_t;

typedef union sx_tele_histogram_key_items {
    sx_tele_histogram_queue_depth_key_t queue_depth; /**< This type is deprecated and will be removed in the future.
                                                      * Please use sx_tele_histogram_port_tc_key_t in its place. */
    sx_tele_histogram_port_tc_key_t port_tc;         /**< Port+TC key */
    sx_tele_histogram_port_pg_key_t port_pg;         /**< Port+PG key */
} sx_tele_histogram_key_items_t;

/** Defines telemetry histogram key */
typedef struct sx_tele_histogram_key {
    sx_tele_histogram_type_e          type; /**< type of the histogram */
    union sx_tele_histogram_key_items key;
} sx_tele_histogram_key_t;

/** Defines telemetry histogram attributes data */
typedef struct sx_tele_histogram_queue_depth_attributes_data {
    uint32_t sample_time_resolution; /**< Sample time, this value is a time resolution.
                                      *  actual sample_time=(2^sample_time_resolution)*128nSec.
                                      *  Max value is defined on the resource manager under tele_histogram_sample_time_resolution_max
                                      *  For Spectrum, it is global for all ports and all traffic classes.
                                      *  For Spectrum2, it is configurable per port.traffic_class, and reserved for latency histogram. */
    uint32_t min_boundary;           /**< min boundary, units of cells. Each cell contains shared_buff_buffer_unit_size (defined on resource manager) bytes.*/
    uint32_t bin_size_resolution;    /**< Counted in cells.
                                      * The total number of bins is equal to tele_histogram_queue_depth_bins.
                                      * Bin 0 for all queue depth < min_boundary.
                                      * Bins 1..tele_histogram_queue_depth_bins-2 distributed between bin 0 and the last bin.
                                      * Bin tele_histogram_queue_depth_bins-1 for all queue depth >= min_boundary + (2^bin_size_resolution).
                                      * min value is defined on the resource manager under tele_histogram_bin_size_resolution_linear_min
                                      *                                                and tele_histogram_bin_size_resolution_exponent_min.
                                      * max value is defined on the resource manager under tele_histogram_bin_size_resolution_max.
                                      *
                                      * for example, if tele_histogram_queue_depth_bins=10 bins distribution will be:
                                      * <----0---|   1   |   2   |   3   |   4   |   5   |   6   |   7   |   8   |---9---->
                                      *         min                                                             max
                                      * where for linear mode:   min=min_boundary, max=min_boundary+(2^bin_size_resolution)
                                      * where for exponent mode: min=min_boundary, max=min_boundary+(255*2^bin_size_resolution) */
    sx_tele_histogram_mode_e mode;   /**< Supported devices: Spectrum2. Linear or exponential division of histogram range into bins. */
} sx_tele_histogram_queue_depth_attributes_data_t;

typedef union sx_tele_histogram_attributes_data_items {
    sx_tele_histogram_queue_depth_attributes_data_t queue_depth;
} sx_tele_histogram_attributes_data_items_t;

/** Defines telemetry histogram attributes data */
typedef struct sx_tele_histogram_attributes_data {
    sx_tele_histogram_type_e                      type;  /**< Histogram type */
    union sx_tele_histogram_attributes_data_items data;  /**< Histogram attributes */
} sx_tele_histogram_attributes_data_t;

/** Defines telemetry histogram data */
typedef struct sx_tele_histogram_data {
    uint64_t bins[SX_TELE_HIST_MAX_BINS]; /**< Bins */
    uint32_t bins_cnt;     /**< Bins count */
    uint64_t min_sampled;  /**< Minimum sampled since last clear. Supported devices: Spectrum2. Reserved for all queue-depth histogram key types. */
    uint64_t max_sampled;  /**< Maximum sampled since last clear. Supported devices: Spectrum2. Reserved for all queue-depth histogram key types. */
    uint64_t avg_sampled;  /**< Average sampled. Supported devices: Spectrum2. Reserved for all queue-depth histogram key types. */
} sx_tele_histogram_data_t;

/** Defines the validity of histogram filter */
typedef enum sx_tele_histogram_key_filter_field_valid {
    SX_TELE_HISTOGRAM_KEY_FILTER_FIELD_NOT_VALID_E = 0,
    SX_TELE_HISTOGRAM_KEY_FILTER_FIELD_VALID_E = 1,
    SX_TELE_HISTOGRAM_KEY_FILTER_FIELD_MAX_E = SX_TELE_HISTOGRAM_KEY_FILTER_FIELD_VALID_E
} sx_tele_histogram_key_filter_field_valid_e;

#define SX_TELE_HISTOGRAM_KEY_FILTER_VALID_CHECK_RANGE(VALID) \
    SX_CHECK_MAX(VALID,                                       \
                 SX_TELE_HISTOGRAM_KEY_FILTER_FIELD_MAX)

typedef struct sx_tele_histogram_filter {
    sx_tele_histogram_key_filter_field_valid_e filter_port_valid; /**< Port filter validity */
    sx_port_log_id_t                           port_filter;     /**< Port filter value */
    sx_tele_histogram_key_filter_field_valid_e filter_tc_valid; /**< TC filter validity */
    sx_cos_traffic_class_t                     tc_filter;       /**< TC filter value */
    sx_tele_histogram_key_filter_field_valid_e filter_pg_valid; /**< Supported devices: Spectrum2. PG filter validity */
    sx_cos_priority_group_t                    pg_filter;       /**< Supported devices: Spectrum2. PG filter value */
} sx_tele_histogram_filter_t;

/** Defines telemetry init parameters */
typedef struct sx_tele_init_params {
    char placeholder[0];     /*place holder*/
} sx_tele_init_params_t;

/****  Thresholds definitions	****/

/** Defines the type of the threshold entity, for event classification */
typedef enum sx_tele_threshold_entity {
    SX_TELE_THRESHOLD_ENTITY_PORT_TC_E = 0, SX_TELE_THRESHOLD_ENTITY_PORT_E = 1
} sx_tele_threshold_entity_e;

#define FOREACH_TELE_THRESHOLD_TYPE(F)                                           \
    F(SX_TELE_THRESHOLD_TYPE_INVALID_E = 0, "N/A")                               \
    F(SX_TELE_THRESHOLD_TYPE_PORT_TC_E = 1, "Port TC")                           \
    F(SX_TELE_THRESHOLD_TYPE_PORT_PG_E = 2, "Port PG")                           \
    F(SX_TELE_THRESHOLD_TYPE_LATENCY_PORT_TC_E = 3, "Latency Port TC")           \
    F(SX_TELE_THRESHOLD_TYPE_LATENCY_MC_SP_E = 4, "Latency MC SP")               \
    F(SX_TELE_THRESHOLD_TYPE_MAX_E = SX_TELE_THRESHOLD_TYPE_LATENCY_MC_SP_E, "") \
    F(SX_TELE_THRESHOLD_TYPE_PORT_E = SX_TELE_THRESHOLD_TYPE_MAX_E + 1, "Port")      /* used for event classification only, not for configuration */

/** Defines the type of the threshold */
typedef enum sx_port_threshold_type {
    FOREACH_TELE_THRESHOLD_TYPE(SX_GENERATE_ENUM)
} sx_port_threshold_type_e;

/** defines a type for telemetry thresholds. Value stored in cells */
typedef uint32_t sx_tele_threshold_t;

typedef struct sx_tele_threshold_port_tc_key {
    sx_port_log_id_t       log_port;
    sx_cos_traffic_class_t tc;
} sx_tele_threshold_port_tc_key_t;

typedef struct sx_tele_threshold_port_key {
    sx_port_log_id_t log_port;
} sx_tele_threshold_port_key_t;

typedef struct sx_tele_threshold_port_pg_key {
    sx_port_log_id_t        log_port;
    sx_cos_priority_group_t pg;
} sx_tele_threshold_port_pg_key_t;

typedef struct sx_tele_threshold_latency_mc_sp_key {
    sx_cos_priority_t sp;
} sx_tele_threshold_latency_mc_sp_key_t;

/** Defines the validity of threshold port filter */
typedef enum sx_tele_threshold_key_port_filter_valid {
    SX_TELE_THRESHOLD_KEY_PORT_FILTER_NOT_VALID_E = 0,
    SX_TELE_THRESHOLD_KEY_PORT_FILTER_VALID_E = 1,
    SX_TELE_THRESHOLD_KEY_PORT_FILTER_FIELD_MAX_E = SX_TELE_THRESHOLD_KEY_PORT_FILTER_VALID_E
} sx_tele_threshold_key_port_filter_valid_e;

/** Defines the validity of threshold tc filter */
typedef enum sx_tele_threshold_key_tc_filter_valid {
    SX_TELE_THRESHOLD_KEY_TC_FILTER_NOT_VALID_E = 0,
    SX_TELE_THRESHOLD_KEY_TC_FILTER_VALID_E = 1,
    SX_TELE_THRESHOLD_KEY_TC_FILTER_MAX_E = SX_TELE_THRESHOLD_KEY_TC_FILTER_VALID_E
} sx_tele_threshold_key_tc_filter_valid_e;

typedef union sx_tele_threshold_key_items {
    sx_tele_threshold_port_tc_key_t       port_tc;
    sx_tele_threshold_port_key_t          port;
    sx_tele_threshold_port_pg_key_t       port_pg;
    sx_tele_threshold_latency_mc_sp_key_t mc_sp;
} sx_tele_threshold_key_items_t;

/** defines threshold attributes key */
typedef struct sx_tele_threshold_key {
    sx_port_threshold_type_e          key_type;
    union sx_tele_threshold_key_items key;
} sx_tele_threshold_key_t;

typedef union sx_tele_threshold_data_items {
    sx_tele_threshold_t port_tc_threshold;
} sx_tele_threshold_data_items_t;

typedef struct sx_tele_threshold_data_ext_items {
    sx_tele_threshold_t threshold_high;
    sx_tele_threshold_t threshold_low; /**< Value 0 means high = low. Not valid for latency */
} sx_tele_threshold_data_ext_items_t;

typedef enum sx_tele_threshold_data_type {
    SX_TELE_THRESHOLD_DATA_TYPE_INVALID_E = 0,
    SX_TELE_THRESHOLD_DATA_TYPE_STATIC_E = 1,
    SX_TELE_THRESHOLD_DATA_TYPE_PERCENTAGE_E = 2,
    SX_TELE_THRESHOLD_DATA_TYPE_LATENCY_E = 3,
} sx_tele_threshold_data_type_e;

/** defines threshold attributes data */
typedef struct sx_tele_threshold_data {
    sx_port_threshold_type_e           data_type;
    sx_tele_threshold_data_items_t     data;
    sx_tele_threshold_data_type_e      threshold_data_type;
    sx_tele_threshold_data_ext_items_t threshold_data; /**< Supported devices: Spectrum2 */
} sx_tele_threshold_data_t;

/** defines the attributed for the threshold filter */
typedef struct sx_tele_threshold_filter {
    sx_tele_threshold_key_port_filter_valid_e port_filter_valid;
    sx_port_log_id_t                          port_filter;
    sx_tele_threshold_key_tc_filter_valid_e   tc_filter_valid;
    sx_cos_traffic_class_t                    tc_filter;
    boolean_t                                 pg_filter_valid;
    sx_cos_priority_group_t                   pg_filter;
} sx_tele_threshold_filter_t;

/** sx_tele_threshold_crossed_data_direction_e defines threshold crossing data direction */
typedef enum sx_tele_threshold_crossed_data_direction {
    SX_TELE_BELOW_THRESHOLD_E = 0,
    SX_TELE_ABOVE_THRESHOLD_E = 1
} sx_tele_threshold_crossed_data_direction_e;

typedef enum sx_tele_threshold_congestion_status {
    SX_TELE_THRESHOLD_MAYBE_CONGESTED_E = 0,
    SX_TELE_THRESHOLD_CONGESTED_E = 1,
    SX_TELE_THRESHOLD_NOT_CONGESTED_E = 2
} sx_tele_threshold_congestion_status_e;

typedef enum sx_tele_threshold_congestion_fp {
    SX_TELE_THRESHOLD_CONGESTION_FP_DISABLED_E = 0,
    SX_TELE_THRESHOLD_CONGESTION_FP_ENABLED_E = 1
} sx_tele_threshold_congestion_fp_e;

typedef union sx_tele_threshold_crossed_data_items {
    sx_tele_threshold_crossed_data_direction_e port_tc;
    sx_tele_threshold_congestion_status_e      port;
    sx_tele_threshold_crossed_data_direction_e port_pg;
} sx_tele_threshold_crossed_data_items_t;

/** sx_tele_threshold_crossed_data_t defines threshold crossing data */
typedef struct sx_tele_threshold_crossed_data {
    sx_port_threshold_type_e               type;
    sx_tele_threshold_crossed_data_items_t data;
} sx_tele_threshold_crossed_data_t;

typedef struct sx_tele_threshold_crossed_data_keys {
    sx_tele_threshold_key_t          key;
    sx_tele_threshold_crossed_data_t crossed_data;
    uint32_t                         key_index;
} sx_tele_threshold_crossed_data_keys_t;

#define SX_TELE_THRESHOLD_KEY_TYPE_NUM (SX_PORT_THRESHOLD_KEY_TYPE_MAX_E + 1)

#define SX_TELE_THRESHOLD_KEY_TYPE_CHECK_RANGE(TYPE) \
    (SX_CHECK_RANGE(SX_PORT_THRESHOLD_KEY_TYPE_MIN_E, (TYPE), SX_PORT_THRESHOLD_KEY_TYPE_MAX_E))

#endif /* __SX_TELE_H__ */
