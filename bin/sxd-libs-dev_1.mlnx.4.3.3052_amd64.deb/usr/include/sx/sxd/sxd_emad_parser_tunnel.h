/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2020 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_PARSER_TUNNEL_H__
#define __SXD_EMAD_PARSER_TUNNEL_H__

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_emad_tunnel_data.h>
#include <sx/sxd/sxd_emad_tunnel_reg.h>


/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

sxd_status_t emad_parser_tunnel_log_verbosity_level(IN sxd_access_cmd_t      cmd,
                                                    IN sx_verbosity_level_t *verbosity_level_p);

/**
 *  This function formats TNGCR register layout from TNGCR register data.
 *
 * @param[in] tngcr_data - TNGCR register data.
 * @param[out] tngcr_reg - TNGCR register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_tngcr(sxd_emad_tngcr_data_t *tngcr_data,
                                  sxd_emad_tngcr_reg_t  *tngcr_reg);

/**
 *  This function formats TNGCR register data from TNGCR register layout.
 *
 * @param[out] tngcr_data - TNGCR register data.
 * @param[in] tngcr_reg - TNGCR register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_tngcr(sxd_emad_tngcr_data_t *tngcr_data,
                                    sxd_emad_tngcr_reg_t  *tngcr_reg);

/**
 *  This function formats TNUMT register layout from TNUMT register data.
 *
 * @param[in] tnumt_data - TNUMT register data.
 * @param[out] tnumt_reg - TNUMT register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_tnumt(sxd_emad_tnumt_data_t *tnumt_data,
                                  sxd_emad_tnumt_reg_t  *tnumt_reg);

/**
 *  This function formats TNUMT register data from TNUMT register layout.
 *
 * @param[out] tnumt_data - TNUMT register data.
 * @param[in] tnumt_reg - TNUMT register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_tnumt(sxd_emad_tnumt_data_t *tnumt_data,
                                    sxd_emad_tnumt_reg_t  *tnumt_reg);

/**
 *  This function formats TIGCR register layout from TIGCR register data.
 *
 * @param[in] tigcr_data - TIGCR register data.
 * @param[out] tigcr_reg - TIGCR register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_tigcr(sxd_emad_tigcr_data_t *tigcr_data,
                                  sxd_emad_tigcr_reg_t  *tigcr_reg);

/**
 *  This function formats TIGCR register data from TIGCR register layout.
 *
 * @param[out] tigcr_data - TIGCR register data.
 * @param[in] tigcr_reg - TIGCR register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_tigcr(sxd_emad_tigcr_data_t *tigcr_data,
                                    sxd_emad_tigcr_reg_t  *tigcr_reg);

#endif /* __SXD_EMAD_PARSER_TUNNEL_H__ */
