/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2019 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_PARSER_FDB_H__
#define __SXD_EMAD_PARSER_FDB_H__

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_emad_fdb_data.h>
#include <sx/sxd/sxd_emad_fdb_reg.h>

/************************************************
 *  Local Defines
 ***********************************************/


/************************************************
 *  Local Macros
 ***********************************************/


/************************************************
 *  Local Type definitions
 ***********************************************/


/************************************************
 *  Defines
 ***********************************************/


/************************************************
 *  Macros
 ***********************************************/


/************************************************
 *  Type definitions
 ***********************************************/


/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Function declarations
 ***********************************************/

sxd_status_t emad_parser_fdb_log_verbosity_level(IN sxd_access_cmd_t      cmd,
                                                 IN sx_verbosity_level_t *verbosity_level_p);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_sfdat(sxd_emad_sfdat_data_t *sfdat_data,
                                  sxd_emad_sfdat_reg_t  *sfdat_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_sfdat(sxd_emad_sfdat_data_t *sfdat_data,
                                    sxd_emad_sfdat_reg_t  *sfdat_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_sfd(sxd_emad_sfd_data_t *sfd_data,
                                sxd_emad_sfd_reg_t  *sfd_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_sfd(sxd_emad_sfd_data_t *sfd_data,
                                  sxd_emad_sfd_reg_t  *sfd_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_sfd_reg_records_size(sxd_emad_sfd_data_t *sfd_data,
                                           uint32_t            *sfd_reg_records_size);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_sfn(sxd_emad_sfn_data_t *sfn_data,
                                sxd_emad_sfn_reg_t  *sfn_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_sfn(sxd_emad_sfn_data_t *sfn_data,
                                  sxd_emad_sfn_reg_t  *sfn_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_spgt(sxd_emad_spgt_data_t *spgt_data,
                                 sxd_emad_spgt_reg_t  *spgt_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_spgt(sxd_emad_spgt_data_t *spgt_data,
                                   sxd_emad_spgt_reg_t  *spgt_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_smid(sxd_emad_smid_data_t *smid_data,
                                 sxd_emad_smid_reg_t  *smid_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_smid(sxd_emad_smid_data_t *smid_data,
                                   sxd_emad_smid_reg_t  *smid_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_smpu(sxd_emad_smpu_data_t *smpu_data,
                                 sxd_emad_smpu_reg_t  *smpu_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_smpu(sxd_emad_smpu_data_t *smpu_data,
                                   sxd_emad_smpu_reg_t  *smpu_reg);

/**
 *
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_sftr(sxd_emad_sftr_data_t *sftr_data,
                                 sxd_emad_sftr_reg_t  *sftr_reg);

/**
 *
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_sftr(sxd_emad_sftr_data_t *sftr_data,
                                   sxd_emad_sftr_reg_t  *sftr_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_svpe(sxd_emad_svpe_data_t *svpe_data,
                                 sxd_emad_svpe_reg_t  *svpe_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_svpe(sxd_emad_svpe_data_t *svpe_data,
                                   sxd_emad_svpe_reg_t  *svpe_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_sfdf(sxd_emad_sfdf_data_t *sfdf_data,
                                 sxd_emad_sfdf_reg_t  *sfdf_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_sfdf(sxd_emad_sfdf_data_t *sfdf_data,
                                   sxd_emad_sfdf_reg_t  *sfdf_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_slecr(sxd_emad_slecr_data_t *slecr_data,
                                  sxd_emad_slecr_reg_t  *slecr_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_slecr(sxd_emad_slecr_data_t *slecr_data,
                                    sxd_emad_slecr_reg_t  *slecr_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_spmlr(sxd_emad_spmlr_data_t *spmlr_data,
                                  sxd_emad_spmlr_reg_t  *spmlr_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_spmlr(sxd_emad_spmlr_data_t *spmlr_data,
                                    sxd_emad_spmlr_reg_t  *spmlr_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_spfsr(sxd_emad_spfsr_data_t *spfsr_data,
                                  sxd_emad_spfsr_reg_t  *spfsr_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_spfsr(sxd_emad_spfsr_data_t *spfsr_data,
                                    sxd_emad_spfsr_reg_t  *spfsr_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_svmlr(sxd_emad_svmlr_data_t *svmlr_data,
                                  sxd_emad_svmlr_reg_t  *svmlr_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_svmlr(sxd_emad_svmlr_data_t *svmlr_data,
                                    sxd_emad_svmlr_reg_t  *svmlr_reg);

/**
 *  This function parses SPVMLR register.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_spvmlr(sxd_emad_spvmlr_data_t *spvmlr_data,
                                   sxd_emad_spvmlr_reg_t  *spvmlr_reg);

/**
 *  This function "deparse" SPVMLR register.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_spvmlr(sxd_emad_spvmlr_data_t *spvmlr_data,
                                     sxd_emad_spvmlr_reg_t  *spvmlr_reg);

/**
 *  This function reruns size of VLAN records in SPVMLR register.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_spvmlr_reg_vlans_size(sxd_emad_spvmlr_data_t *spvmlr_data,
                                            uint32_t               *spvmlr_reg_vlans_size);

#endif /* __SXD_EMAD_PARSER_FDB_H__ */
