/*
 *  Copyright (C) 2010-2019. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */


#ifndef __SX_RM_H__
#define __SX_RM_H__

/************************************************
 *  Type definitions
 ***********************************************/

typedef uint32_t sx_notification_threshold_t;

typedef rm_sdk_table_type_e sx_api_table_type_t;
typedef sx_sdk_entry_duplication_e sx_sdk_entry_duplication_t;

typedef rm_hw_table_type_e sx_api_hw_table_type_t;


#endif
