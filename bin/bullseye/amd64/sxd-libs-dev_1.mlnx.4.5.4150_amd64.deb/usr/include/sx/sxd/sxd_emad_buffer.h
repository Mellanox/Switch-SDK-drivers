/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_BUFFER_H__
#define __SXD_EMAD_BUFFER_H__

#include <complib/cl_qpool.h>

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/kernel_user.h>

/************************************************
 *  Local Defines
 ***********************************************/

#define SXD_EMAD_BUFFER_MAX_SIZE (12 * 1024) /* 12K - Max MTU */

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/


#endif /* __SXD_EMAD_BUFFER_H__ */
