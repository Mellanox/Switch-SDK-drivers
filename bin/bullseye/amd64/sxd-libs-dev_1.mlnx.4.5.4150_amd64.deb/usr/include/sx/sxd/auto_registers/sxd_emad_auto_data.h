/*
 * Copyright © 2018-2022 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */


/*
 * THIS FILE IS AUTO GENERATED.
 * DO NOT MAKE ANY CHANGES!
 * They will be erased with next update.
 *
 */

#ifndef __SXD_EMAD_AUTO_DATA_H__
#define __SXD_EMAD_AUTO_DATA_H__

#include <sx/sxd/sxd_emad_common_data.h>
#include <sx/sxd/sxd_types.h>
#include <sx/sxd/auto_registers/reg.h>


/************************************************
 *  Local Defines
 ***********************************************/


/************************************************
 *  Local Macros
 ***********************************************/


/************************************************
 *  Local Type definitions
 ***********************************************/


/************************************************
 *  Defines
 ***********************************************/


/************************************************
 *  Macros
 ***********************************************/


/************************************************
 *  Type definitions
 ***********************************************/

/**
 * sxd_emad_fsfh_data_t structure is used to store FSFH register data.
 */
typedef struct sxd_emad_fsfh_data {
    sxd_emad_common_data_t   common;
    struct ku_fsfh_reg      *reg_data;
} sxd_emad_fsfh_data_t;

/**
 * sxd_emad_fmtc_data_t structure is used to store FMTC register data.
 */
typedef struct sxd_emad_fmtc_data {
    sxd_emad_common_data_t   common;
    struct ku_fmtc_reg      *reg_data;
} sxd_emad_fmtc_data_t;

/**
 * sxd_emad_icsr_data_t structure is used to store ICSR register data.
 */
typedef struct sxd_emad_icsr_data {
    sxd_emad_common_data_t   common;
    struct ku_icsr_reg      *reg_data;
} sxd_emad_icsr_data_t;

/**
 * sxd_emad_iicr_data_t structure is used to store IICR register data.
 */
typedef struct sxd_emad_iicr_data {
    sxd_emad_common_data_t   common;
    struct ku_iicr_reg      *reg_data;
} sxd_emad_iicr_data_t;

/**
 * sxd_emad_fpums_data_t structure is used to store FPUMS register data.
 */
typedef struct sxd_emad_fpums_data {
    sxd_emad_common_data_t   common;
    struct ku_fpums_reg     *reg_data;
} sxd_emad_fpums_data_t;

/**
 * sxd_emad_pmdr_data_t structure is used to store PMDR register data.
 */
typedef struct sxd_emad_pmdr_data {
    sxd_emad_common_data_t   common;
    struct ku_pmdr_reg      *reg_data;
} sxd_emad_pmdr_data_t;

/**
 * sxd_emad_spevet_data_t structure is used to store SPEVET register data.
 */
typedef struct sxd_emad_spevet_data {
    sxd_emad_common_data_t   common;
    struct ku_spevet_reg    *reg_data;
} sxd_emad_spevet_data_t;

/**
 * sxd_emad_mtecr_data_t structure is used to store MTECR register data.
 */
typedef struct sxd_emad_mtecr_data {
    sxd_emad_common_data_t   common;
    struct ku_mtecr_reg     *reg_data;
} sxd_emad_mtecr_data_t;

/**
 * sxd_emad_igcr_data_t structure is used to store IGCR register data.
 */
typedef struct sxd_emad_igcr_data {
    sxd_emad_common_data_t   common;
    struct ku_igcr_reg      *reg_data;
} sxd_emad_igcr_data_t;

/**
 * sxd_emad_pemrbt_data_t structure is used to store PEMRBT register data.
 */
typedef struct sxd_emad_pemrbt_data {
    sxd_emad_common_data_t   common;
    struct ku_pemrbt_reg    *reg_data;
} sxd_emad_pemrbt_data_t;

/**
 * sxd_emad_sfdf_data_t structure is used to store SFDF register data.
 */
typedef struct sxd_emad_sfdf_data {
    sxd_emad_common_data_t   common;
    struct ku_sfdf_reg      *reg_data;
} sxd_emad_sfdf_data_t;

/**
 * sxd_emad_qtqcr_data_t structure is used to store QTQCR register data.
 */
typedef struct sxd_emad_qtqcr_data {
    sxd_emad_common_data_t   common;
    struct ku_qtqcr_reg     *reg_data;
} sxd_emad_qtqcr_data_t;

/**
 * sxd_emad_rsnh_data_t structure is used to store RSNH register data.
 */
typedef struct sxd_emad_rsnh_data {
    sxd_emad_common_data_t   common;
    struct ku_rsnh_reg      *reg_data;
} sxd_emad_rsnh_data_t;

/**
 * sxd_emad_qtct_data_t structure is used to store QTCT register data.
 */
typedef struct sxd_emad_qtct_data {
    sxd_emad_common_data_t   common;
    struct ku_qtct_reg      *reg_data;
} sxd_emad_qtct_data_t;

/**
 * sxd_emad_fmte_data_t structure is used to store FMTE register data.
 */
typedef struct sxd_emad_fmte_data {
    sxd_emad_common_data_t   common;
    struct ku_fmte_reg      *reg_data;
} sxd_emad_fmte_data_t;

/**
 * sxd_emad_fphhc_data_t structure is used to store FPHHC register data.
 */
typedef struct sxd_emad_fphhc_data {
    sxd_emad_common_data_t   common;
    struct ku_fphhc_reg     *reg_data;
} sxd_emad_fphhc_data_t;

/**
 * sxd_emad_pecnee_data_t structure is used to store PECNEE register data.
 */
typedef struct sxd_emad_pecnee_data {
    sxd_emad_common_data_t   common;
    struct ku_pecnee_reg    *reg_data;
} sxd_emad_pecnee_data_t;

/**
 * sxd_emad_sftr_v2_data_t structure is used to store SFTR_V2 register data.
 */
typedef struct sxd_emad_sftr_v2_data {
    sxd_emad_common_data_t   common;
    struct ku_sftr_v2_reg   *reg_data;
} sxd_emad_sftr_v2_data_t;

/**
 * sxd_emad_pgcr_data_t structure is used to store PGCR register data.
 */
typedef struct sxd_emad_pgcr_data {
    sxd_emad_common_data_t   common;
    struct ku_pgcr_reg      *reg_data;
} sxd_emad_pgcr_data_t;

/**
 * sxd_emad_mvcap_data_t structure is used to store MVCAP register data.
 */
typedef struct sxd_emad_mvcap_data {
    sxd_emad_common_data_t   common;
    struct ku_mvcap_reg     *reg_data;
} sxd_emad_mvcap_data_t;

/**
 * sxd_emad_mtmp_data_t structure is used to store MTMP register data.
 */
typedef struct sxd_emad_mtmp_data {
    sxd_emad_common_data_t   common;
    struct ku_mtmp_reg      *reg_data;
} sxd_emad_mtmp_data_t;

/**
 * sxd_emad_tieem_data_t structure is used to store TIEEM register data.
 */
typedef struct sxd_emad_tieem_data {
    sxd_emad_common_data_t   common;
    struct ku_tieem_reg     *reg_data;
} sxd_emad_tieem_data_t;

/**
 * sxd_emad_raleu_data_t structure is used to store RALEU register data.
 */
typedef struct sxd_emad_raleu_data {
    sxd_emad_common_data_t   common;
    struct ku_raleu_reg     *reg_data;
} sxd_emad_raleu_data_t;

/**
 * sxd_emad_pmsc_data_t structure is used to store PMSC register data.
 */
typedef struct sxd_emad_pmsc_data {
    sxd_emad_common_data_t   common;
    struct ku_pmsc_reg      *reg_data;
} sxd_emad_pmsc_data_t;

/**
 * sxd_emad_mogcr_data_t structure is used to store MOGCR register data.
 */
typedef struct sxd_emad_mogcr_data {
    sxd_emad_common_data_t   common;
    struct ku_mogcr_reg     *reg_data;
} sxd_emad_mogcr_data_t;

/**
 * sxd_emad_qtqdr_data_t structure is used to store QTQDR register data.
 */
typedef struct sxd_emad_qtqdr_data {
    sxd_emad_common_data_t   common;
    struct ku_qtqdr_reg     *reg_data;
} sxd_emad_qtqdr_data_t;

/**
 * sxd_emad_rigr_v2_data_t structure is used to store RIGR_V2 register data.
 */
typedef struct sxd_emad_rigr_v2_data {
    sxd_emad_common_data_t   common;
    struct ku_rigr_v2_reg   *reg_data;
} sxd_emad_rigr_v2_data_t;

/**
 * sxd_emad_rtdp_data_t structure is used to store RTDP register data.
 */
typedef struct sxd_emad_rtdp_data {
    sxd_emad_common_data_t   common;
    struct ku_rtdp_reg      *reg_data;
} sxd_emad_rtdp_data_t;

/**
 * sxd_emad_uter_data_t structure is used to store UTER register data.
 */
typedef struct sxd_emad_uter_data {
    sxd_emad_common_data_t   common;
    struct ku_uter_reg      *reg_data;
} sxd_emad_uter_data_t;

/**
 * sxd_emad_pecner_data_t structure is used to store PECNER register data.
 */
typedef struct sxd_emad_pecner_data {
    sxd_emad_common_data_t   common;
    struct ku_pecner_reg    *reg_data;
} sxd_emad_pecner_data_t;

/**
 * sxd_emad_ifbo_data_t structure is used to store IFBO register data.
 */
typedef struct sxd_emad_ifbo_data {
    sxd_emad_common_data_t   common;
    struct ku_ifbo_reg      *reg_data;
} sxd_emad_ifbo_data_t;

/**
 * sxd_emad_tneem_data_t structure is used to store TNEEM register data.
 */
typedef struct sxd_emad_tneem_data {
    sxd_emad_common_data_t   common;
    struct ku_tneem_reg     *reg_data;
} sxd_emad_tneem_data_t;

/**
 * sxd_emad_qtdem_data_t structure is used to store QTDEM register data.
 */
typedef struct sxd_emad_qtdem_data {
    sxd_emad_common_data_t   common;
    struct ku_qtdem_reg     *reg_data;
} sxd_emad_qtdem_data_t;

/**
 * sxd_emad_tnifr_data_t structure is used to store TNIFR register data.
 */
typedef struct sxd_emad_tnifr_data {
    sxd_emad_common_data_t   common;
    struct ku_tnifr_reg     *reg_data;
} sxd_emad_tnifr_data_t;

/**
 * sxd_emad_usacn_data_t structure is used to store USACN register data.
 */
typedef struct sxd_emad_usacn_data {
    sxd_emad_common_data_t   common;
    struct ku_usacn_reg     *reg_data;
} sxd_emad_usacn_data_t;

/**
 * sxd_emad_peaps_data_t structure is used to store PEAPS register data.
 */
typedef struct sxd_emad_peaps_data {
    sxd_emad_common_data_t   common;
    struct ku_peaps_reg     *reg_data;
} sxd_emad_peaps_data_t;

/**
 * sxd_emad_pmpe_data_t structure is used to store PMPE register data.
 */
typedef struct sxd_emad_pmpe_data {
    sxd_emad_common_data_t   common;
    struct ku_pmpe_reg      *reg_data;
} sxd_emad_pmpe_data_t;

/**
 * sxd_emad_hcot_data_t structure is used to store HCOT register data.
 */
typedef struct sxd_emad_hcot_data {
    sxd_emad_common_data_t   common;
    struct ku_hcot_reg      *reg_data;
} sxd_emad_hcot_data_t;

/**
 * sxd_emad_pddr_data_t structure is used to store PDDR register data.
 */
typedef struct sxd_emad_pddr_data {
    sxd_emad_common_data_t   common;
    struct ku_pddr_reg      *reg_data;
} sxd_emad_pddr_data_t;

/**
 * sxd_emad_sbctr_data_t structure is used to store SBCTR register data.
 */
typedef struct sxd_emad_sbctr_data {
    sxd_emad_common_data_t   common;
    struct ku_sbctr_reg     *reg_data;
} sxd_emad_sbctr_data_t;

/**
 * sxd_emad_fmtm_data_t structure is used to store FMTM register data.
 */
typedef struct sxd_emad_fmtm_data {
    sxd_emad_common_data_t   common;
    struct ku_fmtm_reg      *reg_data;
} sxd_emad_fmtm_data_t;

/**
 * sxd_emad_chltm_data_t structure is used to store CHLTM register data.
 */
typedef struct sxd_emad_chltm_data {
    sxd_emad_common_data_t   common;
    struct ku_chltm_reg     *reg_data;
} sxd_emad_chltm_data_t;

/**
 * sxd_emad_mafti_data_t structure is used to store MAFTI register data.
 */
typedef struct sxd_emad_mafti_data {
    sxd_emad_common_data_t   common;
    struct ku_mafti_reg     *reg_data;
} sxd_emad_mafti_data_t;

/**
 * sxd_emad_qteem_data_t structure is used to store QTEEM register data.
 */
typedef struct sxd_emad_qteem_data {
    sxd_emad_common_data_t   common;
    struct ku_qteem_reg     *reg_data;
} sxd_emad_qteem_data_t;

/**
 * sxd_emad_upcon_data_t structure is used to store UPCON register data.
 */
typedef struct sxd_emad_upcon_data {
    sxd_emad_common_data_t   common;
    struct ku_upcon_reg     *reg_data;
} sxd_emad_upcon_data_t;

/**
 * sxd_emad_hmon_data_t structure is used to store HMON register data.
 */
typedef struct sxd_emad_hmon_data {
    sxd_emad_common_data_t   common;
    struct ku_hmon_reg      *reg_data;
} sxd_emad_hmon_data_t;

/**
 * sxd_emad_mgpir_data_t structure is used to store MGPIR register data.
 */
typedef struct sxd_emad_mgpir_data {
    sxd_emad_common_data_t   common;
    struct ku_mgpir_reg     *reg_data;
} sxd_emad_mgpir_data_t;

/**
 * sxd_emad_fmtb_data_t structure is used to store FMTB register data.
 */
typedef struct sxd_emad_fmtb_data {
    sxd_emad_common_data_t   common;
    struct ku_fmtb_reg      *reg_data;
} sxd_emad_fmtb_data_t;

/**
 * sxd_emad_pmtm_data_t structure is used to store PMTM register data.
 */
typedef struct sxd_emad_pmtm_data {
    sxd_emad_common_data_t   common;
    struct ku_pmtm_reg      *reg_data;
} sxd_emad_pmtm_data_t;

/**
 * sxd_emad_fspt_data_t structure is used to store FSPT register data.
 */
typedef struct sxd_emad_fspt_data {
    sxd_emad_common_data_t   common;
    struct ku_fspt_reg      *reg_data;
} sxd_emad_fspt_data_t;

/**
 * sxd_emad_spfsr_data_t structure is used to store SPFSR register data.
 */
typedef struct sxd_emad_spfsr_data {
    sxd_emad_common_data_t   common;
    struct ku_spfsr_reg     *reg_data;
} sxd_emad_spfsr_data_t;

/**
 * sxd_emad_tnqdr_data_t structure is used to store TNQDR register data.
 */
typedef struct sxd_emad_tnqdr_data {
    sxd_emad_common_data_t   common;
    struct ku_tnqdr_reg     *reg_data;
} sxd_emad_tnqdr_data_t;

/**
 * sxd_emad_sffp_data_t structure is used to store SFFP register data.
 */
typedef struct sxd_emad_sffp_data {
    sxd_emad_common_data_t   common;
    struct ku_sffp_reg      *reg_data;
} sxd_emad_sffp_data_t;

/**
 * sxd_emad_mpcir_data_t structure is used to store MPCIR register data.
 */
typedef struct sxd_emad_mpcir_data {
    sxd_emad_common_data_t   common;
    struct ku_mpcir_reg     *reg_data;
} sxd_emad_mpcir_data_t;

/**
 * sxd_emad_pmecr_data_t structure is used to store PMECR register data.
 */
typedef struct sxd_emad_pmecr_data {
    sxd_emad_common_data_t   common;
    struct ku_pmecr_reg     *reg_data;
} sxd_emad_pmecr_data_t;

/**
 * sxd_emad_spaft_data_t structure is used to store SPAFT register data.
 */
typedef struct sxd_emad_spaft_data {
    sxd_emad_common_data_t   common;
    struct ku_spaft_reg     *reg_data;
} sxd_emad_spaft_data_t;

/**
 * sxd_emad_pter_data_t structure is used to store PTER register data.
 */
typedef struct sxd_emad_pter_data {
    sxd_emad_common_data_t   common;
    struct ku_pter_reg      *reg_data;
} sxd_emad_pter_data_t;

/**
 * sxd_emad_upcnt_data_t structure is used to store UPCNT register data.
 */
typedef struct sxd_emad_upcnt_data {
    sxd_emad_common_data_t   common;
    struct ku_upcnt_reg     *reg_data;
} sxd_emad_upcnt_data_t;

/**
 * sxd_emad_sllm_data_t structure is used to store SLLM register data.
 */
typedef struct sxd_emad_sllm_data {
    sxd_emad_common_data_t   common;
    struct ku_sllm_reg      *reg_data;
} sxd_emad_sllm_data_t;

/**
 * sxd_emad_smpu_data_t structure is used to store SMPU register data.
 */
typedef struct sxd_emad_smpu_data {
    sxd_emad_common_data_t   common;
    struct ku_smpu_reg      *reg_data;
} sxd_emad_smpu_data_t;

/**
 * sxd_emad_cegcr_data_t structure is used to store CEGCR register data.
 */
typedef struct sxd_emad_cegcr_data {
    sxd_emad_common_data_t   common;
    struct ku_cegcr_reg     *reg_data;
} sxd_emad_cegcr_data_t;

/**
 * sxd_emad_pmtu_data_t structure is used to store PMTU register data.
 */
typedef struct sxd_emad_pmtu_data {
    sxd_emad_common_data_t   common;
    struct ku_pmtu_reg      *reg_data;
} sxd_emad_pmtu_data_t;

/**
 * sxd_emad_pmmp_data_t structure is used to store PMMP register data.
 */
typedef struct sxd_emad_pmmp_data {
    sxd_emad_common_data_t   common;
    struct ku_pmmp_reg      *reg_data;
} sxd_emad_pmmp_data_t;

/**
 * sxd_emad_upbt_data_t structure is used to store UPBT register data.
 */
typedef struct sxd_emad_upbt_data {
    sxd_emad_common_data_t   common;
    struct ku_upbt_reg      *reg_data;
} sxd_emad_upbt_data_t;

/**
 * sxd_emad_fmep_data_t structure is used to store FMEP register data.
 */
typedef struct sxd_emad_fmep_data {
    sxd_emad_common_data_t   common;
    struct ku_fmep_reg      *reg_data;
} sxd_emad_fmep_data_t;

/**
 * sxd_emad_pecnrr_data_t structure is used to store PECNRR register data.
 */
typedef struct sxd_emad_pecnrr_data {
    sxd_emad_common_data_t   common;
    struct ku_pecnrr_reg    *reg_data;
} sxd_emad_pecnrr_data_t;

/**
 * sxd_emad_rarlpgt_data_t structure is used to store RARLPGT register data.
 */
typedef struct sxd_emad_rarlpgt_data {
    sxd_emad_common_data_t   common;
    struct ku_rarlpgt_reg   *reg_data;
} sxd_emad_rarlpgt_data_t;

/**
 * sxd_emad_utar_data_t structure is used to store UTAR register data.
 */
typedef struct sxd_emad_utar_data {
    sxd_emad_common_data_t   common;
    struct ku_utar_reg      *reg_data;
} sxd_emad_utar_data_t;

/**
 * sxd_emad_pvgt_data_t structure is used to store PVGT register data.
 */
typedef struct sxd_emad_pvgt_data {
    sxd_emad_common_data_t   common;
    struct ku_pvgt_reg      *reg_data;
} sxd_emad_pvgt_data_t;

/**
 * sxd_emad_mddq_data_t structure is used to store MDDQ register data.
 */
typedef struct sxd_emad_mddq_data {
    sxd_emad_common_data_t   common;
    struct ku_mddq_reg      *reg_data;
} sxd_emad_mddq_data_t;

/**
 * sxd_emad_fsdb_data_t structure is used to store FSDB register data.
 */
typedef struct sxd_emad_fsdb_data {
    sxd_emad_common_data_t   common;
    struct ku_fsdb_reg      *reg_data;
} sxd_emad_fsdb_data_t;

/**
 * sxd_emad_tnpc_data_t structure is used to store TNPC register data.
 */
typedef struct sxd_emad_tnpc_data {
    sxd_emad_common_data_t   common;
    struct ku_tnpc_reg      *reg_data;
} sxd_emad_tnpc_data_t;

/**
 * sxd_emad_pecnre_data_t structure is used to store PECNRE register data.
 */
typedef struct sxd_emad_pecnre_data {
    sxd_emad_common_data_t   common;
    struct ku_pecnre_reg    *reg_data;
} sxd_emad_pecnre_data_t;

/**
 * sxd_emad_mdif_data_t structure is used to store MDIF register data.
 */
typedef struct sxd_emad_mdif_data {
    sxd_emad_common_data_t   common;
    struct ku_mdif_reg      *reg_data;
} sxd_emad_mdif_data_t;

/**
 * sxd_emad_mofs_data_t structure is used to store MOFS register data.
 */
typedef struct sxd_emad_mofs_data {
    sxd_emad_common_data_t   common;
    struct ku_mofs_reg      *reg_data;
} sxd_emad_mofs_data_t;

/**
 * sxd_emad_sltp_data_t structure is used to store SLTP register data.
 */
typedef struct sxd_emad_sltp_data {
    sxd_emad_common_data_t   common;
    struct ku_sltp_reg      *reg_data;
} sxd_emad_sltp_data_t;

/**
 * sxd_emad_ralcm_data_t structure is used to store RALCM register data.
 */
typedef struct sxd_emad_ralcm_data {
    sxd_emad_common_data_t   common;
    struct ku_ralcm_reg     *reg_data;
} sxd_emad_ralcm_data_t;

/**
 * sxd_emad_fmqc_data_t structure is used to store FMQC register data.
 */
typedef struct sxd_emad_fmqc_data {
    sxd_emad_common_data_t   common;
    struct ku_fmqc_reg      *reg_data;
} sxd_emad_fmqc_data_t;

/**
 * sxd_emad_pphcr_data_t structure is used to store PPHCR register data.
 */
typedef struct sxd_emad_pphcr_data {
    sxd_emad_common_data_t   common;
    struct ku_pphcr_reg     *reg_data;
} sxd_emad_pphcr_data_t;

/**
 * sxd_emad_qcap_data_t structure is used to store QCAP register data.
 */
typedef struct sxd_emad_qcap_data {
    sxd_emad_common_data_t   common;
    struct ku_qcap_reg      *reg_data;
} sxd_emad_qcap_data_t;

/**
 * sxd_emad_mtwe_data_t structure is used to store MTWE register data.
 */
typedef struct sxd_emad_mtwe_data {
    sxd_emad_common_data_t   common;
    struct ku_mtwe_reg      *reg_data;
} sxd_emad_mtwe_data_t;

/**
 * sxd_emad_mfgd_data_t structure is used to store MFGD register data.
 */
typedef struct sxd_emad_mfgd_data {
    sxd_emad_common_data_t   common;
    struct ku_mfgd_reg      *reg_data;
} sxd_emad_mfgd_data_t;

/**
 * sxd_emad_mgir_data_t structure is used to store MGIR register data.
 */
typedef struct sxd_emad_mgir_data {
    sxd_emad_common_data_t   common;
    struct ku_mgir_reg      *reg_data;
} sxd_emad_mgir_data_t;

/**
 * sxd_emad_rirt_data_t structure is used to store RIRT register data.
 */
typedef struct sxd_emad_rirt_data {
    sxd_emad_common_data_t   common;
    struct ku_rirt_reg      *reg_data;
} sxd_emad_rirt_data_t;

/**
 * sxd_emad_modcr_data_t structure is used to store MODCR register data.
 */
typedef struct sxd_emad_modcr_data {
    sxd_emad_common_data_t   common;
    struct ku_modcr_reg     *reg_data;
} sxd_emad_modcr_data_t;

/**
 * sxd_emad_uccr_data_t structure is used to store UCCR register data.
 */
typedef struct sxd_emad_uccr_data {
    sxd_emad_common_data_t   common;
    struct ku_uccr_reg      *reg_data;
} sxd_emad_uccr_data_t;

/**
 * sxd_emad_tidem_data_t structure is used to store TIDEM register data.
 */
typedef struct sxd_emad_tidem_data {
    sxd_emad_common_data_t   common;
    struct ku_tidem_reg     *reg_data;
} sxd_emad_tidem_data_t;

/**
 * sxd_emad_tigcr_data_t structure is used to store TIGCR register data.
 */
typedef struct sxd_emad_tigcr_data {
    sxd_emad_common_data_t   common;
    struct ku_tigcr_reg     *reg_data;
} sxd_emad_tigcr_data_t;

/**
 * sxd_emad_ralta_data_t structure is used to store RALTA register data.
 */
typedef struct sxd_emad_ralta_data {
    sxd_emad_common_data_t   common;
    struct ku_ralta_reg     *reg_data;
} sxd_emad_ralta_data_t;

/**
 * sxd_emad_mocmi_data_t structure is used to store MOCMI register data.
 */
typedef struct sxd_emad_mocmi_data {
    sxd_emad_common_data_t   common;
    struct ku_mocmi_reg     *reg_data;
} sxd_emad_mocmi_data_t;

/**
 * sxd_emad_rlcmld_data_t structure is used to store RLCMLD register data.
 */
typedef struct sxd_emad_rlcmld_data {
    sxd_emad_common_data_t   common;
    struct ku_rlcmld_reg    *reg_data;
} sxd_emad_rlcmld_data_t;

/**
 * sxd_emad_ppcgp_data_t structure is used to store PPCGP register data.
 */
typedef struct sxd_emad_ppcgp_data {
    sxd_emad_common_data_t   common;
    struct ku_ppcgp_reg     *reg_data;
} sxd_emad_ppcgp_data_t;

/**
 * sxd_emad_raltb_data_t structure is used to store RALTB register data.
 */
typedef struct sxd_emad_raltb_data {
    sxd_emad_common_data_t   common;
    struct ku_raltb_reg     *reg_data;
} sxd_emad_raltb_data_t;

/**
 * sxd_emad_ceer_data_t structure is used to store CEER register data.
 */
typedef struct sxd_emad_ceer_data {
    sxd_emad_common_data_t   common;
    struct ku_ceer_reg      *reg_data;
} sxd_emad_ceer_data_t;

/**
 * sxd_emad_pmtdb_data_t structure is used to store PMTDB register data.
 */
typedef struct sxd_emad_pmtdb_data {
    sxd_emad_common_data_t   common;
    struct ku_pmtdb_reg     *reg_data;
} sxd_emad_pmtdb_data_t;

/**
 * sxd_emad_ibfmrc_data_t structure is used to store IBFMRC register data.
 */
typedef struct sxd_emad_ibfmrc_data {
    sxd_emad_common_data_t   common;
    struct ku_ibfmrc_reg    *reg_data;
} sxd_emad_ibfmrc_data_t;

/**
 * sxd_emad_meccc_data_t structure is used to store MECCC register data.
 */
typedef struct sxd_emad_meccc_data {
    sxd_emad_common_data_t   common;
    struct ku_meccc_reg     *reg_data;
} sxd_emad_meccc_data_t;

/**
 * sxd_emad_utce_data_t structure is used to store UTCE register data.
 */
typedef struct sxd_emad_utce_data {
    sxd_emad_common_data_t   common;
    struct ku_utce_reg      *reg_data;
} sxd_emad_utce_data_t;

/**
 * sxd_emad_tnifr_v2_data_t structure is used to store TNIFR_V2 register data.
 */
typedef struct sxd_emad_tnifr_v2_data {
    sxd_emad_common_data_t   common;
    struct ku_tnifr_v2_reg  *reg_data;
} sxd_emad_tnifr_v2_data_t;

/**
 * sxd_emad_smid_v2_data_t structure is used to store SMID_V2 register data.
 */
typedef struct sxd_emad_smid_v2_data {
    sxd_emad_common_data_t   common;
    struct ku_smid_v2_reg   *reg_data;
} sxd_emad_smid_v2_data_t;

/**
 * sxd_emad_qstct_data_t structure is used to store QSTCT register data.
 */
typedef struct sxd_emad_qstct_data {
    sxd_emad_common_data_t   common;
    struct ku_qstct_reg     *reg_data;
} sxd_emad_qstct_data_t;

/**
 * sxd_emad_pmcr_data_t structure is used to store PMCR register data.
 */
typedef struct sxd_emad_pmcr_data {
    sxd_emad_common_data_t   common;
    struct ku_pmcr_reg      *reg_data;
} sxd_emad_pmcr_data_t;

/**
 * sxd_emad_mtpps_data_t structure is used to store MTPPS register data.
 */
typedef struct sxd_emad_mtpps_data {
    sxd_emad_common_data_t   common;
    struct ku_mtpps_reg     *reg_data;
} sxd_emad_mtpps_data_t;

/**
 * sxd_emad_xralta_data_t structure is used to store XRALTA register data.
 */
typedef struct sxd_emad_xralta_data {
    sxd_emad_common_data_t   common;
    struct ku_xralta_reg    *reg_data;
} sxd_emad_xralta_data_t;

/**
 * sxd_emad_pifr_v2_data_t structure is used to store PIFR_V2 register data.
 */
typedef struct sxd_emad_pifr_v2_data {
    sxd_emad_common_data_t   common;
    struct ku_pifr_v2_reg   *reg_data;
} sxd_emad_pifr_v2_data_t;

/**
 * sxd_emad_mpagr_data_t structure is used to store MPAGR register data.
 */
typedef struct sxd_emad_mpagr_data {
    sxd_emad_common_data_t   common;
    struct ku_mpagr_reg     *reg_data;
} sxd_emad_mpagr_data_t;

/**
 * sxd_emad_xltq_data_t structure is used to store XLTQ register data.
 */
typedef struct sxd_emad_xltq_data {
    sxd_emad_common_data_t   common;
    struct ku_xltq_reg      *reg_data;
} sxd_emad_xltq_data_t;

/**
 * sxd_emad_ppcnt_data_t structure is used to store PPCNT register data.
 */
typedef struct sxd_emad_ppcnt_data {
    sxd_emad_common_data_t   common;
    struct ku_ppcnt_reg     *reg_data;
} sxd_emad_ppcnt_data_t;

/**
 * sxd_emad_cpqe_data_t structure is used to store CPQE register data.
 */
typedef struct sxd_emad_cpqe_data {
    sxd_emad_common_data_t   common;
    struct ku_cpqe_reg      *reg_data;
} sxd_emad_cpqe_data_t;

/**
 * sxd_emad_pefaad_data_t structure is used to store PEFAAD register data.
 */
typedef struct sxd_emad_pefaad_data {
    sxd_emad_common_data_t   common;
    struct ku_pefaad_reg    *reg_data;
} sxd_emad_pefaad_data_t;

/**
 * sxd_emad_pmlpe_data_t structure is used to store PMLPE register data.
 */
typedef struct sxd_emad_pmlpe_data {
    sxd_emad_common_data_t   common;
    struct ku_pmlpe_reg     *reg_data;
} sxd_emad_pmlpe_data_t;

/**
 * sxd_emad_chlmm_data_t structure is used to store CHLMM register data.
 */
typedef struct sxd_emad_chlmm_data {
    sxd_emad_common_data_t   common;
    struct ku_chlmm_reg     *reg_data;
} sxd_emad_chlmm_data_t;

/**
 * sxd_emad_tncr_data_t structure is used to store TNCR register data.
 */
typedef struct sxd_emad_tncr_data {
    sxd_emad_common_data_t   common;
    struct ku_tncr_reg      *reg_data;
} sxd_emad_tncr_data_t;

/**
 * sxd_emad_rarlu_data_t structure is used to store RARLU register data.
 */
typedef struct sxd_emad_rarlu_data {
    sxd_emad_common_data_t   common;
    struct ku_rarlu_reg     *reg_data;
} sxd_emad_rarlu_data_t;

/**
 * sxd_emad_sbsns_data_t structure is used to store SBSNS register data.
 */
typedef struct sxd_emad_sbsns_data {
    sxd_emad_common_data_t   common;
    struct ku_sbsns_reg     *reg_data;
} sxd_emad_sbsns_data_t;

/**
 * sxd_emad_mdir_data_t structure is used to store MDIR register data.
 */
typedef struct sxd_emad_mdir_data {
    sxd_emad_common_data_t   common;
    struct ku_mdir_reg      *reg_data;
} sxd_emad_mdir_data_t;

/**
 * sxd_emad_spzr_data_t structure is used to store SPZR register data.
 */
typedef struct sxd_emad_spzr_data {
    sxd_emad_common_data_t   common;
    struct ku_spzr_reg      *reg_data;
} sxd_emad_spzr_data_t;

/**
 * sxd_emad_xmdr_data_t structure is used to store XMDR register data.
 */
typedef struct sxd_emad_xmdr_data {
    sxd_emad_common_data_t   common;
    struct ku_xmdr_reg      *reg_data;
} sxd_emad_xmdr_data_t;

/**
 * sxd_emad_mtcap_data_t structure is used to store MTCAP register data.
 */
typedef struct sxd_emad_mtcap_data {
    sxd_emad_common_data_t   common;
    struct ku_mtcap_reg     *reg_data;
} sxd_emad_mtcap_data_t;

/**
 * sxd_emad_fsgcr_data_t structure is used to store FSGCR register data.
 */
typedef struct sxd_emad_fsgcr_data {
    sxd_emad_common_data_t   common;
    struct ku_fsgcr_reg     *reg_data;
} sxd_emad_fsgcr_data_t;

/**
 * sxd_emad_mdfcr_data_t structure is used to store MDFCR register data.
 */
typedef struct sxd_emad_mdfcr_data {
    sxd_emad_common_data_t   common;
    struct ku_mdfcr_reg     *reg_data;
} sxd_emad_mdfcr_data_t;

/**
 * sxd_emad_ugcap_data_t structure is used to store UGCAP register data.
 */
typedef struct sxd_emad_ugcap_data {
    sxd_emad_common_data_t   common;
    struct ku_ugcap_reg     *reg_data;
} sxd_emad_ugcap_data_t;

/**
 * sxd_emad_mddc_data_t structure is used to store MDDC register data.
 */
typedef struct sxd_emad_mddc_data {
    sxd_emad_common_data_t   common;
    struct ku_mddc_reg      *reg_data;
} sxd_emad_mddc_data_t;

/**
 * sxd_emad_paos_data_t structure is used to store PAOS register data.
 */
typedef struct sxd_emad_paos_data {
    sxd_emad_common_data_t   common;
    struct ku_paos_reg      *reg_data;
} sxd_emad_paos_data_t;

/**
 * sxd_emad_mtutc_data_t structure is used to store MTUTC register data.
 */
typedef struct sxd_emad_mtutc_data {
    sxd_emad_common_data_t   common;
    struct ku_mtutc_reg     *reg_data;
} sxd_emad_mtutc_data_t;

/**
 * sxd_emad_sfmr_data_t structure is used to store SFMR register data.
 */
typedef struct sxd_emad_sfmr_data {
    sxd_emad_common_data_t   common;
    struct ku_sfmr_reg      *reg_data;
} sxd_emad_sfmr_data_t;

/**
 * sxd_emad_ptys_data_t structure is used to store PTYS register data.
 */
typedef struct sxd_emad_ptys_data {
    sxd_emad_common_data_t   common;
    struct ku_ptys_reg      *reg_data;
} sxd_emad_ptys_data_t;

/**
 * sxd_emad_upvid_data_t structure is used to store UPVID register data.
 */
typedef struct sxd_emad_upvid_data {
    sxd_emad_common_data_t   common;
    struct ku_upvid_reg     *reg_data;
} sxd_emad_upvid_data_t;

/**
 * sxd_emad_umtu_data_t structure is used to store UMTU register data.
 */
typedef struct sxd_emad_umtu_data {
    sxd_emad_common_data_t   common;
    struct ku_umtu_reg      *reg_data;
} sxd_emad_umtu_data_t;

/**
 * sxd_emad_hrdqt_data_t structure is used to store HRDQT register data.
 */
typedef struct sxd_emad_hrdqt_data {
    sxd_emad_common_data_t   common;
    struct ku_hrdqt_reg     *reg_data;
} sxd_emad_hrdqt_data_t;

/**
 * sxd_emad_mtsde_data_t structure is used to store MTSDE register data.
 */
typedef struct sxd_emad_mtsde_data {
    sxd_emad_common_data_t   common;
    struct ku_mtsde_reg     *reg_data;
} sxd_emad_mtsde_data_t;

/**
 * sxd_emad_smpe_data_t structure is used to store SMPE register data.
 */
typedef struct sxd_emad_smpe_data {
    sxd_emad_common_data_t   common;
    struct ku_smpe_reg      *reg_data;
} sxd_emad_smpe_data_t;

/**
 * sxd_emad_pplr_data_t structure is used to store PPLR register data.
 */
typedef struct sxd_emad_pplr_data {
    sxd_emad_common_data_t   common;
    struct ku_pplr_reg      *reg_data;
} sxd_emad_pplr_data_t;

/**
 * sxd_emad_upvc_data_t structure is used to store UPVC register data.
 */
typedef struct sxd_emad_upvc_data {
    sxd_emad_common_data_t   common;
    struct ku_upvc_reg      *reg_data;
} sxd_emad_upvc_data_t;

/**
 * sxd_emad_hett_data_t structure is used to store HETT register data.
 */
typedef struct sxd_emad_hett_data {
    sxd_emad_common_data_t   common;
    struct ku_hett_reg      *reg_data;
} sxd_emad_hett_data_t;

/**
 * sxd_emad_mtppst_data_t structure is used to store MTPPST register data.
 */
typedef struct sxd_emad_mtppst_data {
    sxd_emad_common_data_t   common;
    struct ku_mtppst_reg    *reg_data;
} sxd_emad_mtppst_data_t;

/**
 * sxd_emad_xgcr_data_t structure is used to store XGCR register data.
 */
typedef struct sxd_emad_xgcr_data {
    sxd_emad_common_data_t   common;
    struct ku_xgcr_reg      *reg_data;
} sxd_emad_xgcr_data_t;

/**
 * sxd_emad_tiqdr_data_t structure is used to store TIQDR register data.
 */
typedef struct sxd_emad_tiqdr_data {
    sxd_emad_common_data_t   common;
    struct ku_tiqdr_reg     *reg_data;
} sxd_emad_tiqdr_data_t;

/**
 * sxd_emad_fpftt_data_t structure is used to store FPFTT register data.
 */
typedef struct sxd_emad_fpftt_data {
    sxd_emad_common_data_t   common;
    struct ku_fpftt_reg     *reg_data;
} sxd_emad_fpftt_data_t;

/**
 * sxd_emad_xraltb_data_t structure is used to store XRALTB register data.
 */
typedef struct sxd_emad_xraltb_data {
    sxd_emad_common_data_t   common;
    struct ku_xraltb_reg    *reg_data;
} sxd_emad_xraltb_data_t;

/**
 * sxd_emad_tngee_data_t structure is used to store TNGEE register data.
 */
typedef struct sxd_emad_tngee_data {
    sxd_emad_common_data_t   common;
    struct ku_tngee_reg     *reg_data;
} sxd_emad_tngee_data_t;

/**
 * sxd_emad_spms_v2_data_t structure is used to store SPMS_V2 register data.
 */
typedef struct sxd_emad_spms_v2_data {
    sxd_emad_common_data_t   common;
    struct ku_spms_v2_reg   *reg_data;
} sxd_emad_spms_v2_data_t;

/**
 * sxd_emad_smpeb_data_t structure is used to store SMPEB register data.
 */
typedef struct sxd_emad_smpeb_data {
    sxd_emad_common_data_t   common;
    struct ku_smpeb_reg     *reg_data;
} sxd_emad_smpeb_data_t;

/**
 * sxd_emad_usadb_data_t structure is used to store USADB register data.
 */
typedef struct sxd_emad_usadb_data {
    sxd_emad_common_data_t   common;
    struct ku_usadb_reg     *reg_data;
} sxd_emad_usadb_data_t;

/**
 * sxd_emad_ibfmr_data_t structure is used to store IBFMR register data.
 */
typedef struct sxd_emad_ibfmr_data {
    sxd_emad_common_data_t   common;
    struct ku_ibfmr_reg     *reg_data;
} sxd_emad_ibfmr_data_t;

/**
 * sxd_emad_sbsnte_data_t structure is used to store SBSNTE register data.
 */
typedef struct sxd_emad_sbsnte_data {
    sxd_emad_common_data_t   common;
    struct ku_sbsnte_reg    *reg_data;
} sxd_emad_sbsnte_data_t;

/**
 * sxd_emad_qspcp_data_t structure is used to store QSPCP register data.
 */
typedef struct sxd_emad_qspcp_data {
    sxd_emad_common_data_t   common;
    struct ku_qspcp_reg     *reg_data;
} sxd_emad_qspcp_data_t;

/**
 * sxd_emad_rngcr_data_t structure is used to store RNGCR register data.
 */
typedef struct sxd_emad_rngcr_data {
    sxd_emad_common_data_t   common;
    struct ku_rngcr_reg     *reg_data;
} sxd_emad_rngcr_data_t;

/**
 * sxd_emad_ppbs_data_t structure is used to store PPBS register data.
 */
typedef struct sxd_emad_ppbs_data {
    sxd_emad_common_data_t   common;
    struct ku_ppbs_reg      *reg_data;
} sxd_emad_ppbs_data_t;

/**
 * sxd_emad_ppbt_data_t structure is used to store PPBT register data.
 */
typedef struct sxd_emad_ppbt_data {
    sxd_emad_common_data_t   common;
    struct ku_ppbt_reg      *reg_data;
} sxd_emad_ppbt_data_t;

/**
 * sxd_emad_msees_data_t structure is used to store MSEES register data.
 */
typedef struct sxd_emad_msees_data {
    sxd_emad_common_data_t   common;
    struct ku_msees_reg     *reg_data;
} sxd_emad_msees_data_t;

/**
 * sxd_emad_sgcr_data_t structure is used to store SGCR register data.
 */
typedef struct sxd_emad_sgcr_data {
    sxd_emad_common_data_t   common;
    struct ku_sgcr_reg      *reg_data;
} sxd_emad_sgcr_data_t;

/**
 * sxd_emad_mpnhlfe_data_t structure is used to store MPNHLFE register data.
 */
typedef struct sxd_emad_mpnhlfe_data {
    sxd_emad_common_data_t   common;
    struct ku_mpnhlfe_reg   *reg_data;
} sxd_emad_mpnhlfe_data_t;

/**
 * sxd_emad_fppc_data_t structure is used to store FPPC register data.
 */
typedef struct sxd_emad_fppc_data {
    sxd_emad_common_data_t   common;
    struct ku_fppc_reg      *reg_data;
} sxd_emad_fppc_data_t;

/**
 * sxd_emad_mtewe_data_t structure is used to store MTEWE register data.
 */
typedef struct sxd_emad_mtewe_data {
    sxd_emad_common_data_t   common;
    struct ku_mtewe_reg     *reg_data;
} sxd_emad_mtewe_data_t;

/**
 * sxd_emad_mtpspu_data_t structure is used to store MTPSPU register data.
 */
typedef struct sxd_emad_mtpspu_data {
    sxd_emad_common_data_t   common;
    struct ku_mtpspu_reg    *reg_data;
} sxd_emad_mtpspu_data_t;

/**
 * sxd_emad_hgcr_data_t structure is used to store HGCR register data.
 */
typedef struct sxd_emad_hgcr_data {
    sxd_emad_common_data_t   common;
    struct ku_hgcr_reg      *reg_data;
} sxd_emad_hgcr_data_t;

/**
 * sxd_emad_fgcr_data_t structure is used to store FGCR register data.
 */
typedef struct sxd_emad_fgcr_data {
    sxd_emad_common_data_t   common;
    struct ku_fgcr_reg      *reg_data;
} sxd_emad_fgcr_data_t;

/**
 * sxd_emad_utfc_data_t structure is used to store UTFC register data.
 */
typedef struct sxd_emad_utfc_data {
    sxd_emad_common_data_t   common;
    struct ku_utfc_reg      *reg_data;
} sxd_emad_utfc_data_t;

/**
 * sxd_emad_xlkbu_data_t structure is used to store XLKBU register data.
 */
typedef struct sxd_emad_xlkbu_data {
    sxd_emad_common_data_t   common;
    struct ku_xlkbu_reg     *reg_data;
} sxd_emad_xlkbu_data_t;

/**
 * sxd_emad_xrmt_data_t structure is used to store XRMT register data.
 */
typedef struct sxd_emad_xrmt_data {
    sxd_emad_common_data_t   common;
    struct ku_xrmt_reg      *reg_data;
} sxd_emad_xrmt_data_t;

/**
 * sxd_emad_cepc_data_t structure is used to store CEPC register data.
 */
typedef struct sxd_emad_cepc_data {
    sxd_emad_common_data_t   common;
    struct ku_cepc_reg      *reg_data;
} sxd_emad_cepc_data_t;

/**
 * sxd_emad_qspip_data_t structure is used to store QSPIP register data.
 */
typedef struct sxd_emad_qspip_data {
    sxd_emad_common_data_t   common;
    struct ku_qspip_reg     *reg_data;
} sxd_emad_qspip_data_t;

/**
 * sxd_emad_slsir_data_t structure is used to store SLSIR register data.
 */
typedef struct sxd_emad_slsir_data {
    sxd_emad_common_data_t   common;
    struct ku_slsir_reg     *reg_data;
} sxd_emad_slsir_data_t;

/**
 * sxd_emad_reiv_data_t structure is used to store REIV register data.
 */
typedef struct sxd_emad_reiv_data {
    sxd_emad_common_data_t   common;
    struct ku_reiv_reg      *reg_data;
} sxd_emad_reiv_data_t;

/**
 * sxd_emad_ppad_data_t structure is used to store PPAD register data.
 */
typedef struct sxd_emad_ppad_data {
    sxd_emad_common_data_t   common;
    struct ku_ppad_reg      *reg_data;
} sxd_emad_ppad_data_t;

/**
 * sxd_emad_prei_data_t structure is used to store PREI register data.
 */
typedef struct sxd_emad_prei_data {
    sxd_emad_common_data_t   common;
    struct ku_prei_reg      *reg_data;
} sxd_emad_prei_data_t;

/**
 * sxd_emad_mocs_data_t structure is used to store MOCS register data.
 */
typedef struct sxd_emad_mocs_data {
    sxd_emad_common_data_t   common;
    struct ku_mocs_reg      *reg_data;
} sxd_emad_mocs_data_t;

/**
 * sxd_emad_ipac_data_t structure is used to store IPAC register data.
 */
typedef struct sxd_emad_ipac_data {
    sxd_emad_common_data_t   common;
    struct ku_ipac_reg      *reg_data;
} sxd_emad_ipac_data_t;

/**
 * sxd_emad_pllp_data_t structure is used to store PLLP register data.
 */
typedef struct sxd_emad_pllp_data {
    sxd_emad_common_data_t   common;
    struct ku_pllp_reg      *reg_data;
} sxd_emad_pllp_data_t;

/**
 * sxd_emad_spad_data_t structure is used to store SPAD register data.
 */
typedef struct sxd_emad_spad_data {
    sxd_emad_common_data_t   common;
    struct ku_spad_reg      *reg_data;
} sxd_emad_spad_data_t;

/**
 * sxd_emad_qeec_data_t structure is used to store QEEC register data.
 */
typedef struct sxd_emad_qeec_data {
    sxd_emad_common_data_t   common;
    struct ku_qeec_reg      *reg_data;
} sxd_emad_qeec_data_t;

/**
 * sxd_emad_rlcmle_data_t structure is used to store RLCMLE register data.
 */
typedef struct sxd_emad_rlcmle_data {
    sxd_emad_common_data_t   common;
    struct ku_rlcmle_reg    *reg_data;
} sxd_emad_rlcmle_data_t;

/**
 * sxd_emad_sbsnt_data_t structure is used to store SBSNT register data.
 */
typedef struct sxd_emad_sbsnt_data {
    sxd_emad_common_data_t   common;
    struct ku_sbsnt_reg     *reg_data;
} sxd_emad_sbsnt_data_t;

/**
 * sxd_emad_rarft_data_t structure is used to store RARFT register data.
 */
typedef struct sxd_emad_rarft_data {
    sxd_emad_common_data_t   common;
    struct ku_rarft_reg     *reg_data;
} sxd_emad_rarft_data_t;

/**
 * sxd_emad_sbgcr_data_t structure is used to store SBGCR register data.
 */
typedef struct sxd_emad_sbgcr_data {
    sxd_emad_common_data_t   common;
    struct ku_sbgcr_reg     *reg_data;
} sxd_emad_sbgcr_data_t;

/**
 * sxd_emad_mcqi_data_t structure is used to store MCQI register data.
 */
typedef struct sxd_emad_mcqi_data {
    sxd_emad_common_data_t   common;
    struct ku_mcqi_reg      *reg_data;
} sxd_emad_mcqi_data_t;

/**
 * sxd_emad_rargcr_data_t structure is used to store RARGCR register data.
 */
typedef struct sxd_emad_rargcr_data {
    sxd_emad_common_data_t   common;
    struct ku_rargcr_reg    *reg_data;
} sxd_emad_rargcr_data_t;

/**
 * sxd_emad_chltr_data_t structure is used to store CHLTR register data.
 */
typedef struct sxd_emad_chltr_data {
    sxd_emad_common_data_t   common;
    struct ku_chltr_reg     *reg_data;
} sxd_emad_chltr_data_t;

/**
 * sxd_emad_rarsr_data_t structure is used to store RARSR register data.
 */
typedef struct sxd_emad_rarsr_data {
    sxd_emad_common_data_t   common;
    struct ku_rarsr_reg     *reg_data;
} sxd_emad_rarsr_data_t;

/**
 * sxd_emad_usak_data_t structure is used to store USAK register data.
 */
typedef struct sxd_emad_usak_data {
    sxd_emad_common_data_t   common;
    struct ku_usak_reg      *reg_data;
} sxd_emad_usak_data_t;

/**
 * sxd_emad_utcc_data_t structure is used to store UTCC register data.
 */
typedef struct sxd_emad_utcc_data {
    sxd_emad_common_data_t   common;
    struct ku_utcc_reg      *reg_data;
} sxd_emad_utcc_data_t;

/**
 * sxd_emad_ratrb_data_t structure is used to store RATRB register data.
 */
typedef struct sxd_emad_ratrb_data {
    sxd_emad_common_data_t   common;
    struct ku_ratrb_reg     *reg_data;
} sxd_emad_ratrb_data_t;

/**
 * sxd_emad_tngcr_data_t structure is used to store TNGCR register data.
 */
typedef struct sxd_emad_tngcr_data {
    sxd_emad_common_data_t   common;
    struct ku_tngcr_reg     *reg_data;
} sxd_emad_tngcr_data_t;

/**
 * sxd_emad_molp_data_t structure is used to store MOLP register data.
 */
typedef struct sxd_emad_molp_data {
    sxd_emad_common_data_t   common;
    struct ku_molp_reg      *reg_data;
} sxd_emad_molp_data_t;

/**
 * sxd_emad_qtttl_data_t structure is used to store QTTTL register data.
 */
typedef struct sxd_emad_qtttl_data {
    sxd_emad_common_data_t   common;
    struct ku_qtttl_reg     *reg_data;
} sxd_emad_qtttl_data_t;

/**
 * sxd_emad_ptasv2_data_t structure is used to store PTASV2 register data.
 */
typedef struct sxd_emad_ptasv2_data {
    sxd_emad_common_data_t   common;
    struct ku_ptasv2_reg    *reg_data;
} sxd_emad_ptasv2_data_t;

/**
 * sxd_emad_mddt_data_t structure is used to store MDDT register data.
 */
typedef struct sxd_emad_mddt_data {
    sxd_emad_common_data_t   common;
    struct ku_mddt_reg      *reg_data;
} sxd_emad_mddt_data_t;

/**
 * sxd_emad_msecq_data_t structure is used to store MSECQ register data.
 */
typedef struct sxd_emad_msecq_data {
    sxd_emad_common_data_t   common;
    struct ku_msecq_reg     *reg_data;
} sxd_emad_msecq_data_t;

/**
 * sxd_emad_rips_data_t structure is used to store RIPS register data.
 */
typedef struct sxd_emad_rips_data {
    sxd_emad_common_data_t   common;
    struct ku_rips_reg      *reg_data;
} sxd_emad_rips_data_t;

/**
 * sxd_emad_tndem_data_t structure is used to store TNDEM register data.
 */
typedef struct sxd_emad_tndem_data {
    sxd_emad_common_data_t   common;
    struct ku_tndem_reg     *reg_data;
} sxd_emad_tndem_data_t;

/**
 * sxd_emad_ralst_data_t structure is used to store RALST register data.
 */
typedef struct sxd_emad_ralst_data {
    sxd_emad_common_data_t   common;
    struct ku_ralst_reg     *reg_data;
} sxd_emad_ralst_data_t;

/**
 * sxd_emad_upcap_data_t structure is used to store UPCAP register data.
 */
typedef struct sxd_emad_upcap_data {
    sxd_emad_common_data_t   common;
    struct ku_upcap_reg     *reg_data;
} sxd_emad_upcap_data_t;

/**
 * sxd_emad_mtppse_data_t structure is used to store MTPPSE register data.
 */
typedef struct sxd_emad_mtppse_data {
    sxd_emad_common_data_t   common;
    struct ku_mtppse_reg    *reg_data;
} sxd_emad_mtppse_data_t;

/**
 * sxd_emad_mafbi_data_t structure is used to store MAFBI register data.
 */
typedef struct sxd_emad_mafbi_data {
    sxd_emad_common_data_t   common;
    struct ku_mafbi_reg     *reg_data;
} sxd_emad_mafbi_data_t;

/**
 * sxd_emad_rarpc_data_t structure is used to store RARPC register data.
 */
typedef struct sxd_emad_rarpc_data {
    sxd_emad_common_data_t   common;
    struct ku_rarpc_reg     *reg_data;
} sxd_emad_rarpc_data_t;

/**
 * sxd_emad_htacg_data_t structure is used to store HTACG register data.
 */
typedef struct sxd_emad_htacg_data {
    sxd_emad_common_data_t   common;
    struct ku_htacg_reg     *reg_data;
} sxd_emad_htacg_data_t;

/**
 * sxd_emad_urcr_data_t structure is used to store URCR register data.
 */
typedef struct sxd_emad_urcr_data {
    sxd_emad_common_data_t   common;
    struct ku_urcr_reg      *reg_data;
} sxd_emad_urcr_data_t;

/**
 * sxd_emad_sfdb_v2_data_t structure is used to store SFDB_V2 register data.
 */
typedef struct sxd_emad_sfdb_v2_data {
    sxd_emad_common_data_t   common;
    struct ku_sfdb_v2_reg   *reg_data;
} sxd_emad_sfdb_v2_data_t;

/**
 * sxd_emad_tnumt_data_t structure is used to store TNUMT register data.
 */
typedef struct sxd_emad_tnumt_data {
    sxd_emad_common_data_t   common;
    struct ku_tnumt_reg     *reg_data;
} sxd_emad_tnumt_data_t;

/**
 * sxd_emad_rlcme_data_t structure is used to store RLCME register data.
 */
typedef struct sxd_emad_rlcme_data {
    sxd_emad_common_data_t   common;
    struct ku_rlcme_reg     *reg_data;
} sxd_emad_rlcme_data_t;

/**
 * sxd_emad_fshe_data_t structure is used to store FSHE register data.
 */
typedef struct sxd_emad_fshe_data {
    sxd_emad_common_data_t   common;
    struct ku_fshe_reg      *reg_data;
} sxd_emad_fshe_data_t;

/**
 * sxd_emad_fpts_data_t structure is used to store FPTS register data.
 */
typedef struct sxd_emad_fpts_data {
    sxd_emad_common_data_t   common;
    struct ku_fpts_reg      *reg_data;
} sxd_emad_fpts_data_t;

/**
 * sxd_emad_rarpr_data_t structure is used to store RARPR register data.
 */
typedef struct sxd_emad_rarpr_data {
    sxd_emad_common_data_t   common;
    struct ku_rarpr_reg     *reg_data;
} sxd_emad_rarpr_data_t;

/**
 * sxd_emad_perar_data_t structure is used to store PERAR register data.
 */
typedef struct sxd_emad_perar_data {
    sxd_emad_common_data_t   common;
    struct ku_perar_reg     *reg_data;
} sxd_emad_perar_data_t;

/**
 * sxd_emad_pevpb_data_t structure is used to store PEVPB register data.
 */
typedef struct sxd_emad_pevpb_data {
    sxd_emad_common_data_t   common;
    struct ku_pevpb_reg     *reg_data;
} sxd_emad_pevpb_data_t;

/**
 * sxd_emad_sfgc_data_t structure is used to store SFGC register data.
 */
typedef struct sxd_emad_sfgc_data {
    sxd_emad_common_data_t   common;
    struct ku_sfgc_reg      *reg_data;
} sxd_emad_sfgc_data_t;

/**
 * sxd_emad_qtctm_data_t structure is used to store QTCTM register data.
 */
typedef struct sxd_emad_qtctm_data {
    sxd_emad_common_data_t   common;
    struct ku_qtctm_reg     *reg_data;
} sxd_emad_qtctm_data_t;

/**
 * sxd_emad_mcion_data_t structure is used to store MCION register data.
 */
typedef struct sxd_emad_mcion_data {
    sxd_emad_common_data_t   common;
    struct ku_mcion_reg     *reg_data;
} sxd_emad_mcion_data_t;

/**
 * sxd_emad_tiqcr_data_t structure is used to store TIQCR register data.
 */
typedef struct sxd_emad_tiqcr_data {
    sxd_emad_common_data_t   common;
    struct ku_tiqcr_reg     *reg_data;
} sxd_emad_tiqcr_data_t;

/**
 * sxd_emad_fsps_data_t structure is used to store FSPS register data.
 */
typedef struct sxd_emad_fsps_data {
    sxd_emad_common_data_t   common;
    struct ku_fsps_reg      *reg_data;
} sxd_emad_fsps_data_t;

/**
 * sxd_emad_tncr_v2_data_t structure is used to store TNCR_V2 register data.
 */
typedef struct sxd_emad_tncr_v2_data {
    sxd_emad_common_data_t   common;
    struct ku_tncr_v2_reg   *reg_data;
} sxd_emad_tncr_v2_data_t;

/**
 * sxd_emad_pcsr_data_t structure is used to store PCSR register data.
 */
typedef struct sxd_emad_pcsr_data {
    sxd_emad_common_data_t   common;
    struct ku_pcsr_reg      *reg_data;
} sxd_emad_pcsr_data_t;

/**
 * sxd_emad_rarcc_data_t structure is used to store RARCC register data.
 */
typedef struct sxd_emad_rarcc_data {
    sxd_emad_common_data_t   common;
    struct ku_rarcc_reg     *reg_data;
} sxd_emad_rarcc_data_t;

/**
 * sxd_emad_cedr_data_t structure is used to store CEDR register data.
 */
typedef struct sxd_emad_cedr_data {
    sxd_emad_common_data_t   common;
    struct ku_cedr_reg      *reg_data;
} sxd_emad_cedr_data_t;

/**
 * sxd_emad_upaft_data_t structure is used to store UPAFT register data.
 */
typedef struct sxd_emad_upaft_data {
    sxd_emad_common_data_t   common;
    struct ku_upaft_reg     *reg_data;
} sxd_emad_upaft_data_t;

/**
 * sxd_emad_rmid_v2_data_t structure is used to store RMID_V2 register data.
 */
typedef struct sxd_emad_rmid_v2_data {
    sxd_emad_common_data_t   common;
    struct ku_rmid_v2_reg   *reg_data;
} sxd_emad_rmid_v2_data_t;

/**
 * sxd_emad_rarcl_data_t structure is used to store RARCL register data.
 */
typedef struct sxd_emad_rarcl_data {
    sxd_emad_common_data_t   common;
    struct ku_rarcl_reg     *reg_data;
} sxd_emad_rarcl_data_t;

/**
 * sxd_emad_ugcr_data_t structure is used to store UGCR register data.
 */
typedef struct sxd_emad_ugcr_data {
    sxd_emad_common_data_t   common;
    struct ku_ugcr_reg      *reg_data;
} sxd_emad_ugcr_data_t;

/**
 * sxd_emad_mafcr_data_t structure is used to store MAFCR register data.
 */
typedef struct sxd_emad_mafcr_data {
    sxd_emad_common_data_t   common;
    struct ku_mafcr_reg     *reg_data;
} sxd_emad_mafcr_data_t;

/**
 * sxd_emad_pvbt_data_t structure is used to store PVBT register data.
 */
typedef struct sxd_emad_pvbt_data {
    sxd_emad_common_data_t   common;
    struct ku_pvbt_reg      *reg_data;
} sxd_emad_pvbt_data_t;

/**
 * sxd_emad_xralst_data_t structure is used to store XRALST register data.
 */
typedef struct sxd_emad_xralst_data {
    sxd_emad_common_data_t   common;
    struct ku_xralst_reg    *reg_data;
} sxd_emad_xralst_data_t;

/**
 * sxd_emad_sbsrd_data_t structure is used to store SBSRD register data.
 */
typedef struct sxd_emad_sbsrd_data {
    sxd_emad_common_data_t   common;
    struct ku_sbsrd_reg     *reg_data;
} sxd_emad_sbsrd_data_t;

/**
 * sxd_emad_fstm_data_t structure is used to store FSTM register data.
 */
typedef struct sxd_emad_fstm_data {
    sxd_emad_common_data_t   common;
    struct ku_fstm_reg      *reg_data;
} sxd_emad_fstm_data_t;

/**
 * sxd_emad_plar_data_t structure is used to store PLAR register data.
 */
typedef struct sxd_emad_plar_data {
    sxd_emad_common_data_t   common;
    struct ku_plar_reg      *reg_data;
} sxd_emad_plar_data_t;

/**
 * sxd_emad_qsptc_data_t structure is used to store QSPTC register data.
 */
typedef struct sxd_emad_qsptc_data {
    sxd_emad_common_data_t   common;
    struct ku_qsptc_reg     *reg_data;
} sxd_emad_qsptc_data_t;

/**
 * sxd_emad_iddd_data_t structure is used to store IDDD register data.
 */
typedef struct sxd_emad_iddd_data {
    sxd_emad_common_data_t   common;
    struct ku_iddd_reg      *reg_data;
} sxd_emad_iddd_data_t;

/**
 * sxd_emad_iedr_data_t structure is used to store IEDR register data.
 */
typedef struct sxd_emad_iedr_data {
    sxd_emad_common_data_t   common;
    struct ku_iedr_reg      *reg_data;
} sxd_emad_iedr_data_t;

/**
 * sxd_emad_ieds_data_t structure is used to store IEDS register data.
 */
typedef struct sxd_emad_ieds_data {
    sxd_emad_common_data_t   common;
    struct ku_ieds_reg      *reg_data;
} sxd_emad_ieds_data_t;

/**
 * sxd_emad_pmaos_data_t structure is used to store PMAOS register data.
 */
typedef struct sxd_emad_pmaos_data {
    sxd_emad_common_data_t   common;
    struct ku_pmaos_reg     *reg_data;
} sxd_emad_pmaos_data_t;

/**
 * sxd_emad_rxlte_data_t structure is used to store RXLTE register data.
 */
typedef struct sxd_emad_rxlte_data {
    sxd_emad_common_data_t   common;
    struct ku_rxlte_reg     *reg_data;
} sxd_emad_rxlte_data_t;

/**
 * sxd_emad_sbhbr_v2_data_t structure is used to store SBHBR_V2 register data.
 */
typedef struct sxd_emad_sbhbr_v2_data {
    sxd_emad_common_data_t   common;
    struct ku_sbhbr_v2_reg  *reg_data;
} sxd_emad_sbhbr_v2_data_t;

/**
 * sxd_emad_tnqcr_data_t structure is used to store TNQCR register data.
 */
typedef struct sxd_emad_tnqcr_data {
    sxd_emad_common_data_t   common;
    struct ku_tnqcr_reg     *reg_data;
} sxd_emad_tnqcr_data_t;

/**
 * sxd_emad_sbhrr_v2_data_t structure is used to store SBHRR_V2 register data.
 */
typedef struct sxd_emad_sbhrr_v2_data {
    sxd_emad_common_data_t   common;
    struct ku_sbhrr_v2_reg  *reg_data;
} sxd_emad_sbhrr_v2_data_t;

/**
 * sxd_emad_pbsr_data_t structure is used to store PBSR register data.
 */
typedef struct sxd_emad_pbsr_data {
    sxd_emad_common_data_t   common;
    struct ku_pbsr_reg      *reg_data;
} sxd_emad_pbsr_data_t;

/**
 * sxd_emad_rxltm_data_t structure is used to store RXLTM register data.
 */
typedef struct sxd_emad_rxltm_data {
    sxd_emad_common_data_t   common;
    struct ku_rxltm_reg     *reg_data;
} sxd_emad_rxltm_data_t;

/**
 * sxd_emad_msgi_data_t structure is used to store MSGI register data.
 */
typedef struct sxd_emad_msgi_data {
    sxd_emad_common_data_t   common;
    struct ku_msgi_reg      *reg_data;
} sxd_emad_msgi_data_t;

/**
 * sxd_emad_uver_data_t structure is used to store UVER register data.
 */
typedef struct sxd_emad_uver_data {
    sxd_emad_common_data_t   common;
    struct ku_uver_reg      *reg_data;
} sxd_emad_uver_data_t;

/**
 * sxd_emad_momte_data_t structure is used to store MOMTE register data.
 */
typedef struct sxd_emad_momte_data {
    sxd_emad_common_data_t   common;
    struct ku_momte_reg     *reg_data;
} sxd_emad_momte_data_t;

/**
 * sxd_emad_rmpe_data_t structure is used to store RMPE register data.
 */
typedef struct sxd_emad_rmpe_data {
    sxd_emad_common_data_t   common;
    struct ku_rmpe_reg      *reg_data;
} sxd_emad_rmpe_data_t;

/**
 * sxd_emad_svfa_data_t structure is used to store SVFA register data.
 */
typedef struct sxd_emad_svfa_data {
    sxd_emad_common_data_t   common;
    struct ku_svfa_reg      *reg_data;
} sxd_emad_svfa_data_t;

/**
 * sxd_emad_fmtpa_data_t structure is used to store FMTPA register data.
 */
typedef struct sxd_emad_fmtpa_data {
    sxd_emad_common_data_t   common;
    struct ku_fmtpa_reg     *reg_data;
} sxd_emad_fmtpa_data_t;

/**
 * sxd_emad_mafri_data_t structure is used to store MAFRI register data.
 */
typedef struct sxd_emad_mafri_data {
    sxd_emad_common_data_t   common;
    struct ku_mafri_reg     *reg_data;
} sxd_emad_mafri_data_t;

/**
 * sxd_emad_fmtpc_data_t structure is used to store FMTPC register data.
 */
typedef struct sxd_emad_fmtpc_data {
    sxd_emad_common_data_t   common;
    struct ku_fmtpc_reg     *reg_data;
} sxd_emad_fmtpc_data_t;

/**
 * sxd_emad_ihsr_data_t structure is used to store IHSR register data.
 */
typedef struct sxd_emad_ihsr_data {
    sxd_emad_common_data_t   common;
    struct ku_ihsr_reg      *reg_data;
} sxd_emad_ihsr_data_t;

/**
 * sxd_emad_mspi_data_t structure is used to store MSPI register data.
 */
typedef struct sxd_emad_mspi_data {
    sxd_emad_common_data_t   common;
    struct ku_mspi_reg      *reg_data;
} sxd_emad_mspi_data_t;

/**
 * sxd_emad_fphtt_data_t structure is used to store FPHTT register data.
 */
typedef struct sxd_emad_fphtt_data {
    sxd_emad_common_data_t   common;
    struct ku_fphtt_reg     *reg_data;
} sxd_emad_fphtt_data_t;

/**
 * sxd_emad_mcc_data_t structure is used to store MCC register data.
 */
typedef struct sxd_emad_mcc_data {
    sxd_emad_common_data_t   common;
    struct ku_mcc_reg       *reg_data;
} sxd_emad_mcc_data_t;

/**
 * sxd_emad_sfdb_data_t structure is used to store SFDB register data.
 */
typedef struct sxd_emad_sfdb_data {
    sxd_emad_common_data_t   common;
    struct ku_sfdb_reg      *reg_data;
} sxd_emad_sfdb_data_t;

/**
 * sxd_emad_pmtps_data_t structure is used to store PMTPS register data.
 */
typedef struct sxd_emad_pmtps_data {
    sxd_emad_common_data_t   common;
    struct ku_pmtps_reg     *reg_data;
} sxd_emad_pmtps_data_t;

/**
 * sxd_emad_mopce_data_t structure is used to store MOPCE register data.
 */
typedef struct sxd_emad_mopce_data {
    sxd_emad_common_data_t   common;
    struct ku_mopce_reg     *reg_data;
} sxd_emad_mopce_data_t;

/**
 * sxd_emad_mfde_data_t structure is used to store MFDE register data.
 */
typedef struct sxd_emad_mfde_data {
    sxd_emad_common_data_t   common;
    struct ku_mfde_reg      *reg_data;
} sxd_emad_mfde_data_t;

/**
 * sxd_emad_rxltcc_data_t structure is used to store RXLTCC register data.
 */
typedef struct sxd_emad_rxltcc_data {
    sxd_emad_common_data_t   common;
    struct ku_rxltcc_reg    *reg_data;
} sxd_emad_rxltcc_data_t;

/**
 * sxd_emad_sbhpc_data_t structure is used to store SBHPC register data.
 */
typedef struct sxd_emad_sbhpc_data {
    sxd_emad_common_data_t   common;
    struct ku_sbhpc_reg     *reg_data;
} sxd_emad_sbhpc_data_t;

/**
 * sxd_emad_mbct_data_t structure is used to store MBCT register data.
 */
typedef struct sxd_emad_mbct_data {
    sxd_emad_common_data_t   common;
    struct ku_mbct_reg      *reg_data;
} sxd_emad_mbct_data_t;

/**
 * sxd_emad_mcda_data_t structure is used to store MCDA register data.
 */
typedef struct sxd_emad_mcda_data {
    sxd_emad_common_data_t   common;
    struct ku_mcda_reg      *reg_data;
} sxd_emad_mcda_data_t;

/**
 * sxd_emad_utfd_data_t structure is used to store UTFD register data.
 */
typedef struct sxd_emad_utfd_data {
    sxd_emad_common_data_t   common;
    struct ku_utfd_reg      *reg_data;
} sxd_emad_utfd_data_t;


/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Function declarations
 ***********************************************/



#endif /* __SXD_EMAD_AUTO_DATA_H__ */
