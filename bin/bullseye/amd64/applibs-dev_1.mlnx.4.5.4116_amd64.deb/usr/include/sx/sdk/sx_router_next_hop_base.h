/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 * LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 * FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 * See the Apache Version 2.0 License for specific language governing
 * permissions and limitations under the License.
 *
 */

/*
 * NOTE:
 * sx_router_next_hop_base.h is a base file with common types and definitions used by router next hops.
 * The various next hops types are defined in sx_next_hop.h
 * Avoid from adding #include of additional sx h files that further includes sx_next_hop.h (it will cause cyclic dependency)
 *
 */
#ifndef __SX_ROUTER_NEXT_HOP_BASE_H__
#define __SX_ROUTER_NEXT_HOP_BASE_H__

#include "sx/sdk/auto_headers/sx_router_next_hop_base_auto.h"

/************************************************
 *  Type definitions
 ***********************************************/

#define SX_ROUTER_ACTION_CHECK_RANGE(ROUTER_ACTION) \
    SX_CHECK_MAX(ROUTER_ACTION, SX_ROUTER_ACTION_MAX)

#endif /* __SX_ROUTER_NEXT_HOP_BASE_H__ */
