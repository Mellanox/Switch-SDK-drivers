/*
 * Copyright (C) Mellanox Technologies, Ltd. 2001-2019 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */


#ifndef WJH_LIB_TYPES_H_
#define WJH_LIB_TYPES_H_

#ifdef __KERNEL__
#include <linux/version.h>

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(5, 10, 0))
#include <linux/time64.h>
#define timespec timespec64
#define time_t   time64_t
#endif /* (LINUX_VERSION_CODE >= KERNEL_VERSION(5, 10, 0)) */
typedef int boolean_t;
#else /* __KERNEL__ */
#include <stdint.h>
#include <time.h>
#include <stdio.h>
#include <string.h>
#include "complib/cl_types_osd.h"
#endif

/************************************************
 *  Macros
 ***********************************************/

#define WJH_USER_CHANNEL_ID_INVALID (0xFFFFFFFF)
#define WJH_INVALID_PORT_ID         (0)
#define WJH_INVALID_PORT_LABEL      (0)
#define WJH_CPU_PORT_ID             (0x40010000)

#define WJH_MEM_CLR(src)            (memset(&(src), 0, sizeof(src)))
#define SX_GENERATE_ENUM(ENUM, STR) ENUM,
/************************************************
 *  Type definitions
 ***********************************************/

typedef enum wjh_drop_reason_group {
    WJH_DROP_REASON_GROUP_BUFFER_E,
    WJH_DROP_REASON_GROUP_ACL_E,
    WJH_DROP_REASON_GROUP_L1_E,
    WJH_DROP_REASON_GROUP_L2_E,
    WJH_DROP_REASON_GROUP_ROUTER_E,
    WJH_DROP_REASON_GROUP_TUNNEL_E,
    WJH_DROP_REASON_GROUP_ROCE_E,
    WJH_DROP_REASON_GROUP_MIN_E = WJH_DROP_REASON_GROUP_BUFFER_E,
    WJH_DROP_REASON_GROUP_MAX_E = WJH_DROP_REASON_GROUP_ROCE_E,
    WJH_DROP_REASON_GROUP_INVALID_E,
} wjh_drop_reason_group_e;

typedef enum wjh_severity {
    WJH_SEVERITY_ALL_E,
    WJH_SEVERITY_NOTICE_E,
    WJH_SEVERITY_WARNING_E,
    WJH_SEVERITY_ERROR_E,
    WJH_SEVERITY_MIN_E = WJH_SEVERITY_ALL_E,
    WJH_SEVERITY_MAX_E = WJH_SEVERITY_ERROR_E,
    WJH_SEVERITY_INVALID_E,
} wjh_severity_e;

typedef enum wjh_drop_reason_id {
    WJH_DROP_REASON_ID_MLAG_PORT_ISOLATION_E                                   = 201,
    WJH_DROP_REASON_ID_DESTINATION_MAC_IS_RESERVED_DMAC_IS_01_80_C2_00_00_0X_E = 202,
    WJH_DROP_REASON_ID_VLAN_TAGGING_MISMATCH_E                                 = 203,
    WJH_DROP_REASON_ID_INGRESS_VLAN_FILTERING_E                                = 204,
    WJH_DROP_REASON_ID_INGRESS_SPANNING_TREE_FILTER_E                          = 205,
    WJH_DROP_REASON_ID_UNICAST_MAC_TABLE_ACTION_DISCARD_E                      = 206,
    WJH_DROP_REASON_ID_MULTICAST_EGRESS_PORT_LIST_IS_EMPTY_E                   = 207,
    WJH_DROP_REASON_ID_PORT_LOOPBACK_FILTER_E                                  = 208,
    WJH_DROP_REASON_ID_SOURCE_MAC_IS_MULTICAST_E                               = 209,
    WJH_DROP_REASON_ID_SOURCE_MAC_EQUALS_DESTINATION_MAC_E                     = 210,
    WJH_DROP_REASON_ID_VLAN_OR_VNI_LOOKUP_FAILED_E                             = 211,
    WJH_DROP_REASON_ID_UNICAST_EGRESS_PORT_LIST_IS_EMPTY_E                     = 212,

    WJH_DROP_REASON_ID_NON_ROUTABLE_PACKET_E                                  = 301,
    WJH_DROP_REASON_ID_BLACKHOLE_ROUTE_E                                      = 302,
    WJH_DROP_REASON_ID_UNRESOLVED_NEIGHBOR_NEXT_HOP_E                         = 303,
    WJH_DROP_REASON_ID_BLACKHOLE_ARP_NEIGHBOR_E                               = 304,
    WJH_DROP_REASON_ID_IPV6_DESTINATION_IN_MULTICAST_SCOPE_FFX0_16_E          = 305,
    WJH_DROP_REASON_ID_IPV6_DESTINATION_IN_MULTICAST_SCOPE_FFX1_16_E          = 306,
    WJH_DROP_REASON_ID_NON_IP_PACKET_E                                        = 307,
    WJH_DROP_REASON_ID_UNICAST_DESTINATION_IP_BUT_MULTICAST_DESTINATION_MAC_E = 308,
    WJH_DROP_REASON_ID_DESTINATION_IP_IS_LOOPBACK_ADDRESS_E                   = 309,
    WJH_DROP_REASON_ID_SOURCE_IP_IS_MULTICAST_E                               = 310,
    WJH_DROP_REASON_ID_SOURCE_IP_IS_IN_CLASS_E_E                              = 311,
    WJH_DROP_REASON_ID_SOURCE_IP_IS_LOOPBACK_ADDRESS_E                        = 312,
    WJH_DROP_REASON_ID_SOURCE_IP_IS_UNSPECIFIED_E                             = 313,
    WJH_DROP_REASON_ID_CHECKSUM_OR_IPVER_OR_IPV4_IHL_TOO_SHORT_E              = 314,
    WJH_DROP_REASON_ID_MULTICAST_MAC_MISMATCH_E                               = 315,
    WJH_DROP_REASON_ID_SOURCE_IP_EQUALS_DESTINATION_IP_E                      = 316,
    WJH_DROP_REASON_ID_IPV4_SOURCE_IP_IS_LIMITED_BROADCAST_E                  = 317,
    WJH_DROP_REASON_ID_IPV4_DESTINATION_IP_IS_LOCAL_NETWORK_E                 = 318,
    WJH_DROP_REASON_ID_IPV4_DESTINATION_IP_IS_LINK_LOCAL_E                    = 319,
    WJH_DROP_REASON_ID_INGRESS_ROUTER_INTERFACE_IS_DISABLED_E                 = 320,
    WJH_DROP_REASON_ID_EGRESS_ROUTER_INTERFACE_IS_DISABLED_E                  = 321,
    WJH_DROP_REASON_ID_IPV4_ROUTING_TABLE_LPM_UNICAST_MISS_E                  = 323,
    WJH_DROP_REASON_ID_IPV6_ROUTING_TABLE_LPM_UNICAST_MISS_E                  = 324,
    WJH_DROP_REASON_ID_ROUTER_INTERFACE_LOOPBACK_E                            = 325,
    WJH_DROP_REASON_ID_PACKET_SIZE_IS_LARGER_THAN_ROUTER_INTERFACE_MTU_E      = 326,
    WJH_DROP_REASON_ID_TTL_VALUE_IS_TOO_SMALL_E                               = 327,

    WJH_DROP_REASON_ID_OVERLAY_SWITCH_SOURCE_MAC_IS_MULTICAST_E           = 402,
    WJH_DROP_REASON_ID_OVERLAY_SWITCH_SOURCE_MAC_EQAULS_DESTINATION_MAC_E = 403,
    WJH_DROP_REASON_ID_BAD_PACKET_WAS_RECEIVED_FROM_THE_PEER_E            = 404,
    WJH_DROP_REASON_ID_ENCAPSULATION_ISOLATION_E                          = 405,

    WJH_DROP_REASON_ID_TAIL_DROP_E       = 503,
    WJH_DROP_REASON_ID_WRED_E            = 504,
    WJH_DROP_REASON_ID_ING_TC_CONGESTION = 505,
    WJH_DROP_REASON_ID_EGR_TC_LATENCY    = 506,

    WJH_DROP_REASON_ID_INGRESS_PORT_ACL_E   = 601,
    WJH_DROP_REASON_ID_INGRESS_ROUTER_ACL_E = 602,
    WJH_DROP_REASON_ID_EGRESS_ROUTER_ACL_E  = 603,
    WJH_DROP_REASON_ID_EGRESS_PORT_ACL_E    = 604,
    WJH_DROP_REASON_ID_INGRESS_TPORT_ACL_E  = 605,
    WJH_DROP_REASON_ID_EGRESS_TPORT_ACL_E   = 606,
    WJH_DROP_REASON_ID_MULTI_POINTS_ACL_E   = 607,

    WJH_DROP_REASON_ID_ROCE_WRONG_PRIORITY       = 701,
    WJH_DROP_REASON_ID_NON_ROCE_ON_ROCE_PRIORITY = 702,
    WJH_DROP_REASON_ID_ROCE_FLOOD                = 703,

    WJH_DROP_REASON_ID_L1_GENERAL_E            = 1000,  /**< General usage for L1 raw packet information, and filter all L1 event.
                                                         * Not a real drop reason */
    WJH_DROP_REASON_ID_L1_PORT_STATE_CHANGES_E = 1002,
    WJH_DROP_REASON_ID_L1_SYMBOL_ERROR_E       = 1004,
    WJH_DROP_REASON_ID_L1_CRC_ERROR_E          = 1005,
} wjh_drop_reason_id_e;

typedef uint32_t wjh_drop_reason_id_t;
typedef uint32_t wjh_port_log_id_t;
typedef uint8_t wjh_traffic_class_t;
typedef uint64_t wjh_acl_rule_id_t;
typedef uint16_t wjh_mirror_cong_t;
typedef uint32_t wjh_mirror_latency_t;
typedef uint8_t wjh_switch_prio_t;


#define WJH_MIRROR_LATENCY_INVALID 0xFFFFFF
#define WJH_MIRROR_TCLASS_INVALID  0x1F
#define WJH_MIRROR_CONG_INVALID    0xFFFF

typedef struct wjh_buffer_drop_basic_attr {
    wjh_port_log_id_t recirculation_port; /**< The port to be used as the analyzer port.
                                           *    This port should not be used as a switch port.
                                           *    Prerequisites for this port on SPC-1:
                                           *    A network port, not a LAG member, no ACL is bound to it,
                                           *    Not an analyzer port already, not an OpenFlow or NVE port,
                                           *    was removed from all L2 protocols,
                                           *    was set to internal loopback mode (will require port admin state
                                           *    to be set to DOWN before),
                                           *    is a member of all vlans, switch prio to PG and buffers are set correctly,
                                           *    Recommended to use single PG with 128Kb of reserved buffer (no shared),
                                           *    is in UP admin state.
                                           *    Requirements for this port on SPC-2:
                                           *    Mirror directly to CPU port is supported.
                                           *    Setting to Invalid (0x0) or CPU port (0x40010000) shall enable mirror to CPU
                                           *    Setting to a valid Network Port will enable
                                           *    legacy backward compatible behavior and
                                           *    the same restrictions of SPC-1 mentioned above applies*/
    uint16_t truncate_size; /**< Optional. Packets will be truncated to this size.
                             *    Units of bytes. The default value is 64B.
                             */
} wjh_buffer_drop_basic_attr_t;

typedef struct wjh_buffer_drop_advanced_attr {
    uint32_t trap_probability; /**< Optional. 1 of trap_probability packets will be trapped.
                                *    Must be a power of 2. Min value of 1, max value of 4096.
                                *    The default value is 128
                                *    in SPC-2 Mirror to CPU Mode, this translates to
                                *    the sample rate of the mirror triggers 1 - 3M*/
    uint32_t trap_id; /**< Optional. SDK trap ID to be used.
                       *  The default value is SX_TRAP_ID_ACL_MAX
                       *  Only applicable to SPC-1 and SPC-2 in legacy mode
                       *  On SPC-2 Mirror to CPU Mode, this is Dont Care*/
    boolean_t ptp_disabled; /**< Deprecated and ignored. The timestamp type for buffer drop is now
                             *   aligned with the timestamp source field in the wjh_user_channel_attr_t. */
} wjh_buffer_drop_advanced_attr_t;

typedef struct wjh_buffer_drop_attr {
    wjh_buffer_drop_basic_attr_t    basic_attr;
    wjh_buffer_drop_advanced_attr_t advanced_attr;
} wjh_buffer_drop_attr_t;

typedef enum wjh_roce_monitor_point {
    WJH_ROCE_MONITOR_POINT_INGRESS = 0,
    WJH_ROCE_MONITOR_POINT_EGRESS  = 1,
    WJH_ROCE_MONITOR_POINT_ALL     = 2,
    WJH_ROCE_MONITOR_POINT_MAX     = WJH_ROCE_MONITOR_POINT_ALL,
} wjh_roce_monitor_point_t;

typedef struct wjh_roce_drop_attr {
    wjh_roce_monitor_point_t roce_monitor_point; /**< The point in which to check for RoCE issues ingress/egress/both */
    wjh_switch_prio_t        roce_switch_prio;   /**< The switch priority expected for RoCE (non-CNP) traffic */
    wjh_switch_prio_t        cnp_switch_prio;    /**< The switch priority expected for CNP RoCE traffic */
} wjh_roce_drop_attr_t;

typedef struct wjh_drop_reason_group_attr {
    union {
        wjh_buffer_drop_attr_t buffer_drop;
        wjh_roce_drop_attr_t   roce_drop;
    } attr;


    uint32_t max_aggregation_entries_cnt;  /**< The maximum number of entries the internal statistics
                                            *   DB may hold when the drop reason group binds to an
                                            *   aggregation or cyclic-and-aggregation user channel.
                                            *   This attribute is ignored when the drop reason group is L1.
                                            *   Value 0 means default value 1024. */
} wjh_drop_reason_group_attr_t;

typedef enum wjh_acl_binding_point {
    WJH_ACL_BINDING_POINT_INGRESS         = 0,
    WJH_ACL_BINDING_POINT_EGRESS          = 1,
    WJH_ACL_BINDING_POINT_RIF_INGRESS     = 2,
    WJH_ACL_BINDING_POINT_RIF_EGRESS      = 3,
    WJH_ACL_BINDING_POINT_TPORT_INGRESS_E = 4,
    WJH_ACL_BINDING_POINT_TPORT_EGRESS_E  = 5,
    WJH_ACL_BINDING_POINT_MULTI_POINTS_E  = 6,
    WJH_ACL_BINDING_POINT_MAX             = WJH_ACL_BINDING_POINT_MULTI_POINTS_E,
} wjh_acl_binding_point_t;

typedef enum wjh_mirror_header_v2_tlv_type {
    WJH_MIRROR_HEADER_V2_TLV_TYPE_ING_BUFF_OCCUPANCY = 0,
    WJH_MIRROR_HEADER_V2_TLV_TYPE_EG_BUFF_OCCUPANCY  = 1,
    WJH_MIRROR_HEADER_V2_TLV_TYPE_LATENCY            = 2,
    WJH_MIRROR_HEADER_V2_TLV_TYPE_FLAGS_EXT          = 3,
    WJH_MIRROR_HEADER_V2_TLV_TYPE_MIRROR_REASON      = 4,
    WJH_MIRROR_HEADER_V2_TLV_TYPE_TCLASS             = 5,
    WJH_MIRROR_HEADER_V2_TLV_TYPE_MIRROR_AGENT       = 6,
    WJH_MIRROR_HEADER_V2_TLV_TYPE_PG                 = 7,
    WJH_MIRROR_HEADER_V2_TLV_TYPE_MAX                = WJH_MIRROR_HEADER_V2_TLV_TYPE_PG
} wjh_mirror_header_v2_tlv_type_e;

typedef enum wjh_event_type {
    WJH_EVENT_NONE_E        = 0,
    WJH_EVENT_PACKET_DROP_E = 1,
    WJH_EVENT_EXCEPTION_E   = 2,
    WJH_EVENT_MIN_E         = WJH_EVENT_NONE_E,
    WJH_EVENT_MAX_E         = WJH_EVENT_EXCEPTION_E,
    WJH_EVENT_INVALID_E     = WJH_EVENT_MAX_E + 1,
} wjh_event_type_e;

typedef struct wjh_drop_reason {
    wjh_drop_reason_id_t id;
    const char         * reason;
    wjh_severity_e       severity;
    const char         * description;
    wjh_event_type_e     event_type;
} wjh_drop_reason_t;

/* raw */
typedef struct wjh_buffer_drop_raw_info {
    void            * packet;
    uint32_t          packet_size;
    wjh_port_log_id_t ingress_port;      /**< ingress_port is not valid when is_lag_member= 1 in recirculation port mode,
                                          * SPAN Mirror header in mirrored packets sent to external network port has either
                                          * ingress LAG or PORT but not both.
                                          */
    wjh_port_log_id_t egress_port;       /**< Spectrum-2 only, Applicable for CONGESTION/LATENCY,
                                          * Not valid when is_egress_lag_member=1 in recirculation port mode */
    wjh_traffic_class_t tc;              /**< Spectrum-2 only */
    wjh_drop_reason_t   drop_reason;     /**< Currently can not tell the individual buffer drop reason
                                          * the id and severity are reserved then, and use same reason string
                                          * and description for all buffer drop reason */
    struct timespec   timestamp;
    uint8_t           is_lag_member;
    wjh_port_log_id_t ingress_lag;
    uint8_t           egress_port_valid;     /**< Spectrum-2 Only, Valid for CONGESTION/LATENCY */
    uint8_t           is_egress_lag_member;  /**< Spectrum-2 only, Applicable for CONGESTION/LATENCY */
    wjh_port_log_id_t egress_lag;            /**< Spectrum-2 only, Applicable for CONGESTION/LATENCY */
    wjh_mirror_cong_t original_occupancy;    /**< Spectrum-2 Only: Port tclass buffer occupancy of the original packet that does mirror_to_cpu,
                                              * units of 8KB, WJH_MIRROR_CONG_INVALID means invalid value
                                              * this will be triggered based on the threshold configured by the user */
    wjh_mirror_latency_t original_latency;  /**< Spectrum-2 Only:  End-to-end latency of the original packet that does mirror_to_cpu,
                                             * default unit is 64 nanoseconds, WJH_MIRROR_LATENCY_INVALID means invalid value
                                             * this will be triggered based on the threshold configured by the user */
} wjh_buffer_drop_raw_info_t;

typedef struct wjh_acl_drop_raw_info {
    void                  * packet;
    uint32_t                packet_size;
    wjh_port_log_id_t       ingress_port;
    wjh_acl_binding_point_t binding_point;
    wjh_acl_rule_id_t       rule_id;
    const char            * acl_name;
    const char            * rule;
    struct timespec         timestamp;
    uint8_t                 is_lag_member;
    wjh_port_log_id_t       ingress_lag;
    wjh_drop_reason_t       drop_reason;
} wjh_acl_drop_raw_info_t;

typedef struct wjh_L2_drop_raw_info {
    void            * packet;
    uint32_t          packet_size;
    wjh_port_log_id_t ingress_port;
    wjh_drop_reason_t drop_reason;
    struct timespec   timestamp;
    uint8_t           is_lag_member;
    wjh_port_log_id_t ingress_lag;
} wjh_L2_drop_raw_info_t;

typedef struct wjh_router_drop_raw_info {
    void            * packet;
    uint32_t          packet_size;
    wjh_port_log_id_t ingress_port;
    wjh_drop_reason_t drop_reason;
    struct timespec   timestamp;
    uint8_t           is_lag_member;
    wjh_port_log_id_t ingress_lag;
} wjh_router_drop_raw_info_t;

typedef struct wjh_tunnel_drop_raw_info {
    void            * packet;
    uint32_t          packet_size;
    wjh_port_log_id_t ingress_port;
    wjh_drop_reason_t drop_reason;
    struct timespec   timestamp;
    uint8_t           is_lag_member;
    wjh_port_log_id_t ingress_lag;
} wjh_tunnel_drop_raw_info_t;

typedef struct wjh_L1_drop_raw_info {
    wjh_port_log_id_t ingress_port;
    struct timespec   timestamp;
    wjh_drop_reason_t reason;
} wjh_L1_drop_raw_info_t;

typedef struct wjh_roce_drop_raw_info {
    void            * packet;
    uint32_t          packet_size;
    wjh_port_log_id_t ingress_port;
    wjh_drop_reason_t drop_reason;
    struct timespec   timestamp;
    uint8_t           is_lag_member;
    wjh_port_log_id_t ingress_lag;
    wjh_switch_prio_t switch_prio;
} wjh_roce_drop_raw_info_t;

/* aggregate */
typedef struct wjh_aggregate_timestamp {
    struct timespec first_timestamp;
    struct timespec last_timestamp;
} wjh_aggregate_timestamp_t;

typedef struct wjh_aggregate_five_tuples {
    const char * sip;
    const char * dip;
    uint8_t      proto;
    uint32_t     sport;
    uint32_t     dport;
} wjh_aggregate_five_tuples_t;

typedef struct wjh_buffer_drop_aggregate_key {
    wjh_aggregate_five_tuples_t five_tuples; /**< Valid if non_ip is 0. */
    uint8_t                     non_ip;
    wjh_port_log_id_t           ingress_port; /**< Valid if the aggregation key mode in WJH initialization parameter is set to detailed mode. */
    uint8_t                     is_lag_member; /**< Valid if the aggregation key mode in WJH initialization parameter is set to detailed mode. */
    wjh_port_log_id_t           ingress_lag; /**< Valid if the aggregation key mode in WJH initialization parameter is set to detailed mode. */
    uint16_t                    vlan; /**< Valid if the aggregation key mode in WJH initialization parameter is set to detailed mode. */
    uint16_t                    ether_type; /**< Valid if the aggregation key mode in WJH initialization parameter is set to detailed mode. */
    unsigned char               dmac[6]; /**< Valid if the aggregation key mode in WJH initialization parameter is set to detailed mode. */
    unsigned char               smac[6]; /**< Valid if the aggregation key mode in WJH initialization parameter is set to detailed mode. */
    wjh_drop_reason_t           reason;
} wjh_buffer_drop_aggregate_key_t;

typedef struct wjh_buffer_drop_aggregate_egress_data {
    wjh_port_log_id_t   egress_port;            /**< Not valid when is_egress_lag_member=1 in recirculation port mode */
    wjh_traffic_class_t tc;
    uint8_t             is_egress_lag_member;
    wjh_port_log_id_t   egress_lag;
    wjh_mirror_cong_t   port_tc_watermark;      /**< Max port tc buffer occupancy of the packet, WJH_MIRROR_CONG_INVALID means invalid value.
                                                 *   This will be triggered based on the threshold configured by the user, user will get the unit by SDK API.
                                                 */
    wjh_mirror_latency_t latency_watermark;     /**< Max end-to-end latency of the packet, WJH_MIRROR_LATENCY_INVALID means invalid value.
                                                 *   This will be triggered based on the threshold configured by the user, user will get the unit by SDK API.
                                                 */
} wjh_buffer_drop_aggregate_egress_data_t;

typedef struct wjh_buffer_drop_aggregate_data {
    wjh_aggregate_timestamp_t               timestamp;
    uint64_t                                count;
    uint8_t                                 egress_data_valid; /**< Spectrum is not supported, Valid for CONGESTION/LATENCY */
    wjh_buffer_drop_aggregate_egress_data_t egress_data;
} wjh_buffer_drop_aggregate_data_t;

typedef struct wjh_acl_drop_aggregate_key {
    wjh_aggregate_five_tuples_t five_tuples; /**< Valid if the aggregation key mode in WJH initialization parameter is set to detailed mode and non_ip is 0. */
    uint8_t                     non_ip; /**< Valid if the aggregation key mode in WJH initialization parameter is set to detailed mode. */
    wjh_port_log_id_t           ingress_port; /**< Valid if the aggregation key mode in WJH initialization parameter is set to detailed mode. */
    uint8_t                     is_lag_member; /**< Valid if the aggregation key mode in WJH initialization parameter is set to detailed mode. */
    wjh_port_log_id_t           ingress_lag; /**< Valid if the aggregation key mode in WJH initialization parameter is set to detailed mode. */
    uint16_t                    vlan; /**< Valid if the aggregation key mode in WJH initialization parameter is set to detailed mode. */
    uint16_t                    ether_type; /**< Valid if the aggregation key mode in WJH initialization parameter is set to detailed mode. */
    unsigned char               dmac[6]; /**< Valid if the aggregation key mode in WJH initialization parameter is set to detailed mode. */
    unsigned char               smac[6]; /**< Valid if the aggregation key mode in WJH initialization parameter is set to detailed mode. */
    wjh_acl_rule_id_t           rule_id;
    const char                * acl_name;
    const char                * rule;
    wjh_drop_reason_t           reason;
} wjh_acl_drop_aggregate_key_t;

typedef struct wjh_acl_drop_aggregate_data {
    wjh_aggregate_timestamp_t timestamp;
    uint64_t                  count;
    uint64_t                  flows_num;      /**< Spectrum-2 only. Not supported for now. */
} wjh_acl_drop_aggregate_data_t;

typedef struct wjh_router_drop_aggregate_key {
    wjh_aggregate_five_tuples_t five_tuples; /**< Valid if non_ip is 0. */
    uint8_t                     non_ip;
    wjh_port_log_id_t           ingress_port; /**< Valid if the aggregation key mode in WJH initialization parameter is set to detailed mode. */
    uint8_t                     is_lag_member; /**< Valid if the aggregation key mode in WJH initialization parameter is set to detailed mode. */
    wjh_port_log_id_t           ingress_lag; /**< Valid if the aggregation key mode in WJH initialization parameter is set to detailed mode. */
    uint16_t                    vlan; /**< Valid if the aggregation key mode in WJH initialization parameter is set to detailed mode. */
    uint16_t                    ether_type; /**< Valid if the aggregation key mode in WJH initialization parameter is set to detailed mode. */
    unsigned char               dmac[6]; /**< Valid if the aggregation key mode in WJH initialization parameter is set to detailed mode. */
    unsigned char               smac[6]; /**< Valid if the aggregation key mode in WJH initialization parameter is set to detailed mode. */
    wjh_drop_reason_t           reason;
} wjh_router_drop_aggregate_key_t;

typedef struct wjh_router_drop_aggregate_data {
    wjh_aggregate_timestamp_t timestamp;
    uint64_t                  count;
} wjh_router_drop_aggregate_data_t;

typedef struct wjh_tunnel_drop_aggregate_key {
    wjh_aggregate_five_tuples_t five_tuples; /**< Valid if non_ip is 0. */
    uint8_t                     non_ip;
    wjh_port_log_id_t           ingress_port; /**< Valid if the aggregation key mode in WJH initialization parameter is set to detailed mode. */
    uint8_t                     is_lag_member; /**< Valid if the aggregation key mode in WJH initialization parameter is set to detailed mode. */
    wjh_port_log_id_t           ingress_lag; /**< Valid if the aggregation key mode in WJH initialization parameter is set to detailed mode. */
    uint16_t                    vlan; /**< Valid if the aggregation key mode in WJH initialization parameter is set to detailed mode. */
    uint16_t                    ether_type; /**< Valid if the aggregation key mode in WJH initialization parameter is set to detailed mode. */
    unsigned char               dmac[6];
    unsigned char               smac[6];
    wjh_drop_reason_t           reason;
} wjh_tunnel_drop_aggregate_key_t;

typedef struct wjh_tunnel_drop_aggregate_data {
    wjh_aggregate_timestamp_t timestamp;
    uint64_t                  count;
} wjh_tunnel_drop_aggregate_data_t;

typedef struct wjh_L2_drop_aggregate_key {
    wjh_aggregate_five_tuples_t five_tuples; /**< Valid if non_ip is 0. */
    uint8_t                     non_ip;
    wjh_port_log_id_t           ingress_port; /**< Valid if the aggregation key mode in WJH initialization parameter is set to detailed mode. */
    uint8_t                     is_lag_member; /**< Valid if the aggregation key mode in WJH initialization parameter is set to detailed mode. */
    wjh_port_log_id_t           ingress_lag; /**< Valid if the aggregation key mode in WJH initialization parameter is set to detailed mode. */
    uint16_t                    vlan; /**< Valid if the aggregation key mode in WJH initialization parameter is set to detailed mode. */
    uint16_t                    ether_type; /**< Valid if the aggregation key mode in WJH initialization parameter is set to detailed mode. */
    unsigned char               dmac[6];
    unsigned char               smac[6];
    wjh_drop_reason_t           reason;
} wjh_L2_drop_aggregate_key_t;

typedef struct wjh_L2_drop_aggregate_data {
    wjh_aggregate_timestamp_t timestamp;
    uint64_t                  count;
} wjh_L2_drop_aggregate_data_t;

typedef struct wjh_L1_drop_aggregate_key {
    wjh_port_log_id_t ingress_port;
} wjh_L1_drop_aggregate_key_t;

typedef struct wjh_L1_drop_aggregate_data {
    uint8_t                   is_port_up;
    char                     *port_down_reason;
    char                     *description;
    uint64_t                  state_change_count;
    uint64_t                  symbol_error_count;
    uint64_t                  crc_error_count;
    wjh_aggregate_timestamp_t timestamp;
    wjh_drop_reason_t         port_state_change_reason; /**< Valid if state_change_count > 0 */
    wjh_drop_reason_t         symbol_error_reason; /**< Valid if symbol_error_count > 0 */
    wjh_drop_reason_t         crc_error_reason; /**< Valid if crc_error_count > 0 */
} wjh_L1_drop_aggregate_data_t;

typedef struct wjh_roce_drop_aggregate_key {
    wjh_aggregate_five_tuples_t five_tuples; /**< Valid if non_ip is 0. */
    uint8_t                     non_ip;
    wjh_port_log_id_t           ingress_port; /**< Valid if the aggregation key mode in WJH initialization parameter is set to detailed mode. */
    uint8_t                     is_lag_member; /**< Valid if the aggregation key mode in WJH initialization parameter is set to detailed mode. */
    wjh_port_log_id_t           ingress_lag; /**< Valid if the aggregation key mode in WJH initialization parameter is set to detailed mode. */
    uint16_t                    vlan; /**< Valid if the aggregation key mode in WJH initialization parameter is set to detailed mode. */
    uint16_t                    ether_type; /**< Valid if the aggregation key mode in WJH initialization parameter is set to detailed mode. */
    unsigned char               dmac[6]; /**< Valid if the aggregation key mode in WJH initialization parameter is set to detailed mode. */
    unsigned char               smac[6]; /**< Valid if the aggregation key mode in WJH initialization parameter is set to detailed mode. */
    wjh_drop_reason_t           reason;
} wjh_roce_drop_aggregate_key_t;

typedef struct wjh_roce_drop_aggregate_data {
    wjh_aggregate_timestamp_t timestamp;
    uint64_t                  count;
} wjh_roce_drop_aggregate_data_t;

/**
 * In push mode, the WJH library periodically queries the dropped packets or statistics and deliver them via user callbacks.
 * In pull mode, the WJH library stops the periodical query. The dropped packets or statistics can be delivered via user callbacks
 * which are explicitly triggered by API wjh_user_channel_pull. Please note that the user callbacks will be executed in the same
 * context/thread of the caller of wjh_user_channel_pull.
 */
typedef enum wjh_user_channel_mode {
    WJH_USER_CHANNEL_MODE_PUSH_E,
    WJH_USER_CHANNEL_MODE_PULL_E,
    WJH_USER_CAHNNEL_MODE_MIN_E = WJH_USER_CHANNEL_MODE_PUSH_E,
    WJH_USER_CAHNNEL_MODE_MAX_E = WJH_USER_CHANNEL_MODE_PULL_E,
} wjh_user_channel_mode_e;

typedef struct wjh_drop_aggregate_attr {
    wjh_user_channel_mode_e mode; /**< Push mode means the data comes from an periodical polling.
                                   *   Pull mode means the data comes from an manual polling (wjh_user_channel_pull API).
                                   */
} wjh_drop_aggregate_attr_t;

typedef enum wjh_status {
    WJH_STATUS_SUCCESS,
    WJH_STATUS_ERROR,
    WJH_STATUS_PARAM_ERROR,
    WJH_STATUS_PARAM_NULL,
    WJH_STATUS_ENTRY_NOT_FOUND,
    WJH_STATUS_ENTRY_ALREADY_EXIST,
    WJH_STATUS_NOT_INITIALIZED,
    WJH_STATUS_ALREADY_INITIALIZED,
    WJH_STATUS_NO_RESOURCES,
    WJH_STATUS_NO_MEMORY,
    WJH_STATUS_UNSUPPORTED,
    WJH_STATUS_IN_PROGRESS,
} wjh_status_t;

typedef enum wjh_verbosity_level {
    WJH_VERBOSITY_LEVEL_NONE = 0,
    WJH_VERBOSITY_LEVEL_ERROR,
    WJH_VERBOSITY_LEVEL_WARNING,
    WJH_VERBOSITY_LEVEL_NOTICE,
    WJH_VERBOSITY_LEVEL_INFO,
    WJH_VERBOSITY_LEVEL_DEBUG,
    WJH_VERBOSITY_LEVEL_FUNCS,
    WJH_VERBOSITY_LEVEL_FRAMES,
    WJH_VERBOSITY_LEVEL_ALL,
    WJH_VERBOSITY_LEVEL_MIN = WJH_VERBOSITY_LEVEL_NONE,
    WJH_VERBOSITY_LEVEL_MAX = WJH_VERBOSITY_LEVEL_ALL,
} wjh_verbosity_level_t;

typedef wjh_status_t (*wjh_buffer_drop_raw_cb)(wjh_buffer_drop_raw_info_t *raw_info_list_p,
                                               uint32_t                   *raw_info_list_size_p);
typedef wjh_status_t (*wjh_acl_drop_raw_cb)(wjh_acl_drop_raw_info_t *raw_info_list_p,
                                            uint32_t                *raw_info_list_size_p);
typedef wjh_status_t (*wjh_router_drop_raw_cb)(wjh_router_drop_raw_info_t *raw_info_list_p,
                                               uint32_t                   *raw_info_list_size_p);
typedef wjh_status_t (*wjh_L2_drop_raw_cb)(wjh_L2_drop_raw_info_t *raw_info_list_p,
                                           uint32_t               *raw_info_list_size_p);
typedef wjh_status_t (*wjh_tunnel_drop_raw_cb)(wjh_tunnel_drop_raw_info_t *raw_info_list_p,
                                               uint32_t                   *raw_info_list_size_p);
typedef wjh_status_t (*wjh_L1_drop_raw_cb)(wjh_L1_drop_raw_info_t *raw_info_list_p,
                                           uint32_t               *raw_info_list_size_p);
typedef wjh_status_t (*wjh_roce_drop_raw_cb)(wjh_roce_drop_raw_info_t *raw_info_list_p,
                                             uint32_t                 *raw_info_list_size_p);

typedef wjh_status_t (*wjh_buffer_drop_aggregate_cb)(wjh_buffer_drop_aggregate_key_t  *key_list_p,
                                                     wjh_buffer_drop_aggregate_data_t *data_list_p,
                                                     uint32_t                         *cnt_p,
                                                     wjh_drop_aggregate_attr_t        *attr_p);
typedef wjh_status_t (*wjh_acl_drop_aggregate_cb)(wjh_acl_drop_aggregate_key_t  *key_list_p,
                                                  wjh_acl_drop_aggregate_data_t *data_list_p,
                                                  uint32_t                      *cnt_p,
                                                  wjh_drop_aggregate_attr_t     *attr_p);
typedef wjh_status_t (*wjh_router_drop_aggregate_cb)(wjh_router_drop_aggregate_key_t  *key_list_p,
                                                     wjh_router_drop_aggregate_data_t *data_list_p,
                                                     uint32_t                         *cnt_p,
                                                     wjh_drop_aggregate_attr_t        *attr_p);
typedef wjh_status_t (*wjh_L2_drop_aggregate_cb)(wjh_L2_drop_aggregate_key_t  *key_list_p,
                                                 wjh_L2_drop_aggregate_data_t *data_list_p,
                                                 uint32_t                     *cnt_p,
                                                 wjh_drop_aggregate_attr_t    *attr_p);
typedef wjh_status_t (*wjh_L1_drop_aggregate_cb)(wjh_L1_drop_aggregate_key_t  *key_list_p,
                                                 wjh_L1_drop_aggregate_data_t *data_list_p,
                                                 uint32_t                     *cnt_p,
                                                 wjh_drop_aggregate_attr_t    *attr_p);
typedef wjh_status_t (*wjh_tunnel_drop_aggregate_cb)(wjh_tunnel_drop_aggregate_key_t  *key_list_p,
                                                     wjh_tunnel_drop_aggregate_data_t *data_list_p,
                                                     uint32_t                         *cnt_p,
                                                     wjh_drop_aggregate_attr_t        *attr_p);
typedef wjh_status_t (*wjh_roce_drop_aggregate_cb)(wjh_roce_drop_aggregate_key_t  *key_list_p,
                                                   wjh_roce_drop_aggregate_data_t *data_list_p,
                                                   uint32_t                       *cnt_p,
                                                   wjh_drop_aggregate_attr_t      *attr_p);

typedef struct wjh_drop_callbacks {
    wjh_drop_reason_group_e drop_reason_group;
    union {
        wjh_buffer_drop_raw_cb buffer;
        wjh_acl_drop_raw_cb    acl;
        wjh_router_drop_raw_cb router;
        wjh_L2_drop_raw_cb     L2;
        wjh_L1_drop_raw_cb     L1;
        wjh_tunnel_drop_raw_cb tunnel;
        wjh_roce_drop_raw_cb   roce;
    } raw_cb;
    union {
        wjh_buffer_drop_aggregate_cb buffer;
        wjh_acl_drop_aggregate_cb    acl;
        wjh_router_drop_aggregate_cb router;
        wjh_L2_drop_aggregate_cb     L2;
        wjh_L1_drop_aggregate_cb     L1;
        wjh_tunnel_drop_aggregate_cb tunnel;
        wjh_roce_drop_aggregate_cb   roce;
    } aggregate_cb;
} wjh_drop_callbacks_t;

typedef uint32_t wjh_user_channel_id_t;

typedef enum wjh_user_channel_type {
    WJH_USER_CHANNEL_TAILDROP_E,
    WJH_USER_CHANNEL_CYCLIC_E,
    WJH_USER_CHANNEL_AGGREGATE_E, /**< The aggregation channel works in a tail-drop manner.
                                   *   More specifically, if the internal statistics DB is full and a newly coming
                                   *   packet needs a new entry in the DB, then the statistics of this packet will NOT
                                   *   be recorded nor delivered to user via callback.
                                   */
    WJH_USER_CHANNEL_CYCLIC_AND_AGGREGATE_E, /**< For the cyclic-and-aggregation channel, the raw callbacks and aggregation callbacks
                                              *   will be called sequentially in a polling interval, first the raw callbacks,
                                              *   then the aggregation callbacks.
                                              */
    WJH_USER_CHANNEL_MIN_E = WJH_USER_CHANNEL_TAILDROP_E,
    WJH_USER_CHANNEL_MAX_E = WJH_USER_CHANNEL_CYCLIC_AND_AGGREGATE_E,
} wjh_user_channel_type_e;

typedef enum wjh_aggregation_read_mode {
    WJH_AGGREGATION_READ_MODE_READ_CLEAR,
    WJH_AGGREGATION_READ_MODE_READ,
    WJH_AGGREGATION_READ_MODE_MIN_E = WJH_AGGREGATION_READ_MODE_READ_CLEAR,
    WJH_AGGREGATION_READ_MODE_MAX_E = WJH_AGGREGATION_READ_MODE_READ,
} wjh_aggregation_read_mode_e;

typedef enum wjh_user_channel_timestamp_source {
    WJH_USER_CHANNEL_TIMESTAMP_SOURCE_LINUX_E,
    WJH_USER_CHANNEL_TIMESTAMP_SOURCE_HW_CLOCK_E,
    WJH_USER_CHANNEL_TIMESTAMP_SOURCE_MIN_E = WJH_USER_CHANNEL_TIMESTAMP_SOURCE_LINUX_E,
    WJH_USER_CHANNEL_TIMESTAMP_SOURCE_MAX_E = WJH_USER_CHANNEL_TIMESTAMP_SOURCE_HW_CLOCK_E,
} wjh_user_channel_timestamp_source_e;

/**
 * The packets belong to L1/RoCE drop reason group are not sent to drop monitor.
 * The packets belong to buffer drop reason group are sent to drop monitor only in mirror-to-CPU mode (SPC2 and above).
 * The packets delivered to user space by drop monitor always carry Linux timestamps.
 * The WJH library filters won't take effect on the packets sent to drop monitor.
 */
typedef enum wjh_user_channel_destination {
    WJH_USER_CHANNEL_DESTINATION_CALLBACK_AND_DROP_MONITOR_E, /**< Reporting the packets/statistics via both user callback and Linux drop monitor functionality */
    WJH_USER_CHANNEL_DESTINATION_DROP_MONITOR_E, /**< Reporting the packets/statistics via Linux drop monitor functionality */
    WJH_USER_CHANNEL_DESTINATION_MIN_E = WJH_USER_CHANNEL_DESTINATION_CALLBACK_AND_DROP_MONITOR_E,
    WJH_USER_CHANNEL_DESTINATION_MAX_E = WJH_USER_CHANNEL_DESTINATION_DROP_MONITOR_E
} wjh_user_channel_destination_e;

/**
 * Except for the user_channel_dest field, the other fields don't apply to the packets sent to Linux drop monitor functionality.
 */
typedef struct wjh_user_channel_attr {
    uint32_t polling_interval; /**< The polling interval in milliseconds, not valid for tail drop channel.
                                *   Value 0 means default value.
                                *   Default values: cyclic channel - 5000 milliseconds (5 seconds)
                                *                   aggregation channel - 30000 milliseconds (30 seconds)
                                *                   cyclic-and-aggregation channel - 30000 milliseconds (30 seconds) */
    wjh_user_channel_mode_e     mode; /**< Not valid for tail drop channel. Default value is push mode. */
    wjh_aggregation_read_mode_e aggregation_read_mode; /**< Only valid for aggregation channel or cyclic-and-aggregation channel.
                                                        *   Default value is READ_CLEAR mode.
                                                        *   The wjh_user_channel_pull API will ignore this mode, it always does READ_CLEAR. */
    wjh_user_channel_timestamp_source_e timestamp_source; /**< The packet timestamp source - Linux or HW clock, default value is Linux.
                                                           *   HW timestamp of the packet is appropriate only if HW clock is set and
                                                           *   it's the WJH lib user's responsibility to set the HW clock for the switch.
                                                           *   When the timestamp source is Linux, user may experience same timestamps for multiple packets,
                                                           *   and the Linux timestamp will not be as accurate as HW timestamp.
                                                           *   For L1 drop reason group, it will always have Linux timestamp regardless of the timestamp source
                                                           *   configured for the channel.
                                                           *   For Spectrum-1,  if HW clock is configured to a user channel, then the
                                                           *   drop reason groups (except for buffer drop reason group) bound to this channel will still have Linux timestamp,
                                                           *   only buffer drop reason group bound to this channel will have HW timestamp.*/
    wjh_user_channel_destination_e user_channel_dest; /**< Default value is reporting the packets/statistics via both user callback and Linux drop monitor functionality.*/
} wjh_user_channel_attr_t;

typedef struct wjh_drop_counter {
    uint64_t dropped_packets;      /**< total dropped packets counter, for CYCLIC user channel only */
    uint64_t received_packets;     /**< trapped drop packets counter */
} wjh_drop_counter_t;

typedef void (*wjh_deactive_cb)(void);

typedef void (*wjh_log_cb_t)(wjh_verbosity_level_t severity, char *msg);

/**
 *  WJH_INGRESS_INFO_TYPE_LOGPORT:
 *   drop_info contains valid ingress/egress port
 *  WJH_INGRESS_INFO_TYPE_IF_INDEX:
 *   If there is netdevice created over the port:
 *       Drop_info will contain valid if_index of the netdevice
 *   Else
 *       Drop_info will contain invalid if_index WJH_INVALID_IF_INDEX
 */
typedef enum wjh_port_type {
    WJH_INGRESS_INFO_TYPE_LOGPORT = 0,
    WJH_INGRESS_INFO_TYPE_IF_INDEX,
    WJH_INGRESS_INFO_TYPE_PORT_LABEL, /**< This mode is mandatory if user
                                       *    configuring mirroring port label  */
    WJH_INGRESS_INFO_TYPES_NUM,
} wjh_ingress_info_type_e;

/**
 * The mode controls which fields in buffer/ACL/router/tunnel/L2 aggregation keys will be taken into account.
 *   If the mode is set to WJH_AGGREGATION_KEY_MODE_DETAILED_E, all fields will be taken into account.
 *   If the mode is set to WJH_AGGREGATION_KEY_MODE_STREAMING_E, only the fields which are not marked as "detailed mode" will be taken into account.
 *   The comments in each aggregation key's definition indicate which fields are marked as "detailed mode".
 */
typedef enum wjh_aggregation_key_mode {
    WJH_AGGREGATION_KEY_MODE_STREAMING_E,
    WJH_AGGREGATION_KEY_MODE_DETAILED_E,
    WJH_AGGREGATION_KEY_MIN_E = WJH_AGGREGATION_KEY_MODE_STREAMING_E,
    WJH_AGGREGATION_KEY_MAX_E = WJH_AGGREGATION_KEY_MODE_DETAILED_E,
} wjh_aggregation_key_mode_e;

/**
 * The mode indicate which trap group allocate mode WJH lib should take.
 *   If the mode is set to WJH_TRAP_GROUP_ALLOCATE_MODE_STATIC_E, WJH lib will use static mode by SET/UNSET.
 *   If the mode is set to WJH_TRAP_GROUP_ALLOCATE_MODE_DYNAMIC_E, WJH lib will use dynamic mode by CREATE/EDIT/DELETE.
 */
typedef enum wjh_trap_group_allocate_mode {
    WJH_TRAP_GROUP_ALLOCATE_MODE_STATIC_E,
    WJH_TRAP_GROUP_ALLOCATE_MODE_DYNAMIC_E,
    WJH_TRAP_GROUP_ALLOCATE_MODE_MIN_E = WJH_TRAP_GROUP_ALLOCATE_MODE_STATIC_E,
    WJH_TRAP_GROUP_ALLOCATE_MODE_MAX_E = WJH_TRAP_GROUP_ALLOCATE_MODE_DYNAMIC_E,
} wjh_trap_group_allocate_mode_e;

/**
 * The lower level driver related initialization parameters.
 */
typedef struct wjh_driver_init_param {
    wjh_trap_group_allocate_mode_e trap_group_allocate_mode; /**< The trap group allocation mode WJH lib should take */
} wjh_driver_init_param_t;

typedef struct wjh_init_param {
    uint8_t         force;
    wjh_deactive_cb deactive_cb;
    uint8_t         max_bandwidth_percent; /**< Bandwidth percentage, valid value is 0 - 100, 0 means default value which is 80 percent. */
    wjh_log_cb_t    log_cb;
    const char     *conf_xml_path; /**< NULL means using default XML file. Severity for all ACl drop reasons
                                    *   must be set to the same. Must not change reason id. */
    const char                *debug_fs_path; /**< NULL means using default debug file system path (/sys/kernel/debug). */
    wjh_ingress_info_type_e    ingress_info_type; /**< Defines the port type in meta data : log_port / if_index. */
    wjh_aggregation_key_mode_e aggregation_key_mode; /**< Defines the aggregation key mode, 0 means default value which is WJH_AGGREGATION_KEY_MODE_STREAMING_E. */
    wjh_driver_init_param_t    driver_init_param;    /**< The init param related to low level driver */
} wjh_init_param_t;

typedef uint32_t wjh_filter_id_t;
typedef enum wjh_filter_key {
    WJH_FILTER_KEY_PORT_E,
    WJH_FILTER_KEY_DROP_REASON_E,                       /**< All buffer drop reasons supported on Spectrum-2.
                                                         *   WJH_DROP_REASON_ID_TAIL_DROP_E supported only for all buffer drop on Spectrum.
                                                         */

    WJH_FILTER_KEY_IP_PROTO_E,
    WJH_FILTER_KEY_ETHER_TYPE_E,
    WJH_FILTER_KEY_MIN_E = WJH_FILTER_KEY_PORT_E,
    WJH_FILTER_KEY_MAX_E = WJH_FILTER_KEY_ETHER_TYPE_E
} wjh_filter_key_e;

typedef union wjh_filter_key_field {
    wjh_port_log_id_t    port;              /**< Logical port, LAG member is not allowed */
    wjh_drop_reason_id_e drop_reason;
    uint8_t              ip_proto;
    uint16_t             ether_type;
} wjh_filter_key_field_t;

typedef struct wjh_filter_key_desc {
    wjh_filter_key_e       key;
    wjh_filter_key_field_t field;
} wjh_filter_key_desc_t;

typedef struct wjh_filter_rule {
    wjh_filter_key_desc_t *key_desc_list_p; /**< Cannot contain same key, rule will do exact match on all keys in the list */
    uint32_t               key_desc_count;
} wjh_filter_rule_t;


#endif /* WJH_LIB_TYPES_H_ */
