/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_PORT_H__
#define __SXD_EMAD_PORT_H__

#include <complib/sx_log.h>

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_emad_port_data.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/**
 * This function sets the log verbosity level of EMAD PORT MODULE
 * @param[in] cmd               - SET / GET
 * @param[in] verbosity_level_p - verbosity level
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_ERROR - general error
 * @return SXD_STATUS_CMD_UNSUPPORTED - Unsupported command
 */
sxd_status_t sxd_emad_port_log_verbosity_level(sxd_access_cmd_t      cmd,
                                               sx_verbosity_level_t *verbosity_level_p);

/**
 * This function Sets the SPMCR Switch Descriptor fields.
 *
 * @param[in,out]	spmcr_data_arr - SPMCR EMAD array
 * @param[in]		spmcr_data_num - Number of SPMCR EMAD data
 * @param[in]		handler - Sender ID
 * @param[in,out]	context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_spmcr_set(sxd_emad_spmcr_data_t        *spmcr_data_arr,
                                uint32_t                      spmcr_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 * This function Retrieves the SPMCR Switch Descriptor fields.
 *
 * @param[in,out]	spmcr_data_arr - SPMCR EMAD array
 * @param[in]		spmcr_data_num - Number of SPMCR EMAD data
 * @param[in]		handler - Sender ID
 * @param[in,out]	context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */

sxd_status_t sxd_emad_spmcr_get(sxd_emad_spmcr_data_t        *spmcr_data_arr,
                                uint32_t                      spmcr_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 * This function Retrieves the PCAP Switch Descriptor fields.
 *
 * @param[in,out]	pcap_data_arr - PCAP EMAD array
 * @param[in]		pcap_data_num - Number of PCAP EMAD data
 * @param[in]		handler - Sender ID
 * @param[in,out]	context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_pcap_get(sxd_emad_pcap_data_t         *pcap_data_arr,
                               uint32_t                      pcap_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 * This function Sets the PMLP Switch Descriptor fields.
 *
 * @param[in,out]	pmlp_data_arr - PMLP EMAD array
 * @param[in]		pmlp_data_num - Number of PMLP EMAD data
 * @param[in]		handler - Sender ID
 * @param[in,out]	context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_pmlp_set(sxd_emad_pmlp_data_t         *pmlp_data_arr,
                               uint32_t                      pmlp_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 * This function Retrieves the PMLP Switch Descriptor fields.
 *
 * @param[in,out]	pmlp_data_arr - PMLP EMAD array
 * @param[in]		pmlp_data_num - Number of PMLP EMAD data
 * @param[in]		handler - Sender ID
 * @param[in,out]	context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_pmlp_get(sxd_emad_pmlp_data_t         *pmlp_data_arr,
                               uint32_t                      pmlp_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 * This function Sets the SBCM Switch Descriptor fields.
 *
 * @param[in,out]   sbcm_data_arr - SBCM EMAD array
 * @param[in]       sbcm_data_num - Number of SBCM EMAD data
 * @param[in]       handler - Sender ID
 * @param[in,out]   context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_sbcm_set(sxd_emad_sbcm_data_t         *sbcm_data_arr,
                               uint32_t                      sbcm_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 * This function Retrieves the SBCM Switch Descriptor fields.
 *
 * @param[in,out]   sbcm_data_arr - SBCM EMAD array
 * @param[in]       sbcm_data_num - Number of SBCM EMAD data
 * @param[in]       handler - Sender ID
 * @param[in,out]   context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_sbcm_get(sxd_emad_sbcm_data_t         *sbcm_data_arr,
                               uint32_t                      sbcm_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);


/**
 * This function Sets the SBPM Switch Descriptor fields.
 *
 * @param[in,out]   sbpm_data_arr - SBPM EMAD array
 * @param[in]       sbpm_data_num - Number of SBPM EMAD data
 * @param[in]       handler - Sender ID
 * @param[in,out]   context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_sbpm_set(sxd_emad_sbpm_data_t         *sbpm_data_arr,
                               uint32_t                      sbpm_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 * This function Retrieves the SBPM Switch Descriptor fields.
 *
 * @param[in,out]   sbpm_data_arr - SBPM EMAD array
 * @param[in]       sbpm_data_num - Number of SBPM EMAD data
 * @param[in]       handler - Sender ID
 * @param[in,out]   context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_sbpm_get(sxd_emad_sbpm_data_t         *sbpm_data_arr,
                               uint32_t                      sbpm_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 * This function Sets the PMPR Switch Descriptor fields.
 *
 * @param[in,out]   pmpr_data_arr - PMPR EMAD array
 * @param[in]       pmpr_data_num - Number of PMPR EMAD data
 * @param[in]       handler - Sender ID
 * @param[in,out]   context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_pmpr_set(sxd_emad_pmpr_data_t         *pmpr_data_arr,
                               uint32_t                      pmpr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 * This function Retrieves the PMPR Switch Descriptor fields.
 *
 * @param[in,out]   pmpr_data_arr - PMPR EMAD array
 * @param[in]       pmpr_data_num - Number of PMPR EMAD data
 * @param[in]       handler - Sender ID
 * @param[in,out]   context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_pmpr_get(sxd_emad_pmpr_data_t         *pmpr_data_arr,
                               uint32_t                      pmpr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 * This function Sets the PPLM Switch Descriptor fields.
 *
 * @param[in,out]	pplm_data_arr - PPLM EMAD array
 * @param[in]		pplm_data_num - Number of PPLM EMAD data
 * @param[in]		handler - Sender ID
 * @param[in,out]	context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_pplm_set(sxd_emad_pplm_data_t         *pplm_data_arr,
                               uint32_t                      pplm_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 * This function Retrieves the PPLM Switch Descriptor fields.
 *
 * @param[in,out]	pplm_data_arr - PPLM EMAD array
 * @param[in]		pplm_data_num - Number of PPLM EMAD data
 * @param[in]		handler - Sender ID
 * @param[in,out]	context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_pplm_get(sxd_emad_pplm_data_t         *pplm_data_arr,
                               uint32_t                      pplm_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 * This function Sets the PLPC Switch Descriptor fields.
 *
 * @param[in,out]	plpc_data_arr - PLPC EMAD array
 * @param[in]		plpc_data_num - Number of PLPC EMAD data
 * @param[in]		handler - Sender ID
 * @param[in,out]	context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_plpc_set(sxd_emad_plpc_data_t         *plpc_data_arr,
                               uint32_t                      plpc_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 * This function Retrieves the PLPC Switch Descriptor fields.
 *
 * @param[in,out]	plpc_data_arr - PLPC EMAD array
 * @param[in]		plpc_data_num - Number of PLPC EMAD data
 * @param[in]		handler - Sender ID
 * @param[in,out]	context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_plpc_get(sxd_emad_plpc_data_t         *plpc_data_arr,
                               uint32_t                      plpc_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 * This function Sets the PFCC Switch Descriptor fields.
 *
 * @param[in,out]	pfcc_data_arr - PFCC EMAD array
 * @param[in]		pfcc_data_num - Number of PFCC EMAD data
 * @param[in]		handler - Sender ID
 * @param[in,out]	context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_pfcc_set(sxd_emad_pfcc_data_t         *pfcc_data_arr,
                               uint32_t                      pfcc_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 * This function Retrieves the PFCC Switch Descriptor fields.
 *
 * @param[in,out]	pfcc_data_arr - PFCC EMAD array
 * @param[in]		pfcc_data_num - Number of PFCC EMAD data
 * @param[in]		handler - Sender ID
 * @param[in,out]	context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_pfcc_get(sxd_emad_pfcc_data_t         *pfcc_data_arr,
                               uint32_t                      pfcc_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 * This function Sets the PELC Switch Descriptor fields.
 *
 * @param[in,out]	pelc_data_arr - PELC EMAD array
 * @param[in]		pelc_data_num - Number of PELC EMAD data
 * @param[in]		handler - Sender ID
 * @param[in,out]	context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_pelc_set(sxd_emad_pelc_data_t         *pelc_data_arr,
                               uint32_t                      pelc_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 * This function Retrieves the PELC Switch Descriptor fields.
 *
 * @param[in,out]	pelc_data_arr - PELC EMAD array
 * @param[in]		pelc_data_num - Number of PELC EMAD data
 * @param[in]		handler - Sender ID
 * @param[in,out]	context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_pelc_get(sxd_emad_pelc_data_t         *pelc_data_arr,
                               uint32_t                      pelc_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 * This function Sets the PLIB Switch Descriptor fields.
 *
 * @param[in,out]	plib_data_arr - PLIB EMAD array
 * @param[in]		plib_data_num - Number of PLIB EMAD data
 * @param[in]		handler - Sender ID
 * @param[in,out]	context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_plib_set(sxd_emad_plib_data_t         *plib_data_arr,
                               uint32_t                      plib_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 * This function Retrieves the PLIB Switch Descriptor fields.
 *
 * @param[in,out]	plib_data_arr - PLIB EMAD array
 * @param[in]		plib_data_num - Number of PLIB EMAD data
 * @param[in]		handler - Sender ID
 * @param[in,out]	context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_plib_get(sxd_emad_plib_data_t         *plib_data_arr,
                               uint32_t                      plib_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 * This function Sets the PPTB Switch Descriptor fields.
 *
 * @param[in,out]	pptb_data_arr - PPTB EMAD array
 * @param[in]		pptb_data_num - Number of PPTB EMAD data
 * @param[in]		handler - Sender ID
 * @param[in,out]	context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_pptb_set(sxd_emad_pptb_data_t         *pptb_data_arr,
                               uint32_t                      pptb_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 * This function Retrieves the PPTB Switch Descriptor fields.
 *
 * @param[in,out]	pptb_data_arr - PPTB EMAD array
 * @param[in]		pptb_data_num - Number of PPTB EMAD data
 * @param[in]		handler - Sender ID
 * @param[in,out]	context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_pptb_get(sxd_emad_pptb_data_t         *pptb_data_arr,
                               uint32_t                      pptb_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 * This function Sets the PBMC Switch Descriptor fields.
 *
 * @param[in,out]	pbmc_data_arr - PBMC EMAD array
 * @param[in]		pbmc_data_num - Number of PBMC EMAD data
 * @param[in]		handler - Sender ID
 * @param[in,out]	context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_pbmc_set(sxd_emad_pbmc_data_t         *pbmc_data_arr,
                               uint32_t                      pbmc_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 * This function Retrieves the PBMC Switch Descriptor fields.
 *
 * @param[in,out]	pbmc_data_arr - PBMC EMAD array
 * @param[in]		pbmc_data_num - Number of PBMC EMAD data
 * @param[in]		handler - Sender ID
 * @param[in,out]	context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_pbmc_get(sxd_emad_pbmc_data_t         *pbmc_data_arr,
                               uint32_t                      pbmc_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 * This function Sets the PSPA Switch Descriptor fields.
 *
 * @param[in,out]	pspa_data_arr - PSPA EMAD array
 * @param[in]		pspa_data_num - Number of PSPA EMAD data
 * @param[in]		handler - Sender ID
 * @param[in,out]	context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_pspa_set(sxd_emad_pspa_data_t         *pspa_data_arr,
                               uint32_t                      pspa_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 * This function Retrieves the PSPA Switch Descriptor fields.
 *
 * @param[in,out]	pspa_data_arr - PSPA EMAD array
 * @param[in]		pspa_data_num - Number of PSPA EMAD data
 * @param[in]		handler - Sender ID
 * @param[in,out]	context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_pspa_get(sxd_emad_pspa_data_t         *pspa_data_arr,
                               uint32_t                      pspa_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 * This function Sets the QPBR Switch Descriptor fields.
 *
 * @param[in,out]	qpbr_data_arr - QPBR EMAD array
 * @param[in]		qpbr_data_num - Number of QPBR EMAD data
 * @param[in]		handler - Sender ID
 * @param[in,out]	context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_qpbr_set(sxd_emad_qpbr_data_t         *qpbr_data_arr,
                               uint32_t                      qpbr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 * This function Retrieves the QPBR Switch Descriptor fields.
 *
 * @param[in,out]	qpbr_data_arr - QPBR EMAD array
 * @param[in]		qpbr_data_num - Number of QPBR EMAD data
 * @param[in]		handler - Sender ID
 * @param[in,out]	context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_qpbr_get(sxd_emad_qpbr_data_t         *qpbr_data_arr,
                               uint32_t                      qpbr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 * This function Sets/gets the PLBF Switch Descriptor fields.
 *
 * @param[in,out]	plbf_data_arr - PLBF EMAD array
 * @param[in]		plbf_data_num - Number of PLBF EMAD data
 * @param[in]		handler - Sender ID
 * @param[in,out]	context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_plbf_access(sxd_emad_plbf_data_t         *plbf_data_arr,
                                  uint32_t                      plbf_data_num,
                                  sxd_emad_completion_handler_t handler,
                                  void                         *context);

/**
 * This function Sets the PIFR Switch Descriptor fields.
 *
 * @param[in,out]	pifr_data_arr - PIFR EMAD array
 * @param[in]		pifr_data_num - Number of PIFR EMAD data
 * @param[in]		handler - Sender ID
 * @param[in,out]	context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_pifr_set(sxd_emad_pifr_data_t         *pifr_data_arr,
                               uint32_t                      pifr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 * This function Retrieves the PIFR Switch Descriptor fields.
 *
 * @param[in,out]	pifr_data_arr - PIFR EMAD array
 * @param[in]		pifr_data_num - Number of PIFR EMAD data
 * @param[in]		handler - Sender ID
 * @param[in,out]	context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_pifr_get(sxd_emad_pifr_data_t         *pifr_data_arr,
                               uint32_t                      pifr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);


/**
 * This function Sets the PMPC Switch Descriptor fields.
 *
 * @param[in,out]	pmpc_data_arr - PMPC EMAD array
 * @param[in]		pmpc_data_num - Number of PMPC EMAD data
 * @param[in]		handler - Sender ID
 * @param[in,out]	context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_pmpc_set(sxd_emad_pmpc_data_t         *pmpc_data_arr,
                               uint32_t                      pmpc_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 * This function Retrieves the PMPC Switch Descriptor fields.
 *
 * @param[in,out]	pmpc_data_arr - PMPC EMAD array
 * @param[in]		pmpc_data_num - Number of PMPC EMAD data
 * @param[in]		handler - Sender ID
 * @param[in,out]	context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_pmpc_get(sxd_emad_pmpc_data_t         *pmpc_data_arr,
                               uint32_t                      pmpc_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 * This function Sets the MPSC Switch Descriptor fields.
 *
 * @param[in,out]	mpsc_data_arr - MPSC EMAD array
 * @param[in]		mpsc_data_num - Number of MPSC EMAD data
 * @param[in]		handler - Sender ID
 * @param[in,out]	context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_mpsc_set(sxd_emad_mpsc_data_t         *mpsc_data_arr,
                               uint32_t                      mpsc_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 * This function Retrieves the MPSC Switch Descriptor fields.
 *
 * @param[in,out]	mpsc_data_arr - MPSC EMAD array
 * @param[in]		mpsc_data_num - Number of MPSC EMAD data
 * @param[in]		handler - Sender ID
 * @param[in,out]	context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_mpsc_get(sxd_emad_mpsc_data_t         *mpsc_data_arr,
                               uint32_t                      mpsc_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 * This function Sets the MLCR Switch Descriptor fields.
 *
 * @param[in,out]   mlcr_data_arr - MLCR EMAD array
 * @param[in]       mlcr_data_num - Number of MLCR EMAD data
 * @param[in]       handler - Sender ID
 * @param[in,out]   context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_mlcr_set(sxd_emad_mlcr_data_t         *mlcr_data_arr,
                               uint32_t                      mlcr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 * This function Retrieves the MLCR Switch Descriptor fields.
 *
 * @param[in,out]   mlcr_data_arr - MLCR EMAD array
 * @param[in]       mlcr_data_num - Number of MLCR EMAD data
 * @param[in]       handler - Sender ID
 * @param[in,out]   context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_mlcr_get(sxd_emad_mlcr_data_t         *mlcr_data_arr,
                               uint32_t                      mlcr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);


/**
 * This function Sets the PMCR Switch Descriptor fields.
 *
 * @param[in,out]   pmcr_data_arr - PMCR EMAD array
 * @param[in]       pmcr_data_num - Number of PMCR EMAD data
 * @param[in]       handler - Sender ID
 * @param[in,out]   context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_pmcr_set(sxd_emad_pmcr_data_t         *pmcr_data_arr,
                               uint32_t                      pmcr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 * This function Retrieves the PMCR Switch Descriptor fields.
 *
 * @param[in,out]   pmcr_data_arr - PMCR EMAD array
 * @param[in]       pmcr_data_num - Number of PMCR EMAD data
 * @param[in]       handler - Sender ID
 * @param[in,out]   context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_pmcr_get(sxd_emad_pmcr_data_t         *pmcr_data_arr,
                               uint32_t                      pmcr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 * This function Sets the PFSC Switch Descriptor fields.
 *
 * @param[in,out]   pfsc_data_arr - PFSC EMAD array
 * @param[in]       pfsc_data_num - Number of PFSC EMAD data
 * @param[in]       handler - Sender ID
 * @param[in,out]   context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_pfsc_set(sxd_emad_pfsc_data_t         *pfsc_data_arr,
                               uint32_t                      pfsc_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 * This function Retrieves the PFSC Switch Descriptor fields.
 *
 * @param[in,out]   pfsc_data_arr - PFSC EMAD array
 * @param[in]       pfsc_data_num - Number of PFSC EMAD data
 * @param[in]       handler - Sender ID
 * @param[in,out]   context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_pfsc_get(sxd_emad_pfsc_data_t         *pfsc_data_arr,
                               uint32_t                      pfsc_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 * This function Sets the MDRI Switch Descriptor fields.
 *
 * @param[in,out]   mdri_data_arr - MDRI EMAD array
 * @param[in]       mdri_data_num - Number of MDRI EMAD data
 * @param[in]       handler - Sender ID
 * @param[in,out]   context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_mdri_set(sxd_emad_mdri_data_t         *mdri_data_arr,
                               uint32_t                      mdri_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 * This function Retrieves the MDRI Switch Descriptor fields.
 *
 * @param[in,out]   mdri_data_arr - MDRI EMAD array
 * @param[in]       mdri_data_num - Number of MDRI EMAD data
 * @param[in]       handler - Sender ID
 * @param[in,out]   context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_mdri_get(sxd_emad_mdri_data_t         *mdri_data_arr,
                               uint32_t                      mdri_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);


#endif /* __SXD_EMAD_PORT_H__ */
