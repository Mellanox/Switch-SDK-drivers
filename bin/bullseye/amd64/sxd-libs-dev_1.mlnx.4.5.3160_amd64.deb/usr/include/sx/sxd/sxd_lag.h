/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_LAG_H__
#define __SXD_LAG_H__

#include <complib/cl_types.h>
#include <sx/sxd/sxd_check.h>

#ifdef SXD_LAG_C_

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/
#endif

/************************************************
 *  Defines
 ***********************************************/

#define SXD_LAG_ID_MIN (0x00000000)
#define SXD_LAG_ID_MAX (0x000000FF)

#define SXD_LAG_ID_CHECK_RANGE(LAG_ID) SXD_CHECK_RANGE(SXD_LAG_ID_MIN, LAG_ID, SXD_LAG_ID_MAX)

#define SXD_LAG_MAX_PORTS_PER_LAG (rm_resource_global.lag_port_members_max)

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/* LAG ID:
 **************
 * Logical entity, that represents the HW's index of LAG in the GLOBAL system's table
 ************************************************************************************
 * +--------------------------------------------------------------------------------+
 * |                                 LAG-ID[15:0]                                   |
 * +--------------------------------------------------------------------------------+
 ************************************************************************************
 */
typedef uint16_t sxd_lag_id_t;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

#endif /* __SXD_LAG_H__ */
