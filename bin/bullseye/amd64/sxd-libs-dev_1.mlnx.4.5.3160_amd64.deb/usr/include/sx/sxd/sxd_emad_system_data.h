/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_SYSTEM_DATA_H__
#define __SXD_EMAD_SYSTEM_DATA_H__

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_port.h>
#include <sx/sxd/sxd_emad_common_data.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/
/**
 * sxd_emad_scar_data_t structure is used to store SCAR register
 * data.
 */
typedef struct sxd_emad_scar_data {
    sxd_emad_common_data_t common; /**< Common EMAD data*/
    struct ku_scar_reg    *reg_data;
} sxd_emad_scar_data_t;

/**
 * sxd_emad_ppsc_data_t structure is used to store PPSC register
 * data.
 */
typedef struct sxd_emad_ppsc_data {
    sxd_emad_common_data_t common;
    struct ku_ppsc_reg    *reg_data;
} sxd_emad_ppsc_data_t;

/**
 * sxd_emad_mjtag_data_t structure is used to store MJTAG
 * register data.
 */
typedef struct sxd_emad_mjtag_data {
    sxd_emad_common_data_t common;
    struct ku_mjtag_reg   *reg_data;
} sxd_emad_mjtag_data_t;

/**
 * sxd_emad_sspr_data_t structure is used to store SSPR register
 * data.
 */
typedef struct sxd_emad_sspr_data {
    sxd_emad_common_data_t common;  /**< Common EMAD data */
    struct ku_sspr_reg    *reg_data;
} sxd_emad_sspr_data_t;

/**
 * sxd_emad_mfba_data_t structure is used to store MFBA register
 * data.
 */
typedef struct sxd_emad_mfba_data {
    sxd_emad_common_data_t common;  /**< Common EMAD data */
    struct ku_mfba_reg    *reg_data;
} sxd_emad_mfba_data_t;

/**
 * sxd_emad_mfpa_data_t structure is used to store MFPA register
 * data.
 */
typedef struct sxd_emad_mfpa_data {
    sxd_emad_common_data_t common;  /**< Common EMAD data */
    struct ku_mfpa_reg    *reg_data;
} sxd_emad_mfpa_data_t;

/**
 * sxd_emad_mfbe_data_t structure is used to store MFBE register
 * data.
 */
typedef struct sxd_emad_mfbe_data {
    sxd_emad_common_data_t common;  /**< Common EMAD data */
    struct ku_mfbe_reg    *reg_data;
} sxd_emad_mfbe_data_t;

/**
 * sxd_emad_msci_data_t structure is used to store MSCI register
 * data.
 */
typedef struct sxd_emad_msci_data {
    sxd_emad_common_data_t common;  /**< Common EMAD data */
    struct ku_msci_reg    *reg_data;
} sxd_emad_msci_data_t;

/**
 * sxd_emad_mtbr_data_t structure is used to store MTBR register
 * data.
 */
typedef struct sxd_emad_mtbr_data {
    sxd_emad_common_data_t common;  /**< Common EMAD data */
    struct ku_mtbr_reg    *reg_data;
} sxd_emad_mtbr_data_t;


/**
 * sxd_emad_raw_data_t structure is used to store RAW register
 * data.
 */
typedef struct sxd_emad_raw_data {
    sxd_emad_common_data_t common;  /**< Common EMAD data */
    uint16_t               register_id;
    struct ku_raw_reg     *reg_data;
} sxd_emad_raw_data_t;

/**
 * sxd_emad_mrsr_data_t structure is used to store MRSR register
 * data.
 */
typedef struct sxd_emad_mrsr_data {
    sxd_emad_common_data_t common;  /**< Common EMAD data */
    struct ku_mrsr_reg    *reg_data;
} sxd_emad_mrsr_data_t;

/**
 * sxd_emad_moni_data structure is used to store MONI register data.
 */
typedef struct sxd_emad_moni_data {
    sxd_emad_common_data_t common;    /**< Common EMAD data */
    struct ku_moni_reg    *reg_data;
} sxd_emad_moni_data_t;


/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

#endif /* __SXD_EMAD_SYSTEM_DATA_H__ */
