/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_MPLS_REG_H__
#define __SXD_EMAD_MPLS_REG_H__

#include <sx/sxd/sxd_types.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

#include <complib/cl_packon.h>

/**
 * sxd_emad_mpgcr_reg_t structure is used to store MPGCR register
 * layout.
 */
typedef struct sxd_emad_mpgcr_reg {
    uint8_t mpls_et;
    uint8_t mpls_pcp_ler_exp_rw;
    uint8_t reserved1[3];
    uint8_t ingress_egress_ler_lsr_egress_ttl;
    uint8_t reserved2;
    uint8_t ingress_ler_ttl_value;
    uint8_t reserved3[7];
    uint8_t hrlsn;
    net32_t label_id_min;
    net32_t label_id_max;
    uint8_t reserved4;
    uint8_t entropy_msb;
    uint8_t reserved5[3];
    uint8_t irif_vr_en;
    uint8_t reserved6[5];
    uint8_t activity_dis_mpnhlfe;
} PACK_SUFFIX sxd_emad_mpgcr_reg_t;

/**
 * sxd_emad_mpilm_reg_t structure is used to store MPILM register
 * layout.
 */
typedef struct sxd_emad_mpilm_reg {
    uint8_t op;
    uint8_t reserved1[2];
    uint8_t label_space;
    net32_t label_id;
    net32_t nhlfe_index;
    uint8_t npop;
    uint8_t reserved2;
    net16_t ecmp_size;
    uint8_t trap_action;
    uint8_t reserved3;
    net16_t trap_id;
    net32_t counter_set;
} PACK_SUFFIX sxd_emad_mpilm_reg_t;

/**
 * sxd_emad_mpibe_reg_t structure is used to store MPIBE register
 * layout.
 */
typedef struct sxd_emad_mpibe_reg {
    uint8_t  reserved1[3];
    uint8_t  label_space;
    uint32_t reserved2[3];
    net32_t  nhlfe_index;
    uint16_t reserved4;
    net16_t  ecmp_size;
    uint32_t reserved5[2];
    net32_t  new_nhlfe_index;
    uint16_t reserved7;
    net16_t  new_ecmp_size;
} PACK_SUFFIX sxd_emad_mpibe_reg_t;


#include <complib/cl_packoff.h>

#endif /* __SXD_EMAD_MPLS_REG_H__ */
