/*
 * Copyright (C) 2001-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */
#ifndef SX_SDK_SX_JSON_H_
#define SX_SDK_SX_JSON_H_

#include "cJSON.h"
#define SX_JSON_MAX_ATTR_SIZE 1024
typedef cJSON sx_json_t;
typedef cJSON_bool sx_json_bool_t;
#define SX_JSON_FALSE                ((sx_json_bool_t)0)
#define SX_JSON_TRUE                 (!SX_JSON_FALSE)
#define sx_json_print                cJSON_Print
#define sx_json_print_pre_allocated  cJSON_PrintPreallocated
#define sx_json_create_object        cJSON_CreateObject
#define sx_json_create_string        cJSON_CreateString
#define sx_json_add_item_to_object   cJSON_AddItemToObject
#define sx_json_delete               cJSON_Delete
#define sx_json_create_string_array  cJSON_CreateStringArray
#define sx_json_add_item_to_array    cJSON_AddItemToArray
#define sx_json_create_integer_array cJSON_CreateIntArray
#define sx_json_add_number_to_object cJSON_AddNumberToObject
#define sx_json_add_string_to_object cJSON_AddStringToObject
#define sx_json_create_array         cJSON_CreateArray
#define sx_json_add_true_to_object   cJSON_AddTrueToObject
#define sx_json_add_false_to_object  cJSON_AddFalseToObject
#define sx_json_add_bool_to_object   cJSON_AddBoolToObject
#define sx_json_malloc               cJSON_malloc
#define sx_json_free                 cJSON_free
#define sx_cjson_version             cJSON_Version

typedef struct sx_json_context {
    sx_json_t *root;
    sx_json_t *sections;
    void     * data;
} sx_json_context_t;

typedef struct sx_json_table_context {
    sx_json_t *cols_list;
    sx_json_t *val_list;
} sx_json_table_context_t;

#endif /*SX_SDK_SX_JSON_H_ */
