/*
 *  Copyright (C) 2010-2019. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */


#ifndef __SX_FCF_H__
#define __SX_FCF_H__

#include <sx/sdk/sx_mac.h>
#include <sx/sdk/sx_vlan.h>

#define SX_FCF_MIN 0
#define SX_FCF_MAX 0
#define SX_FCF_CHECK_RANGE(FCF) SX_CHECK_MAX(FCF, SX_FCF_MAX)

#define SX_VF_PORT_ID 0
#define SX_VF_PORT_CHECK_RANGE(VF_PORT) (VF_PORT == SX_VF_PORT_ID)

#define SX_VE_PORT_MIN (SX_VF_PORT_ID + 1)
#define SX_VE_PORT_MAX 8000
#define SX_VE_PORT_CHECK_RANGE(VE_PORT) SX_CHECK_MAX(VE_PORT, SX_VE_PORT_MAX)
#define SX_MAX_NUM_VE_PORTS (SX_VE_PORT_MAX - SX_VE_PORT_MIN)
#define SX_NUM_VE_PORTS_CHECK_RANGE(NUM_VE_PORTS) SX_CHECK_MAX(NUM_VE_PORTS, SX_MAX_NUM_VE_PORTS)

#define SX_V_PORT_MIN SX_VF_PORT_MIN
#define SX_V_PORT_MAX SX_VE_PORT_MAX
#define SX_V_PORT_CHECK_RANGE(V_PORT) SX_CHECK_MAX(V_PORT, SX_V_PORT_MAX)

#define SX_FW_RULE_MIN 0
#define SX_FW_RULE_MAX 7999
#define SX_FW_RULE_CHECK_RANGE(FW_RULE)           SX_CHECK_MAX(FW_RULE, SX_FW_RULE_MAX)
#define SX_NUM_FW_RULES_CHECK_RANGE(NUM_FW_RULES) SX_CHECK_MAX(NUM_FW_RULES, (SX_FW_RULE_MAX + 1))

/**
 * FCF ID.
 */
typedef uint8_t sx_fcf_id_t;

/**
 * FCF v_port handle.
 */
typedef uint16_t sx_fcf_v_port_handle_t;

/**
 * V_PORT types
 */
typedef enum sx_fcf_port_type {
    VF_PORT,    /**< Virtual Fabric Port  */
    VE_PORT,    /**< Virtual Expansion Port  */
} sx_fcf_port_type_t;

/**
 * FC-ID: Fibre Channel ID (FC ID) The source ID (SID) or the destination ID (DID).
 * The possible values for mask are
 * FFFFFF (the entire FC ID is used this is the default),
 * FFFF00 (only domain and area FC ID is used), or
 * FF0000 (only domain FC ID is used).
 */
#define FC_ADDR_LEN 3

typedef struct sx_fc_addr {
    uint8_t fc_addr[FC_ADDR_LEN];    /**< Fibre-Channel Address (24 bit)  */
} sx_fc_addr_t;

/**
 * FC-MAP is the 24-bit FPMA address prefix being used on the fabric
 */
typedef sx_fc_addr_t sx_fc_map_t;

/**
 * FCF counter ID.
 */
typedef uint32_t sx_fcf_cntr_id_t;

/**
 * sx_fcf_param_t is used to store the FCF general
 * configuration parameters.
 */
typedef struct sx_fcf_param {
    uint32_t num_of_v_port_assigned_mac;    /**< Maximum number of VE_Ports that will be configured in the system  */
    uint32_t num_of_fw_rules;    /**< Maximum number of forwarding rules that will be configured in the system  */
} sx_fcf_param_t;

/**
 * sx_fcf_attributes_t structure is used to store FCF attributes.
 */
typedef struct sx_fcf_attributes {
    sx_vlan_id_t  vid;   /**< VLAN ID  */
    uint8_t       prio; /**< VLAN prio  */
    sx_mac_addr_t mac_addr;    /**< MAC address  */
    sx_fc_map_t   fc_map;  /**< Fibre Channel map (24 bit)  */
} sx_fcf_attributes_t;

/**
 * sx_v_port_instance_attributes_t structure is used to store v_port attributes.
 */
typedef struct sx_fcf_v_port_attributes {
    sx_fcf_port_type_t port_type;    /**< VF_Port or VE_Port (currently only VF_Port is supported)  */
    union {
        struct {
            sx_mac_addr_t mac_addr;    /**< Hardware address parameter for VE_Port */
        } ve_port; /* V_PORT assigned MAC */
        struct {
        } vf_port; /* FC_MAP_BASED_MAC */
    } hw_addr;
} sx_fcf_v_port_attributes_t;

/**
 * FCF Counter ID minimum/maximum values.
 */
#define SX_FCF_CNTR_ID_MIN (0x00)
#define SX_FCF_CNTR_ID_MAX (0x00)

#define SX_FCF_CNTR_ID_CHECK_RANGE(CNTR_ID) \
    SX_CHECK_MAX(CNTR_ID, SX_FCF_CNTR_ID_MAX)

/**
 * FCF Counter Set.
 */
typedef struct sx_fcf_cntr_set {
} sx_fcf_cntr_set_t;

#define SX_FCF_CNTR_SET_SIZE (sizeof(sx_fcf_cntr_set_t) / sizeof(uint64_t))
#endif /* __SX_FCF_H__ */
