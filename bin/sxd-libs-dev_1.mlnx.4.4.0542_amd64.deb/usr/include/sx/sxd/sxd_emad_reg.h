/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2020 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_REG_H__
#define __SXD_EMAD_REG_H__

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_registers.h>
#include <sx/sxd/sxd_emad_acl_reg.h>
#include <sx/sxd/sxd_emad_cos_reg.h>
#include <sx/sxd/sxd_emad_fdb_reg.h>
#include <sx/sxd/sxd_emad_host_reg.h>
#include <sx/sxd/sxd_emad_lag_reg.h>
#include <sx/sxd/sxd_emad_mstp_reg.h>
#include <sx/sxd/sxd_emad_policer_reg.h>
#include <sx/sxd/sxd_emad_port_reg.h>
#include <sx/sxd/sxd_emad_mpls_reg.h>
#include <sx/sxd/sxd_emad_router_reg.h>
#include <sx/sxd/sxd_emad_shspm_reg.h>
#include <sx/sxd/sxd_emad_system_reg.h>
#include <sx/sxd/sxd_emad_vlan_reg.h>
#include <sx/sxd/sxd_emad_span_reg.h>
#include <sx/sxd/sxd_emad_flow_counter_reg.h>
#include <sx/sxd/sxd_emad_redecn_reg.h>
#include <sx/sxd/sxd_emad_tunnel_reg.h>
#include <sx/sxd/sxd_emad_rm_reg.h>

#ifdef SXD_EMAD_REG_C_

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

#endif

#include <complib/cl_packon.h>

/************************************************
 *  Defines
 ***********************************************/

/**
 * emad header field values
 */
#define EMAD_HEADER_SMAC      0x0002C90102030000ULL
#define EMAD_HEADER_DMAC      0x0102C90000010000ULL
#define EMAD_HEADER_ET        0x8932
#define EMAD_HEADER_MLX_PROTO 0
#define EMAD_HEADER_VER       0

#define EMAD_FW_STATUS_SUCCESS     0
#define EMAD_FW_STATUS_BUSY        1
#define EMAD_FW_STATUS_BAD_PARAM   7
#define EMAD_FW_STATUS_NO_RESOURCE 8

/************************************************
 *  Macros
 ***********************************************/

#define EMAD_TLV_BUILD_TYPE_LEN(type, len_in_dwords) (cl_hton16(((type) << 11) | (len_in_dwords)))
#define EMAD_TLV_GET_TYPE_LEN(tlv_hdr)               (cl_ntoh16(*(uint16_t*)(tlv_hdr)))
#define EMAD_TLV_TYPE(tlv_hdr)                       (EMAD_TLV_GET_TYPE_LEN(tlv_hdr) >> 11)
#define EMAD_TLV_LEN(tlv_hdr)                        (EMAD_TLV_GET_TYPE_LEN(tlv_hdr) & 0x7ff)

/* EMAD TLV headers lengths (in dwords) */
#define EMAD_TLV_LEN_END       (sizeof(sxd_emad_end_t) >> 2)
#define EMAD_TLV_LEN_OPERATION (sizeof(sxd_emad_operation_t) >> 2)
#define EMAD_TLV_LEN_STRING    (sizeof(sxd_emad_string_t) >> 2)

/************************************************
 *  Type definitions
 ***********************************************/

typedef enum emad_tlv_types {
    EMAD_TLV_TYPE_END_E,
    EMAD_TLV_TYPE_OPERATION_E,
    EMAD_TLV_TYPE_STRING_E,
    EMAD_TLV_TYPE_REG_E
} emad_tlv_types_t;

/**
 * sxd_emad_header_t structure is used to store EMAD header layout.
 */
typedef struct sxd_emad_header {
    uint8_t dmac[6];
    uint8_t smac[6];
    net16_t et;
    uint8_t mlx_proto;
    uint8_t ver;
} PACK_SUFFIX sxd_emad_header_t;

/**
 * sxd_emad_operation_t structure is used to store EMAD operation
 * layout.
 */
typedef struct sxd_emad_operation {
    net16_t type_len;
    uint8_t dr_status;
    uint8_t reserved1;
    net16_t register_id;
    uint8_t r_method;
    uint8_t class;
    net64_t tid;
} PACK_SUFFIX sxd_emad_operation_t;

/**
 * sxd_emad_string_t structure is used to store EMAD string (in case of error)
 * layout.
 */
typedef struct sxd_emad_string {
    net16_t type_len;
    uint8_t reserved[2];
    char    string[128];
} PACK_SUFFIX sxd_emad_string_t;

/**
 * sxd_emad_reg_data_t union is used to store SwitchX register
 * layout.
 */
typedef union sxd_emad_reg_data {
    sxd_emad_mfba_reg_t    mfba;
    sxd_emad_mfbe_reg_t    mfbe;
    sxd_emad_mfpa_reg_t    mfpa;
    sxd_emad_sgcr_reg_t    sgcr;
    sxd_emad_scar_reg_t    scar;
    sxd_emad_spad_reg_t    spad;
    sxd_emad_sspr_reg_t    sspr;
    sxd_emad_sfdat_reg_t   sfdat;
    sxd_emad_sfd_reg_t     sfd;
    sxd_emad_sfn_reg_t     sfn;
    sxd_emad_spgt_reg_t    spgt;
    sxd_emad_smid_reg_t    smid;
    sxd_emad_spms_reg_t    spms;
    sxd_emad_spvid_reg_t   spvid;
    sxd_emad_spvc_reg_t    spvc;
    sxd_emad_sver_reg_t    sver;
    sxd_emad_spvm_reg_t    spvm;
    sxd_emad_spvtr_reg_t   spvtr;
    sxd_emad_spaft_reg_t   spaft;
    sxd_emad_sftr_reg_t    sftr;
    sxd_emad_svpe_reg_t    svpe;
    sxd_emad_sfdf_reg_t    sfdf;
    sxd_emad_sfdt_reg_t    sfdt;
    sxd_emad_sldr_reg_t    sldr;
    sxd_emad_slcr_reg_t    slcr;
    sxd_emad_slcor_reg_t   slcor;
    sxd_emad_slecr_reg_t   slecr;
    sxd_emad_spmlr_reg_t   spmlr;
    sxd_emad_svmlr_reg_t   svmlr;
    sxd_emad_spvmlr_reg_t  spvmlr;
    sxd_emad_spfsr_reg_t   spfsr;
    sxd_emad_qcap_reg_t    qcap;
    sxd_emad_qpts_reg_t    qpts;
    sxd_emad_qpcr_reg_t    qpcr;
    sxd_emad_qpbr_reg_t    qpbr;
    sxd_emad_qpdp_reg_t    qpdp;
    sxd_emad_qprt_reg_t    qprt;
    sxd_emad_qsptc_reg_t   qsptc;
    sxd_emad_qtct_reg_t    qtct;
    sxd_emad_qstct_reg_t   qstct;
    sxd_emad_spmcr_reg_t   spmcr;
    sxd_emad_pcap_reg_t    pcap;
    sxd_emad_pplm_reg_t    pplm;
    sxd_emad_pmlp_reg_t    pmlp;
    sxd_emad_pmcr_reg_t    pmcr;
    sxd_emad_pfsc_reg_t    pfsc;
    sxd_emad_pmmp_reg_t    pmmp;
    sxd_emad_pplr_reg_t    pplr;
    sxd_emad_pmpr_reg_t    pmpr;
    sxd_emad_ptys_reg_t    ptys;
    sxd_emad_pmtps_reg_t   pmtps;
    sxd_emad_ppsc_reg_t    ppsc;
    sxd_emad_pmaos_reg_t   pmaos;
    sxd_emad_mjtag_reg_t   mjtag;
    sxd_emad_pfcc_reg_t    pfcc;
    sxd_emad_pelc_reg_t    pelc;
    sxd_emad_pude_reg_t    pude;
    sxd_emad_pmpe_reg_t    pmpe;
    sxd_emad_plib_reg_t    plib;
    sxd_emad_pptb_reg_t    pptb;
    sxd_emad_pbmc_reg_t    pbmc;
    sxd_emad_pmpc_reg_t    pmpc;
    sxd_emad_pspa_reg_t    pspa;
    sxd_emad_rcap_reg_t    rcap;
    sxd_emad_rgcr_reg_t    rgcr;
    sxd_emad_ritr_reg_t    ritr;
    sxd_emad_rigr_reg_t    rigr;
    sxd_emad_rigr_v2_reg_t rigr_v2;
    sxd_emad_rtar_reg_t    rtar;
    sxd_emad_recr_reg_t    recr;
    sxd_emad_recr_v2_reg_t recr_v2;
    sxd_emad_ruft_reg_t    ruft;
    sxd_emad_ruht_reg_t    ruht;
    sxd_emad_rauht_reg_t   rauht;
    sxd_emad_rauhtd_reg_t  rauhtd;
    sxd_emad_rmft_reg_t    rmft;
    sxd_emad_rmft_v2_reg_t rmft_v2;
    sxd_emad_rmftad_reg_t  rmftad;
    sxd_emad_ptcead_reg_t  ptcead;
    sxd_emad_ratr_reg_t    ratr;
    sxd_emad_ratrad_reg_t  ratrad;
    sxd_emad_rdpm_reg_t    rdpm;
    sxd_emad_rrcr_reg_t    rrcr;
    sxd_emad_rica_reg_t    rica;
    sxd_emad_ricnt_reg_t   ricnt;
    sxd_emad_rtca_reg_t    rtca;
    sxd_emad_rtps_reg_t    rtps;
    sxd_emad_ralta_reg_t   ralta;
    sxd_emad_ralst_reg_t   ralst;
    sxd_emad_raltb_reg_t   raltb;
    sxd_emad_ralue_reg_t   ralue;
    sxd_emad_raleu_reg_t   raleu;
    sxd_emad_ralbu_reg_t   ralbu;
    sxd_emad_rmeir_reg_t   rmeir;
    sxd_emad_rmid_reg_t    rmid;
    sxd_emad_rmpu_reg_t    rmpu;
    sxd_emad_hcap_reg_t    hcap;
    sxd_emad_htgt_reg_t    htgt;
    sxd_emad_hpkt_reg_t    hpkt;
    sxd_emad_hdrt_reg_t    hdrt;
    sxd_emad_hctr_reg_t    hctr;
    sxd_emad_hespr_reg_t   hespr;
    sxd_emad_ptar_reg_t    ptar;
    sxd_emad_pacl_reg_t    pacl;
    sxd_emad_ptce_reg_t    ptce;
    sxd_emad_ptce2_reg_t   ptce2;
    sxd_emad_prbt_reg_t    prbt;
    sxd_emad_pefa_reg_t    pefa;
    sxd_emad_pecb_reg_t    pecb;
    sxd_emad_pemb_reg_t    pemb;
    sxd_emad_prcr_reg_t    prcr;
    sxd_emad_ppbt_reg_t    ppbt;
    sxd_emad_pvbt_reg_t    pvbt;
    sxd_emad_pagt_reg_t    pagt;
    sxd_emad_pifr_reg_t    pifr;
    sxd_emad_pprr_reg_t    pprr;
    sxd_emad_pfca_reg_t    pfca;
    sxd_emad_pfcnt_reg_t   pfcnt;
    sxd_emad_pvgt_reg_t    pvgt;
    sxd_emad_pgcr_reg_t    pgcr;
    sxd_emad_puet_reg_t    puet;
    sxd_emad_mpat_reg_t    mpat;
    sxd_emad_sbib_reg_t    sbib;
    sxd_emad_mpar_reg_t    mpar;
    sxd_emad_msci_reg_t    msci;
    sxd_emad_mtbr_reg_t    mtbr;
    sxd_emad_plbf_reg_t    plbf;
    sxd_emad_raw_reg_t     raw;
    sxd_emad_mrsr_reg_t    mrsr;
    sxd_emad_sbpr_reg_t    sbpr;
    sxd_emad_sbsr_reg_t    sbsr;
    sxd_emad_sbcm_reg_t    sbcm;
    sxd_emad_sbpm_reg_t    sbpm;
    sxd_emad_sbmm_reg_t    sbmm;
    sxd_emad_qpdpm_reg_t   qpdpm;
    sxd_emad_qepm_reg_t    qepm;
    sxd_emad_qeec_reg_t    qeec;
    sxd_emad_qpdpc_reg_t   qpdpc;
    sxd_emad_qtctm_reg_t   qtctm;
    sxd_emad_qspip_reg_t   qspip;
    sxd_emad_qspcp_reg_t   qspcp;
    sxd_emad_qrwe_reg_t    qrwe;
    sxd_emad_qpem_reg_t    qpem;
    sxd_emad_qpdsm_reg_t   qpdsm;
    sxd_emad_qppm_reg_t    qppm;
    sxd_emad_cwgcr_reg_t   cwgcr;
    sxd_emad_cwtp_reg_t    cwtp;
    sxd_emad_cwtpm_reg_t   cwtpm;
    sxd_emad_cwpp_reg_t    cwpp;
    sxd_emad_cwppm_reg_t   cwppm;
    sxd_emad_cpqe_reg_t    cpqe;
    sxd_emad_mgpc_reg_t    mgpc;
    sxd_emad_mpsc_reg_t    mpsc;
    sxd_emad_tngcr_reg_t   tngcr;
    sxd_emad_tnumt_reg_t   tnumt;
    sxd_emad_tigcr_reg_t   tigcr;
    sxd_emad_mlcr_reg_t    mlcr;
    sxd_emad_mpgcr_reg_t   mpgcr;
    sxd_emad_mpilm_reg_t   mpilm;
    sxd_emad_mpnhlfe_reg_t mpnhlfe;
    sxd_emad_mdri_reg_t    mdri;
    sxd_emad_sbctc_reg_t   sbctc;
    sxd_emad_sbctr_reg_t   sbctr;
    sxd_emad_pbsr_reg_t    pbsr;
    sxd_emad_ppbme_reg_t   ppbme;
    sxd_emad_ptce3_reg_t   ptce3;
    sxd_emad_perpt_reg_t   perpt;
    sxd_emad_perar_reg_t   perar;
    sxd_emad_percr_reg_t   percr;
    sxd_emad_peabfe_reg_t  peabfe;
    sxd_emad_mgir_reg_t    mgir;
    sxd_emad_mcion_reg_t   mcion;
} PACK_SUFFIX sxd_emad_reg_data_t;

/**
 * sxd_emad_reg_t structure is used to store EMAD register layout.
 */
typedef struct sxd_emad_reg {
    net16_t             type_len;
    net16_t             reserved1;
    sxd_emad_reg_data_t data[0];
} PACK_SUFFIX sxd_emad_reg_t;

/**
 * sxd_emad_end_t structure is used to store EMAD end layout.
 */
typedef struct sxd_emad_end {
    net16_t type_len;
    net16_t reserved1;
} PACK_SUFFIX sxd_emad_end_t;

/**
 * sxd_emad_dr_t structure is used to store EMAD DR layout.
 */
typedef struct sxd_emad_dr {
} PACK_SUFFIX sxd_emad_dr_t;

/**
 * sxd_emad_dr_t structure is used to store EMAD DR layout.
 */
typedef struct sxd_emad_userdata {
} PACK_SUFFIX sxd_emad_userdata_t;

#include <complib/cl_packoff.h>

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/


#endif /* __SXD_EMAD_REG_H__ */
