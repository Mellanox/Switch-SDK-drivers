/*
 * Copyright (C) 2010-2021 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_COMMAND_IFC_H_
#define __SXD_COMMAND_IFC_H_

#include <complib/cl_spinlock.h>
#include <complib/cl_types.h>
#include <sx/sxd/sxdev.h>
#include <sx/sxd/sxd_status.h>
#include <complib/sx_log.h>
#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_access_cmd.h>
#include <sx/sxd/kernel_user.h>

/************************************************
 *  Local Defines
 ***********************************************/
/**
 * MAX_REGISTERS_TO_ACCESS defines the maximum
 * number of register accesses possible in a single API call.
 */
#define MAX_HW_HANDELS 16

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/


typedef struct sxd_command_ifc_hw {
    sxd_handle    dev;   /*!< handle descriptor for the device */
    cl_spinlock_t mtx;   /*!< mutex lock on parallel API calls */
    boolean_t     is_initalized; /*!< is handle initialized */
} sxd_command_ifc_hw_t;

typedef struct ku_query_fw query_fw_t;


/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/**
 *  Sets or gets the log verbosity for command_ifc module
 *
 * @param[in] cmd - SET or GET
 * @param[in/out] verbosity_level_p - Verbosity level
 *
 * @return SXD_STATUS_CMD_UNSUPPORTED
 *	SXD_STATUS_SUCCESS
 */
sxd_status_t sxd_command_ifc_log_verbosity_level(sxd_access_cmd_t cmd, sx_verbosity_level_t *verbosity_level_p);

/**
 *  This function init the command ifc lib
 *
 * @param[in] logging_cb - optional log messages callback
 * @param[in] log_level  - command interface module log level
 * @param[out] hw_p - handle that should be used in all
 *                    further command ifc operations. Invalid handle (0) returned
 *		      in case of an error.
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *      SXD_STATUS_DEVICE_OPEN_ERROR
 *      SXD_STATUS_DEVICE_GET_ERROR
 *	SXD_STATUS_SUCCESS
 */
sxd_status_t sxd_command_ifc_init(sx_log_cb_t                logging_cb,
                                  const sx_verbosity_level_t verbosity_level,
                                  sxd_command_ifc_hw_t     **hw_p);

/**
 *  This function de-init the command interface module
 *
 * @param[in] hw_p - command interface handle.
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *	SXD_STATUS_SUCCESS
 *	SXD_STATUS_DEVICE_CLOSE_ERROR
 */
sxd_status_t sxd_command_ifc_deinit(sxd_command_ifc_hw_t *hw_p);

sxd_status_t sxd_command_ifc_set_default_vid(sxd_command_ifc_hw_t *hw_p,
                                             sxd_dev_id_t          dev_id,
                                             uint8_t               is_lag,
                                             sxd_port_sys_id_t     sysport,
                                             uint16_t              lag_id,
                                             sxd_vid_t             default_vid);

#ifdef SW_PUDE_EMULATION
/* PUDE WA for NOS (PUDE events are handled by SDK). Needed for BU. */
sxd_status_t sxd_command_ifc_set_admin_status(sxd_command_ifc_hw_t   *hw_p,
                                              sxd_dev_id_t            dev_id,
                                              sxd_port_sys_id_t       sysport,
                                              sxd_paos_admin_status_t admin_status);
#endif /* SW_PUDE_EMULATION */

sxd_status_t sxd_command_ifc_set_vid_membership(sxd_command_ifc_hw_t *hw_p,
                                                sxd_dev_id_t          dev_id,
                                                uint8_t               is_lag,
                                                sxd_port_phy_id_t     phy_port,
                                                uint16_t              lag_id,
                                                sxd_vid_t             vid,
                                                uint8_t               is_tagged);

sxd_status_t sxd_command_ifc_set_prio_tagging(sxd_command_ifc_hw_t *hw_p,
                                              sxd_dev_id_t          dev_id,
                                              uint8_t               is_lag,
                                              sxd_port_phy_id_t     phy_port,
                                              uint16_t              lag_id,
                                              uint8_t               is_prio_tagged);

sxd_status_t sxd_command_ifc_set_prio_to_tc(sxd_command_ifc_hw_t   *hw_p,
                                            sxd_dev_id_t            dev_id,
                                            uint8_t                 is_lag,
                                            sxd_port_phy_id_t       phy_port,
                                            uint16_t                lag_id,
                                            sxd_cos_port_priority_t priority,
                                            sxd_cos_traffic_class_t traffic_class);

sxd_status_t sxd_command_ifc_set_local_to_swid(sxd_command_ifc_hw_t *hw_p,
                                               sxd_dev_id_t          dev_id,
                                               uint8_t               local_port,
                                               sxd_swid_t            swid);

sxd_status_t sxd_command_ifc_set_ib_to_local_port(sxd_command_ifc_hw_t *hw_p,
                                                  sxd_dev_id_t          dev_id,
                                                  uint8_t               ib_port,
                                                  uint8_t               local_port);

sxd_status_t sxd_command_ifc_set_system_to_local_port(sxd_command_ifc_hw_t *hw_p,
                                                      sxd_dev_id_t          dev_id,
                                                      uint16_t              system_port,
                                                      uint8_t               local_port);

sxd_status_t sxd_command_ifc_set_port_rp_mode(sxd_command_ifc_hw_t *hw_p,
                                              sxd_dev_id_t          dev_id,
                                              uint8_t               is_lag,
                                              uint16_t              lag_id_system_port,
                                              uint16_t              vlan_id,
                                              uint8_t               is_rp,
                                              sxd_access_cmd_t      access_cmd,
                                              uint16_t              rif_id,
                                              uint16_t              hw_efid);

sxd_status_t sxd_command_ifc_set_local_port_to_lag(sxd_command_ifc_hw_t *hw_p,
                                                   sxd_dev_id_t          dev_id,
                                                   uint16_t              is_lag,
                                                   uint16_t              lag_id,
                                                   uint16_t              lag_port_index,
                                                   uint16_t              local_port);

/**
 *  This function sets lag operating state in driver.
 *
 * @param[in] hw_p        - command interface handle.
 * @param[in] lag_id      - LAG ID.
 * @param[in] oper_state  - LAG operating state.
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *	SXD_STATUS_SUCCESS
 *	SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_lag_oper_state_set(sxd_command_ifc_hw_t *hw_p,
                                                uint16_t              lag_id,
                                                uint8_t               oper_state);

/**
 *  This function sets port BER monitor state in driver.
 *
 * @param[in] hw_p              - command interface handle.
 * @param[in] dev_id            - Device ID.
 * @param[in] local_port        - Local port.
 * @param[in] ber_monitor_state - BER monitor state.
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *  SXD_STATUS_SUCCESS
 *  SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_port_ber_monitor_state_set(sxd_command_ifc_hw_t *hw_p,
                                                        sxd_dev_id_t          dev_id,
                                                        uint8_t               local_port,
                                                        uint8_t               ber_monitor_state);

/**
 *  This function sets port sample rate in driver.
 *
 * @param[in] hw_p        - command interface handle.
 * @param[in] local_port  - Local port.
 * @param[in] sample_rate - port sample rate.
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *  SXD_STATUS_SUCCESS
 *  SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_port_sample_rate_update(sxd_command_ifc_hw_t *hw_p,
                                                     uint8_t               local_port,
                                                     uint32_t              sample_rate);

/**
 *  This function sets port BER monitor bitmask in driver.
 *
 * @param[in] hw_p              - command interface handle.
 * @param[in] dev_id            - Device ID.
 * @param[in] local_port        - Local port.
 * @param[in] bitmask           - BER monitor configuration bitmask.
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *  SXD_STATUS_SUCCESS
 *  SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_port_ber_monitor_bitmask_set(sxd_command_ifc_hw_t *hw_p,
                                                          sxd_dev_id_t          dev_id,
                                                          uint16_t              local_port,
                                                          uint8_t               bitmask);

/**
 *  This function sets telemetry threshold configuration in driver.
 *
 * @param[in] hw_p              - Command interface handle.
 * @param[in] local_port        - Local port.
 * @param[in] dir_ing           - Direction Egress / Ingress.
 * @param[in] tc_vec            - Enabled TCs.
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *  SXD_STATUS_SUCCESS
 *  SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_tele_threshold_set(sxd_command_ifc_hw_t *hw_p,
                                                uint8_t               local_port,
                                                uint8_t               dir_ing,
                                                uint64_t              tc_vec);

/**
 *  This function performs ISSU FW
 *
 * @param[in]  hw_p   - Command interface handle.
 * @param[in]  dev_id - Device ID.
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *  SXD_STATUS_SUCCESS
 *  SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_issu_fw(sxd_command_ifc_hw_t *hw_p, sxd_dev_id_t dev_id);

/**
 *  This function sets a state of FW ISSU
 *
 * @param[in]  hw_p   - Command interface handle.
 * @param[in]  is_issu_start - TRUE=ISSU start, FALSE=ISSU stop
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *  SXD_STATUS_SUCCESS
 *  SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_send_issu_notification(sxd_command_ifc_hw_t *hw_p,
                                                    boolean_t             is_issu_start);

/**
 *  This function retrieve various firmware properties
 *
 * @param[in]  hw_p        - command interface handle.
 * @param[out] fw_info_p - firmware information.
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *	SXD_STATUS_SUCCESS
 *	SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_query_fw_info(sxd_command_ifc_hw_t *hw_p,
                                           query_fw_t           *fw_info_p);

/**
 *  This function retrieve various resource information
 *
 * @param[in]  hw_p        - command interface handle.
 * @param[out] fw_info_p - resource information.
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *	SXD_STATUS_SUCCESS
 *	SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_query_rsrc_info(sxd_command_ifc_hw_t *hw_p,
                                             struct ku_query_rsrc *rsrc_info_p);
/**
 *  This function run a device restart on a local PCI device
 *
 * @param[in]  hw_p  - command interface handle.
 * @param[in] dev_id - the device to restart.
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *	SXD_STATUS_SUCCESS
 *	SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_pci_device_restart(sxd_command_ifc_hw_t *hw_p,
                                                sxd_dev_id_t          dev_id);

/**
 *  The TRUNCATE_SIZE_SET command sets the truncate parameters of an RDQ.
 *
 * @param[in]     hw_p              - command interface handle.
 * @param[in,out] truncate_params   - truncate parameters
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *	SXD_STATUS_SUCCESS
 *	SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_truncate_size_set(sxd_command_ifc_hw_t          *hw_p,
                                               struct ku_set_truncate_params *truncate_params);

/**
 *  The GET_PCI_PROFILE command gets the pci profile
 *
 * @param[in]  hw_p            - command interface handle.
 * @param[out] pci_profile_p   - returned pci profile
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *	SXD_STATUS_SUCCESS
 *	SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_pci_profile_get(sxd_command_ifc_hw_t  *hw_p,
                                             struct sx_pci_profile *pci_profile_p);


/**
 *  The CONFIG_PROFILE command sets and queries the Switch Profile.
 *  The set command can be executed on the device only once at
 *  startup in order to allocate and configure all switch resources
 *  and prepare it for operational mode.
 *  It is not possible to change the device profile after the chip is
 *  in operational mode.
 *
 * @param[in]     hw_p           - command interface handle.
 * @param[in]     access_cmd   - GET / SET
 * @param[in,out] profile_p    - device profile
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *	SXD_STATUS_SUCCESS
 *	SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_device_profile_access(sxd_command_ifc_hw_t *hw_p,
                                                   sxd_access_cmd_t      access_cmd,
                                                   struct ku_profile    *profile_p);

/**
 *  This function retrieve board information
 *
 * @param[in]  hw_p           - command interface handle.
 * @param[out] board_info_p - board information.
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *	SXD_STATUS_SUCCESS
 *	SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_query_board_info(sxd_command_ifc_hw_t       *hw_p,
                                              struct ku_query_board_info *board_info_p);

/**
 *  This function retrieve the RDQ that was allocated for SWID. if there are
 *  multiple RDQs allocated , the function returns the first one. it there are
 *  no RDQs allocated for this SWID the return value will be SXD_STATUS_RDQ_NOT_ALLOCATED
 *
 * @param[in]  hw_p           - command interface handle.
 * @param[in]  swid         - switch ID
 * @param[out] rdq_p	    - RDQ number
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *	SXD_STATUS_SUCCESS
 *	SXD_STATUS_HANDLE_ERROR
 *	SXD_STATUS_RDQ_NOT_ALLOCATED - if RDQ was not allocated for this SWID
 */
sxd_status_t sxd_command_ifc_swid_to_rdq(sxd_command_ifc_hw_t *hw_p,
                                         sxd_swid_t            swid,
                                         uint8_t              *rdq_p);

/**
 *  This function checks whether restoring the sx_core driver DB is allowed or not.
 *
 * @param[in]  hw_p                 - command interface handle.
 * @param[out] is_restore_allowed_p	- is it allowed to restore sx_core driver DB.
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *	SXD_STATUS_SUCCESS
 *	SXD_STATUS_HANDLE_ERROR
 *  SXD_STATUS_INVALID_ACCESS_CMD
 *  SXD_STATUS_DEVICE_IOCTL_ERROR
 *  SXD_STATUS_PARAM_ERROR
 */
sxd_status_t sxd_command_ifc_sx_core_db_restore_allowed(sxd_command_ifc_hw_t *hw_p,
                                                        sxd_boolean_t        *is_restore_allowed_p);


/**
 *  This function get/set the sx_core driver DB.
 *
 * @param[in]  hw_p         - command interface handle.
 * @param[out] sx_core_db_p	- sx_core driver DB.
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *	SXD_STATUS_SUCCESS
 *	SXD_STATUS_HANDLE_ERROR
 *  SXD_STATUS_INVALID_ACCESS_CMD
 *  SXD_STATUS_DEVICE_IOCTL_ERROR
 *  SXD_STATUS_PARAM_ERROR
 */
sxd_status_t sxd_command_ifc_sx_core_db_access(sxd_command_ifc_hw_t *hw_p,
                                               sxd_access_cmd_t      access_cmd,
                                               struct ku_sx_core_db *sx_core_db_p);


/*******************************************************************/
/*                           ACCESS REG				   */
/*******************************************************************/

/**
 *  This function get / set PTYS register
 *  Register full name : Port type and speed register
 *
 * @param[in]      hw_p         - command interface handle.
 * @param[in]      access_cmd - GET / SET
 * @param[in]	   dev_id     - device id
 * @param[in,out]  ptys_reg_p - PTYS register data
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *	SXD_STATUS_SUCCESS
 *	SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_access_ptys_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_ptys_reg   *ptys_reg_p);

/**
 *  This function get / set PSPA register
 *  Register full name : Port Switch Partition Allocation register
 *
 * @param[in]      hw_p         - command interface handle.
 * @param[in]      access_cmd - GET / SET
 * @param[in]	   dev_id     - device id
 * @param[in,out]  pspa_reg_p - PSPA register data
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *	SXD_STATUS_SUCCESS
 *	SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_access_pspa_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_pspa_reg   *pspa_reg_p);

/**
 *  This function get / set QSPTC register
 *  Register full name : QoS Stacking Port TClass Table register
 *
 * @param[in]      hw_p         - command interface handle.
 * @param[in]      access_cmd - GET / SET
 * @param[in]	   dev_id     - device id
 * @param[in,out]  qsptc_reg_p - QSPTC register data
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *	SXD_STATUS_SUCCESS
 *	SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_access_qsptc_reg(sxd_command_ifc_hw_t *hw_p,
                                              sxd_access_cmd_t      access_cmd,
                                              sxd_dev_id_t          dev_id,
                                              struct ku_qsptc_reg  *qsptc_reg_p);

/**
 *  This function get / set QSTCT register
 *  Register full name : QoS Switch Stacking TClass Table register
 *
 * @param[in]      hw_p          - command interface handle.
 * @param[in]      access_cmd  - GET / SET
 * @param[in]	   dev_id      - device id
 * @param[in,out]  qstct_reg_p - QSTCT register data
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *	SXD_STATUS_SUCCESS
 *	SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_access_qstct_reg(sxd_command_ifc_hw_t *hw_p,
                                              sxd_access_cmd_t      access_cmd,
                                              sxd_dev_id_t          dev_id,
                                              struct ku_qstct_reg  *qstct_reg_p);

/**
 *  This function get / set PMLP register
 *  Register full name : Ports Module to Local Port register
 *
 * @param[in]      hw_p          - command interface handle.
 * @param[in]      access_cmd  - GET / SET
 * @param[in]	   dev_id      - device id
 * @param[in,out]  pmlp_reg_p  - PMLP register data
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *	SXD_STATUS_SUCCESS
 *	SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_access_pmlp_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_pmlp_reg   *pmlp_reg_p);

/**
 *  This function get / set PLIB register
 *  Register full name : Port Local Port to IB Port Mapping register
 *
 * @param[in]      hw_p          - command interface handle.
 * @param[in]      access_cmd  - GET / SET
 * @param[in]	   dev_id      - device id
 * @param[in,out]  plib_reg_p  - PLIB register data
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *	SXD_STATUS_SUCCESS
 *	SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_access_plib_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_plib_reg   *plib_reg_p);

/**
 *  This function get / set PPLR register
 *  Register full name : Port Physical Loopback Register
 *
 * @param[in]      hw_p          - command interface handle.
 * @param[in]      access_cmd  - GET / SET
 * @param[in]	   dev_id      - device id
 * @param[in,out]  pplr_reg_p  - PPLR register data
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *	SXD_STATUS_SUCCESS
 *	SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_access_pplr_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_pplr_reg   *pplr_reg_p);


/**
 *  This function get / set PPLM register
 *  Register full name : Ports Administrative and Operational Status Register
 *
 * @param[in]      hw_p          - command interface handle.
 * @param[in]      access_cmd  - GET / SET
 * @param[in]	   dev_id      - device id
 * @param[in,out]  pplm_reg_p  - PPLM register data
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *	SXD_STATUS_SUCCESS
 *	SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_access_pplm_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_pplm_reg   *pplm_reg_p);

/**
 *  This function get / set PLPC register
 *  Register full name : Ports Administrative and Operational Status Register
 *
 * @param[in]      hw_p          - command interface handle.
 * @param[in]      access_cmd  - GET / SET
 * @param[in]	   dev_id      - device id
 * @param[in,out]  plpc_reg_p  - PLPC register data
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *	SXD_STATUS_SUCCESS
 *	SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_access_plpc_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_plpc_reg   *plpc_reg_p);

/**
 *  This function get / set PMPC register
 *  Register full name : Ports Administrative and Operational Status Register
 *
 * @param[in]      hw_p          - command interface handle.
 * @param[in]      access_cmd  - GET / SET
 * @param[in]	   dev_id      - device id
 * @param[in,out]  pmpc_reg_p  - PMPC register data
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *	SXD_STATUS_SUCCESS
 *	SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_access_pmpc_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_pmpc_reg   *pmpc_reg_p);

/**
 *  This function get / set PMCR register
 *  Register full name : Ports Module Control Register
 *
 * @param[in]      hw_p        - command interface handle.
 * @param[in]      access_cmd  - GET / SET
 * @param[in]      dev_id      - device id
 * @param[in,out]  pmcr_reg_p  - PMCR register data
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *  SXD_STATUS_SUCCESS
 *  SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_access_pmcr_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_pmcr_reg   *pmcr_reg_p);

/**
 *  This function get / set PFSC register
 *  Register full name : Ports Forward Switching Control Register
 *
 * @param[in]      hw_p        - command interface handle.
 * @param[in]      access_cmd  - GET / SET
 * @param[in]      dev_id      - device id
 * @param[in,out]  pfsc_reg_p  - PMCR register data
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *  SXD_STATUS_SUCCESS
 *  SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_access_pfsc_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_pfsc_reg   *pfsc_reg_p);

/**
 *  This function get / set MJTAG register
 *  Register full name : Misc JTAG Register
 *
 * @param[in]      hw_p          - command interface handle.
 * @param[in]      access_cmd  - GET / SET
 * @param[in]	   dev_id      - device id
 * @param[in,out]  mjtag_reg_p  - MJTAG register data
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *	SXD_STATUS_SUCCESS
 *	SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_access_mjtag_reg(sxd_command_ifc_hw_t *hw_p,
                                              sxd_access_cmd_t      access_cmd,
                                              sxd_dev_id_t          dev_id,
                                              struct ku_mjtag_reg  *mjtag_reg_p);

/**
 *  This function get / set PPSC register
 *  Register full name : Misc PPSC Register
 *
 * @param[in]      hw_p          - command interface handle.
 * @param[in]      access_cmd  - GET / SET
 * @param[in]	   dev_id      - device id
 * @param[in,out]  ppsc_reg_p  - PPSC register data
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *	SXD_STATUS_SUCCESS
 *	SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_access_ppsc_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_ppsc_reg   *ppsc_reg_p);

/**
 *  This function get / set PMPR register
 *  Register full name : Ports Module PRoperties
 *
 * @param[in]      hw_p          - command interface handle.
 * @param[in]      access_cmd  - GET / SET
 * @param[in]	   dev_id      - device id
 * @param[in,out]  pmpr_reg_p  - PMPR register data
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *	SXD_STATUS_SUCCESS
 *	SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_access_pmpr_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_pmpr_reg   *pmpr_reg_p);

/**
 *  This function get / set HTGT register
 *  Register full name : Host Trap Group Table Register
 *
 * @param[in]      hw_p          - command interface handle.
 * @param[in]      access_cmd  - GET / SET
 * @param[in]	   dev_id      - device id
 * @param[in,out]  htgt_reg_p  - HTGT register data
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *	SXD_STATUS_SUCCESS
 *	SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_access_htgt_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_htgt_reg   *htgt_reg_p);

/**
 *  This function get / set HPKT register
 *  Register full name : Host Packet Trap Register
 *
 * @param[in]      hw_p          - command interface handle.
 * @param[in]      access_cmd  - GET / SET
 * @param[in]	   dev_id      - device id
 * @param[in,out]  hpkt_reg_p  - HPKT register data
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *	SXD_STATUS_SUCCESS
 *	SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_access_hpkt_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_hpkt_reg   *hpkt_reg_p);

/**
 *  This function get / set HCAP register
 *  Register full name : Host interface capabilities
 *
 * @param[in]      hw_p          - command interface handle.
 * @param[in]      access_cmd  - GET / SET
 * @param[in]	   dev_id      - device id
 * @param[in,out]  hcap_reg_p  - HCAP register data
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *	SXD_STATUS_SUCCESS
 *	SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_access_hcap_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_hcap_reg   *hcap_reg_p);

/**
 *  This function get / set HDRT register
 *  Register full name : Host direct route table
 *
 * @param[in]      hw_p          - command interface handle.
 * @param[in]      access_cmd  - GET / SET
 * @param[in]	   dev_id      - device id
 * @param[in,out]  hdrt_reg_p  - HDRT register data
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *	SXD_STATUS_SUCCESS
 *	SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_access_hdrt_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_hdrt_reg   *hdrt_reg_p);

/**
 *  This function get / set HCTR register
 *  Register full name : Host direct route table
 *
 * @param[in]      hw_p          - command interface handle.
 * @param[in]      access_cmd  - GET / SET
 * @param[in]      dev_id      - device id
 * @param[in,out]  hctr_reg_p  - HCTR register data
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *  SXD_STATUS_SUCCESS
 *  SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_access_hctr_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_hctr_reg   *hctr_reg_p);

/**
 *  This function get / set PELC register
 *  Register full name : Port extended link capabilities
 *
 * @param[in]      hw_p          - command interface handle.
 * @param[in]      access_cmd  - GET / SET
 * @param[in]	   dev_id      - device id
 * @param[in,out]  pelc_reg_p  - PELC register data
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *	SXD_STATUS_SUCCESS
 *	SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_access_pelc_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_pelc_reg   *pelc_reg_p);

/**
 *  This function get / set SPAD register
 *  Register full name : Port extended link capabilities
 *
 * @param[in]      hw_p          - command interface handle.
 * @param[in]      access_cmd  - GET / SET
 * @param[in]	   dev_id      - device id
 * @param[in,out]  spad_reg_p  - SPAD register data
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *	SXD_STATUS_SUCCESS
 *	SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_access_spad_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_spad_reg   *spad_reg_p);

/**
 *  This function get / set MCIA register
 *  Register full name : Misc cable info access
 *
 * @param[in]      hw_p          - command interface handle.
 * @param[in]      access_cmd  - GET / SET
 * @param[in]	   dev_id      - device id
 * @param[in,out]  mcia_reg_p  - MCIA register data
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *	SXD_STATUS_SUCCESS
 *	SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_access_mcia_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_mcia_reg   *mcia_reg_p);

/**
 *  This function get / set QPRT register
 *  Register full name : QoS Priority Regeneration Table Register
 *
 * @param[in]      hw_p          - command interface handle.
 * @param[in]      access_cmd  - GET / SET
 * @param[in]	   dev_id      - device id
 * @param[in,out]  qprt_reg_p  - QPRT register data
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *	SXD_STATUS_SUCCESS
 *	SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_access_qprt_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_qprt_reg   *qprt_reg_p);


/*******************************************************************/
/*                           FAN CONTROL			   */
/*******************************************************************/

/**
 *  This function get / set MFCR register
 *  Register full name : Misc Fan Control Register
 *
 * @param[in]      hw_p          - command interface handle.
 * @param[in]      access_cmd  - GET / SET
 * @param[in]	   dev_id      - device id
 * @param[in,out]  mfcr_reg_p  - MFCR register data
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *	SXD_STATUS_SUCCESS
 *	SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_access_mfcr_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_mfcr_reg   *mfcr_reg_p);

/**
 *  This function get / set MFSL register
 *  Register full name : Misc Fan Speed limit register
 *
 * @param[in]      hw_p          - command interface handle.
 * @param[in]      access_cmd  - GET / SET
 * @param[in]	   dev_id      - device id
 * @param[in,out]  mfsl_reg_p  - MFSL register data
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *	SXD_STATUS_SUCCESS
 *	SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_access_mfsl_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_mfsl_reg   *mfsl_reg_p);

/**
 *  This function get / set FORE register
 *  Register full name : Fan Out of Range Event Register
 *
 * @param[in]      hw_p        - command interface handle.
 * @param[in]      access_cmd  - GET / SET
 * @param[in]	   dev_id      - device id
 * @param[in,out]  fore_reg_p  - FORE register data
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *	SXD_STATUS_SUCCESS
 *	SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_access_fore_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_fore_reg   *fore_reg_p);

/*******************************************************************/
/*                           TEMPERATURE CONTROL			       */
/*******************************************************************/

/**
 *  This function get / set MTCAP register
 *  Register full name : Misc Temperature Capabilities Register
 *
 * @param[in]      hw_p        - command interface handle.
 * @param[in]      access_cmd  - GET / SET
 * @param[in]	   dev_id      - device id
 * @param[in,out]  mtcap_reg_p - MTCAP register data
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *	SXD_STATUS_SUCCESS
 *	SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_access_mtcap_reg(sxd_command_ifc_hw_t *hw_p,
                                              sxd_access_cmd_t      access_cmd,
                                              sxd_dev_id_t          dev_id,
                                              struct ku_mtcap_reg  *mtcap_reg_p);

/**
 * This function get / set MTBR register
 * Register full name : Management Temperature Bulk Register
 *
 * @param[in]      hw_p        - command interface handle.
 * @param[in]      access_cmd  - GET / SET
 * @param[in]      dev_id      - device id
 * @param[in,out]  mtbr_reg_p  - MTBR register data
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *     SXD_STATUS_SUCCESS
 *     SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_access_mtbr_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_mtbr_reg   *mtbr_reg_p);

/**
 *  This function get / set MTWE register
 *  Register full name : Misc Temperature Warning Event Register
 *
 * @param[in]      hw_p        - command interface handle.
 * @param[in]      access_cmd  - GET / SET
 * @param[in]	   dev_id      - device id
 * @param[in,out]  mtwe_reg_p  - MTWE register data
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *	SXD_STATUS_SUCCESS
 *	SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_access_mtwe_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_mtwe_reg   *mtwe_reg_p);

/**
 *  This function get / set MFPA register
 *  Register full name : Misc Flash Params register
 *
 * @param[in]      hw_p        - command interface handle.
 * @param[in]      access_cmd  - GET / SET
 * @param[in]	   dev_id      - device id
 * @param[in,out]  mfpa_reg_p  - MFPA register data
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *	SXD_STATUS_SUCCESS
 *	SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_access_mfpa_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_mfpa_reg   *mfpa_reg_p);

/**
 *  This function get / set MFBE register
 *  Register full name : Misc Flash Block Erase register
 *
 * @param[in]      hw_p        - command interface handle.
 * @param[in]      access_cmd  - GET / SET
 * @param[in]	   dev_id      - device id
 * @param[in,out]  mfbe_reg_p  - MFBE register data
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *	SXD_STATUS_SUCCESS
 *	SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_access_mfbe_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_mfbe_reg   *mfbe_reg_p);

/**
 *  This function get / set MFBA register
 *  Register full name : Misc Flash Block Access register
 *
 * @param[in]      hw_p        - command interface handle.
 * @param[in]      access_cmd  - GET / SET
 * @param[in]	   dev_id      - device id
 * @param[in,out]  mfba_reg_p  - MFBA register data
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *	SXD_STATUS_SUCCESS
 *	SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_access_mfba_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_mfba_reg   *mfba_reg_p);

/**
 *  This function get / set QCAP register
 *  Register full name : Misc Flash Block Access register
 *
 * @param[in]      hw_p        - command interface handle.
 * @param[in]      access_cmd  - GET / SET
 * @param[in]	   dev_id      - device id
 * @param[in,out]  qcap_reg_p  - QCAP register data
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *	SXD_STATUS_SUCCESS
 *	SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_access_qcap_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_qcap_reg   *qcap_reg_p);

/**
 *  This function get / set a RAW register
 *
 * @param[in]      hw_p		- command interface handle.
 * @param[in]      access_cmd	- GET / SET
 * @param[in]	   dev_id	- device id
 * @param[in]	   register_id	- register id
 * @param[in,out]  raw_reg_p	- RAW register data
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *	SXD_STATUS_SUCCESS
 *	SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_access_raw_reg(sxd_command_ifc_hw_t *hw_p,
                                            sxd_access_cmd_t      access_cmd,
                                            sxd_dev_id_t          dev_id,
                                            uint16_t              register_id,
                                            struct ku_raw_reg    *raw_reg_p);

/**
 *  This function sends a RAW buffer to the FW using ACCESS_REG command
 *
 * @param[in]      hw_p		- command interface handle.
 * @param[in]	   dev_id	- device id
 * @param[in,out]  raw_buff_p	- RAW buff data
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *	SXD_STATUS_SUCCESS
 *	SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_access_reg_raw_buff(sxd_command_ifc_hw_t *hw_p,
                                                 sxd_dev_id_t          dev_id,
                                                 struct ku_raw_reg    *raw_buff_p);


/**
 *  This function get / set MFM register
 *  Register full name : Misc Fabric Memory Register
 *
 * @param[in]      hw_p          - command interface handle.
 * @param[in]      access_cmd  - GET / SET
 * @param[in]	   dev_id      - device id
 * @param[in,out]  mfm_reg_p  - MFM register data
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *	SXD_STATUS_SUCCESS
 *	SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_access_sspr_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_sspr_reg   *sspr_reg_p);
sxd_status_t sxd_command_ifc_access_spmcr_reg(sxd_command_ifc_hw_t *hw_p,
                                              sxd_access_cmd_t      access_cmd,
                                              sxd_dev_id_t          dev_id,
                                              struct ku_spmcr_reg  *spmcr_reg_p);
sxd_status_t sxd_command_ifc_access_pbmc_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_pbmc_reg   *pbmc_reg_p);
sxd_status_t sxd_command_ifc_access_pptb_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_pptb_reg   *pptb_reg_p);
sxd_status_t sxd_command_ifc_access_smid_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_smid_reg   *smid_reg_p);

sxd_status_t sxd_command_ifc_access_spms_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_spms_reg   *spms_reg_p);
sxd_status_t sxd_command_ifc_access_spvid_reg(sxd_command_ifc_hw_t *hw_p,
                                              sxd_access_cmd_t      access_cmd,
                                              sxd_dev_id_t          dev_id,
                                              struct ku_spvid_reg  *spvid_reg_p);
sxd_status_t sxd_command_ifc_access_sfd_reg(sxd_command_ifc_hw_t *hw_p,
                                            sxd_access_cmd_t      access_cmd,
                                            sxd_dev_id_t          dev_id,
                                            struct ku_sfd_reg    *sfd_reg_p);

sxd_status_t sxd_command_ifc_access_qpbr_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_qpbr_reg   *qpbr_reg_p);
/**
 *  This function get / set a PLBF register
 *
 * @param[in]      hw_p		- command interface handle.
 * @param[in]      access_cmd	- GET / SET
 * @param[in]	   dev_id	- device id
 * @param[in,out]  plbf_reg_p	- PLBF register data
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *	SXD_STATUS_SUCCESS
 *	SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_access_plbf_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_plbf_reg   *plbf_reg_p);

sxd_status_t sxd_command_ifc_access_sgcr_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_sgcr_reg   *sgcr_reg_p);

sxd_status_t sxd_command_ifc_access_msci_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_msci_reg   *msci_reg_p);

sxd_status_t sxd_command_ifc_access_mrsr_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_mrsr_reg   *mrsr_reg_p);

sxd_status_t sxd_command_ifc_access_sbpr_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_sbpr_reg   *sbpr_reg_p);

sxd_status_t sxd_command_ifc_access_sbcm_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_sbcm_reg   *sbcm_reg_p);

sxd_status_t sxd_command_ifc_access_sbpm_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_sbpm_reg   *sbpm_reg_p);

sxd_status_t sxd_command_ifc_access_sbmm_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_sbmm_reg   *sbmm_reg_p);

sxd_status_t sxd_command_ifc_access_mpsc_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_mpsc_reg   *mpsc_reg_p);

/**
 *  This function get / set MLCR register
 *  Register full name : Management LED control register
 *
 * @param[in]      hw_p          - command interface handle.
 * @param[in]      access_cmd  - GET / SET
 * @param[in]      dev_id      - device id
 * @param[in,out]  mlcr_reg_p  - mlcr register data
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *  SXD_STATUS_SUCCESS
 *  SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_access_mlcr_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_mlcr_reg   *mlcr_reg_p);

sxd_status_t sxd_command_ifc_access_mdri_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_mdri_reg   *mdri_reg_p);

sxd_status_t sxd_command_ifc_set_port_vid_to_fid_map(sxd_command_ifc_hw_t *hw_p,
                                                     sxd_dev_id_t          dev_id,
                                                     uint8_t               local_port,
                                                     uint16_t              vid,
                                                     uint8_t               is_mapped_to_fid,
                                                     uint16_t              fid);

sxd_status_t sxd_command_ifc_access_rgcr_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_rgcr_reg   *rgcr_reg_p);

sxd_status_t sxd_command_ifc_access_rtps_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_rtps_reg   *rtps_reg_p);

sxd_status_t sxd_command_ifc_access_rtca_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_rtca_reg   *rtca_reg_p);

sxd_status_t sxd_command_ifc_access_ritr_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_ritr_reg   *ritr_reg_p);
sxd_status_t sxd_command_ifc_access_ruft_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_ruft_reg   *ruft_reg_p);

sxd_status_t sxd_command_ifc_system_m_key_access(sxd_command_ifc_hw_t   *hw_p,
                                                 sxd_access_cmd_t        access_cmd,
                                                 struct ku_system_m_key *system_m_key_p);

/**
 *  This function get / set MPGCR register
 *  Register full name : MPLS General Configuration register
 *
 * @param[in]      hw_p          - command interface handle.
 * @param[in]      access_cmd  - GET / SET
 * @param[in]      dev_id      - device id
 * @param[in,out]  mpgcr_reg_p  - mpgcr register data
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *  SXD_STATUS_SUCCESS
 *  SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_access_mpgcr_reg(sxd_command_ifc_hw_t *hw_p,
                                              sxd_access_cmd_t      access_cmd,
                                              sxd_dev_id_t          dev_id,
                                              struct ku_mpgcr_reg  *mpgcr_reg_p);

/**
 *  This function get / set MPILM register
 *  Register full name : MPLS General Configuration register
 *
 * @param[in]      hw_p          - command interface handle.
 * @param[in]      access_cmd  - GET / SET
 * @param[in]      dev_id      - device id
 * @param[in,out]  mpilm_reg_p  - mpilm register data
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *  SXD_STATUS_SUCCESS
 *  SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_access_mpilm_reg(sxd_command_ifc_hw_t *hw_p,
                                              sxd_access_cmd_t      access_cmd,
                                              sxd_dev_id_t          dev_id,
                                              struct ku_mpilm_reg  *mpilm_reg_p);

/**
 *  This function get / set MPNHLFE register
 *  Register full name : MPLS General Configuration register
 *
 * @param[in]      hw_p          - command interface handle.
 * @param[in]      access_cmd  - GET / SET
 * @param[in]      dev_id      - device id
 * @param[in,out]  mpnhlfe_reg_p  - mpnhlfe register data
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *  SXD_STATUS_SUCCESS
 *  SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_access_mpnhlfe_reg(sxd_command_ifc_hw_t  *hw_p,
                                                sxd_access_cmd_t       access_cmd,
                                                sxd_dev_id_t           dev_id,
                                                struct ku_mpnhlfe_reg *mpnhlfe_reg_p);

/**
 *  This function get / set QPCR register
 *  Register full name : QoS Policer Configuration Register
 *
 * @param[in]      hw_p          - command interface handle.
 * @param[in]      access_cmd    - GET / SET
 * @param[in]      dev_id        - device id
 * @param[in,out]  qpcr_reg_p    - qpcr register data
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *  SXD_STATUS_SUCCESS
 *  SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_access_qpcr_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_qpcr_reg   *qpcr_reg_p);


/**
 *  This function set MAD DEMUX on a device
 *
 * @param[in]      hw_p          - command interface handle.
 * @param[in]      dev_id        - device id
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *  SXD_STATUS_SUCCESS
 */
sxd_status_t sxd_command_ifc_set_mad_demux(sxd_command_ifc_hw_t *hw_p,
                                           sxd_dev_id_t          dev_id,
                                           uint8_t               enable);


/**
 *  This function set SW IB node description
 *
 * @param[in]      hw_p          - command interface handle.
 * @param[in]      node_desc     - IB node description info
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *  SXD_STATUS_SUCCESS
 */
sxd_status_t sxd_command_ifc_set_sw_ib_node_description(sxd_command_ifc_hw_t          *hw_p,
                                                        struct ku_ib_node_description *node_desc);


/**
 *  This function enables/disables sdk_health trap  in driver.
 *
 * @param[in] hw_p        - command interface handle.
 * @param[in] dev_id      - device id
 * @param[in] sdk_health_state    - TRUE - enabled /FALSE - disable.
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *         SXD_STATUS_SUCCESS
 *         SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_sdk_health_state_set(sxd_command_ifc_hw_t *hw_p,
                                                  uint8_t               dev_id,
                                                  boolean_t             sdk_health_state);


/**
 *  This function reads sdk_health trap enablement status  in driver.
 *
 * @param[in] hw_p        - command interface handle.
 * @param[in] dev_id      - device id
 * @param[in] get and disable - get sdk health status and disable
 * @param[out] sdk_health_state    - TRUE - enabled; FALSE - disable.
 *
 * @return SXD_STATUS_NOT_INITIALIZED
 *	SXD_STATUS_SUCCESS
 *	SXD_STATUS_HANDLE_ERROR
 */
sxd_status_t sxd_command_ifc_sdk_health_state_get(sxd_command_ifc_hw_t *hw_p,
                                                  uint8_t               dev_id,
                                                  boolean_t             get_and_disable,
                                                  boolean_t            *sdk_health_state_p);


#endif /* __SXD_COMMAND_IFC_H_ */
