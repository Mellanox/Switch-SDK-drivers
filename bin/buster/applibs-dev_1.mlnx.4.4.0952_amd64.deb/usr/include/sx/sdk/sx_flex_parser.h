/*
 *  Copyright (C) 2010-2020. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */

#ifndef __SX_FLEX_PARSER_H__
#define __SX_FLEX_PARSER_H__

#include <sx/sdk/sx_types.h>

#include "sx/sdk/auto_headers/sx_flex_parser_auto.h"


/************************************************
 *  Local Defines
 ***********************************************/
#ifndef     IN
#define     IN
#endif  /*  IN */

#ifndef     OUT
#define     OUT
#endif  /*  OUT */

#ifndef     INOUT
#define     INOUT
#endif  /*  INOUT   */


/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

#define FLEX_PARSER_VXLAN_DEFAULT_UDP_PORT 4789
#define SX_IS_FLEX_PARSER_HDR_NODE_VALID(hdr) is_flex_parser_node_valid(hdr)

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/**
 * Specifies the fixed flex parser header type – Minimum support for VXLAN Destination port configuration
 */
typedef enum sx_flex_parser_header_fixed {
    SX_FLEX_PARSER_HEADER_UDP_E = 32,
    SX_FLEX_PARSER_HEADER_VXLAN_E = 64,
    SX_FLEX_PARSER_HEADER_MIN = SX_FLEX_PARSER_HEADER_UDP_E,
    SX_FLEX_PARSER_HEADER_MAX = SX_FLEX_PARSER_HEADER_VXLAN_E
} sx_flex_parser_header_fixed_e;


/**
 * Specifies the init flex parser params – dont-care for Spectrum
 */

typedef struct sx_flex_parser_param {
    boolean_t default_flex_parser_graph;
} sx_flex_parser_param_t;


/**
 * Specifies whether a parse header is an outer header or
 * an inner encapsulated header
 */
typedef enum sx_flex_parser_encap_level {
    SX_FLEX_PARSER_ENCAP_OUTER_E
} sx_flex_parser_encap_level_e;

/**
 * Specifies whether a header type is fixed or flex type
 */
typedef enum sx_flex_parser_header_type {
    SX_FLEX_PARSER_HEADER_FIXED_E
} sx_flex_parser_header_type_e;

typedef union sx_flex_parser_header_data {
    sx_flex_parser_header_fixed_e parser_hdr_fixed;
} sx_flex_parser_header_data_t;

/**
 * Specifies the flex parser header information. Flex headers would
 * be added in future
 */
typedef struct sx_flex_parser_header {
    sx_flex_parser_header_type_e     parser_hdr_type;
    union sx_flex_parser_header_data hdr_data;
} sx_flex_parser_header_t;


/**
 * Structure to hold the transition states and transition values.
 */

typedef struct sx_flex_parser_transition {
    sx_flex_parser_header_t      next_parser_hdr;
    sx_flex_parser_encap_level_e encap_level;
    uint32_t                     transition_value;
} sx_flex_parser_transition_t;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/
static inline boolean_t is_flex_parser_node_valid(sx_flex_parser_header_t hdr)
{
    boolean_t rc = TRUE;

    if (hdr.parser_hdr_type != SX_FLEX_PARSER_HEADER_FIXED_E) {
        rc = FALSE;
        goto out;
    }

    switch (hdr.hdr_data.parser_hdr_fixed) {
    case SX_FLEX_PARSER_HEADER_UDP_E:
    case SX_FLEX_PARSER_HEADER_VXLAN_E:
        goto out;
        break;

    default:
        rc = FALSE;
        goto out;
        break;
    }
out:
    return rc;
}

#endif /* __SX_FLEX_PARSER_H___    */
