/*
 *  Copyright (C) 2014-2020. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */
#ifndef __SX_TUNNEL_H__
#define __SX_TUNNEL_H__

/************************************************
 *  Type definitions
 ***********************************************/

#include <sx/sdk/sx_bridge.h>
#include <sx/sdk/sx_router.h>
#include <sx/sdk/sx_span.h>
#include <sx/sdk/sx_vlan.h>
#include <sx/sdk/sx_cos.h>
#include <sx/sdk/sx_acl.h>
#include <sx/sdk/sx_tunnel_id.h>

#include "sx/sdk/auto_headers/sx_tunnel_auto.h"


#define SX_GENERATE_ENUM(ENUM, STR) ENUM,

#define FOREACH_TUNNEL_DECAP_KEY_FIELDS_TYPE(F)                                                                    \
    F(SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP = 0 /**< Key contains packet destination IP */, "DIP")                   \
    F(SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP_SIP /**< Key contains packet destination IP and source IP */, "DIP SIP") \
    F(SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_MIN = SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP, "")                               \
    F(SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_MAX = SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP_SIP, "")

/**
 * This define is used for NVE ports to specify that packet
 * Ethertype should be determined based on the egress port
 * configuration. Supported devices: Spectrum2, Spectrum3.
 */
#define SX_ETHERTYPE_FROM_EGRESS_PORT 0xFFFF

/**
 * Decap table fields types
 */
typedef enum sx_tunnel_decap_key_fields_type {
    FOREACH_TUNNEL_DECAP_KEY_FIELDS_TYPE(SX_GENERATE_ENUM)
} sx_tunnel_decap_key_fields_type_e;

#define SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_CHECK_RANGE(TYPE) \
    SX_CHECK_MAX(TYPE, SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_MAX)

#define TUNNEL_MAP_ENTRIES_SET_MAX_NUM 64
#define MAX_NUM_ENRTY_GET              8192

/**
 * Decap table entry key
 */
typedef struct sx_tunnel_decap_entry_key {
    sx_tunnel_type_e                  tunnel_type; /**< Tunnel Type */
    sx_tunnel_decap_key_fields_type_e type; /**< Key fields */
    sx_router_id_t                    underlay_vrid;  /**< Router ID the key associated with */
    sx_ip_addr_t                      underlay_dip;   /**< Destination ip in underlay packet */
    sx_ip_addr_t                      underlay_sip;   /**< Source ip in underlay packet */
} sx_tunnel_decap_entry_key_t;

/**
 * Decap table entry data
 */
typedef struct sx_tunnel_decap_entry_data {
    sx_tunnel_id_t                           tunnel_id; /**< Tunnel ID */
    sx_router_action_t                       action; /**< Which action when decap */
    sx_flow_counter_id_t                     counter_id; /**< Flow counter to attach */
    sx_trap_attributes_t                     trap_attr; /**< Trap attributes */
    sx_span_session_id_t                     span_session_id; /**< Span session ID */
    boolean_t                                set_user_token; /**< If set, user token will be attached to packet's meta data */
    sx_flex_acl_flex_action_set_user_token_t user_token; /**< User token that should be attached to packet's meta data */
} sx_tunnel_decap_entry_data_t;

/**
 * IPinIP General parameters
 */
typedef struct sx_tunnel_ipinip_general_params {
    uint16_t encap_flowlabel; /**< 12msb of Flow Label value for underlay packet in encap operation, if set, the 8 lsb will be calculated from ecmp hash, set to 0 to disable */
    uint32_t encap_gre_hash; /**< 24msb of GRE hash value for underlay packet in encap operation */
} sx_tunnel_ipinip_general_params_t;

#define FOREACH_TUNNEL_IPINIP_GRE_MODE(F)                                                                  \
    F(SX_TUNNEL_IPINIP_GRE_MODE_ENABLED = 0 /**< GRE Enabled */, "Enabled")                                \
    F(SX_TUNNEL_IPINIP_GRE_MODE_ENABLED_WITH_KEY /**< GRE Enabled with key support */, "Enabled with Key") \
    F(SX_TUNNEL_IPINIP_GRE_MODE_ENABLED_WITH_KEY_HASH /**< GRE Enabled with both key and hash support */,  \
      "Enabled with Key Hash")                                                                             \
    F(SX_TUNNEL_IPINIP_GRE_MODE_MIN = SX_TUNNEL_IPINIP_GRE_MODE_ENABLED, "")                               \
    F(SX_TUNNEL_IPINIP_GRE_MODE_MAX = SX_TUNNEL_IPINIP_GRE_MODE_ENABLED_WITH_KEY_HASH, "")

/**
 * IPinIP Tunnel GRE Mode
 */
typedef enum sx_tunnel_ipinip_gre_mode {
    FOREACH_TUNNEL_IPINIP_GRE_MODE(SX_GENERATE_ENUM)
} sx_tunnel_ipinip_gre_mode_e;

/**
 * IPinIP encap attributes
 */
typedef struct sx_tunnel_ipinip_p2p_encap_attributes {
    sx_router_id_t              underlay_vrid;    /**< Router ID which the encapsulated packets will be sent from. */
    sx_ip_addr_t                underlay_sip;    /**< Source IP on encapsulated packets */
    sx_tunnel_ipinip_gre_mode_e gre_mode; /**< GRE Mode (Enabled or Enabled with options) */
    sx_tunnel_gre_key_t         gre_key;  /**< GRE Key used in case tunnel enabled GRE Key */
} sx_tunnel_ipinip_p2p_encap_attributes_t;

/**
 * IPinIP decap attributes
 */
typedef struct sx_tunnel_ipinip_p2p_decap_attributes {
    boolean_t           gre_check_key;     /**< Check GRE Key with expected_gre_key when doing decapsulation operation */
    sx_tunnel_gre_key_t gre_expected_key;  /**< Expected GRE Key */
} sx_tunnel_ipinip_p2p_decap_attributes_t;

/**
 * IPinIP Peer 2 Peer Tunnel attributes
 */
typedef struct sx_tunnel_ipinip_p2p_attribute {
    sx_router_interface_t                   overlay_rif;  /**< Tunnel interface to connect the tunnel to overlay router */
    sx_router_interface_t                   underlay_rif; /**< Tunnel interface to connect the tunnel to underlay router. Applicable when setting underlay domain type to RIF - Supported devices: Spectrum2, Spectrum3. */
    sx_tunnel_ipinip_p2p_encap_attributes_t encap;        /**< IPinIP Encap attributes */
    sx_tunnel_ipinip_p2p_decap_attributes_t decap;        /**< IPinIP Decap attributes */
    sx_tunnel_underlay_domain_type_e        underlay_domain_type; /**< Tunnel Underlay Domain Type */
} sx_tunnel_ipinip_p2p_attribute_t;

/**
 * NVE General parameters
 */
typedef struct sx_tunnel_nve_general_params {
    uint8_t            encap_sport; /**< Source UDP port on the packet, 8 bits filled by LAG hash. won't be used for NVGRE packets */
    uint16_t           encap_flowlabel; /**< 12msb of Flow Label value for underlay packet in encap operation, if set, the 8 lsb will be calculated from ecmp hash, set to 0 to disable */
    boolean_t          flood_ecmp_enabled; /**< Spectrum only; The flag defines whether we support or not a setting of an ECMP container as a flood vector. For the Spectrum, an ECMP support can be enabled only globally. */
    boolean_t          fdb_resolution_valid; /**< set TRUE to use fdb_resolution_action */
    sx_router_action_t fdb_resolution_action; /**< action for the neighbor that is in bridge with RIF and tunnel, when its MAC doesn't have resolution in FDB table */
    boolean_t          mc_ecmp_enabled; /**< Spectrum only; The flag defines whether we support or not a setting an ECMP container of multicast entries for a Multicast Tunnel FDB Record. For the Spectrum, an ECMP support can be enabled only globally.*/
    uint32_t           ecmp_max_size; /**< Spectrum only; Can be set to: 0,1,2,4,8,16,32,64; Affects both ECMP NVE MC and NVE FLOOD containers; 0 means that the size is set to 16 by SDK. */
} sx_tunnel_nve_general_params_t;

/**
 * NVE tunnel counter
 */
typedef struct sx_tunnel_nve_counter {
    uint64_t encapsulated_pkts;
    uint64_t decapsulated_pkts;
    uint64_t decapsulated_errors;
    uint64_t decapsulated_discards;
} sx_tunnel_nve_counter_t;

typedef union sx_tunnel_counter_items {
    sx_tunnel_nve_counter_t nve;
} sx_tunnel_counter_items_t;

/**
 * Tunnel counters
 */
typedef struct sx_tunnel_counter {
    sx_tunnel_type_e              type;
    union sx_tunnel_counter_items counter;
} sx_tunnel_counter_t;

/**
 * NVE encap attributes
 */
typedef struct sx_tunnel_nve_encap_attributes {
    sx_router_id_t        underlay_vrid;     /**< Router ID which the encapsulated packets will be sent from */
    sx_ip_addr_t          underlay_sip;      /**< Source IP on encapsulated packets */
    sx_router_interface_t underlay_rif;      /**< Tunnel interface to connect the tunnel to underlay router. Applicable when setting underlay domain type to RIF - Supported devices: Spectrum2, Spectrum3.*/
} sx_tunnel_nve_encap_attributes_t;


/**
 * NVE decap attributes
 */
typedef struct sx_tunnel_nve_decap_attributes {
    sx_router_interface_t underlay_rif;     /**< Tunnel interface to connect the tunnel to underlay router. Applicable when setting underlay domain type to RIF - Supported devices: Spectrum2, Spectrum3 */
    sx_ether_type_t       ethertype;
} sx_tunnel_nve_decap_attributes_t;

/**
 * NVE tunnel specific attributes
 */
typedef struct sx_tunnel_nve_attribute {
    sx_tunnel_nve_encap_attributes_t encap;         /**< NVE Encap Attributes */
    sx_tunnel_nve_decap_attributes_t decap;         /**< NVE Decap Attributes */
    sx_port_log_id_t                 nve_log_port;  /**< NVE Logical Port */
    sx_tunnel_underlay_domain_type_e underlay_domain_type; /**< Tunnel Underlay Domain Type */
} sx_tunnel_nve_attribute_t;

typedef enum sx_tunnel_map_dir {
    SX_TUNNEL_MAP_DIR_BIDIR,
    SX_TUNNEL_MAP_DIR_DECAP
} sx_tunnel_map_dir_e;

typedef struct sx_tunnel_nve_map_entry {
    sx_bridge_id_t      bridge_id;             /* Bridge ID / VLAN ID */
    sx_tunnel_vni_t     vni;                   /* VNI - VxLan / Geneve, VSID - NVGRE */
    sx_tunnel_map_dir_e direction;
} sx_tunnel_nve_map_entry_t;

typedef union sx_tunnel_map_entry_params {
    sx_tunnel_nve_map_entry_t nve; /* NVE Params */
} sx_tunnel_map_entry_params_t;

/**
 * Tunnel mapping entry
 */
typedef struct sx_tunnel_map_entry {
    sx_tunnel_type_e                 type;
    union sx_tunnel_map_entry_params params;
} sx_tunnel_map_entry_t;

/**
 * Tunneling general parameters
 */
typedef struct sx_tunnel_general_params {
    sx_tunnel_nve_general_params_t    nve;    /* NVE General Params */
    sx_tunnel_ipinip_general_params_t ipinip; /* IPinIP General Params */
} sx_tunnel_general_params_t;

typedef union sx_tunnel_attribute_items {
    sx_tunnel_ipinip_p2p_attribute_t ipinip_p2p;     /* IPinIP P2P */
    sx_tunnel_ipinip_p2p_attribute_t ipinip_p2p_gre; /* IPinIP P2P GRE */
    sx_tunnel_nve_attribute_t        vxlan;          /* VxLan / VxLan v6*/
    sx_tunnel_nve_attribute_t        vxlan_gpe;      /* VxLan-GPE */
    sx_tunnel_nve_attribute_t        geneve;         /* Geneve */
    sx_tunnel_nve_attribute_t        nvgre;          /* nvgre */
} sx_tunnel_attribute_items_t;

/**
 * Tunnel attributes
 */
typedef struct sx_tunnel_attribute {
    sx_tunnel_type_e                type;                  /**< Tunnel Type */
    sx_tunnel_direction_e           direction;             /**< Tunnel Direction */
    union sx_tunnel_attribute_items attributes;
} sx_tunnel_attribute_t;

/**
 * Tunnel TTL data
 */
typedef enum {
    SX_TUNNEL_TTL_CMD_SET_E = 1,
    SX_TUNNEL_TTL_CMD_COPY_E = 2,
    SX_TUNNEL_TTL_CMD_MIN = SX_TUNNEL_TTL_CMD_SET_E,
    SX_TUNNEL_TTL_CMD_MAX = SX_TUNNEL_TTL_CMD_COPY_E,
} sx_tunnel_ttl_cmd_e;

typedef struct sx_tunnel_ttl_data {
    sx_tunnel_direction_e direction;
    sx_tunnel_ttl_cmd_e   ttl_cmd;
    uint8_t               ttl_value;   /* valid only when cmd is SX_TUNNEL_TTL_CMD_SET_E */
} sx_tunnel_ttl_data_t;

/**
 * Tunnel HASH data
 */
typedef enum {
    SX_TUNNEL_HASH_FIELD_TYPE_UDP_SPORT_E = 1,  /* applicable only for NVE tunnel */
    SX_TUNNEL_HASH_FIELD_TYPE_IPV6_FLOW_LABEL_E = 2, /* applicable only for IPv6 tunnel */
    SX_TUNNEL_HASH_FIELD_TYPE_MIN = SX_TUNNEL_HASH_FIELD_TYPE_UDP_SPORT_E,
    SX_TUNNEL_HASH_FIELD_TYPE_MAX = SX_TUNNEL_HASH_FIELD_TYPE_IPV6_FLOW_LABEL_E,
} sx_tunnel_hash_field_type_e;

typedef enum {
    SX_TUNNEL_HASH_CMD_SET_ZERO_E = 1,
    SX_TUNNEL_HASH_CMD_CALCULATE_E = 2,
    SX_TUNNEL_HASH_CMD_MIN = SX_TUNNEL_HASH_CMD_SET_ZERO_E,
    SX_TUNNEL_HASH_CMD_MAX = SX_TUNNEL_HASH_CMD_CALCULATE_E,
} sx_tunnel_hash_cmd_e;

typedef struct sx_tunnel_hash_data {
    sx_tunnel_hash_field_type_e hash_field_type;
    sx_tunnel_hash_cmd_e        hash_cmd;
} sx_tunnel_hash_data_t;


/**
 * Tunnel CoS
 */
typedef boolean_t sx_tunnel_cos_prio_update_t;

typedef struct sx_tunnel_cos_ecn_decap_data {
    boolean_t            valid;          /**<TRUE entry is going to be updated, for get always TRUE */
    sx_cos_ecn_t         egress_ecn;     /**<Egress ECN value */
    boolean_t            trap_enable;    /**<TRUE trap is going to be updated */
    sx_trap_attributes_t trap_attr;      /**<SX_TRAP_PRIORITY_LOW or SX_TRAP_PRIORITY_HIGH */
} sx_tunnel_cos_ecn_decap_data_t;

typedef struct sx_tunnel_cos_ecn_encap_data {
    boolean_t    valid;                  /**<TRUE entry is going to be updated, for get always TRUE */
    sx_cos_ecn_t egress_ecn;             /**<Egress ECN value */
} sx_tunnel_cos_ecn_encap_data_t;

typedef struct sx_tunnel_cos_ecn_encap_params {
    sx_tunnel_cos_ecn_encap_data_t ecn_encap_map[COS_ECN_MAX_NUM + 1]; /**<[ecn value from incoming packet(overlay)]*/
} sx_tunnel_cos_ecn_encap_params_t;

typedef struct sx_tunnel_cos_ecn_decap_params {
    sx_tunnel_cos_ecn_decap_data_t ecn_decap_map[COS_ECN_MAX_NUM + 1][COS_ECN_MAX_NUM + 1];   /**<[overlay ecn][underlay ecn]*/
} sx_tunnel_cos_ecn_decap_params_t;

typedef enum sx_tunnel_cos_param_type {
    SX_TUNNEL_COS_PARAM_TYPE_ENCAP_E = 0,
    SX_TUNNEL_COS_PARAM_TYPE_DECAP_E = 1,
    SX_TUNNEL_COS_PARAM_TYPE_MIN_E = SX_TUNNEL_COS_PARAM_TYPE_ENCAP_E,
    SX_TUNNEL_COS_PARAM_TYPE_MAX_E = SX_TUNNEL_COS_PARAM_TYPE_DECAP_E
} sx_tunnel_cos_param_type_e;

typedef union sx_tunnel_cos_data_ecn_params {
    sx_tunnel_cos_ecn_encap_params_t ecn_encap;        /**<ecn encap params*/
    sx_tunnel_cos_ecn_decap_params_t ecn_decap;        /**<ecn decap params*/
} sx_tunnel_cos_data_ecn_params_t;

/**
 * Tunnel CoS data
 */
typedef struct sx_tunnel_cos_data {
    sx_tunnel_cos_param_type_e          param_type; /**<ENCAP/DECAP*/
    sx_cos_priority_color_t             prio_color; /**<priority and color*/
    sx_tunnel_cos_prio_update_t         update_priority_color; /**<boolean for priority update*/
    sx_cos_dscp_rewrite_e               dscp_rewrite; /**<DSCP rewrite action*/
    sx_tunnel_cos_dscp_action_e         dscp_action; /**<DSCP action */
    uint32_t                            dscp_value; /**<DSCP set value*/
    union sx_tunnel_cos_data_ecn_params cos_ecn_params;
} sx_tunnel_cos_data_t;

/**
 * Tunnel Iterator
 */
typedef enum sx_tunnel_key_filter_field_valid {
    SX_TUNNEL_KEY_FILTER_FIELD_NOT_VALID = 0,
    SX_TUNNEL_KEY_FILTER_FIELD_VALID = 1,
    SX_TUNNEL_KEY_FILTER_FIELD_MAX = SX_TUNNEL_KEY_FILTER_FIELD_VALID
} sx_tunnel_key_filter_field_valid_t;

typedef struct sx_tunnel_filter {
    sx_tunnel_key_filter_field_valid_t filter_by_type;
    sx_tunnel_type_e                   type;
    sx_tunnel_key_filter_field_valid_t filter_by_direction;
    sx_tunnel_direction_e              direction;
} sx_tunnel_filter_t;

#endif /* __SX_TUNNEL_H__ */
