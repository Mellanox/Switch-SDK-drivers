/*
 * Copyright (C) 2010-2021 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 * LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 * FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 * See the Apache Version 2.0 License for specific language governing
 * permissions and limitations under the License.
 *
 */


#ifndef SX_COS_H_
#define SX_COS_H_

#include "sx/sdk/auto_headers/sx_cos_auto.h"

/************************************************
 *  Type definitions
 ***********************************************/

/**
 * SX_COS_PORT_PRIO_MIN define minimum port priority
 */
#define SX_COS_PORT_PRIO_MIN SXD_COS_PORT_PRIO_MIN

/**
 * SX_COS_PORT_TRUST_LEVEL_MIN define minimum port trust level
 */
#define SX_COS_PORT_TRUST_LEVEL_MIN SXD_COS_PORT_TRUST_LEVEL_MIN

/**
 * SX_COS_PORT_TRUST_LEVEL_MAX define maximum port trust level
 */
#define SX_COS_PORT_TRUST_LEVEL_MAX SXD_COS_PORT_TRUST_LEVEL_MAX

/**
 * SX_COS_PORT_DSCP_MIN define minimum port DSCP
 */
#define SX_COS_PORT_DSCP_MIN SXD_COS_PORT_DSCP_MIN

/**
 * SX_COS_PORT_DSCP_MAX define maximum port DSCP
 */
#define SX_COS_PORT_DSCP_MAX SXD_COS_PORT_DSCP_MAX

/**
 * SX_COS_TCLASS_MIN define minimum traffic class
 */
#define SX_COS_TCLASS_MIN SXD_COS_TCLASS_MIN

/**
 * SX_COS_TCLASS_REQUIRED defines the required num of traffic class
 */
#define SX_COS_TCLASS_REQUIRED SXD_COS_TCLASS_MAX

/**
 * SX_COS_BW_ALLOCATION_MIN define minimum BW allocation number
 */
#define SX_COS_BW_ALLOCATION_MIN SXD_COS_BW_ALLOCATION_MIN

/**
 * SX_COS_BW_ALLOCATION_MAX define maximum BW allocation number
 */
#define SX_COS_BW_ALLOCATION_MAX SXD_COS_BW_ALLOCATION_MAX

/**
 * SX_COS_BW_VALUE_MIN define minimum BW (rate limiter) value number
 */
#define SX_COS_BW_VALUE_MIN SXD_COS_BW_VALUE_MIN

/**
 * SX_COS_BW_VALUE_MAX define maximum BW (rate limiter) value number
 */
#define SX_COS_BW_VALUE_MAX SXD_COS_BW_VALUE_MAX

/**
 * SX_COS_TRAFFIC_CLASS_MIN_MAX defines 'minimum,maximum' value
 */
#define SX_COS_TRAFFIC_CLASS_MIN_MAX SX_COS_TRAFFIC_CLASS_MIN, SX_COS_TRAFFIC_CLASS_MAX

/**
 * SX_COS_RECEIVE_QUEUE_MIN_MAX defines 'minimum,maximum' value
 */
#define SX_COS_RECEIVE_QUEUE_MIN_MAX SX_COS_RECEIVE_QUEUE_MIN, SX_COS_RECEIVE_QUEUE_MAX

#define SX_COS_POOL_ID_INVALID UINT32_MAX

#define SX_COS_PRIO_CHECK_RANGE(prio) SX_CHECK_MAX(prio, rm_resource_global.cos_port_prio_max)

#define SX_COS_COLOR_CHECK_RANGE(color) SX_CHECK_MAX(color, rm_resource_global.cos_port_color_max)

#define SX_COS_PCP_CHECK_RANGE(pcp) SX_CHECK_MAX(pcp, COS_PCP_MAX_NUM)

#define SX_COS_DEI_CHECK_RANGE(dei) SX_CHECK_MAX(dei, COS_DEI_MAX_NUM)

#define SX_COS_DSCP_CHECK_RANGE(dscp) SX_CHECK_MAX(dscp, COS_DSCP_MAX_NUM)

#define SX_COS_EXP_CHECK_RANGE(exp) SX_CHECK_MAX(exp, COS_EXP_MAX_NUM)

#define SX_COS_ECN_CHECK_RANGE(ecn) SX_CHECK_MAX(ecn, COS_ECN_MAX_NUM)

#define SX_COS_IEEE_PRIO_CHECK_RANGE(ieee) SX_CHECK_MAX(ieee, COS_IEEE_PRIO_MAX_NUM)

/*********/
/* ENUMS */
/*********/

/**********************************************
 *  DEFINITIONS
 ***********************************************/

/**
 * SX_COS_TRAFFIC_CLASS_CHECK_RANGE defines a traffic class check range macro
 */
#define SX_COS_TRAFFIC_CLASS_CHECK_RANGE(tc) SX_CHECK_MAX(tc, SX_COS_TRAFFIC_CLASS_MAX)

#define SX_SB_SNAPSHOT_TRIGGER_ENABLE_TYPE_CHECK_MAX(type) \
    (SX_CHECK_MAX(type, SX_SB_SNAPSHOT_TRIGGER_ENABLE_TYPE_NOT_ACL_MAX_E))

#define SX_SB_SNAPSHOT_ACTION_CHECK_MAX(action) \
    (SX_CHECK_MAX(action, SX_SB_SNAPSHOT_ACTION_FIELD_MAX_E))

#endif /* SX_COS_H_ */
