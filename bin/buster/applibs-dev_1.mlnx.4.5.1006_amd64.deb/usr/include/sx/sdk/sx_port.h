/*
 * Copyright (C) 2010-2021 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 * LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 * FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 * See the Apache Version 2.0 License for specific language governing
 * permissions and limitations under the License.
 *
 */


#ifndef __SX_PORT_H__
#define __SX_PORT_H__

#include "sx/sdk/auto_headers/sx_port_auto.h"


/************************************************
 *  Type definitions
 ***********************************************/

#define SX_PORT_MODULE_STATUS_MIN_MAX SX_PORT_MODULE_STATUS_MIN, SX_PORT_MODULE_STATUS_MAX
#define SX_PORT_MODULE_STATUS_CHECK_RANGE(status) \
    SX_CHECK_RANGE(SX_PORT_MODULE_STATUS_MIN,     \
                   (int)status,                   \
                   SX_PORT_MODULE_STATUS_MAX)

#define SX_PORT_ADMIN_STATUS_MIN_MAX SX_PORT_ADMIN_STATUS_MIN, SX_PORT_ADMIN_STATUS_MAX
#define SX_PORT_ADMIN_STATUS_CHECK_RANGE(status) \
    SX_CHECK_RANGE(SX_PORT_ADMIN_STATUS_MIN,     \
                   (int)status,                  \
                   SX_PORT_ADMIN_STATUS_MAX)

#define SX_PORT_OPER_STATUS_MIN_MAX SX_PORT_OPER_STATUS_MIN, SX_PORT_OPER_STATUS_MAX
#define SX_PORT_OPER_STATUS_CHECK_RANGE(status) \
    SX_CHECK_RANGE(SX_PORT_OPER_STATUS_MIN,     \
                   (int)status,                 \
                   SX_PORT_OPER_STATUS_MAX)

#define IS_PORT_TYPE_NETWORK_OR_LAG(log_port)                   \
    ((SX_PORT_TYPE_ID_GET(log_port) == SX_PORT_TYPE_NETWORK) || \
     (SX_PORT_TYPE_ID_GET(log_port) == SX_PORT_TYPE_LAG))

#define SX_PORT_TYPE_MIN_MAX SX_PORT_TYPE_MIN, SX_PORT_TYPE_MAX
#define SX_PORT_TYPE_CHECK_RANGE(type) SX_CHECK_RANGE(SX_PORT_TYPE_MIN, (int)type, SX_PORT_TYPE_MAX)

#define SX_PORT_FEC_MODE_STR(val) \
    #val

#define SX_PORT_PHY_SPEED_CHECK_RANGE(speed) SX_CHECK_RANGE(SX_PORT_PHY_SPEED_MIN, (int)speed, SX_PORT_PHY_SPEED_MAX)

#define SX_PORT_MODE_CHECK_RANGE(mode) SX_CHECK_RANGE(SX_PORT_MODE_MIN, (int)mode, SX_PORT_MODE_MAX)

#define SX_PORT_MAPPING_MODE_MIN_MAX SX_PORT_MAPPING_MODE_MIN, SX_PORT_MAPPING_MODE_MAX
#define SX_PORT_MAPPING_MODE_CHECK_RANGE(mode) \
    SX_CHECK_RANGE(SX_PORT_MAPPING_MODE_MIN,   \
                   (int)mode,                  \
                   SX_PORT_MAPPING_MODE_MAX)

#define SX_PORT_PHYS_LOOPBACK_CHECK_RANGE(phys) \
    SX_CHECK_RANGE(SX_PORT_PHYS_LOOPBACK_MIN,   \
                   (int)phys,                   \
                   SX_PORT_PHYS_LOOPBACK_MAX)

#define SX_PORT_PHYS_LINK_SIDE_CHECK_RANGE(phys) \
    SX_CHECK_RANGE(SX_PORT_PHYS_LINK_SIDE_MIN,   \
                   (int)phys,                    \
                   SX_PORT_PHYS_LINK_SIDE_MAX)

#define SX_PORT_MTU_CHECK_RANGE(MTU) \
    SX_CHECK_RANGE(SX_PORT_MTU_MIN, MTU, SX_PORT_MTU_MAX)

#define SX_PORT_INFO_FIELD_BIT_MIN_MAX SX_PORT_INFO_FIELD_BIT_MIN, SX_PORT_INFO_FIELD_BIT_MAX
#define SX_PORT_INFO_FIELD_BIT_CHECK_RANGE(bit) \
    SX_CHECK_RANGE(SX_PORT_INFO_FIELD_BIT_MIN,  \
                   (uint64_t)bit,               \
                   SX_PORT_INFO_FIELD_BIT_MAX)

#define SX_PORT_SPEED_BIT_MIN_MAX SX_PORT_SPEED_BIT_MIN, SX_PORT_SPEED_BIT_MAX
#define SX_PORT_SPEED_BIT_CHECK_RANGE(bit) SX_CHECK_RANGE(SX_PORT_SPEED_BIT_MIN, (int)bit, SX_PORT_SPEED_BIT_MAX)

#define SX_PORT_PAUSE_POLICY_RX_MIN_MAX SX_PORT_PAUSE_POLICY_RX_MIN, SX_PORT_PAUSE_POLICY_RX_MAX
#define SX_PORT_PAUSE_POLICY_RX_CHECK_RANGE(mode) \
    SX_CHECK_RANGE(SX_PORT_PAUSE_POLICY_RX_MIN,   \
                   (int)mode,                     \
                   SX_PORT_PAUSE_POLICY_RX_MAX)

#define SX_PORT_PAUSE_POLICY_TX_MIN_MAX SX_PORT_PAUSE_POLICY_TX_MIN, SX_PORT_PAUSE_POLICY_TX_MAX
#define SX_PORT_PAUSE_POLICY_TX_CHECK_RANGE(mode) \
    SX_CHECK_RANGE(SX_PORT_PAUSE_POLICY_TX_MIN,   \
                   (int)mode,                     \
                   SX_PORT_PAUSE_POLICY_TX_MAX)

#define SX_PORT_FLOW_CTRL_MODE_MIN_MAX SX_PORT_FLOW_CTRL_MODE_MIN, SX_PORT_FLOW_CTRL_MODE_MAX
#define SX_PORT_FLOW_CTRL_MODE_CHECK_RANGE(mode) \
    SX_CHECK_RANGE(SX_PORT_FLOW_CTRL_MODE_MIN,   \
                   (int)mode,                    \
                   SX_PORT_FLOW_CTRL_MODE_MAX)

#define SX_PORT_FLOW_CTRL_PRIO_MIN_MAX SX_PORT_FLOW_CTRL_PRIO_MIN, SX_PORT_FLOW_CTRL_PRIO_MAX
#define SX_PORT_FLOW_CTRL_PRIO_CHECK_RANGE(prio) \
    SX_CHECK_RANGE(SX_PORT_FLOW_CTRL_PRIO_MIN,   \
                   (int)prio,                    \
                   SX_PORT_FLOW_CTRL_PRIO_MAX)

#define SX_PORT_LOOPBACK_FILTER_MODE_CHECK_RANGE(LOOPBACK_FILTER_MODE) \
    SX_CHECK_RANGE(SX_LOOPBACK_FILTER_MODE_MIN,                        \
                   LOOPBACK_FILTER_MODE,                               \
                   SX_LOOPBACK_FILTER_MODE_MAX)

#define SX_PORT_PACKET_TYPE_MIN_MAX SX_PORT_PACKET_TYPE_MIN, SX_PORT_PACKET_TYPE_MAX
#define SX_PORT_PACKET_TYPE_CHECK_RANGE(type) \
    SX_CHECK_RANGE(SX_PORT_PACKET_TYPE_MIN,   \
                   (int)type,                 \
                   SX_PORT_PACKET_TYPE_MAX)

/*********************************************************************************************************************/

#define SX_PORT_CNTR_GRP_MIN_MAX SX_PORT_CNTR_GRP_MIN, SX_PORT_CNTR_GRP_MAX
#define SX_PORT_CNTR_GRP_CHECK_RANGE(mode) SX_CHECK_RANGE(SX_PORT_CNTR_GRP_MIN, (int)mode, SX_PORT_CNTR_GRP_MAX)

#define SX_PORT_PRIO_ID_MIN_MAX SX_PORT_PRIO_ID_MIN, SX_PORT_PRIO_ID_MAX
#define SX_PORT_PRIO_ID_CHECK_RANGE(mode) SX_CHECK_RANGE(SX_PORT_PRIO_ID_MIN, (int)mode, SX_PORT_PRIO_ID_MAX)
#define SX_PORT_TC_ID_CHECK_RANGE(mode)   SX_CHECK_RANGE(SX_PORT_TC_ID_MIN, (int)mode, SX_PORT_TC_ID_MAX)

/*********************************************************************************************************************/

#define SX_PORT_CNTR_GRP_PHY_STATISTICS_SIZE (sizeof(sx_port_cntr_phy_layer_statistics_t) / sizeof(sx_port_cntr_t))
#define SX_PORT_CNTR_GRP_PHY_INTERNAL_LINK_SIZE       \
    (sizeof(sx_port_cntr_phy_layer_internal_link_t) / \
     sizeof(sx_port_cntr_t))
#define SX_PORT_CNTR_GRP_PHY_LAYER_SIZE         (sizeof(sx_port_cntr_phy_layer_t) / sizeof(sx_port_cntr_t))
#define SX_PORT_CNTR_GRP_IEEE_802_DOT_3_SIZE    (sizeof(sx_port_cntr_ieee_802_dot_3_t) / sizeof(sx_port_cntr_t))
#define SX_PORT_CNTR_GRP_RFC_2863_SIZE          (sizeof(sx_port_cntr_rfc_2863_t) / sizeof(sx_port_cntr_t))
#define SX_PORT_CNTR_GRP_RFC_2819_SIZE          (sizeof(sx_port_cntr_rfc_2819_t) / sizeof(sx_port_cntr_t))
#define SX_PORT_CNTR_GRP_RFC_3635_SIZE          (sizeof(sx_port_cntr_rfc_3635_t) / sizeof(sx_port_cntr_t))
#define SX_PORT_CNTR_GRP_DISCARD_SIZE           (sizeof(sx_port_cntr_discard_t) / sizeof(sx_port_cntr_t))
#define SX_PORT_CNTR_GRP_CLI_SIZE               (sizeof(sx_port_cntr_cli_t) / sizeof(sx_port_cntr_t))
#define SX_PORT_CNTR_GRP_PER_PRIO_SIZE          (sizeof(sx_port_cntr_prio_t) / sizeof(sx_port_cntr_t))
#define SX_PORT_CNTR_GRP_PER_TC_CONGESTION_SIZE (sizeof(sx_port_cntr_tc_congestion_t) / sizeof(sx_port_cntr_t))
#define SX_PORT_CNTR_GRP_PERF_SIZE              (sizeof(sx_port_cntr_perf_t) / sizeof(sx_port_cntr_t))

/*********************************************************************************************************************/

#define SX_MAP_BITMAP_MIN_MAX SX_MAP_BITMAP_MIN, SX_MAP_BITMAP_MAX
#define SX_MAP_BITMAP_CHECK_RANGE(mode) SX_CHECK_RANGE(SX_MAP_BITMAP_MIN, (int)mode, SX_MAP_BITMAP_MAX)

/*********************************************************************************************************************/

#define SX_PORT_SFLOW_SAMPLING_RATE_VALIDATE(rate) \
    (((rate >= SX_PORT_SFLOW_SAMPLING_RATE_MIN) && \
      (rate <= SX_PORT_SFLOW_SAMPLING_RATE_MAX)) ? TRUE : FALSE)

#define SX_PORT_PACKET_STORING_MODE_CHECK_RANGE(mode) \
    SX_CHECK_RANGE(SX_PORT_PACKET_STORING_MODE_MIN,   \
                   (int)mode,                         \
                   SX_PORT_PACKET_STORING_MODE_MAX)

#define SX_PORT_PHY_BER_MAGNITUDE_GET(value) ((value) & 0xFF)
#define SX_PORT_PHY_BER_COEF_GET(value)      ((value >> 8) & 0xF)

#define SX_PORT_BAD_CRC_INGRESS_MODE_CHECK_RANGE(mode) \
    SX_CHECK_RANGE(SX_PORT_BAD_CRC_INGRESS_MODE_MIN,   \
                   (int)mode,                          \
                   SX_PORT_BAD_CRC_INGRESS_MODE_MAX)

#define SX_PORT_CRC_EGRESS_RECALC_MODE_CHECK_RANGE(mode) \
    SX_CHECK_RANGE(SX_PORT_CRC_EGRESS_RECALC_MODE_MIN,   \
                   (int)mode,                            \
                   SX_PORT_CRC_EGRESS_RECALC_MODE_MAX)


#endif /* __SX_PORT_H__ */
