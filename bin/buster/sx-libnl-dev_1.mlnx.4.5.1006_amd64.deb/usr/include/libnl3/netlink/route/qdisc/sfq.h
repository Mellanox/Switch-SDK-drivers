/*
 * Copyright (C) Mellanox Technologies, Ltd. 2003-2018 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef NETLINK_SFQ_H_
#define NETLINK_SFQ_H_

#include <netlink/netlink.h>
#include <netlink/route/qdisc.h>

#ifdef __cplusplus
extern "C" {
#endif

extern void	rtnl_sfq_set_quantum(struct rtnl_qdisc *, int);
extern int	rtnl_sfq_get_quantum(struct rtnl_qdisc *);

extern void	rtnl_sfq_set_limit(struct rtnl_qdisc *, int);
extern int	rtnl_sfq_get_limit(struct rtnl_qdisc *);

extern void	rtnl_sfq_set_perturb(struct rtnl_qdisc *, int);
extern int	rtnl_sfq_get_perturb(struct rtnl_qdisc *);

extern int	rtnl_sfq_get_divisor(struct rtnl_qdisc *);

#ifdef __cplusplus
}
#endif

#endif
