/*
 * Copyright (C) Mellanox Technologies, Ltd. 2003-2018 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef NETLINK_HTB_H_
#define NETLINK_HTB_H_

#include <netlink/netlink.h>
#include <netlink/route/tc.h>
#include <netlink/route/qdisc.h>
#include <netlink/route/class.h>

#ifdef __cplusplus
extern "C" {
#endif

extern uint32_t	rtnl_htb_get_rate2quantum(struct rtnl_qdisc *);
extern int	rtnl_htb_set_rate2quantum(struct rtnl_qdisc *, uint32_t);
extern uint32_t	rtnl_htb_get_defcls(struct rtnl_qdisc *);
extern int	rtnl_htb_set_defcls(struct rtnl_qdisc *, uint32_t);

extern uint32_t	rtnl_htb_get_prio(struct rtnl_class *);
extern int	rtnl_htb_set_prio(struct rtnl_class *, uint32_t);
extern uint32_t	rtnl_htb_get_rate(struct rtnl_class *);
extern int	rtnl_htb_set_rate(struct rtnl_class *, uint32_t);
extern uint32_t	rtnl_htb_get_ceil(struct rtnl_class *);
extern int	rtnl_htb_set_ceil(struct rtnl_class *, uint32_t);
extern uint32_t	rtnl_htb_get_rbuffer(struct rtnl_class *);
extern int	rtnl_htb_set_rbuffer(struct rtnl_class *, uint32_t);
extern uint32_t	rtnl_htb_get_cbuffer(struct rtnl_class *);
extern int	rtnl_htb_set_cbuffer(struct rtnl_class *, uint32_t);
extern uint32_t	rtnl_htb_get_quantum(struct rtnl_class *);
extern int	rtnl_htb_set_quantum(struct rtnl_class *, uint32_t);
extern int	rtnl_htb_get_level(struct rtnl_class *);

#ifdef __cplusplus
}
#endif

#endif
