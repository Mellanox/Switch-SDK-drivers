/*
 * Copyright (C) Mellanox Technologies, Ltd. 2003-2018 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef NETLINK_FW_H_
#define NETLINK_FW_H_

#include <netlink/netlink.h>
#include <netlink/route/classifier.h>

#ifdef __cplusplus
extern "C" {
#endif

extern int	rtnl_fw_set_classid(struct rtnl_cls *, uint32_t);
extern int	rtnl_fw_set_mask(struct rtnl_cls *, uint32_t);

#ifdef __cplusplus
}
#endif

#endif
