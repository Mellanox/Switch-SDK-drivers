/*
 * Copyright (C) Mellanox Technologies, Ltd. 2009-2018 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef NETLINK_CLS_CGROUP_H_
#define NETLINK_CLS_CGROUP_H_

#include <netlink/netlink.h>
#include <netlink/cache.h>
#include <netlink/route/classifier.h>
#include <netlink/route/cls/ematch.h>

#ifdef __cplusplus
extern "C" {
#endif

extern void			rtnl_cgroup_set_ematch(struct rtnl_cls *,
						struct rtnl_ematch_tree *);
struct rtnl_ematch_tree *	rtnl_cgroup_get_ematch(struct rtnl_cls *);

#ifdef __cplusplus
}
#endif

#endif
