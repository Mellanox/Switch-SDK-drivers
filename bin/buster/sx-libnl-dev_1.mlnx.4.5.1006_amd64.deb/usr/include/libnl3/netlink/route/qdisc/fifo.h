/*
 * Copyright (C) Mellanox Technologies, Ltd. 2003-2018 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef NETLINK_FIFO_H_
#define NETLINK_FIFO_H_

#include <netlink/netlink.h>
#include <netlink/route/qdisc.h>

#ifdef __cplusplus
extern "C" {
#endif

extern int	rtnl_qdisc_fifo_set_limit(struct rtnl_qdisc *, int);
extern int	rtnl_qdisc_fifo_get_limit(struct rtnl_qdisc *);

#ifdef __cplusplus
}
#endif

#endif
