/*
 * Copyright (C) Mellanox Technologies, Ltd. 2013-2018 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef NETLINK_DUMMY_LINK_API_H_
#define NETLINK_DUMMY_LINK_API_H_

#include <netlink/netlink.h>
#include <netlink/route/link.h>

#warning "You are including a deprecated header file, include <netlink/route/link.h>."

#endif
