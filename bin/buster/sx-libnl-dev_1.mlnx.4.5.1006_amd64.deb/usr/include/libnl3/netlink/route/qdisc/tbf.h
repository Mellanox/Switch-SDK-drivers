/*
 * Copyright (C) Mellanox Technologies, Ltd. 2003-2018 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef NETLINK_TBF_H_
#define NETLINK_TBF_H_

#include <netlink/netlink.h>
#include <netlink/route/tc.h>
#include <netlink/route/qdisc.h>

#ifdef __cplusplus
extern "C" {
#endif

extern void rtnl_qdisc_tbf_set_limit(struct rtnl_qdisc *, int);
extern int rtnl_qdisc_tbf_set_limit_by_latency(struct rtnl_qdisc *, int);
extern int rtnl_qdisc_tbf_get_limit(struct rtnl_qdisc *);

extern void rtnl_qdisc_tbf_set_rate(struct rtnl_qdisc *, int, int, int);
extern int rtnl_qdisc_tbf_get_rate(struct rtnl_qdisc *);
extern int rtnl_qdisc_tbf_get_rate_bucket(struct rtnl_qdisc *);
extern int rtnl_qdisc_tbf_get_rate_cell(struct rtnl_qdisc *);

extern int rtnl_qdisc_tbf_set_peakrate(struct rtnl_qdisc *, int, int, int);
extern int rtnl_qdisc_tbf_get_peakrate(struct rtnl_qdisc *);
extern int rtnl_qdisc_tbf_get_peakrate_bucket(struct rtnl_qdisc *);
extern int rtnl_qdisc_tbf_get_peakrate_cell(struct rtnl_qdisc *);

#ifdef __cplusplus
}
#endif

#endif
