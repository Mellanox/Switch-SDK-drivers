/*
 * Copyright (C) Mellanox Technologies, Ltd. 2013-2018 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef NETLINK_LINK_VETH_H_
#define NETLINK_LINK_VETH_H_

#include <netlink/netlink.h>
#include <netlink/route/link.h>
#include <sys/types.h>

#ifdef __cplusplus
extern "C" {
#endif

extern struct rtnl_link *rtnl_link_veth_alloc(void);
extern void rtnl_link_veth_release(struct rtnl_link *);

extern int rtnl_link_is_veth(struct rtnl_link *);

extern struct rtnl_link *rtnl_link_veth_get_peer(struct rtnl_link *);
extern int rtnl_link_veth_add(struct nl_sock *sock, const char *name,
			      const char *peer, pid_t pid);

#ifdef __cplusplus
}
#endif

#endif
