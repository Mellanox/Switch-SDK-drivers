/*
 * Copyright (C) Mellanox Technologies, Ltd. 2003-2018 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef NETLINK_CLASS_H_
#define NETLINK_CLASS_H_

#include <netlink/netlink.h>
#include <netlink/route/tc.h>
#include <netlink/route/qdisc.h>

#ifdef __cplusplus
extern "C" {
#endif

struct rtnl_class;

extern struct rtnl_class *
			rtnl_class_alloc(void);
extern void		rtnl_class_put(struct rtnl_class *);

extern int		rtnl_class_alloc_cache(struct nl_sock *, int,
					       struct nl_cache **);
extern struct rtnl_class *
			rtnl_class_get(struct nl_cache *, uint32_t, uint32_t);

extern struct rtnl_qdisc *
			rtnl_class_leaf_qdisc(struct rtnl_class *,
						      struct nl_cache *);

extern int		rtnl_class_build_add_request(struct rtnl_class *, int,
						     struct nl_msg **);
extern int		rtnl_class_add(struct nl_sock *, struct rtnl_class *,
				       int);

extern int		rtnl_class_build_delete_request(struct rtnl_class *,
							struct nl_msg **);
extern int		rtnl_class_delete(struct nl_sock *,
					  struct rtnl_class *);

/* deprecated functions */
extern void		rtnl_class_foreach_child(struct rtnl_class *,
						 struct nl_cache *,
						 void (*cb)(struct nl_object *,
						 	    void *),
						 void *)
						 __attribute__((deprecated));
extern void		rtnl_class_foreach_cls(struct rtnl_class *,
					       struct nl_cache *,
					       void (*cb)(struct nl_object *,
							  void *),
					       void *)
					       __attribute__((deprecated));

#ifdef __cplusplus
}
#endif

#endif
