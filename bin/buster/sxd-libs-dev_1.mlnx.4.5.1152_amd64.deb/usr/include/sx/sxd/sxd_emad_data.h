/*
 * Copyright (C) 2010-2021 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_DATA_H__
#define __SXD_EMAD_DATA_H__

#include <sx/sxd/sxd_emad_cos_data.h>
#include <sx/sxd/sxd_emad_acl_data.h>
#include <sx/sxd/sxd_emad_fdb_data.h>
#include <sx/sxd/sxd_emad_flow_counter_data.h>
#include <sx/sxd/sxd_emad_host_data.h>
#include <sx/sxd/sxd_emad_lag_data.h>
#include <sx/sxd/sxd_emad_mstp_data.h>
#include <sx/sxd/sxd_emad_policer_data.h>
#include <sx/sxd/sxd_emad_port_data.h>
#include <sx/sxd/sxd_emad_mpls_data.h>
#include <sx/sxd/sxd_emad_router_data.h>
#include <sx/sxd/sxd_emad_shspm_data.h>
#include <sx/sxd/sxd_emad_system_data.h>
#include <sx/sxd/sxd_emad_vlan_data.h>
#include <sx/sxd/sxd_emad_span_data.h>
#include <sx/sxd/sxd_emad_redecn_data.h>
#include <sx/sxd/sxd_emad_tunnel_data.h>
#include <sx/sxd/sxd_emad_rm_data.h>
#include <sx/sxd/auto_registers/sxd_emad_auto_data.h>


/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

typedef struct sxd_emad_dummy_data {
    sxd_emad_common_data_t common;
} sxd_emad_dummy_data_t;

/**
 * sxd_emad_data_t union is used to store SwitchX emad data
 */
typedef union sxd_emad_data {
    sxd_emad_mfba_data_t    mfba;
    sxd_emad_mfbe_data_t    mfbe;
    sxd_emad_mfpa_data_t    mfpa;
    sxd_emad_sgcr_data_t    sgcr;
    sxd_emad_scar_data_t    scar;
    sxd_emad_sspr_data_t    sspr;
    sxd_emad_sfdat_data_t   sfdat;
    sxd_emad_sfd_data_t     sfd;
    sxd_emad_sfn_data_t     sfn;
    sxd_emad_spgt_data_t    spgt;
    sxd_emad_smid_data_t    smid;
    sxd_emad_spms_data_t    spms;
    sxd_emad_spvid_data_t   spvid;
    sxd_emad_sver_data_t    sver;
    sxd_emad_spvc_data_t    spvc;
    sxd_emad_spvm_data_t    spvm;
    sxd_emad_spvtr_data_t   spvtr;
    sxd_emad_spaft_data_t   spaft;
    sxd_emad_sftr_data_t    sftr;
    sxd_emad_svpe_data_t    svpe;
    sxd_emad_sfdf_data_t    sfdf;
    sxd_emad_sfdt_data_t    sfdt;
    sxd_emad_sldr_data_t    sldr;
    sxd_emad_slcr_data_t    slcr;
    sxd_emad_slcor_data_t   slcor;
    sxd_emad_slecr_data_t   slecr;
    sxd_emad_spmlr_data_t   spmlr;
    sxd_emad_spfsr_data_t   spfsr;
    sxd_emad_svmlr_data_t   svmlr;
    sxd_emad_spvmlr_data_t  spvmlr;
    sxd_emad_qcap_data_t    qcap;
    sxd_emad_qpts_data_t    qpts;
    sxd_emad_qpcr_data_t    qpcr;
    sxd_emad_qpbr_data_t    qpbr;
    sxd_emad_qpdp_data_t    qpdp;
    sxd_emad_qprt_data_t    qprt;
    sxd_emad_qsptc_data_t   qsptc;
    sxd_emad_qtct_data_t    qtct;
    sxd_emad_qstct_data_t   qstct;
    sxd_emad_spmcr_data_t   spmcr;
    sxd_emad_spad_data_t    spad;
    sxd_emad_mjtag_data_t   mjtag;
    sxd_emad_pcap_data_t    pcap;
    sxd_emad_pmlp_data_t    pmlp;
    sxd_emad_pmcr_data_t    pmcr;
    sxd_emad_pfsc_data_t    pfsc;
    sxd_emad_pplr_data_t    pplr;
    sxd_emad_pmpr_data_t    pmpr;
    sxd_emad_ptys_data_t    ptys;
    sxd_emad_pmtps_data_t   pmtps;
    sxd_emad_ppsc_data_t    ppsc;
    sxd_emad_plpc_data_t    plpc;
    sxd_emad_pplm_data_t    pplm;
    sxd_emad_pfcc_data_t    pfcc;
    sxd_emad_pelc_data_t    pelc;
    sxd_emad_pude_data_t    pude;
    sxd_emad_pmpe_data_t    pmpe;
    sxd_emad_plib_data_t    plib;
    sxd_emad_pptb_data_t    pptb;
    sxd_emad_pbmc_data_t    pbmc;
    sxd_emad_pmpc_data_t    pmpc;
    sxd_emad_pspa_data_t    pspa;
    sxd_emad_rcap_data_t    rcap;
    sxd_emad_rgcr_data_t    rgcr;
    sxd_emad_ritr_data_t    ritr;
    sxd_emad_rigr_data_t    rigr;
    sxd_emad_rigr_v2_data_t rigr_v2;
    sxd_emad_rtar_data_t    rtar;
    sxd_emad_recr_data_t    recr;
    sxd_emad_recr_v2_data_t recr_v2;
    sxd_emad_ruft_data_t    ruft;
    sxd_emad_ruht_data_t    ruht;
    sxd_emad_rauht_data_t   rauht;
    sxd_emad_rauhtd_data_t  rauhtd;
    sxd_emad_rmft_data_t    rmft;
    sxd_emad_rmft_v2_data_t rmft_v2;
    sxd_emad_rmftad_data_t  rmftad;
    sxd_emad_ptcead_data_t  ptcead;
    sxd_emad_ratr_data_t    ratr;
    sxd_emad_ratrad_data_t  ratrad;
    sxd_emad_rdpm_data_t    rdpm;
    sxd_emad_rrcr_data_t    rrcr;
    sxd_emad_rica_data_t    rica;
    sxd_emad_ricnt_data_t   ricnt;
    sxd_emad_rtca_data_t    rtca;
    sxd_emad_rtps_data_t    rtps;
    sxd_emad_ralta_data_t   ralta;
    sxd_emad_ralst_data_t   ralst;
    sxd_emad_raltb_data_t   raltb;
    sxd_emad_ralue_data_t   ralue;
    sxd_emad_raleu_data_t   raleu;
    sxd_emad_ralbu_data_t   ralbu;
    sxd_emad_rmeir_data_t   rmeir;
    sxd_emad_rmid_data_t    rmid;
    sxd_emad_rmpu_data_t    rmpu;
    sxd_emad_hcap_data_t    hcap;
    sxd_emad_hdrt_data_t    hdrt;
    sxd_emad_hctr_data_t    hctr;
    sxd_emad_htgt_data_t    htgt;
    sxd_emad_hpkt_data_t    hpkt;
    sxd_emad_hespr_data_t   hespr;
    sxd_emad_ptar_data_t    ptar;
    sxd_emad_pacl_data_t    pacl;
    sxd_emad_pifr_data_t    pifr;
    sxd_emad_ptce_data_t    ptce;
    sxd_emad_ptce2_data_t   ptce2;
    sxd_emad_prbt_data_t    prbt;
    sxd_emad_pefa_data_t    pefa;
    sxd_emad_pecb_data_t    pecb;
    sxd_emad_pemb_data_t    pemb;
    sxd_emad_prcr_data_t    prcr;
    sxd_emad_pfca_data_t    pfca;
    sxd_emad_pfcnt_data_t   pfcnt;
    sxd_emad_ppbt_data_t    ppbt;
    sxd_emad_pvbt_data_t    pvbt;
    sxd_emad_pagt_data_t    pagt;
    sxd_emad_pprr_data_t    pprr;
    sxd_emad_pvgt_data_t    pvgt;
    sxd_emad_mpat_data_t    mpat;
    sxd_emad_sbib_data_t    sbib;
    sxd_emad_mpar_data_t    mpar;
    sxd_emad_msci_data_t    msci;
    sxd_emad_mtbr_data_t    mtbr;
    sxd_emad_plbf_data_t    plbf;
    sxd_emad_pgcr_data_t    pgcr;
    sxd_emad_puet_data_t    puet;
    sxd_emad_mrsr_data_t    mrsr;
    sxd_emad_sbpr_data_t    sbpr;
    sxd_emad_sbsr_data_t    sbsr;
    sxd_emad_sbcm_data_t    sbcm;
    sxd_emad_sbpm_data_t    sbpm;
    sxd_emad_sbmm_data_t    sbmm;
    sxd_emad_qpdpm_data_t   qpdpm;
    sxd_emad_qepm_data_t    qepm;
    sxd_emad_qpdpc_data_t   qpdpc;
    sxd_emad_qtctm_data_t   qtctm;
    sxd_emad_qspip_data_t   qspip;
    sxd_emad_qspcp_data_t   qspcp;
    sxd_emad_qrwe_data_t    qrwe;
    sxd_emad_qpem_data_t    qpem;
    sxd_emad_qpdsm_data_t   qpdsm;
    sxd_emad_qppm_data_t    qppm;
    sxd_emad_cwgcr_data_t   cwgcr;
    sxd_emad_cwtp_data_t    cwtp;
    sxd_emad_cwtpm_data_t   cwtpm;
    sxd_emad_cwpp_data_t    cwpp;
    sxd_emad_cwppm_data_t   cwppm;
    sxd_emad_cpqe_data_t    cpqe;
    sxd_emad_mgpc_data_t    mgpc;
    sxd_emad_mpsc_data_t    mpsc;
    sxd_emad_mlcr_data_t    mlcr;
    sxd_emad_mpgcr_data_t   mpgcr;
    sxd_emad_mpilm_data_t   mpilm;
    sxd_emad_mpnhlfe_data_t mpnhlfe;
    sxd_emad_mdri_data_t    mdri;
    sxd_emad_iddd_data_t    iddd;
    sxd_emad_sbctc_data_t   sbctc;
    sxd_emad_sbctr_data_t   sbctr;
    sxd_emad_ppbme_data_t   ppbme;
    sxd_emad_pbsr_data_t    pbsr;
    sxd_emad_ptce3_data_t   ptce3;
    sxd_emad_perpt_data_t   perpt;
    sxd_emad_perar_data_t   perar;
    sxd_emad_percr_data_t   percr;
    sxd_emad_peabfe_data_t  peabfe;
    sxd_emad_ibfmr_data_t   ibfmr;
    sxd_emad_mfde_data_t    mfde;
    sxd_emad_mocs_data_t    mocs;
    sxd_emad_mtewe_data_t   mtewe;
    sxd_emad_mtsde_data_t   mtsde;
    sxd_emad_pmlpe_data_t   pmlpe;
    sxd_emad_mddq_data_t    mddq;
    sxd_emad_sbsns_data_t   sbsns;
} sxd_emad_data_t;


/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

#endif /* __SXD_EMAD_DATA_H__ */
