/*
 * Copyright (C) 2010-2021 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 * LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 * FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 * See the Apache Version 2.0 License for specific language governing
 * permissions and limitations under the License.
 *
 */


#ifndef __SX_ROUTER_H__
#define __SX_ROUTER_H__

#include <sx/sxd/sxd_router.h>

#include <sx/sdk/sx_ar.h>
#include <sx/sdk/sx_mac.h>
#include <sx/sdk/sx_ip.h>
#include <sx/sdk/sx_port.h>
#include <sx/sdk/sx_vlan.h>
#include <sx/sdk/sx_swid.h>
#include <sx/sdk/sx_status.h>
#include <sx/sdk/sx_init.h>
#include <sx/sdk/sx_trap_id.h>
#include <sx/sdk/sx_bridge.h>
#include <sx/sdk/sx_flow_counter.h>
#include <sx/sdk/sx_next_hop.h>
#include <resource_manager/resource_manager.h>

#include "sx/sdk/auto_headers/sx_router_auto.h"


/************************************************
 *  Type definitions
 ***********************************************/

#define SX_ROUTER_ECMP_ID_CHECK_RANGE(ECMP_ID) \
    ((ECMP_ID) != SX_ROUTER_ECMP_ID_INVALID)

#define SX_MC_CONTAINER_ID_CHECK_RANGE(MC_ID) \
    ((MC_ID) != SX_MC_CONTAINER_ID_INVALID)

#define SX_L2_INTERFACE_TYPE_CHECK_RANGE(L2_INTERFACE_TYPE) \
    SX_CHECK_RANGE(SX_L2_INTERFACE_TYPE_MIN,                \
                   L2_INTERFACE_TYPE,                       \
                   SX_L2_INTERFACE_TYPE_MAX)                \

#define SX_ROUTER_QOS_MODE_CHECK_RANGE(QOS_MODE) \
    SX_CHECK_MAX(QOS_MODE,                       \
                 SX_ROUTER_QOS_MODE_MAX)         \

#define SX_ROUTER_ENABLE_STATE_CHECK_RANGE(STATE) \
    SX_CHECK_MAX(STATE,                           \
                 SX_ROUTER_ENABLE_STATE_MAX)      \

#define SX_UC_ROUTE_TYPE_CHECK_RANGE(UC_ROUTE_TYPE) \
    SX_CHECK_MAX(UC_ROUTE_TYPE, SX_UC_ROUTE_TYPE_MAX)

#define SX_UC_ROUTE_TYPE_INVALID (SX_UC_ROUTE_TYPE_MAX + 1)

#define SX_ROUTER_RPF_ACTION_CHECK_RANGE(ROUTER_RPF_ACTION) \
    SX_CHECK_MAX(ROUTER_RPF_ACTION, SX_ROUTER_RPF_ACTION_MAX)

#define SX_ROUTER_ASSERT_ACTION_CHECK_RANGE(ROUTER_ASSERT_ACTION) \
    SX_CHECK_MAX(ROUTER_ASSERT_ACTION, SX_ROUTER_ASSERT_ACTION_MAX)

#define SX_ROUTER_ECMP_HASH_TYPE_SWITCHX_CHECK_RANGE(ECMP_HASH_TYPE) \
    SX_CHECK_MAX(ECMP_HASH_TYPE, SX_ROUTER_ECMP_HASH_TYPE_XOR)
#define SX_ROUTER_ECMP_HASH_TYPE_SPECTRUM_CHECK_RANGE(ECMP_HASH_TYPE) \
    SX_CHECK_MAX(ECMP_HASH_TYPE, SX_ROUTER_ECMP_HASH_TYPE_MAX)

#define SX_ROUTER_COUNTER_TYPE_CHECK_RANGE(type) \
    (SX_CHECK_MAX(type, SX_ROUTER_COUNTER_TYPE_MAX))


#define SX_ROUTER_COUNTER_SET_SIZE (sizeof(sx_router_counter_set_t) / sizeof(uint64_t))
#define SX_ROUTER_CNTR_SET_STR_LEN (sizeof(sx_router_cntr_set_str) / sizeof(char*))

static __attribute__((__used__)) const char* sx_router_cntr_set_str[SX_ROUTER_COUNTER_SET_SIZE] = {
    "router_ingress_good_unicast_packets",
    "router_ingress_good_multicast_packets",
    "router_ingress_good_unicast_bytes",
    "router_ingress_good_multicast_bytes",
    "router_egress_good_unicast_packets",
    "router_egress_good_multicast_packets",
    "router_egress_good_unicast_bytes",
    "router_egress_good_multicast_bytes",
    "router_ingress_good_broadcast_packets",
    "router_ingress_discard_packets",
    "router_ingress_good_broadcast_bytes",
    "router_ingress_discard_bytes",
    "router_egress_good_broadcast_packets",
    "router_egress_discard_packets",
    "router_egress_good_broadcast_bytes",
    "router_egress_discard_bytes",
};

#define SX_ROUTER_COUNTER_STR(index)                       \
    (SX_CHECK_MAX(index, SX_ROUTER_CNTR_SET_STR_LEN - 1) ? \
     sx_router_cntr_set_str[index] : "UNKNOWN")

#define SX_ROUTER_TTL_CMD_CHECK_RANGE(TTL_CMD) \
    (SX_CHECK_RANGE(SX_ROUTE_TTL_CMD_MIN, (TTL_CMD), SX_ROUTE_TTL_CMD_MAX))

#define SX_ROUTER_VINTERFACE_TYPE_CHECK_RANGE(ROUTER_VIF_TYPE) \
    SX_CHECK_MAX(ROUTER_VIF_TYPE, SX_ROUTER_VINTERFACE_TYPE_MAX)

#define SX_PRIO_TYPE_CHECK_RANGE(PRIO_TYPE) \
    (SX_CHECK_RANGE(SX_PRIO_TYPE_MIN, (PRIO_TYPE), SX_PRIO_TYPE_MAX))

#define SX_KEY_FILTER_VALID_CHECK_RANGE(VALID) SX_CHECK_MAX(VALID, SX_KEY_FILTER_FIELD_MAX)

#define SX_ECMP_TYPE_CHECK_RANGE(TYPE) \
    SX_CHECK_MAX(TYPE, SX_ECMP_TYPE_MAX)

#define SX_ECMP_CONTAINER_TYPE_CHECK_RANGE(TYPE) \
    SX_CHECK_MAX(TYPE, SX_ECMP_CONTAINER_TYPE_MAX)

#endif /* __SX_ROUTER_H__ */
