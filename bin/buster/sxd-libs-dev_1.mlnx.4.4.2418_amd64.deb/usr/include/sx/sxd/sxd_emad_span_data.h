/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2021 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_SPAN_DATA_H__
#define __SXD_EMAD_SPAN_DATA_H__

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_emad_common_data.h>


/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/**
 * sxd_emad_mpat_data_t structure is used to store MPAT register
 * data.
 */
typedef struct sxd_emad_mpat_data {
    sxd_emad_common_data_t common;
    struct ku_mpat_reg    *reg_data;
} sxd_emad_mpat_data_t;


/**
 * sxd_emad_mpar_data_t structure is used to store MPAR register
 * data.
 */
typedef struct sxd_emad_mpar_data {
    sxd_emad_common_data_t common;
    struct ku_mpar_reg    *reg_data;
} sxd_emad_mpar_data_t;

/**
 * sxd_emad_sbib_data_t structure is used to store SBIB register
 * data.
 */
typedef struct sxd_emad_sbib_data {
    sxd_emad_common_data_t common;
    struct ku_sbib_reg    *reg_data;
} sxd_emad_sbib_data_t;


#endif /* __SXD_EMAD_SPAN_DATA_H__ */
