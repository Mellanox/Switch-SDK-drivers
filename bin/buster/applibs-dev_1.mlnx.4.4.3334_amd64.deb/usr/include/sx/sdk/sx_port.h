/*
 * Copyright (C) 2010-2021 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 * LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 * FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 * See the Apache Version 2.0 License for specific language governing
 * permissions and limitations under the License.
 *
 */


#ifndef __SX_PORT_H__
#define __SX_PORT_H__

#include "sx/sdk/auto_headers/sx_port_auto.h"


/************************************************
 *  Type definitions
 ***********************************************/

#define SX_PORT_MODULE_STATUS_MIN_MAX SX_PORT_MODULE_STATUS_MIN, SX_PORT_MODULE_STATUS_MAX
#define SX_PORT_MODULE_STATUS_CHECK_RANGE(status) \
    SX_CHECK_RANGE(SX_PORT_MODULE_STATUS_MIN,     \
                   (int)status,                   \
                   SX_PORT_MODULE_STATUS_MAX)

#define SX_PORT_ADMIN_STATUS_MIN_MAX SX_PORT_ADMIN_STATUS_MIN, SX_PORT_ADMIN_STATUS_MAX
#define SX_PORT_ADMIN_STATUS_CHECK_RANGE(status) \
    SX_CHECK_RANGE(SX_PORT_ADMIN_STATUS_MIN,     \
                   (int)status,                  \
                   SX_PORT_ADMIN_STATUS_MAX)

#define SX_PORT_OPER_STATUS_MIN_MAX SX_PORT_OPER_STATUS_MIN, SX_PORT_OPER_STATUS_MAX
#define SX_PORT_OPER_STATUS_CHECK_RANGE(status) \
    SX_CHECK_RANGE(SX_PORT_OPER_STATUS_MIN,     \
                   (int)status,                 \
                   SX_PORT_OPER_STATUS_MAX)

#define IS_PORT_TYPE_NETWORK_OR_LAG(log_port)                   \
    ((SX_PORT_TYPE_ID_GET(log_port) == SX_PORT_TYPE_NETWORK) || \
     (SX_PORT_TYPE_ID_GET(log_port) == SX_PORT_TYPE_LAG))

#define SX_PORT_TYPE_MIN_MAX SX_PORT_TYPE_MIN, SX_PORT_TYPE_MAX
#define SX_PORT_TYPE_CHECK_RANGE(type) SX_CHECK_RANGE(SX_PORT_TYPE_MIN, (int)type, SX_PORT_TYPE_MAX)

#define SX_PORT_FEC_MODE_STR(val) \
    #val

#define SX_PORT_PHY_SPEED_CHECK_RANGE(speed) SX_CHECK_RANGE(SX_PORT_PHY_SPEED_MIN, (int)speed, SX_PORT_PHY_SPEED_MAX)

#define SX_PORT_MODE_CHECK_RANGE(mode) SX_CHECK_RANGE(SX_PORT_MODE_MIN, (int)mode, SX_PORT_MODE_MAX)

#define SX_PORT_MAPPING_MODE_MIN_MAX SX_PORT_MAPPING_MODE_MIN, SX_PORT_MAPPING_MODE_MAX
#define SX_PORT_MAPPING_MODE_CHECK_RANGE(mode) \
    SX_CHECK_RANGE(SX_PORT_MAPPING_MODE_MIN,   \
                   (int)mode,                  \
                   SX_PORT_MAPPING_MODE_MAX)

#define SX_PORT_PHYS_LOOPBACK_CHECK_RANGE(phys) \
    SX_CHECK_RANGE(SX_PORT_PHYS_LOOPBACK_MIN,   \
                   (int)phys,                   \
                   SX_PORT_PHYS_LOOPBACK_MAX)

#define SX_PORT_PHYS_LINK_SIDE_CHECK_RANGE(phys) \
    SX_CHECK_RANGE(SX_PORT_PHYS_LINK_SIDE_MIN,   \
                   (int)phys,                    \
                   SX_PORT_PHYS_LINK_SIDE_MAX)

#define SX_PORT_MTU_CHECK_RANGE(MTU) \
    SX_CHECK_RANGE(SX_PORT_MTU_MIN, MTU, SX_PORT_MTU_MAX)

#define SX_PORT_INFO_FIELD_BIT_MIN_MAX SX_PORT_INFO_FIELD_BIT_MIN, SX_PORT_INFO_FIELD_BIT_MAX
#define SX_PORT_INFO_FIELD_BIT_CHECK_RANGE(bit) \
    SX_CHECK_RANGE(SX_PORT_INFO_FIELD_BIT_MIN,  \
                   (uint64_t)bit,               \
                   SX_PORT_INFO_FIELD_BIT_MAX)

/**
 * \deprecated This definition is deprecated and will be removed in the future.
 */
static const char *sx_port_info_field_bit_str[] = {
    "NONE",
    "ID",
    "TYPE",
    "SWITCH ID",
    "DEVICE ID",
    "MAPPING",
    "STACKING MODE",
    "MTU",
    "TYPE SPEED",
    "MAC ADDR",
    "STATUS",
    "MULTI CHANNEL",
    "FLOW CONTROL CONFIGURATION",
    "OPER EVENT MODE",
    "MODULE EVENT MODE",
    "INGRESS FILTER MODE",
    "LAG MEMBER MODE",
    "MAC_LEARN_DISABLED_BY_USER",
    "MAC_LEARN_DISABLED_BY_LIMIT",
    "LOOPBACK_FILTER_MODE",
    "PVID",
    "ROUTER_MODE",
    "BUFF_CONF_MODE",
    "QCN_PROFILE_ID",
    "QCN_MODE",
    "QCN_ENABLE",
    "LAG_LOG_PORT",
    "FDB_PROTECT_MODE",
    "SPAN_MODE",
    "SHARED_BUFFERS",
    "UNTAGGED_PRIO_STATE",
    "SFLOW_PORT",
    "CONFIG_STATE",
    "EGRESS_MIRROR_SIZE",
    "HEADROOM_SIZE",
    "EGRESS_MIRROR_REF_COUNT",
    "FORWARDING_MODE",
    "BER PROFILE",
    "BER MONITOR CONFIG",
    "GC HANDLE",
    "API TYPE",
    "RIF_ID",
    "PHYS_LOOPBACK",
    "SPEED CAPABILITY",
};

/**
 * \deprecated This definition is deprecated and will be removed in the future.
 */
static const int sx_port_info_field_bit_str_len = sizeof(sx_port_info_field_bit_str) / sizeof(char*);

/**
 * \deprecated This API is deprecated and will be removed in the future.
 */
#define SX_PORT_INFO_FIELD_BIT_STR(bit) \
    (SX_CHECK_RANGE(0, ffsl(bit),       \
                    sx_port_info_field_bit_str_len - 1) ? sx_port_info_field_bit_str[ffsl(bit)] : "UNKNOWN")

#define SX_PORT_SPEED_BIT_MIN_MAX SX_PORT_SPEED_BIT_MIN, SX_PORT_SPEED_BIT_MAX
#define SX_PORT_SPEED_BIT_CHECK_RANGE(bit) SX_CHECK_RANGE(SX_PORT_SPEED_BIT_MIN, (int)bit, SX_PORT_SPEED_BIT_MAX)


/**
 * \deprecated This definition is deprecated and will be removed in the future.
 */
static const char *sx_port_speed_bit_str[] = {
    "NONE",
    "SGMII",
    "XAUI",
    "1GB KX",
    "10GB CX4",
    "10GB KX4",
    "10GB KR",
    "10GB KR FEC",
    "10GB KR2",
    "10GB KR2 FEC",
    "40GB KR4",
    "40GB KR4 FEC",
};

/**
 * \deprecated This definition is deprecated and will be removed in the future.
 */
static const int sx_port_speed_bit_str_len = sizeof(sx_port_speed_bit_str) / sizeof(char*);


/**
 * \deprecated This API is deprecated and will be removed in the future.
 */
#define SX_PORT_SPEED_BIT_STR(bit)    \
    (SX_CHECK_RANGE(0, ffs((int)bit), \
                    sx_port_speed_bit_str_len - 1) ? sx_port_speed_bit_str[ffs((int)bit)] : "UNKNOWN")

#define SX_PORT_PAUSE_POLICY_RX_MIN_MAX SX_PORT_PAUSE_POLICY_RX_MIN, SX_PORT_PAUSE_POLICY_RX_MAX
#define SX_PORT_PAUSE_POLICY_RX_CHECK_RANGE(mode) \
    SX_CHECK_RANGE(SX_PORT_PAUSE_POLICY_RX_MIN,   \
                   (int)mode,                     \
                   SX_PORT_PAUSE_POLICY_RX_MAX)

#define SX_PORT_PAUSE_POLICY_TX_MIN_MAX SX_PORT_PAUSE_POLICY_TX_MIN, SX_PORT_PAUSE_POLICY_TX_MAX
#define SX_PORT_PAUSE_POLICY_TX_CHECK_RANGE(mode) \
    SX_CHECK_RANGE(SX_PORT_PAUSE_POLICY_TX_MIN,   \
                   (int)mode,                     \
                   SX_PORT_PAUSE_POLICY_TX_MAX)

#define SX_PORT_FLOW_CTRL_MODE_MIN_MAX SX_PORT_FLOW_CTRL_MODE_MIN, SX_PORT_FLOW_CTRL_MODE_MAX
#define SX_PORT_FLOW_CTRL_MODE_CHECK_RANGE(mode) \
    SX_CHECK_RANGE(SX_PORT_FLOW_CTRL_MODE_MIN,   \
                   (int)mode,                    \
                   SX_PORT_FLOW_CTRL_MODE_MAX)

#define SX_PORT_FLOW_CTRL_PRIO_MIN_MAX SX_PORT_FLOW_CTRL_PRIO_MIN, SX_PORT_FLOW_CTRL_PRIO_MAX
#define SX_PORT_FLOW_CTRL_PRIO_CHECK_RANGE(prio) \
    SX_CHECK_RANGE(SX_PORT_FLOW_CTRL_PRIO_MIN,   \
                   (int)prio,                    \
                   SX_PORT_FLOW_CTRL_PRIO_MAX)

#define SX_PORT_LOOPBACK_FILTER_MODE_CHECK_RANGE(LOOPBACK_FILTER_MODE) \
    SX_CHECK_RANGE(SX_LOOPBACK_FILTER_MODE_MIN,                        \
                   LOOPBACK_FILTER_MODE,                               \
                   SX_LOOPBACK_FILTER_MODE_MAX)

#define SX_PORT_PACKET_TYPE_MIN_MAX SX_PORT_PACKET_TYPE_MIN, SX_PORT_PACKET_TYPE_MAX
#define SX_PORT_PACKET_TYPE_CHECK_RANGE(type) \
    SX_CHECK_RANGE(SX_PORT_PACKET_TYPE_MIN,   \
                   (int)type,                 \
                   SX_PORT_PACKET_TYPE_MAX)

/*********************************************************************************************************************/

#define SX_PORT_CNTR_GRP_MIN_MAX SX_PORT_CNTR_GRP_MIN, SX_PORT_CNTR_GRP_MAX
#define SX_PORT_CNTR_GRP_CHECK_RANGE(mode) SX_CHECK_RANGE(SX_PORT_CNTR_GRP_MIN, (int)mode, SX_PORT_CNTR_GRP_MAX)


/**
 * \deprecated This definition is deprecated and will be removed in the future.
 */
static const char *sx_port_cntr_grp_str[] = {
    "IEEE 802.3",
    "RFC 2863",
    "RFC 2819",
    "RFC 3635",
    "CLI",
    "EXTENDED",
    "DISCARD",
    "N/A",
    "N/A",
    "N/A",
    "N/A",
    "N/A",
    "N/A",
    "N/A",
    "N/A",
    "N/A",
#ifndef     __SX_PORT_CNTR_GRP_PER_PRIO__
    "PER PRIO",
    "PER TC",
    "N/A",
    "N/A",
    "N/A",
    "PER BUFF",
    "N/A",
    "N/A",
#else /*	__SX_PORT_CNTR_GRP_PER_PRIO__   */
    "PER PRIO 0",
    "PER PRIO 1",
    "PER PRIO 2",
    "PER PRIO 3",
    "PER PRIO 4",
    "PER PRIO 5",
    "PER PRIO 6",
    "PER PRIO 7",
#endif /*       __SX_PORT_CNTR_GRP_PER_PRIO__   */
    "N/A",
    "N/A",
    "N/A",
    "N/A",
    "N/A",
    "N/A",
    "N/A",
    "N/A",
    "N/A",
    "PER TC 0",
    "PER TC 1",
    "PER TC 2",
    "PER TC 3",
    "PER TC 4",
    "PER TC 5",
    "PER TC 6",
    "PER TC 7",
    "PER PRIO 0",
    "PER PRIO 1",
    "PER PRIO 2",
    "PER PRIO 3",
    "PER PRIO 4",
    "PER PRIO 5",
    "PER PRIO 6",
    "PER PRIO 7",
    "PER BUFF 0",
    "PER BUFF 1",
    "PER BUFF 2",
    "PER BUFF 3",
    "PER BUFF 4",
    "PER BUFF 5",
    "PER BUFF 6",
    "PER BUFF 7",
    "N/A",
    "N/A",
    "N/A",
    "N/A",
    "N/A",
    "N/A",
    "N/A",
    "N/A",
    "N/A",
    "N/A",
    "N/A",
    "N/A",
    "ALL GROUPS"
};

/**
 * \deprecated This definition is deprecated and will be removed in the future.
 */
static const int sx_port_cntr_grp_str_len = sizeof(sx_port_cntr_grp_str) / sizeof(char*);

/**
 * \deprecated This API is deprecated and will be removed in the future.
 * please use sx_port_cntr_grp_str(index) found in sx_strings.h instead.
 */
#define SX_PORT_CNTR_GRP_STR(index)                  \
    SX_LOG_DEPRECATED_FUNC_ERR(sx_port_cntr_grp_str) \
    (SX_CHECK_RANGE(0, (int)index,                   \
                    sx_port_cntr_grp_str_len - 1) ? sx_port_cntr_grp_str[index] : "UNKNOWN")

#define SX_PORT_PRIO_ID_MIN_MAX SX_PORT_PRIO_ID_MIN, SX_PORT_PRIO_ID_MAX
#define SX_PORT_PRIO_ID_CHECK_RANGE(mode) SX_CHECK_RANGE(SX_PORT_PRIO_ID_MIN, (int)mode, SX_PORT_PRIO_ID_MAX)
#define SX_PORT_TC_ID_CHECK_RANGE(mode)   SX_CHECK_RANGE(SX_PORT_TC_ID_MIN, (int)mode, SX_PORT_TC_ID_MAX)

/**
 * \deprecated This definition is deprecated and will be removed in the future.
 */
static const char* sx_port_cntr_ieee_802_dot_3_str[] = {
    "frames_transmitted_ok",
    "frames_received_ok",
    "frame_check_sequence_errors",
    "alignment_errors",
    "octets_transmitted_ok",
    "octets_received_ok",
    "multicast_frames_xmitted_ok",
    "broadcast_frames_xmitted_ok",
    "multicast_frames_received_ok",
    "broadcast_frames_received_ok",
    "in_range_length_errors",
    "out_of_range_length_field",
    "frame_too_long_errors",
    "symbol_error_during_carrier",
    "mac_control_frames_transmitted",
    "mac_control_frames_received",
    "unsupported_opcodes_received",
    "pause_mac_ctrl_frames_received",
    "pause_mac_ctrl_frames_transmitted",
};

/**
 * \deprecated This definition is deprecated and will be removed in the future.
 */
static const int sx_port_cntr_ieee_802_dot_3_str_len = sizeof(sx_port_cntr_ieee_802_dot_3_str) / sizeof(char*);

/**
 * \deprecated This definition is deprecated and will be removed in the future.
 */
#define SX_PORT_CNTR_IEEE_802_DOT_3_NUM sx_port_cntr_ieee_802_dot_3_str_len

/**
 * \deprecated this API is deprecated and will be removed in the future.
 * please use sx_port_cntr_ieee_802_dot_3_str found in sx_strings.h instead.
 */
#define SX_PORT_CNTR_IEEE_802_DOT_3_STR(index)                                \
    SX_LOG_DEPRECATED_FUNC_ERR(sx_port_cntr_ieee_802_dot_3_str)               \
    (SX_CHECK_RANGE(0, (int)index, sx_port_cntr_ieee_802_dot_3_str_len - 1) ? \
     sx_port_cntr_ieee_802_dot_3_str[index] : "UNKNOWN")

/*********************************************************************************************************************/

/**
 * \deprecated This definition is deprecated and will be removed in the future.
 */
static const char* sx_port_cntr_rfc_2863_str[] = {
    "if_in_octets",
    "if_in_ucast_pkts",
    "if_in_discards",
    "if_in_errors",
    "if_in_unknown_protos",
    "if_out_octets",
    "if_out_ucast_pkts",
    "if_out_discards",
    "if_out_errors",
    "if_in_multicast_pkts",
    "if_in_broadcast_pkts",
    "if_out_multicast_pkts",
    "if_out_broadcast_pkts",
};

/**
 * \deprecated This definition is deprecated and will be removed in the future.
 */
static const int sx_port_cntr_rfc_2863_str_len = sizeof(sx_port_cntr_rfc_2863_str) / sizeof(char*);

/**
 * \deprecated This definition is deprecated and will be removed in the future.
 */
#define SX_PORT_CNTR_RFC_2863_NUM sx_port_cntr_rfc_2863_str_len

/**
 * \deprecated this API is deprecated and will be removed in the future.
 * please use sx_port_cntr_rfc_2863_str(index) found in sx_strings.h instead.
 */
#define SX_PORT_CNTR_RFC_2863_STR(index)                                \
    SX_LOG_DEPRECATED_FUNC_ERR(sx_port_cntr_rfc_2863_str)               \
    (SX_CHECK_RANGE(0, (int)index, sx_port_cntr_rfc_2863_str_len - 1) ? \
     sx_port_cntr_rfc_2863_str[index] : "UNKNOWN")

/*********************************************************************************************************************/

/**
 * \deprecated This definition is deprecated and will be removed in the future.
 */
static const char* sx_port_cntr_rfc_2819_str[] = {
    "ether_stats_drop_events",
    "ether_stats_octets",
    "ether_stats_pkts",
    "ether_stats_broadcast_pkts",
    "ether_stats_multicast_pkts",
    "ether_stats_crc_align_errors",
    "ether_stats_undersize_pkts",
    "ether_stats_oversize_pkts",
    "ether_stats_fragments",
    "ether_stats_jabbers",
    "ether_stats_collisions",
    "ether_stats_pkts64octets",
    "ether_stats_pkts65to127octets",
    "ether_stats_pkts128to255octets",
    "ether_stats_pkts256to511octets",
    "ether_stats_pkts512to1023octets",
    "ether_stats_pkts1024to1518octets",
    "ether_stats_pkts1519to2047octets",
    "ether_stats_pkts2048to4095octets",
    "ether_stats_pkts4096to8191octets",
    "ether_stats_pkts8192to10239octets"
};

/**
 * \deprecated This definition is deprecated and will be removed in the future.
 */
static const int sx_port_cntr_rfc_2819_str_len = sizeof(sx_port_cntr_rfc_2819_str) / sizeof(char*);

/**
 * \deprecated This definition is deprecated and will be removed in the future.
 */
#define SX_PORT_CNTR_RFC_2819_NUM sx_port_cntr_rfc_2819_str_len

/**
 * \deprecated this API is deprecated and will be removed in the future.
 * please use sx_port_cntr_rfc_2819_str(index) found in sx_strings.h instead.
 */
#define SX_PORT_CNTR_RFC_2819_STR(index)                                \
    SX_LOG_DEPRECATED_FUNC_ERR(sx_port_cntr_rfc_2819_str)               \
    (SX_CHECK_RANGE(0, (int)index, sx_port_cntr_rfc_2819_str_len - 1) ? \
     sx_port_cntr_rfc_2819_str[index] : "UNKNOWN")

/*********************************************************************************************************************/

/**
 * \deprecated This definition is deprecated and will be removed in the future.
 */
static const char* sx_port_cntr_phy_layer_str[] = {
    "time_since_last_clear",
    "symbol_errors",
    "sync_headers_errors",
    "edpl_bip_errors_lane0",
    "edpl_bip_errors_lane1",
    "edpl_bip_errors_lane2",
    "edpl_bip_errors_lane3",
    "fc_fec_corrected_blocks_lane0",
    "fc_fec_corrected_blocks_lane1",
    "fc_fec_corrected_blocks_lane2",
    "fc_fec_corrected_blocks_lane3",
    "fc_fec_uncorrectable_blocks_lane0",
    "fc_fec_uncorrectable_blocks_lane1",
    "fc_fec_uncorrectable_blocks_lane2",
    "fc_fec_uncorrectable_blocks_lane3",
    "rs_fec_corrected_blocks",
    "rs_fec_uncorrectable_blocks",
    "rs_fec_no_errors_blocks",
    "rs_fec_single_error_blocks",
    "rs_fec_corrected_symbols_total",
    "rs_fec_corrected_symbols_lane0",
    "rs_fec_corrected_symbols_lane1",
    "rs_fec_corrected_symbols_lane2",
    "rs_fec_corrected_symbols_lane3",
    "link_down_events",
    "successful_recovery_events"
};

/**
 * \deprecated This definition is deprecated and will be removed in the future.
 */
static const int sx_port_cntr_phy_layer_str_len = sizeof(sx_port_cntr_phy_layer_str) / sizeof(char*);

/**
 * \deprecated This definition is deprecated and will be removed in the future.
 */
#define SX_PORT_CNTR_PHY_LAYER_NUM sx_port_cntr_phy_layer_str_len

/**
 * \deprecated this API is deprecated and will be removed in the future.
 * please use sx_port_cntr_phy_layer_str(index) found in sx_strings.h instead.
 */
#define SX_PORT_CNTR_PHY_LAYER_STR(index)                                \
    SX_LOG_DEPRECATED_FUNC_ERR(sx_port_cntr_phy_layer_str)               \
    (SX_CHECK_RANGE(0, (int)index, sx_port_cntr_phy_layer_str_len - 1) ? \
     sx_port_cntr_phy_layer_str[index] : "UNKNOWN")

/*********************************************************************************************************************/

/**
 * \deprecated This definition is deprecated and will be removed in the future.
 */
static const char* sx_port_cntr_phy_layer_statistics_str[] = {
    "time_since_last_clear",
    "phy_received_bits",
    "phy_symbol_errors",
    "phy_corrected_bits",
    "phy_raw_errors_lane0",
    "phy_raw_errors_lane1",
    "phy_raw_errors_lane2",
    "phy_raw_errors_lane3",
    "phy_raw_errors_lane4",
    "phy_raw_errors_lane5",
    "phy_raw_errors_lane6",
    "phy_raw_errors_lane7",
    "raw_ber_magnitude",
    "raw_ber_coef",
    "effective_ber_magnitude",
    "effective_ber_coef"
};

/**
 * \deprecated This definition is deprecated and will be removed in the future.
 */
static const int sx_port_cntr_phy_layer_statistics_str_len = sizeof(sx_port_cntr_phy_layer_statistics_str) /
                                                             sizeof(char*);

/**
 * \deprecated This definition is deprecated and will be removed in the future.
 */
#define SX_PORT_CNTR_PHY_LAYER_STATISTICS_NUM sx_port_cntr_phy_layer_statistics_str_len

/**
 * \deprecated This API is deprecated and will be removed in the future.
 * please use sx_port_cntr_phy_layer_statistics_str(index) found in sx_strings.h instead.
 */
#define SX_PORT_CNTR_PHY_LAYER_STATISTICS_STR(index)                                \
    SX_LOG_DEPRECATED_FUNC_ERR(sx_port_cntr_phy_layer_statistics_str)               \
    (SX_CHECK_RANGE(0, (int)index, sx_port_cntr_phy_layer_statistics_str_len - 1) ? \
     sx_port_cntr_phy_layer_statistics_str[index] : "UNKNOWN")

/*********************************************************************************************************************/

/**
 * \deprecated This definition is deprecated and will be removed in the future.
 */
static const char* sx_port_cntr_phy_layer_internal_link_str[] = {
    "time_since_last_clear",
    "fc_fec_corrected_blocks_lane0",
    "fc_fec_corrected_blocks_lane1",
    "fc_fec_corrected_blocks_lane2",
    "fc_fec_corrected_blocks_lane3",
    "fc_fec_corrected_blocks_lane4",
    "fc_fec_corrected_blocks_lane5",
    "fc_fec_corrected_blocks_lane6",
    "fc_fec_corrected_blocks_lane7",
    "fc_fec_uncorrectable_blocks_lane0",
    "fc_fec_uncorrectable_blocks_lane1",
    "fc_fec_uncorrectable_blocks_lane2",
    "fc_fec_uncorrectable_blocks_lane3",
    "fc_fec_uncorrectable_blocks_lane4",
    "fc_fec_uncorrectable_blocks_lane5",
    "fc_fec_uncorrectable_blocks_lane6",
    "fc_fec_uncorrectable_blocks_lane7",
    "link_down_event_cnt"
};

/**
 * \deprecated This definition is deprecated and will be removed in the future.
 */
static const int sx_port_cntr_phy_layer_internal_link_str_len = sizeof(sx_port_cntr_phy_layer_internal_link_str) /
                                                                sizeof(char*);

/**
 * \deprecated This definition is deprecated and will be removed in the future.
 */
#define SX_PORT_CNTR_PHY_LAYER_INTERNAL_LINK_NUM sx_port_cntr_phy_layer_internal_link_str_len

/**
 * \deprecated This API is deprecated and will be removed in the future.
 * please use sx_port_cntr_phy_layer_internal_link_str(index) found in sx_strings.h instead.
 */
#define SX_PORT_CNTR_PHY_LAYER_INTERNAL_LINK_STR(index)                                \
    SX_LOG_DEPRECATED_FUNC_ERR(sx_port_cntr_phy_layer_internal_link_str)               \
    (SX_CHECK_RANGE(0, (int)index, sx_port_cntr_phy_layer_internal_link_str_len - 1) ? \
     sx_port_cntr_phy_layer_internal_link_str[index] : "UNKNOWN")

/*********************************************************************************************************************/

/**
 * \deprecated This definition is deprecated and will be removed in the future.
 */
static const char* sx_port_cntr_rfc_3635_str[] = {
    "dot3stats_alignment_errors",
    "dot3stats_fcs_errors",
    "dot3stats_single_collision_frames",
    "dot3stats_multiple_collision_frames",
    "dot3stats_sqe_test_errors",
    "dot3stats_deferred_transmissions",
    "dot3stats_late_collisions",
    "dot3stats_excessive_collisions",
    "dot3stats_internal_mac_transmit_errors",
    "dot3stats_carrier_sense_errors",
    "dot3stats_frame_too_longs",
    "dot3stats_internal_mac_receive_errors",
    "dot3stats_symbol_errors",
    "dot3control_in_unknown_opcodes",
    "dot3in_pause_frames",
    "dot3out_pause_frames",
};

/**
 * \deprecated This definition is deprecated and will be removed in the future.
 */
static const int sx_port_cntr_rfc_3635_str_len = sizeof(sx_port_cntr_rfc_3635_str) / sizeof(char*);

/**
 * \deprecated This definition is deprecated and will be removed in the future.
 */
#define SX_PORT_CNTR_RFC_3635_NUM sx_port_cntr_rfc_3635_str_len

/**
 * \deprecated This API is deprecated and will be removed in the future.
 * please use sx_port_cntr_rfc_3635_str(index) found in sx_strings.h instead.
 */
#define SX_PORT_CNTR_RFC_3635_STR(index)                                \
    SX_LOG_DEPRECATED_FUNC_ERR(sx_port_cntr_rfc_3635_str)               \
    (SX_CHECK_RANGE(0, (int)index, sx_port_cntr_rfc_3635_str_len - 1) ? \
     sx_port_cntr_rfc_3635_str[index] : "UNKNOWN")

/*********************************************************************************************************************/

/**
 * \deprecated This definition is deprecated and will be removed in the future.
 */
static const char* sx_port_cntr_discard_str[] = {
    "ingress_general",
    "ingress_policy_engine",
    "ingress_vlan_membership",
    "ingress_tag_frame_type",
    "egress_vlan_membership",
    "loopback_filter",
    "egress_general",
    "egress_link_down",
    "egress_hoq",
    "port_isolation",
    "egress_policy_engine",
    "ingress_tx_link_down",
    "egress_stp_filter",
    "egress_hoq_stall",
    "egress_sll",
    "ingress_discard_all",
};

/**
 * \deprecated This definition is deprecated and will be removed in the future.
 */
static const int sx_port_cntr_discard_str_len = sizeof(sx_port_cntr_discard_str) / sizeof(char*);

/**
 * \deprecated This definition is deprecated and will be removed in the future.
 */
#define SX_PORT_CNTR_DISCARD_NUM sx_port_cntr_discard_str_len

/**
 * \deprecated This API is deprecated and will be removed in the future.
 * please use sx_port_cntr_discard_str(index) found in sx_strings.h instead.
 */
#define SX_PORT_CNTR_DISCARD_STR(index)                                \
    SX_LOG_DEPRECATED_FUNC_ERR(sx_port_cntr_discard_str)               \
    (SX_CHECK_RANGE(0, (int)index, sx_port_cntr_discard_str_len - 1) ? \
     sx_port_cntr_discard_str[index] : "UNKNOWN")

/*********************************************************************************************************************/

/**
 * \deprecated This definition is deprecated and will be removed in the future.
 */
static const char* sx_port_cntr_cli_str[] = {
    "port_rx_octets",
    "port_rx_frames",
    "port_rx_jumbo",
    "port_rx_unicast",
    "port_rx_multicast",
    "port_rx_broadcast",
    "port_rx_no_buffer",
    "port_rx_fcs_errors",
    "port_rx_runt",
    "port_rx_other_errors",
    "port_tx_octets",
    "port_tx_frames",
    "port_tx_jumbo",
    "port_tx_unicast",
    "port_tx_multicast",
    "port_tx_broadcast",
    "port_tx_errors",
};

/**
 * \deprecated This definition is deprecated and will be removed in the future.
 */
static const int sx_port_cntr_cli_str_len = sizeof(sx_port_cntr_cli_str) / sizeof(char*);

/**
 * \deprecated This definition is deprecated and will be removed in the future.
 */
#define SX_PORT_CNTR_CLI_NUM sx_port_cntr_cli_str_len

/**
 * \deprecated This API is deprecated and will be removed in the future.
 * please use sx_port_cntr_cli_str(index) found in sx_strings.h instead.
 */
#define SX_PORT_CNTR_CLI_STR(index)                                \
    SX_LOG_DEPRECATED_FUNC_ERR(sx_port_cntr_cli_str)               \
    (SX_CHECK_RANGE(0, (int)index, sx_port_cntr_cli_str_len - 1) ? \
     sx_port_cntr_cli_str[index] : "UNKNOWN")

/*********************************************************************************************************************/

/**
 * \deprecated This definition is deprecated and will be removed in the future.
 */
static const char* sx_port_traffic_cntr_str[] = {
    "tx_octet",
    "tx_uc_frames",
    "tx_mc_frames",
    "tx_bc_frames",
    "tx_frames",
    "tx_queue",
    "tx_no_buffer_discard_uc",
    "tx_wred_discard",
};

/**
 * \deprecated This definition is deprecated and will be removed in the future.
 */
static const int sx_port_traffic_cntr_str_len = sizeof(sx_port_traffic_cntr_str) / sizeof(char*);

/**
 * \deprecated This definition is deprecated and will be removed in the future.
 */
#define SX_PORT_CNTR_TRAFFIC_NUM sx_port_traffic_cntr_str_len

/**
 * \deprecated This API is deprecated and will be removed in the future.
 * please use sx_port_cntr_traffic_str(index)  found in sx_strings.h instead.
 */
#define SX_PORT_CNTR_TRAFFIC_STR(index)                                \
    SX_LOG_DEPRECATED_FUNC_ERR(sx_port_cntr_traffic_str)               \
    (SX_CHECK_RANGE(0, (int)index, sx_port_traffic_cntr_str_len - 1) ? \
     sx_port_traffic_cntr_str[index] : "UNKNOWN")

/*********************************************************************************************************************/

/**
 * \deprecated This definition is deprecated and will be removed in the future.
 */
static const char*sx_port_cntr_prio_str[] = {
    "rx_octets",
    "rx_uc_frames",
    "rx_mc_frames",
    "rx_bc_frames",
    "rx_frames",
    "tx_octets",
    "tx_uc_frames",
    "tx_mc_frames",
    "tx_bc_frames",
    "tx_frames",
    "rx_pause",
    "rx_pause_duration",
    "tx_pause",
    "tx_pause_duration",
    "rx_pause_transition",
    "rx_discard",
};

/**
 * \deprecated This definition is deprecated and will be removed in the future.
 */
static const int sx_port_cntr_prio_str_len = sizeof(sx_port_cntr_prio_str) / sizeof(char*);

/**
 * \deprecated This definition is deprecated and will be removed in the future.
 */
#define SX_PORT_CNTR_PRIO_NUM sx_port_cntr_prio_str_len

/**
 * \deprecated This API is deprecated and will be removed in the future.
 * please use sx_port_cntr_prio_str(index)  found in sx_strings.h instead.
 */
#define SX_PORT_CNTR_PRIO_STR(index)                                \
    SX_LOG_DEPRECATED_FUNC_ERR(sx_port_cntr_prio_str)               \
    (SX_CHECK_RANGE(0, (int)index, sx_port_cntr_prio_str_len - 1) ? \
     sx_port_cntr_prio_str[index] : "UNKNOWN")

/*********************************************************************************************************************/

/**
 * \deprecated This definition is deprecated and will be removed in the future.
 */
static const char *sx_port_cntr_buff_str[] = {
    "rx_octets",
    "rx_frames",
    "rx_buffer_discard",
    "rx_shared_buffer_discard",
};

/**
 * \deprecated This definition is deprecated and will be removed in the future.
 */
static const int sx_port_cntr_buff_str_len = sizeof(sx_port_cntr_buff_str) / sizeof(char *);

/**
 * \deprecated This definition is deprecated and will be removed in the future.
 */
#define SX_PORT_CNTR_BUFF_NUM sx_port_cntr_buff_str_len

/**
 * \deprecated This API is deprecated and will be removed in the future.
 * please use sx_port_cntr_buff_str(index) found in sx_strings.h instead.
 */
#define SX_PORT_CNTR_BUFF_STR(index)                                \
    SX_LOG_DEPRECATED_FUNC_ERR(sx_port_cntr_buff_str)               \
    (SX_CHECK_RANGE(0, (int)index, sx_port_cntr_buff_str_len - 1) ? \
     sx_port_cntr_buff_str[index] : "UNKNOWN")

/*****************************************************************************************************************************/

/**
 * \deprecated This definition is deprecated and will be removed in the future.
 */
static const char*sx_port_cntr_tc_congestion_str[] = {
    "wred_discard"
};

/**
 * \deprecated This definition is deprecated and will be removed in the future.
 */
static const int sx_port_cntr_tc_congestion_len = sizeof(sx_port_cntr_tc_congestion_str) / sizeof(char*);

/**
 * \deprecated This definition is deprecated and will be removed in the future.
 */
#define SX_PORT_CNTR_TC_CONGESTION_NUM sx_port_cntr_tc_congestion_len

/**
 * \deprecated This API is deprecated and will be removed in the future.
 * please use sx_port_cntr_tc_congestion_str(index) found in sx_strings.h instead.
 */
#define SX_PORT_CNTR_TC_CONGESTION_STR(index)                            \
    SX_LOG_DEPRECATED_FUNC_ERR(sx_port_cntr_tc_congestion_str)           \
    (SX_CHECK_RANGE(0, (int)index, sx_port_cntr_tc_congestion_len - 1) ? \
     sx_port_cntr_tc_congestion_str[index] : "UNKNOWN")

/*****************************************************************************************************************************/

/**
 * \deprecated This definition is deprecated and will be removed in the future.
 */
static const char*sx_port_cntr_perf_str[] = {
    "tx_wait",
    "ecn_marked",
    "no_buffer_discard_mc",
    "rx_ebp",
    "tx_ebp",
    "rx_buffer_almost_full",
    "rx_buffer_full",
    "tx_stats_pkts64octets",
    "tx_stats_pkts65to127octets",
    "tx_stats_pkts128to255octets",
    "tx_stats_pkts256to511octets",
    "tx_stats_pkts512to1023octets",
    "tx_stats_pkts1024to1518octets",
    "tx_stats_pkts1519to2047octets",
    "tx_stats_pkts2048to4095octets",
    "tx_stats_pkts4096to8191octets",
    "tx_stats_pkts8192to10239octets"
};

/**
 * \deprecated This definition is deprecated and will be removed in the future.
 */
static const int sx_port_cntr_perf_str_len = sizeof(sx_port_cntr_perf_str) / sizeof(char*);

/**
 * \deprecated This definition is deprecated and will be removed in the future.
 */
#define SX_PORT_CNTR_PERF_NUM sx_port_cntr_perf_str_len

/**
 * \deprecated This API is deprecated and will be removed in the future.
 * please use sx_port_cntr_perf_str(index) found in sx_strings.h instead.
 */
#define SX_PORT_CNTR_PERF_STR(index)                                \
    SX_LOG_DEPRECATED_FUNC_ERR(sx_port_cntr_perf_str)               \
    (SX_CHECK_RANGE(0, (int)index, sx_port_cntr_perf_str_len - 1) ? \
     sx_port_cntr_perf_str[index] : "UNKNOWN")
/*****************************************************************************************************************************/

#define SX_PORT_CNTR_GRP_PHY_STATISTICS_SIZE (sizeof(sx_port_cntr_phy_layer_statistics_t) / sizeof(sx_port_cntr_t))
#define SX_PORT_CNTR_GRP_PHY_INTERNAL_LINK_SIZE       \
    (sizeof(sx_port_cntr_phy_layer_internal_link_t) / \
     sizeof(sx_port_cntr_t))
#define SX_PORT_CNTR_GRP_PHY_LAYER_SIZE         (sizeof(sx_port_cntr_phy_layer_t) / sizeof(sx_port_cntr_t))
#define SX_PORT_CNTR_GRP_IEEE_802_DOT_3_SIZE    (sizeof(sx_port_cntr_ieee_802_dot_3_t) / sizeof(sx_port_cntr_t))
#define SX_PORT_CNTR_GRP_RFC_2863_SIZE          (sizeof(sx_port_cntr_rfc_2863_t) / sizeof(sx_port_cntr_t))
#define SX_PORT_CNTR_GRP_RFC_2819_SIZE          (sizeof(sx_port_cntr_rfc_2819_t) / sizeof(sx_port_cntr_t))
#define SX_PORT_CNTR_GRP_RFC_3635_SIZE          (sizeof(sx_port_cntr_rfc_3635_t) / sizeof(sx_port_cntr_t))
#define SX_PORT_CNTR_GRP_DISCARD_SIZE           (sizeof(sx_port_cntr_discard_t) / sizeof(sx_port_cntr_t))
#define SX_PORT_CNTR_GRP_CLI_SIZE               (sizeof(sx_port_cntr_cli_t) / sizeof(sx_port_cntr_t))
#define SX_PORT_CNTR_GRP_PER_PRIO_SIZE          (sizeof(sx_port_cntr_prio_t) / sizeof(sx_port_cntr_t))
#define SX_PORT_CNTR_GRP_PER_TC_CONGESTION_SIZE (sizeof(sx_port_cntr_tc_congestion_t) / sizeof(sx_port_cntr_t))
#define SX_PORT_CNTR_GRP_PERF_SIZE              (sizeof(sx_port_cntr_perf_t) / sizeof(sx_port_cntr_t))

/*********************************************************************************************************************/

#define SX_MAP_BITMAP_MIN_MAX SX_MAP_BITMAP_MIN, SX_MAP_BITMAP_MAX
#define SX_MAP_BITMAP_CHECK_RANGE(mode) SX_CHECK_RANGE(SX_MAP_BITMAP_MIN, (int)mode, SX_MAP_BITMAP_MAX)

/*********************************************************************************************************************/

#define SX_PORT_SFLOW_SAMPLING_RATE_VALIDATE(rate) \
    (((rate >= SX_PORT_SFLOW_SAMPLING_RATE_MIN) && \
      (rate <= SX_PORT_SFLOW_SAMPLING_RATE_MAX)) ? TRUE : FALSE)

#define SX_PORT_PACKET_STORING_MODE_CHECK_RANGE(mode) \
    SX_CHECK_RANGE(SX_PORT_PACKET_STORING_MODE_MIN,   \
                   (int)mode,                         \
                   SX_PORT_PACKET_STORING_MODE_MAX)

#define SX_PORT_PHY_BER_MAGNITUDE_GET(value) ((value) & 0xFF)
#define SX_PORT_PHY_BER_COEF_GET(value)      ((value >> 8) & 0xF)

#define SX_PORT_BAD_CRC_INGRESS_MODE_CHECK_RANGE(mode) \
    SX_CHECK_RANGE(SX_PORT_BAD_CRC_INGRESS_MODE_MIN,   \
                   (int)mode,                          \
                   SX_PORT_BAD_CRC_INGRESS_MODE_MAX)

#define SX_PORT_CRC_EGRESS_RECALC_MODE_CHECK_RANGE(mode) \
    SX_CHECK_RANGE(SX_PORT_CRC_EGRESS_RECALC_MODE_MIN,   \
                   (int)mode,                            \
                   SX_PORT_CRC_EGRESS_RECALC_MODE_MAX)


#endif /* __SX_PORT_H__ */
