/*
 *  Copyright (C) 2010-2020. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */

#ifndef __SX_REGISTER_H__
#define __SX_REGISTER_H__

#include "sx/sdk/auto_headers/sx_register_auto.h"

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/**
 * Size of general purpose register.
 */
typedef uint16_t sx_gp_register_t;

/**
 * General purpose registers ID.
 */
typedef enum __attribute__((__packed__)) sx_gp_register {
    SX_GP_REGISTER_0_E,
    SX_GP_REGISTER_1_E,
    SX_GP_REGISTER_2_E,
    SX_GP_REGISTER_3_E,
    SX_GP_REGISTER_4_E,
    SX_GP_REGISTER_5_E,
    SX_GP_REGISTER_6_E,
    SX_GP_REGISTER_7_E,
    SX_GP_REGISTER_8_E,
    SX_GP_REGISTER_9_E,
    SX_GP_REGISTER_LAST_E,
} sx_gp_register_e;

/**
 * General purpose register key type.
 * General purpose registers are fixed size entities that the HW exposes.
 * This can be used to extract data from packet headers (for example as ACL key),
 * store and perform flex ACL ALU operations.
 * On Spectrum2 and Spectrum3 general purpose register N is map to custom bytes 2N+1 and 2N.
 */
typedef struct sx_gp_register_key {
    sx_gp_register_e reg_id;
} sx_gp_register_key_t;

/**
 * Register key attributes.
 */
typedef union sx_register_key_attr {
    sx_gp_register_key_t gp_reg;
} sx_register_key_attr_t;

/**
 * Register key type.
 */
typedef enum sx_register_key_type {
    SX_REGISTER_KEY_TYPE_GENERAL_PURPOSE_E = 0,
    SX_REGISTER_KEY_TYPE_MAX_E = SX_REGISTER_KEY_TYPE_GENERAL_PURPOSE_E,
} sx_register_key_type_e;

/**
 * Register key.
 */
typedef struct sx_register_key {
    sx_register_key_type_e type;
    sx_register_key_attr_t key;
} sx_register_key_t;

/**
 * Filter criteria for register list iterator.
 * Reserved for future expansion.
 */
typedef struct sx_register_filter {
} sx_register_filter_t;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

#endif /* __SX_REGISTER_H__  */
