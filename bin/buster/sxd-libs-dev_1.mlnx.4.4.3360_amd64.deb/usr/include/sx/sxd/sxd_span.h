/*
 * Copyright (C) 2010-2021 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_SPAN_H__
#define __SXD_SPAN_H__

#include <complib/cl_types.h>
#include <sx/sxd/sxd_check.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/**
 * SPAN ID.
 */
typedef uint8_t sxd_span_id_t;

/**
 * sx_span_state_t enumerated type is used to note a SPAN state.
 */
typedef enum sxd_span_state {
    SXD_SPAN_STATE_DISABLE = 0,  /**< SPAN state  disable*/
    SXD_SPAN_STATE_ENABLE  = 1, /**< SPAN state  enable */
} sxd_span_state_t;

typedef enum sxd_span_type {
    SXD_SPAN_TYPE_LOCAL_ETH       = 0,
    SXD_SPAN_TYPE_REMOTE_ETH_VLAN = 1,
    SXD_SPAN_TYPE_REMOTE_ETH_L2   = 2,
    SXD_SPAN_TYPE_REMOTE_ETH_L3   = 3,
    SXD_SPAN_TYPE_LOCAL_IB        = 4,
    SXD_SPAN_TYPE_REMOTE_IB       = 8,

    SXD_SPAN_TYPE_MIN = SXD_SPAN_TYPE_LOCAL_ETH,
    SXD_SPAN_TYPE_MAX = SXD_SPAN_TYPE_REMOTE_IB
} sxd_span_type_t;

typedef enum sxd_span_mirror_header_version {
    SXD_SPAN_MIRROR_HEADER_VERSION_0   = 0,
    SXD_SPAN_MIRROR_HEADER_VERSION_1   = 1,
    SXD_SPAN_MIRROR_HEADER_VERSION_2   = 2,
    SXD_SPAN_MIRROR_HEADER_NONE        = 15,
    SXD_SPAN_MIRROR_HEADER_VERSION_MIN = SXD_SPAN_MIRROR_HEADER_VERSION_0,
    SXD_SPAN_MIRROR_HEADER_VERSION_MAX = SXD_SPAN_MIRROR_HEADER_NONE,
} sxd_span_mirror_header_version_t;


#define SXD_SPAN_TYPE_CHECK_RANGE(type) \
    SXD_CHECK_MAX(type, SXD_HOST_IF_TYPE_MAX)


typedef enum sxd_span_mirror_port_direction {
    SXD_MPAR_MIRROR_DIRECTION_EGRESS                 = 0, /**< SPAN mirror port direction EGRESS*/
    SXD_MPAR_MIRROR_DIRECTION_INGRESS                = 1, /**< SPAN mirror port direction INGRESS */
    SXD_MPAR_MIRROR_DIRECTION_INGRESS_WRED           = 2, /**< SPAN mirror port direction INGRESS WRED drop */
    SXD_MPAR_MIRROR_DIRECTION_INGRESS_SHARED_BUFFER  = 3, /**< SPAN mirror port direction INGRESS shared buffer drop */
    SXD_MPAR_MIRROR_DIRECTION_INGRESS_ING_CONGESTION = 4,  /**< SPAN mirror port direction INGRESS ING congestion */
    SXD_MPAR_MIRROR_DIRECTION_INGRESS_EGR_CONGESTION = 5,  /**< SPAN mirror port direction INGRESS EGR congestion */
    SXD_MPAR_MIRROR_DIRECTION_EGRESS_ECN             = 6, /**< SPAN mirror port direction EGRESS ECN */
    SXD_MPAR_MIRROR_DIRECTION_EGRESS_TC_LATENCY      = 7, /**< SPAN mirror port direction EGRESS high latency */
} sxd_span_mirror_port_direction_t;

typedef enum sxd_span_mirror_enable_type {
    SXD_MOMTE_MIRROR_ENABLE_TYPE_INGRESS_WRED                   = 0x20,
    SXD_MOMTE_MIRROR_ENABLE_TYPE_INGRESS_SHARED_BUFFER_TCLASS   = 0x31,
    SXD_MOMTE_MIRROR_ENABLE_TYPE_INGRESS_SHARED_BUFFER_EGR_PORT = 0x33,
    SXD_MOMTE_MIRROR_ENABLE_TYPE_INGRESS_ING_CONGESTION         = 0x40,
    SXD_MOMTE_MIRROR_ENABLE_TYPE_INGRESS_EGR_CONGESTION         = 0x50,
    SXD_MOMTE_MIRROR_ENABLE_TYPE_EGRESS_ECN                     = 0x60,
    SXD_MOMTE_MIRROR_ENABLE_TYPE_EGRESS_TC_LATENCY              = 0x70,
} sxd_span_mirror_enable_type_t;

typedef enum sxd_span_mngr_type {
    SXD_SPAN_MNGR_HYPERVISOR            = 0,    /**< SPAN mngr_type: Hypervisor*/
    SXD_SPAN_MNGR_LOCAL_NETWORK_MANAGER = 1,    /**< SPAN mngr_type: Local Network Manager */
} sxd_span_mngr_type_t;

#endif /* __SXD_SPAN_H__ */
