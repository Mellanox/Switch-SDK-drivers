/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_PARSER_POLICER_H__
#define __SXD_EMAD_PARSER_POLICER_H__

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_emad_policer_data.h>
#include <sx/sxd/sxd_emad_policer_reg.h>


/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_qpcr(sxd_emad_qpcr_data_t *qpcr_data,
                                 sxd_emad_qpcr_reg_t  *qpcr_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_qpcr(sxd_emad_qpcr_data_t *qpcr_data,
                                   sxd_emad_qpcr_reg_t  *qpcr_reg);


#endif /* __SXD_EMAD_PARSER_POLICER_H__ */
