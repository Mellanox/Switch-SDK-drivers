/*
 *  Copyright (C) 2010-2020. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */


#ifndef __SX_STATUS_H__
#define __SX_STATUS_H__

#include "sx/sdk/auto_headers/sx_status_auto.h"


/************************************************
 *  Type definitions
 ***********************************************/

static __attribute__((__used__)) const sx_status_t sxd_status2sx_status_arr[] = {
    /* SXD_STATUS_SUCCESS */
    SX_STATUS_SUCCESS,
    /* SXD_STATUS_ERROR */
    SX_STATUS_ERROR,
    /* SXD_STATUS_NO_RESOURCES */
    SX_STATUS_NO_RESOURCES,
    /* SXD_STATUS_NO_MEMORY */
    SX_STATUS_NO_MEMORY,
    /* SXD_STATUS_PARAM_ERROR */
    SX_STATUS_PARAM_ERROR,
    /* SXD_STATUS_NOT_INITIALIZED */
    SX_STATUS_ERROR,
    /* SXD_STATUS_DEVICE_OPEN_ERROR */
    SX_STATUS_SXD_RETURNED_NON_ZERO,
    /* SXD_STATUS_DEVICE_CLOSE_ERROR */
    SX_STATUS_SXD_RETURNED_NON_ZERO,
    /* SXD_STATUS_DEVICE_GET_ERROR */
    SX_STATUS_SXD_RETURNED_NON_ZERO,
    /* SXD_STATUS_DEVICE_IOCTL_ERROR */
    SX_STATUS_SXD_RETURNED_NON_ZERO,
    /* SXD_STATUS_HANDLE_ERROR */
    SX_STATUS_INVALID_HANDLE,
    /* SXD_STATUS_INVALID_ACCESS_CMD */
    SX_STATUS_CMD_ERROR,
    /* SXD_STATUS_TIMEOUT */
    SX_STATUS_TIMEOUT,
    /* SXD_STATUS_CMD_UNSUPPORTED */
    SX_STATUS_CMD_UNSUPPORTED,
    /* SXD_STATUS_NO_PATH_TO_DEVICE */
    SX_STATUS_SXD_RETURNED_NON_ZERO,
    /* SXD_STATUS_FW_ERROR */
    SX_STATUS_SXD_RETURNED_NON_ZERO,
    /* SXD_STATUS_FW_BUSY */
    SX_STATUS_SXD_RETURNED_NON_ZERO,
    /* SXD_STATUS_FW_NO_RESOURCES */
    SX_STATUS_NO_RESOURCES
};

#define SXD_STATUS_TO_SX_STATUS(STATUS)                                 \
    SXD_STATUS_CHECK_RANGE(STATUS) ? sxd_status2sx_status_arr[STATUS] : \
    SX_STATUS_SXD_RETURNED_NON_ZERO

static inline sx_status_t sxd_status_to_sx_status(sxd_status_t sxd_status)
{
    return SXD_STATUS_TO_SX_STATUS((int)sxd_status);
}


/************************************************
 *  Macro definitions
 ***********************************************/


#define SX_STATUS_CHECK_RANGE(STATUS) SX_CHECK_RANGE(SX_STATUS_MIN, (int)STATUS, SX_STATUS_MAX)


#endif /* __SX_STATUS_H__ */
