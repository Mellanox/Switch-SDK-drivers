/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2020 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_SPAN_REG_H__
#define __SXD_EMAD_SPAN_REG_H__

#include <sx/sxd/sxd_types.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

#include <complib/cl_packon.h>

/**
 * sxd_emad_mpat_encap_local_eth_reg_t structure is used to
 * store LOCAL ETH SPAN fields register layout.
 */
typedef struct sxd_emad_mpat_encap_local_eth_reg {
    uint8_t reserved1[15];
    uint8_t tclass;
} PACK_SUFFIX sxd_emad_mpat_encap_local_eth_reg_t;

/**
 * sxd_emad_mpat_encap_remote_eth_vlan_reg_t structure is used to
 * store REMOTE ETH VLAN SPAN fields register layout.
 */
typedef struct sxd_emad_mpat_encap_remote_eth_vlan_reg {
    uint8_t reserved1[10];
    net16_t pcp_dei_vid;
    uint8_t reserved2;
    uint8_t vlan_ethertype_id;
    uint8_t reserved3;
    uint8_t tclass;
} PACK_SUFFIX sxd_emad_mpat_encap_remote_eth_vlan_reg_t;

/**
 * sxd_emad_mpat_encap_remote_eth_l2_reg_t structure is used to
 * store REMOTE ETH L2 SPAN fields register layout.
 */
typedef struct sxd_emad_mpat_encap_remote_eth_l2_reg {
    uint8_t swid;
    uint8_t ver_dpa;
    uint8_t mac[6];
    uint8_t reserved1;
    uint8_t tp;
    net16_t pcp_dei_vid;
    uint8_t reserved2;
    uint8_t vlan_ethertype_id;
    uint8_t reserved3;
    uint8_t tclass;
} PACK_SUFFIX sxd_emad_mpat_encap_remote_eth_l2_reg_t;

/**
 * sxd_emad_mpat_encap_local_eth_reg_t structure is used to
 * store LOCAL IB SPAN fields register layout.
 */
typedef struct sxd_emad_mpat_encap_local_ib_reg {
    uint8_t reserved1[15];
    uint8_t vl;
} PACK_SUFFIX sxd_emad_mpat_encap_local_ib_reg_t;

/**
 * sxd_emad_mpat_encap_local_eth_reg_t structure is used to
 * store REMOTE IB SPAN fields register layout.
 */
typedef struct sxd_emad_mpat_encap_remote_ib_reg {
    uint8_t reserved1;
    uint8_t sl;
    net16_t dlid;
    net16_t reserved2;
    net16_t slid;
    uint8_t reserved3[7];
    uint8_t vl;
} PACK_SUFFIX sxd_emad_mpat_encap_remote_ib_reg_t;

/**
 * sxd_emad_mpat_encap_remote_eth_l3_reg_t structure is used to
 * store REMOTE ETH L3 SPAN fields register layout.
 */
typedef struct sxd_emad_mpat_encap_remote_eth_l3_reg {
    uint8_t swid;
    uint8_t ver_dpa;
    uint8_t mac[6];
    uint8_t protocol;
    uint8_t dscp_tp;
    net16_t pcp_dei_vid;
    uint8_t reserved1;
    uint8_t vlan_ethertype_id;
    net16_t ecn_ttl_tclass;
    net16_t reserved2;
    uint8_t smac[6];
    uint8_t reserved3[24];
    net32_t dip[4];
    net32_t sip[4];
} PACK_SUFFIX sxd_emad_mpat_encap_remote_eth_l3_reg_t;

/**
 * sxd_emad_mpat_encap_t union is used to store the encapsulation
 * format of SPAN session .
 */
typedef union sxd_emad_mpat_encap {
    sxd_emad_mpat_encap_local_eth_reg_t       local_eth;
    sxd_emad_mpat_encap_remote_eth_vlan_reg_t remote_eth_vlan;
    sxd_emad_mpat_encap_remote_eth_l2_reg_t   remote_eth_l2;
    sxd_emad_mpat_encap_local_ib_reg_t        local_ib;
    sxd_emad_mpat_encap_remote_ib_reg_t       remote_ib;
    sxd_emad_mpat_encap_remote_eth_l3_reg_t   remote_eth_l3;
    uint8_t                                   place_holder[80]; /* reserves maximum size */
} PACK_SUFFIX sxd_emad_mpat_encap_t;

/**
 * sxd_emad_mpat_reg_t structure is used to store MPAT register
 * layout.
 */
typedef struct sxd_emad_mpat_reg {
    uint8_t               pa_id;
    uint8_t               mngr_type;
    net16_t               system_port;
    uint8_t               e_c_qos_be_tr;
    uint8_t               reserved1;
    uint8_t               stclass;
    uint8_t               span_type;
    uint8_t               reserved2[2];
    net16_t               truncation_size;
    uint8_t               reserved3[4];
    sxd_emad_mpat_encap_t encap;
    uint64_t              buffer_drop;
    uint64_t              be_drop;
    uint64_t              wred_drop;
} PACK_SUFFIX sxd_emad_mpat_reg_t;

/**
 * sxd_emad_mpar_reg_t structure is used to store MPAR register
 * layout.
 */
typedef struct sxd_emad_mpar_reg {
    uint8_t  mngr_type;
    uint8_t  local_port;
    uint8_t  sub_port;
    uint8_t  i_e;
    uint8_t  enable;
    net16_t  reserved1;
    uint8_t  pa_id;
    uint32_t probability_rate;
} PACK_SUFFIX sxd_emad_mpar_reg_t;

/**
 * sxd_emad_sbib_reg_t structure is used to store SBIB register
 * layout.
 */
typedef struct sxd_emad_sbib_reg {
    uint8_t  type;
    uint8_t  local_port;
    uint8_t  reserved1;
    uint8_t  int_buff_index;
    uint8_t  status;
    uint8_t  reserved2[3];
    uint32_t buff_size;
    uint8_t  reserved3[4];
} PACK_SUFFIX sxd_emad_sbib_reg_t;

#include <complib/cl_packoff.h>

#endif /* __SXD_EMAD_SPAN_REG_H__ */
