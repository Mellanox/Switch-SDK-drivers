/*
 *  Copyright (C) 2010-2021. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */


#ifndef __SX_DEV_H__
#define __SX_DEV_H__

#include "sx/sdk/auto_headers/sx_dev_auto.h"

/************************************************
 *  Macro definitions
 ***********************************************/

#define SX_DEVICE_ID_MIN     SXD_DEV_ID_MIN
#define SX_DEVICE_ID_MAX     SXD_DEV_ID_MAX
#define SX_DEVICE_ID_MIN_MAX SX_DEVICE_ID_MIN, SX_DEVICE_ID_MAX

/**
 * SX Device ID maximum/minimum values
 */
#define SX_DEV_ID_MIN        SXD_DEV_ID_MIN
#define SX_DEV_ID_MAX        SXD_DEV_ID_MAX
#define SX_DEVICE_ID_COUNT   SXD_DEV_ID_COUNT
#define SX_DEV_NUM_MAX       (SX_DEV_ID_MAX + 1)
#define SX_DEV_ID_DEFAULT    (0)
#define SX_DEVICE_ID_DEFAULT SX_DEV_ID_DEFAULT

#define SX_DEV_NODE_TYPE_DEFAULT SX_DEV_NODE_TYPE_LEAF
#define SX_DEV_NODE_TYPE_MIN_MAX SX_DEV_NODE_TYPE_MIN, SX_DEV_NODE_TYPE_MAX

/**
 * SX Device number of Ports maximum/minimum values
 */
#define SX_DEV_PORTS_NUM_MIN 32
#define SX_DEV_PORTS_NUM_MAX (RM_API_HOST_IFC_NUM_MAX)


#define SX_DEVICE_ID_CHECK_RANGE(device_id) (SX_CHECK_RANGE(SX_DEVICE_ID_MIN, device_id, SX_DEVICE_ID_MAX))
#define SX_DEV_NODE_TYPE_CHECK_RANGE(node)  (SX_CHECK_RANGE(SX_DEV_NODE_TYPE_MIN, (int)node, SX_DEV_NODE_TYPE_MAX))
#define SX_DEV_ID_CHECK_RANGE(DEV_ID)       SX_CHECK_RANGE(SX_DEV_ID_MIN, DEV_ID, SX_DEV_ID_MAX)

#endif /* __SX_DEV_H__ */
