/*
 *  Copyright (C) 2014-2021. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */

#ifndef __SX_BULK_COUNTER_H__
#define __SX_BULK_COUNTER_H__

#include <sx/sxd/kernel_user.h>
#include <sx/sdk/auto_headers/sx_port_id_auto.h>
#include <sx/sdk/auto_headers/sx_bulk_counter_auto.h>
#include <resource_manager/resource_manager.h>
#include <sx/sdk/sx_port.h>

#define SX_BULK_CNTR_PG_NUM   SXD_BULK_CNTR_PG_NUM
#define SX_BULK_CNTR_TC_NUM   SXD_BULK_CNTR_TC_NUM
#define SX_BULK_CNTR_POOL_NUM SXD_BULK_CNTR_POOL_NUM
#define SX_BULK_CNTR_SP_NUM   SXD_BULK_CNTR_SP_NUM

#define SX_BULK_CNTR_TOTAL_POOL_MAX_NUM SXD_BULK_CNTR_TOTAL_POOL_MAX_NUM

typedef sxd_bulk_cntr_buffer_layout_common_t sx_bulk_cntr_buffer_layout_common_t;
typedef sxd_bulk_cntr_buffer_layout_flow_t sx_bulk_cntr_buffer_layout_flow_t;

typedef struct sx_bulk_cntr_read_key_port {
    sx_bulk_cntr_port_grp_e grp; /**< Counter-set of port counters */
    sx_port_log_id_t        log_port; /**< Port ID */
    union {
        sx_cos_ieee_prio_t      prio_id; /**< Priority ID (in use only when grp is SX_BULK_PORT_CNTR_GRP_PRIO_E) */
        sx_port_tc_id_t         tc_id; /**< TC ID (in use only when grp is SX_BULK_PORT_CNTR_GRP_TC_E) */
        sx_cos_priority_group_t prio_group; /**< Priority group (in use only when grp is SX_BULK_PORT_CNTR_GRP_BUFF_E) */
    } grp_ex_param;
} sx_bulk_cntr_read_key_port_t;

typedef struct sx_bulk_cntr_read_key_flow {
    sx_flow_counter_id_t cntr_id; /**< Flow counter ID */
} sx_bulk_cntr_read_key_flow_t;

typedef struct sx_bulk_cntr_read_key_shared_buffer {
    sx_bulk_cntr_shared_buffer_attr_type_e type;        /**< Shared buffer counter attribute type */
    union {
        sx_port_log_id_t log_port;                      /**< Port ID, physical port supported only.
                                                         * (in use when attr is SX_BULK_CNTR_SHARED_BUFFER_PORT_ATTR_E
                                                         * or SX_BULK_CNTR_SHARED_BUFFER_MULTICAST_PORT_ATTR_E) */
    } attr;
} sx_bulk_cntr_read_key_shared_buffer_t;

typedef struct sx_bulk_cntr_read_key_headroom {
    sx_port_log_id_t log_port;                        /**< Port ID, physical port supported only */
} sx_bulk_cntr_read_key_headroom_t;

typedef struct sx_bulk_cntr_read_key {
    sx_bulk_cntr_key_type_e type; /**< Type of counter to get */
    union {
        sx_bulk_cntr_read_key_port_t          port_key;          /**< Port counter key */
        sx_bulk_cntr_read_key_flow_t          flow_key;          /**< Flow counter key */
        sx_bulk_cntr_read_key_shared_buffer_t shared_buffer_key; /**< Shared buffer counters key */
        sx_bulk_cntr_read_key_headroom_t      headroom_key;      /**< Headroom counters key */
        sx_bulk_cntr_read_key_elephant_t      elephant_key;      /**< Detected elephant flow key */
    } key;
} sx_bulk_cntr_read_key_t;

typedef struct sx_bulk_cntr_shared_buffer_pool_statistic {
    sx_cos_pool_id_t        pool_id;
    uint32_t                reserved;
    sx_cos_buff_statistic_t statistics;
} sx_bulk_cntr_shared_buffer_pool_statistic_t;

typedef struct sx_bulk_cntr_shared_buffer_port {
    sx_cos_buff_statistic_t                     port_pg[SX_BULK_CNTR_PG_NUM];             /**< Use PG as index, PG8 is reserved */
    sx_cos_buff_statistic_t                     port_tc[SX_BULK_CNTR_TC_NUM];             /**< Use TC as index */
    sx_bulk_cntr_shared_buffer_pool_statistic_t ingress_port[SX_BULK_CNTR_POOL_NUM];      /**< Pool ID is stated within the data.
                                                                                           * Pool ID SX_COS_POOL_ID_INVALID is used to
                                                                                           * mark end of list */
    sx_bulk_cntr_shared_buffer_pool_statistic_t egress_port[SX_BULK_CNTR_POOL_NUM];       /**< Pool ID is stated within the data.
                                                                                           * Pool ID SX_COS_POOL_ID_INVALID is used to
                                                                                           * mark end of list */
    sx_cos_buff_statistic_t                     port_pg_desc[SX_BULK_CNTR_PG_NUM];        /**< Use PG as index, PG8 is reserved */
    sx_cos_buff_statistic_t                     port_tc_desc[SX_BULK_CNTR_TC_NUM];        /**< Use TC as index */
    sx_bulk_cntr_shared_buffer_pool_statistic_t ingress_port_desc[SX_BULK_CNTR_POOL_NUM]; /**< Pool ID is stated within the data.
                                                                                           * Pool ID SX_COS_POOL_ID_INVALID is used to
                                                                                           * mark end of list */
    sx_bulk_cntr_shared_buffer_pool_statistic_t egress_port_desc[SX_BULK_CNTR_POOL_NUM];  /**< Pool ID is stated within the data.
                                                                                           * Pool ID SX_COS_POOL_ID_INVALID is used to
                                                                                           * mark end of list */
} sx_bulk_cntr_shared_buffer_port_t;

typedef struct sx_bulk_cntr_shared_buffer_mc_switch_prio {
    sx_cos_buff_statistic_t statistics[SX_BULK_CNTR_SP_NUM];    /**< Use switch priority as index */
} sx_bulk_cntr_shared_buffer_mc_switch_prio_t;

typedef struct sx_bulk_cntr_shared_buffer_mc_port {
    sx_cos_buff_statistic_t statistics;
} sx_bulk_cntr_shared_buffer_mc_port_t;

typedef struct sx_bulk_cntr_shared_buffer_pool {
    sx_bulk_cntr_shared_buffer_pool_statistic_t statistics[SX_BULK_CNTR_TOTAL_POOL_MAX_NUM];  /**< Pool ID is stated within the data.
                                                                                               * Pool ID SX_COS_POOL_ID_INVALID is used to
                                                                                               * mark end of list */
} sx_bulk_cntr_shared_buffer_pool_t;

typedef struct sx_bulk_cntr_occupancy_statistics_list {
    uint64_t                cnt;                                    /**< Indicates how many instances of statistics were returned */
    sx_cos_buff_statistic_t statistics[SX_COS_PORT_BUFF_NUM_MAX_E]; /**< Used for 8x lanes interface, since there we have two buffers,
                                                                     * supported on Spectrum2 and Spectrum3 */
} sx_bulk_cntr_occupancy_statistics_list_t;

typedef struct sx_bulk_cntr_headroom_statistic {
    sx_cos_buff_statistic_t                  statistics;
    sx_bulk_cntr_occupancy_statistics_list_t occupancy_statistics_lst;
} sx_bulk_cntr_headroom_statistic_t;

typedef struct sx_bulk_cntr_headroom_t {
    sx_bulk_cntr_headroom_statistic_t port_pg[SX_BULK_CNTR_PG_NUM];  /**< Use priority group as index, PG8 is reserved */
    sx_bulk_cntr_headroom_statistic_t port_shared_buffer;
    sx_cos_buff_statistic_t           port_shared_headroom_pool_usage;     /**< Usage of the shared headroom pool.
                                                                            * Not supported on Spectrum2, Spectrum3
                                                                            * Note: watermark is not supported. */
} sx_bulk_cntr_headroom_t;

typedef struct sx_bulk_cntr_data {
    union {
        union {
            const sx_port_cntr_ieee_802_dot_3_t       *port_cntr_ieee_802_p;    /**< IEEE 802.3 counters entry */
            const sx_port_cntr_rfc_2863_t             *port_cntr_rfc_2863_p;    /**< RFC 2863 counters entry */
            const sx_port_cntr_rfc_2819_t             *port_cntr_rfc_2819_p;    /**< RFC 2819 counters entry */
            const sx_port_cntr_rfc_3635_t             *port_cntr_rfc_3635_p;    /**< RFC 3635 counters entry */
            const sx_port_cntr_prio_t                 *port_cntr_prio_p;    /**< Priority counters entry */
            const sx_port_traffic_cntr_t              *port_cntr_tc_p;    /**< Per TC counters */
            const sx_port_cntr_buff_t                 *port_cntr_buff_p;    /**< Buffer counters entry */
            const sx_port_cntr_perf_t                 *port_cntr_perf_p;    /**< Performance counters entry */
            const sx_port_cntr_discard_t              *port_cntr_discard_p;    /**< Discard counters entry */
            const sx_port_cntr_phy_layer_t            *port_cntr_phy_p;    /**< Phy layer counters entry */
            const sx_port_cntr_phy_layer_statistics_t *port_cntr_phy_stats_p;    /**< Phy layer stats counters entry */
        } port_counters;
        union {
            const sx_flow_counter_set_t *flow_cntr_p; /**< Flow counter */
        } flow_counters;
        union {
            const sx_bulk_cntr_shared_buffer_port_t           *port_p;
            const sx_bulk_cntr_shared_buffer_mc_port_t        *mc_port_p;
            const sx_bulk_cntr_shared_buffer_mc_switch_prio_t *mc_switch_prio_p;
            const sx_bulk_cntr_shared_buffer_pool_t           *pool_p;
        } shared_buffer_counters;
        union {
            const sx_bulk_cntr_headroom_t *headroom_p;
        } headroom_counters;
        union {
            const sx_cos_elephant_flow_ids_list_t *flow_id_list_p; /**< List of detected elephant flows per port */
            const sx_cos_elephant_flow_data_t     *elephant_flow_data_p; /**< Detected elephant flow data per port and flow ID */
        } elephant_flow_data;
    } data;
} sx_bulk_cntr_data_t;

#endif /* ifndef __SX_BULK_COUNTER_H__ */
