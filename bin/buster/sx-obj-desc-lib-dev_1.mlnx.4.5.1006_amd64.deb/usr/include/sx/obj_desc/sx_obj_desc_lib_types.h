/*
 * Copyright (C) Mellanox Technologies, Ltd. 2001-2020 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef SX_OBJ_DESC_LIB_TYPES_H
#define SX_OBJ_DESC_LIB_TYPES_H

#include <sx/sdk/sx_port.h>
#include <sx/sdk/sx_vlan.h>
#include <sx/sdk/sx_acl.h>
#include <sx/sdk/sx_fdb.h>
#include <sx/sdk/sx_span.h>
#include <sx/sdk/sx_bridge.h>

/**
 * sx_obj_desc_object_type_t
 * Enumerated type - Object type.
 */
typedef enum sx_obj_desc_object_type {
    SX_OBJ_DESC_OBJECT_TYPE_NONE_E     = 0,
    SX_OBJ_DESC_OBJECT_TYPE_ACL_E      = 1,
    SX_OBJ_DESC_OBJECT_TYPE_BRIDGE_E   = 2,
    SX_OBJ_DESC_OBJECT_TYPE_FDB_E      = 3,
    SX_OBJ_DESC_OBJECT_TYPE_PORT_LAG_E = 4,
    SX_OBJ_DESC_OBJECT_TYPE_ROUTER_E   = 5,
    SX_OBJ_DESC_OBJECT_TYPE_SPAN_E     = 6,
    SX_OBJ_DESC_OBJECT_TYPE_TUNNEL_E   = 7,
    SX_OBJ_DESC_OBJECT_TYPE_MIN_E      = SX_OBJ_DESC_OBJECT_TYPE_NONE_E,
    SX_OBJ_DESC_OBJECT_TYPE_NAX_E      = SX_OBJ_DESC_OBJECT_TYPE_TUNNEL_E,
} sx_obj_desc_object_type_t;

/**
 * sx_status_t
 * Enumerated type - Provides functions' return values.
 */
typedef enum sx_obj_desc_status {
    SX_OBJ_DESC_STATUS_SUCCESS,
    SX_OBJ_DESC_STATUS_ERROR,
    SX_OBJ_DESC_STATUS_PARAM_ERROR,
    SX_OBJ_DESC_STATUS_PARAM_NULL,
    SX_OBJ_DESC_STATUS_ENTRY_NOT_FOUND,
    SX_OBJ_DESC_STATUS_ENTRY_ALEADY_EXISTS,
    SX_OBJ_DESC_STATUS_NOT_INITIALIZED,
    SX_OBJ_DESC_STATUS_ALREADY_INITIALIZED,
    SX_OBJ_DESC_STATUS_NO_RESOURCES,
    SX_OBJ_DESC_STATUS_NO_MEMORY,
    SX_OBJ_DESC_STATUS_MEMORY_ERROR,
    SX_OBJ_DESC_STATUS_UNSUPPORTED,
    SX_OBJ_DESC_STATUS_MIN = SX_OBJ_DESC_STATUS_SUCCESS,
    SX_OBJ_DESC_STATUS_MAX = SX_OBJ_DESC_STATUS_UNSUPPORTED,
} sx_obj_desc_status_t;

/**
 * sx_obj_desc_access_cmd_t
 * Enumerated type - Access command.
 */
typedef enum sx_obj_desc_access_cmd {
    SX_OBJ_DESC_ACCESS_CMD_NONE,
    SX_OBJ_DESC_ACCESS_CMD_SET,
    SX_OBJ_DESC_ACCESS_CMD_UNSET,
    SX_OBJ_DESC_ACCESS_CMD_DELETE,
    SX_OBJ_DESC_ACCESS_CMD_DELETE_ALL,
    SX_OBJ_DESC_ACCESS_CMD_MIN = SX_OBJ_DESC_ACCESS_CMD_NONE,
    SX_OBJ_DESC_ACCESS_CMD_MAX = SX_OBJ_DESC_ACCESS_CMD_DELETE_ALL,
} sx_obj_desc_access_cmd_t;

/**
 * sx_obj_desc_lib_init_param_t structure is used to store the init params.
 */
typedef struct sx_obj_desc_lib_init_param {
    uint64_t reserved;
} sx_obj_desc_lib_init_param_t;

/**
 * sx_obj_desc_acl_obj_id_t structure is used to store acl object id.
 */
typedef struct sx_obj_desc_acl_obj_id {
    sx_acl_region_id_t   acl_region;
    sx_acl_rule_offset_t acl_rule_offset;
} sx_obj_desc_acl_obj_id_t;

/**
 * sx_obj_desc_acl_obj_id_t structure is used to store bridge object id.
 */
typedef struct sx_obj_desc_bridge_obj_id {
    sx_bridge_id_t bridge_id;
} sx_obj_desc_bridge_obj_id_t;

/**
 * sx_obj_desc_acl_obj_id_t structure is used to store fdb object id.
 */
typedef struct sx_obj_desc_fdb_obj_id {
    sx_fid_t fdb_fid;
} sx_obj_desc_fdb_obj_id_t;

/**
 * sx_obj_desc_acl_obj_id_t structure is used to store port object id.
 */
typedef struct sx_obj_desc_port_obj_id {
    sx_port_id_t port_id;
} sx_obj_desc_port_obj_id_t;

/**
 * sx_obj_desc_acl_obj_id_t structure is used to store router object id.
 */
typedef struct sx_obj_desc_router_obj_id {
    sx_router_id_t        vrid;
    sx_router_interface_t rif;
} sx_obj_desc_router_obj_id_t;

/**
 * sx_obj_desc_acl_obj_id_t structure is used to store span object id.
 */
typedef struct sx_obj_desc_span_obj_id {
    sx_span_session_id_t span_id;
} sx_obj_desc_span_obj_id_t;

/**
 * sx_obj_desc_acl_obj_id_t structure is used to store tunnel object id.
 */
typedef struct sx_obj_desc_tunnel_obj_id {
    sx_tunnel_id_t tunnel_id;
} sx_obj_desc_tunnel_obj_id_t;

/**
 * sx_obj_desc_object_key_t structure is used to store object key.
 */
typedef struct sx_obj_desc_object_key {
    sx_obj_desc_object_type_t key_type;
    union {
        sx_obj_desc_acl_obj_id_t    acl_obj_id;
        sx_obj_desc_bridge_obj_id_t bridge_obj_id;
        sx_obj_desc_fdb_obj_id_t    fdb_obj_id;
        sx_obj_desc_port_obj_id_t   port_lag_obj_id;
        sx_obj_desc_router_obj_id_t router_obj_id;
        sx_obj_desc_span_obj_id_t   span_obj_id;
        sx_obj_desc_tunnel_obj_id_t tunnel_obj_id;
    } obj_id;
} sx_obj_desc_object_key_t;

/**
 * sx_obj_desc_set_param_t structure is used to store object set parameters.
 */
typedef struct sx_obj_desc_set_param_t {
    sx_obj_desc_object_key_t obj_key;           /**< IN: Object key to set description of */
    char                    *obj_desc_p;        /**< IN: Object Desc */
    uint32_t                 obj_desc_len;      /**< IN: Object Desc Length */
} sx_obj_desc_set_param_t;

/**
 * sx_obj_desc_get_param_t structure is used to store object get parameters.
 * @ [IN] obj_key -
 */
typedef struct sx_obj_desc_get_param_t {
    sx_obj_desc_object_key_t obj_key;           /**< IN: Object key to set description of */
    char                    *obj_desc_p;        /**< IN/OUT: Pre-allocated by user */
    uint32_t                 obj_desc_len;      /**< IN/OUT: Length of obj_desc_p, return description actual length */
} sx_obj_desc_get_param_t;

#endif /* ifndef SX_OBJ_DESC_LIB_TYPES_H */
