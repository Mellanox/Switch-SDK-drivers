/*
 * Copyright (C) Mellanox Technologies, Ltd. 2001-2020 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef SX_OBJ_DESC_LIB_H
#define SX_OBJ_DESC_LIB_H

#include <stdint.h>
#include "sx_obj_desc_lib_types.h"

/**
 * This API init the sx object description library.
 *
 * @param[in] init_params          - init parameters
 * @return SX_OBJ_DESC_STATUS_SUCCESS if operation completes successfully
 * @return SX_OBJ_DESC_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return SX_OBJ_DESC_STATUS_ERROR for a general error
 */
sx_obj_desc_status_t sx_obj_desc_lib_init(sx_obj_desc_lib_init_param_t init_params);

/**
 * This API deinit the sx object description library.
 *
 * @return SX_OBJ_DESC_STATUS_SUCCESS if operation completes successfully
 * @return SX_OBJ_DESC_STATUS_ERROR for a general error
 */
sx_obj_desc_status_t sx_obj_desc_lib_deinit(void);

/**
 * This API sets the description of object.
 * SET on SET is not supported. If object is SET previously, must UNSET first to SET again.
 * The API user should make sure to only UNSET the object which is SET by it previously.
 *
 * @param[in] cmd                          - SX_OBJ_DESC_ACCESS_CMD_SET/SX_OBJ_DESC_ACCESS_CMD_UNSET
 * @param[in] obj_desc_set_params          - object description set parameter
 * @return SX_OBJ_DESC_STATUS_SUCCESS if operation completes successfully
 * @return SX_OBJ_DESC_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return SX_OBJ_DESC_STATUS_PARAM_NULL if an input parameter is NULL
 * @return SX_OBJ_DESC_STATUS_ERROR for a general error
 */
sx_obj_desc_status_t sx_obj_desc_lib_object_description_set(sx_obj_desc_access_cmd_t cmd,
                                                            sx_obj_desc_set_param_t  obj_desc_set_params);
/**
 * This API gets the description of object.
 *
 * @param[in/out] obj_desc_get_params_p      - object description get parameter
 * @return SX_OBJ_DESC_STATUS_SUCCESS if operation completes successfully
 * @return SX_OBJ_DESC_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return SX_OBJ_DESC_STATUS_PARAM_NULL if an input parameter is NULL
 * @return SX_OBJ_DESC_STATUS_ERROR for a general error
 */
sx_obj_desc_status_t sx_obj_desc_lib_object_description_get(sx_obj_desc_get_param_t *obj_desc_get_params_p);

/**
 * This API cleanup the objects with specific type or all objects.
 *
 * @param[in] cmd                        - SX_OBJ_DESC_ACCESS_CMD_DELETE/SX_OBJ_DESC_ACCESS_CMD_DELETE_ALL
 * @param[in] type                       - type
 * @return SX_OBJ_DESC_STATUS_SUCCESS if operation completes successfully
 * @return SX_OBJ_DESC_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return SX_OBJ_DESC_STATUS_PARAM_NULL if an input parameter is NULL
 * @return SX_OBJ_DESC_STATUS_ERROR for a general error
 */
sx_obj_desc_status_t sx_obj_desc_lib_object_description_cleanup(sx_obj_desc_access_cmd_t  cmd,
                                                                sx_obj_desc_object_type_t type);

/**
 * This API generate dump to the specified file path.
 *
 * @param[in] file_path                       - debug file path, use "/tmp/obj_desc_dump" as default if it's NULL.
 * @return SX_OBJ_DESC_STATUS_SUCCESS if operation completes successfully
 * @return SX_OBJ_DESC_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return SX_OBJ_DESC_STATUS_PARAM_NULL if an input parameter is NULL
 * @return SX_OBJ_DESC_STATUS_ERROR for a general error
 */
sx_obj_desc_status_t sx_obj_desc_lib_generate_dump(const char *file_path);

#endif /* SX_OBJ_DESC_LIB_H */
