/*
 *  Copyright (C) 2010-2021. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */


#ifndef __SX_MAC_H__
#define __SX_MAC_H__

#include <net/ethernet.h>
#include <complib/cl_types.h>

#include "sx/sdk/auto_headers/sx_mac_auto.h"


/************************************************
 *  Type definitions
 ***********************************************/


/************************************************
 *  Macro definitions
 ***********************************************/

/**
 * Convert sx_mac_addr_t structure to unsigned 64-bit value
 */
#define SX_MAC_TO_U64(mac_addr)                         \
    (((uint64_t)(mac_addr).ether_addr_octet[0] << 40) | \
     ((uint64_t)(mac_addr).ether_addr_octet[1] << 32) | \
     ((uint64_t)(mac_addr).ether_addr_octet[2] << 24) | \
     ((uint64_t)(mac_addr).ether_addr_octet[3] << 16) | \
     ((uint64_t)(mac_addr).ether_addr_octet[4] << 8) |  \
     ((uint64_t)(mac_addr).ether_addr_octet[5]))


#define SX_MAC_EQUAL(mac1, mac2) \
    (SX_MAC_TO_U64(mac1) == SX_MAC_TO_U64(mac2))

#define SX_MAC_CMPR(mac1, mac2) \
    (SX_MAC_TO_U64(mac1) - SX_MAC_TO_U64(mac2))

static sx_mac_addr_t reserved_mc_groups[] = {
    {
        {0x01, 0x00, 0x5e, 0x00, 0x00, 0x01}
    },                                  /* 224.0.0.1    All Hosts */
    {
        {0x01, 0x00, 0x5e, 0x00, 0x00, 0x02}
    },                                  /* 224.0.0.2    All Routers */
    {
        {0x01, 0x00, 0x5e, 0x00, 0x00, 0x03}
    },
    {
        {0x01, 0x00, 0x5e, 0x00, 0x00, 0x04}
    },                                 /* 224.0.0.4		The Distance Vector Multicast Routing Protocol (DVMRP) to address multicast routers */
    {
        {0x01, 0x00, 0x5e, 0x00, 0x00, 0x05}
    },                                 /* 224.0.0.5		The Open Shortest Path First (OSPF) All OSPF Routers address */
    {
        {0x01, 0x00, 0x5e, 0x00, 0x00, 0x06}
    },                                 /* 224.0.0.6		The OSPF All D Routers address */
    {
        {0x01, 0x00, 0x5e, 0x00, 0x00, 0x09}
    },                                 /* 224.0.0.9		The Routing Information Protocol (RIP) version 2 group address  */
    {
        {0x01, 0x00, 0x5e, 0x00, 0x00, 0x0a}
    },                                 /* 224.0.0.10	The Enhanced Interior Gateway Routing Protocol (EIGRP) group address  */
    {
        {0x01, 0x00, 0x5e, 0x00, 0x00, 0x0d}
    },                                 /* 224.0.0.13		Protocol Independent Multicast (PIM) Version 2 */
    {
        {0x01, 0x00, 0x5e, 0x00, 0x00, 0x12}
    },                                  /* 224.0.0.18		Virtual Router Redundancy Protocol (VRRP) */
    {
        {0x01, 0x00, 0x5e, 0x00, 0x00, 0x13}
    },                                 /* 224.0.0.19		IS-IS over IP */
    {
        {0x01, 0x00, 0x5e, 0x00, 0x00, 0x14}
    },                                 /* 224.0.0.20		IS-IS over IP */
    {
        {0x01, 0x00, 0x5e, 0x00, 0x00, 0x15}
    },                                 /* 224.0.0.21		IS-IS over IP */
    {
        {0x01, 0x00, 0x5e, 0x00, 0x00, 0x16}
    },                                 /* 224.0.0.22		Internet Group Management Protocol (IGMP) Version 3 */
    {
        {0x01, 0x00, 0x5e, 0x00, 0x00, 0x66}
    },                                 /* 224.0.0.102		Hot Standby Router Protocol version 2 (HSRPv2) / Gateway Load Balancing Protocol (GLBP) */
    {
        {0x01, 0x00, 0x5e, 0x00, 0x00, 0x6b}
    },                                 /* 224.0.0.107		Precision Time Protocol version 2 peer delay measurement messaging */
    {
        {0x01, 0x00, 0x5e, 0x00, 0x00, 0xfb}
    },                                 /* 224.0.0.251		Multicast DNS (mDNS) address */
    {
        {0x01, 0x00, 0x5e, 0x00, 0x00, 0xfc}
    },                                 /* 224.0.0.252		Link-local Multicast Name Resolution (LLMNR) address */
};

#define SX_FDB_MC_NUM_OF_RES_MC_GROUPS (sizeof(reserved_mc_groups) / sizeof(sx_mac_addr_t))

static inline int is_mac_reserved_mc(sx_mac_addr_t mc_group)
{
    unsigned int i;

    for (i = 0; i < SX_FDB_MC_NUM_OF_RES_MC_GROUPS; i++) {
        if (SX_MAC_EQUAL(mc_group, reserved_mc_groups[i]) == TRUE) {
            return TRUE;
        }
    }

    return FALSE;
}


#endif /* __SX_MAC_H__ */
