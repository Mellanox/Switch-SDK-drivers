/*
 * Copyright (C) Mellanox Technologies, Ltd. 2001-2019 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef SX_ACL_HELPER_H
#define SX_ACL_HELPER_H

#include <stdint.h>

typedef uint32_t sx_acl_helper_acl_id_t;
typedef uint64_t sx_acl_helper_rule_id_t;

typedef enum sx_acl_helper_status {
    SX_ACL_HELPER_STATUS_SUCCESS,
    SX_ACL_HELPER_STATUS_ERROR,
    SX_ACL_HELPER_STATUS_PARAM_ERROR,
    SX_ACL_HELPER_STATUS_PARAM_NULL,
    SX_ACL_HELPER_STATUS_ENTRY_NOT_FOUND,
    SX_ACL_HELPER_STATUS_NOT_INITIALIZED,
    SX_ACL_HELPER_STATUS_ALREADY_INITIALIZED,
    SX_ACL_HELPER_STATUS_NO_RESOURCES,
    SX_ACL_HELPER_STATUS_NO_MEMORY,
    SX_ACL_HELPER_STATUS_UNSUPPORTED,
} sx_acl_helper_status_t;

/**
 * This API init sx acl helper lib.
 *
 *
 * @return SX_ACL_HELPER_STATUS_SUCCESS if operation completes successfully
 * @return SX_ACL_HELPER_STATUS_ALREADY_INITIALIZED if it's already initialized
 * @return SX_ACL_HELPER_STATUS_ERROR for a general error
 */
sx_acl_helper_status_t sx_acl_helper_init(void);

/**
 * This API deinit sx acl helper lib.
 *
 *
 * @return SX_ACL_HELPER_STATUS_SUCCESS if operation completes successfully
 * @return SX_ACL_HELPER_STATUS_NOT_INITIALIZED if it's not initialized yet
 * @return SX_ACL_HELPER_STATUS_ERROR for a general error
 */
sx_acl_helper_status_t sx_acl_helper_deinit(void);

/**
 * This API get acl description.
 *
 * @param[in] acl_id                - ACL id
 * @param[in] rule                  - ACL rule id
 * @param[in/out] acl_name_p        - ACL name string, allocated by user
 * @param[in/out] acl_name_len_p    - ACL name string length, output the actual length
 * @param[in/out] rule_p            - ACL rule string, allocated by user
 * @param[in/out] rule_len_p        - ACL rule string length, output the actual length
 *
 * If input acl_name_len_p is 0, will output acl_name_len_p only, not output acl_name_p
 * If input rule_len_p is 0, will output rule_len_p only, not output rule_p
 *
 * @return SX_ACL_HELPER_STATUS_SUCCESS if operation completes successfully
 * @return SX_ACL_HELPER_STATUS_PARAM_NULL if an input parameter is NULL
 * @return SX_ACL_HELPER_STATUS_ENTRY_NOT_FOUND if entry is not found
 * @return SX_ACL_HELPER_STATUS_ERROR for a general error
 */
sx_acl_helper_status_t sx_acl_helper_acl_description_get(sx_acl_helper_acl_id_t  acl_id,
                                                         sx_acl_helper_rule_id_t rule_id,
                                                         char                   *acl_name_p,
                                                         uint32_t               *acl_name_len_p,
                                                         char                   *rule_p,
                                                         uint32_t               *rule_len_p);

#define SX_ACL_HELPER_RULE_ID_BUILD(rule_id, region_id, rule_offset) \
    ((rule_id) |= ((uint64_t)(region_id) << 32));                    \
    ((rule_id) |= ((uint64_t)rule_offset))


#endif /* SX_ACL_HELPER_H */
