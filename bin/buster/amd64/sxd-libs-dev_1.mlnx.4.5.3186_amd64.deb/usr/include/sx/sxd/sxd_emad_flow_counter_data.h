/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_FLOW_COUNTER_DATA_H__
#define __SXD_EMAD_FLOW_COUNTER_DATA_H__

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_emad_common_data.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/**
 * sxd_emad_pfca_data_t structure is used to store PFCA register
 * data.
 */
typedef struct sxd_emad_pfca_data {
    sxd_emad_common_data_t common;
    struct ku_pfca_reg    *reg_data;
} sxd_emad_pfca_data_t;

/**
 * sxd_emad_pfcnt_data_t structure is used to store PFCNT register
 * data.
 */
typedef struct sxd_emad_pfcnt_data {
    sxd_emad_common_data_t common;
    struct ku_pfcnt_reg   *reg_data;
} sxd_emad_pfcnt_data_t;

/**
 * sxd_emad_mgpc_data_t structure is used to store MGPC register
 * data.
 */
typedef struct sxd_emad_mgpc_data {
    sxd_emad_common_data_t common;
    struct ku_mgpc_reg    *reg_data;
} sxd_emad_mgpc_data_t;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

#endif /* __SXD_EMAD_FLOW_COUNTER_DATA_H__ */
