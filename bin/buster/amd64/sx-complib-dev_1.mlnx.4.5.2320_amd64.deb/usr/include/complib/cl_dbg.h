/*
 * Copyright (c) 2004, 2005 Voltaire, Inc. All rights reserved.
 * Copyright (c) 2002-2005 Mellanox Technologies LTD. All rights reserved.
 * Copyright (c) 1996-2003 Intel Corporation. All rights reserved.
 *
 * This software is available to you under a choice of one of two
 * licenses.  You may choose to be licensed under the terms of the GNU
 * General Public License (GPL) Version 2, available from the file
 * COPYING in the main directory of this source tree, or the
 * OpenIB.org BSD license below:
 *
 *     Redistribution and use in source and binary forms, with or
 *     without modification, are permitted provided that the following
 *     conditions are met:
 *
 *      - Redistributions of source code must retain the above
 *        copyright notice, this list of conditions and the following
 *        disclaimer.
 *
 *      - Redistributions in binary form must reproduce the above
 *        copyright notice, this list of conditions and the following
 *        disclaimer in the documentation and/or other materials
 *        provided with the distribution.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
 * BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
 * ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */
/****h* Component Library/Debug
 * NAME
 *  Debug
 *
 * DESCRIPTION
 *  This module contains debugging tools for Component Library.
 *
 *  Current debug utilities supported:
 *      - Pool Database - track where are the memory spend through the SDK
 *      - Background processes Control - control(start/stop, change sleep time) threads
 *
 * SEE ALSO
 *  Structures:
 *      cl_dbg_pool_db_entry_t, cl_dbg_pool_db_bucket_t, cl_dbg_bp_ctl_db_entry_t
 *
 *  Initialization/Destruction:
 *      cl_dbg_pool_db_force_deinit, cl_dbg_bp_ctl_db_init, cl_dbg_bp_ctl_db_deinit,
 *      cl_dbg_bp_ctl_thread_register, cl_dbg_bp_ctl_thread_unregister,
 *
 *  Manipulation:
 *      cl_dbg_pool_db_insert, cl_dbg_pool_db_remove, cl_dbg_pool_db_bucket_apply,
 *      cl_dbg_bp_ctl_thread_sync, cl_dbg_bp_ctl_thread_lock_set, cl_dbg_bp_ctl_thread_mutable_set,
 *      cl_dbg_bp_ctl_thread_period_register, cl_dbg_bp_ctl_thread_period_set,
 *      cl_dbg_bp_ctl_thread_period_reset, cl_dbg_bp_ctl_thread_period_get,
 *      cl_dbg_bp_ctl_thread_period_us_get, cl_dbg_bp_ctl_thread_period_mod_get,
 *      cl_dbg_bp_ctl_db_apply
 *
 *  Wrappers:
 *      cl_qcpool_init_wrap, cl_qpool_init_wrap, cl_cpool_init_wrap, cl_pool_init_wrap,
 *      cl_qcpool_destroy_wrap, cl_qpool_destroy_wrap, cl_cpool_destroy_wrap, cl_pool_destroy_wrap
 *
 *  Attributes:
 *      cl_dbg_pool_db_get, cl_dbg_pool_db_spinlock_get, cl_dbg_bp_ctl_db_spinlock_get
 *********/

#ifndef _CL_POOL_DEBUG_H_
#define _CL_POOL_DEBUG_H_

#include <complib/cl_qcomppool.h>
#include <complib/cl_qpool.h>
#include <complib/cl_comppool.h>
#include <complib/cl_pool.h>
#include <complib/cl_fleximap.h>
#include <complib/cl_spinlock.h>
#include <complib/cl_event.h>

#ifdef __cplusplus
#  define BEGIN_C_DECLS extern "C" {
#  define END_C_DECLS   }
#else               /* !__cplusplus */
#  define BEGIN_C_DECLS
#  define END_C_DECLS
#endif              /* __cplusplus */

BEGIN_C_DECLS

/******************************************
* Defines
******************************************/

#define CL_DBG_THREAD_NAME_SIZE (16u)

#ifndef UNITTESTS
#define CL_QCPOOL_INIT(p_pool, min_size, max_size, grow_size, component_sizes, num_components,  \
                       pfn_initializer, pfn_destructor, context)                                \
    cl_qcpool_init_wrap(p_pool, min_size, max_size, grow_size, component_sizes, num_components, \
                        pfn_initializer, pfn_destructor, context, __FUNCTION__, __LINE__)
#else
#define CL_QCPOOL_INIT(p_pool, min_size, max_size, grow_size, component_sizes, num_components, \
                       pfn_initializer, pfn_destructor, context)                               \
    cl_qcpool_init(p_pool, min_size, max_size, grow_size, component_sizes, num_components,     \
                   pfn_initializer, pfn_destructor, context)
#endif

#ifndef UNITTESTS
#define CL_QPOOL_INIT(p_pool, min_size, max_size, grow_size, object_size, pfn_initializer,                  \
                      pfn_destructor, context)                                                              \
    cl_qpool_init_wrap(p_pool, min_size, max_size, grow_size, object_size, pfn_initializer, pfn_destructor, \
                       context, __FUNCTION__, __LINE__)
#else
#define CL_QPOOL_INIT(p_pool, min_size, max_size, grow_size, object_size, pfn_initializer, \
                      pfn_destructor, context)                                             \
    cl_qpool_init(p_pool, min_size, max_size, grow_size, object_size, pfn_initializer,     \
                  pfn_destructor, context)
#endif

#ifndef UNITTESTS
#define CL_CPOOL_INIT(p_pool, min_size, max_size, grow_size, component_sizes, num_components,  \
                      pfn_initializer, pfn_destructor, context)                                \
    cl_cpool_init_wrap(p_pool, min_size, max_size, grow_size, component_sizes, num_components, \
                       pfn_initializer, pfn_destructor, context, __FUNCTION__, __LINE__)
#else
#define CL_CPOOL_INIT(p_pool, min_size, max_size, grow_size, component_sizes, num_components, \
                      pfn_initializer, pfn_destructor, context)                               \
    cl_cpool_init(p_pool, min_size, max_size, grow_size, component_sizes, num_components,     \
                  pfn_initializer, pfn_destructor, context)
#endif

#ifndef UNITTESTS
#define CL_POOL_INIT(p_pool, min_size, max_size, grow_size, object_size, pfn_initializer,  \
                     pfn_destructor, context)                                              \
    cl_pool_init_wrap(p_pool, min_size, max_size, grow_size, object_size, pfn_initializer, \
                      pfn_destructor, context, __FUNCTION__, __LINE__)
#else
#define CL_POOL_INIT(p_pool, min_size, max_size, grow_size, object_size, pfn_initializer, \
                     pfn_destructor, context)                                             \
    cl_pool_init(p_pool, min_size, max_size, grow_size, object_size, pfn_initializer,     \
                 pfn_destructor, context)
#endif

#ifndef UNITTESTS
#define CL_QCPOOL_DESTROY(p_pool) cl_qcpool_destroy_wrap(p_pool)
#else
#define CL_QCPOOL_DESTROY(p_pool) cl_qcpool_destroy(p_pool)
#endif

#ifndef UNITTESTS
#define CL_QPOOL_DESTROY(p_pool) cl_qpool_destroy_wrap(p_pool)
#else
#define CL_QPOOL_DESTROY(p_pool) cl_qpool_destroy(p_pool)
#endif

#ifndef UNITTESTS
#define CL_CPOOL_DESTROY(p_pool) cl_cpool_destroy_wrap(p_pool)
#else
#define CL_CPOOL_DESTROY(p_pool) cl_cpool_destroy(p_pool)
#endif

#ifndef UNITTESTS
#define CL_POOL_DESTROY(p_pool) cl_pool_destroy_wrap(p_pool)
#else
#define CL_POOL_DESTROY(p_pool) cl_pool_destroy(p_pool)
#endif

/******************************************
* Typedefs
******************************************/
typedef struct _cl_dbg_pool_db_entry {
    cl_pool_item_t pool_item;
    cl_list_item_t list_item;
    cl_qcpool_t   *pool_p;
} cl_dbg_pool_db_entry_t;

typedef struct _cl_dbg_pool_db_bucket {
    cl_pool_item_t           pool_item;
    cl_fmap_item_t           map_item;
    cl_dbg_pool_db_map_key_t key;
    cl_qlist_t               list;
} cl_dbg_pool_db_bucket_t;

/****s* Component Library: Debug/cl_dbg_bp_ctl_db_entry_t
 * NAME
 *  cl_dbg_bp_ctl_db_entry_t
 *
 * DESCRIPTION
 *  Entry type in the Background processes Control Database. The structure contains
 *  all needed information and mechanisms to control the thread which the entry is representing
 *  in the Database.
 *
 *  The cl_dbg_bp_ctl_db_entry_t structure should be treated as opaque and should be
 *  manipulated only through the provided functions.
 *
 * SYNOPSIS
 */
typedef struct __cl_thread_db_entry {
    cl_pool_item_t pool_item;
    cl_list_item_t list_item;
    uint64_t       db_entry_id;
    pthread_t      thread_id;
    char (*thread_name_p)[CL_DBG_THREAD_NAME_SIZE];
    boolean_t  time_based;
    uint32_t  *default_interval_p;
    boolean_t  interval_is_set;
    uint32_t   interval;
    uint32_t   interval_mod;
    uint32_t   interval_div;
    boolean_t  mutable;
    boolean_t  is_muted;
    cl_event_t event;
} cl_dbg_bp_ctl_db_entry_t;
/*
 * FIELDS
 *  db_entry_id
 *      The unique ID specifically represents the entry in the Background processes Database.
 *
 *  thread_id
 *      The unique identifier that represents the thread on OS level.
 *
 *  thread_name_p
 *      Pointer to the thread name in the cl_thread_t structure.
 *
 *  time_based
 *      Marker that shows if the thread is based on sleep delays.
 *
 *  default_interval_p
 *      The pointer to the sleep interval variable configured by the user.
 *
 *  interval_is_set
 *      Marker that show if some value is set by cl_dbg_bp_ctl_thread_period_set API.
 *      By design it should be set form debug CLI.
 *
 *  interval
 *      The sleep interval set by user using cl_dbg_bp_ctl_thread_period_set. The value is not
 *      in uS. To get interval in uS you should multiply 'interval' by 'interval_div'.
 *
 *  interval_mod
 *      The sleep interval module from the division of user-configured time by interval_div.
 *      The value is in uS.
 *
 *  interval_div
 *      The value to sleep per one interval. The value is in uS.
 *
 *  mutable
 *      Marker that shows if the thread can be stopped(muted).
 *
 *  is_muted
 *      Marker that shows if the thread is stopped(muted) by the user.
 *
 *  event
 *      An event to wait before continuing. We start waiting for the event when the 'is_muted' marker is set.
 *      To continue, the event should be sent from the user.
 *
 * SEE ALSO
 *    Debug
 *********/

/******************************************
* Getters
******************************************/

/****f* Component Library: Debug/cl_dbg_pool_db_get
 * NAME
 *  cl_dbg_pool_db_get
 *
 * DESCRIPTION
 *  The cl_dbg_pool_db_get function returns a pointer to the Pool DB.
 *
 * SYNOPSIS
 */
cl_fmap_t * cl_dbg_pool_db_get(void);

/****f* Component Library: Debug/cl_dbg_pool_db_spinlock_get
 * NAME
 *  cl_dbg_pool_db_spinlock_get
 *
 * DESCRIPTION
 *  The cl_dbg_pool_db_spinlock_get function returns a pointer to the spinlock
 *  that protects the Pool DB.
 *
 * SYNOPSIS
 */
cl_spinlock_t * cl_dbg_pool_db_spinlock_get(void);

/******************************************
* Setters
******************************************/

/****f* Component Library: Debug/cl_dbg_pool_db_disable
 * NAME
 *  cl_dbg_pool_db_disable
 *
 * DESCRIPTION
 *  The cl_dbg_pool_db_disable function set the state of Pool DB to Force Deinit
 *
 * SYNOPSIS
 */
boolean_t cl_dbg_pool_db_disable(void);

/******************************************
* Pool DB API
******************************************/

/****f* Component Library: Debug/cl_dbg_pool_db_force_deinit
 * NAME
 *  cl_dbg_pool_db_force_deinit
 *
 * DESCRIPTION
 *  The cl_dbg_pool_db_force_deinit function clears the DB and call all destructors.
 *
 * SYNOPSIS
 */
void cl_dbg_pool_db_force_deinit(void);

/****f* Component Library: Debug/cl_dbg_pool_db_insert
 * NAME
 *  cl_dbg_pool_db_insert
 *
 * DESCRIPTION
 *  The cl_dbg_pool_db_insert function insert an entry into the Pool DB.
 *
 * SYNOPSIS
 */
cl_status_t cl_dbg_pool_db_insert(IN cl_qcpool_t *pool_p, IN const char *p_name, IN const uint32_t file_line);

/****f* Component Library: Debug/cl_dbg_pool_db_remove
 * NAME
 *  cl_dbg_pool_db_remove
 *
 * DESCRIPTION
 *  The cl_dbg_pool_db_remove function remove an entry from the Pool DB.
 *
 * SYNOPSIS
 */
cl_status_t cl_dbg_pool_db_remove(IN cl_qcpool_t * const pool_p);

/****f* Component Library: Debug/cl_dbg_pool_db_bucket_apply
 * NAME
 *  cl_dbg_pool_db_bucket_apply
 *
 * DESCRIPTION
 *  The cl_dbg_pool_db_bucket_apply function apply the the pfn_func to every bucket in the Pool DB.
 *
 * SYNOPSIS
 */
void cl_dbg_pool_db_bucket_apply(IN cl_pfn_fmap_apply_t pfn_func, IN const void *const context);

/******************************************
* Background processes thread DB API
******************************************/

/****f* Component Library: Debug/cl_dbg_bp_ctl_db_init
 * NAME
 *  cl_dbg_bp_ctl_db_init
 *
 * DESCRIPTION
 *  The cl_dbg_bp_ctl_db_init initialize the BP CTL database. This function should be called
 *  before any thread is created(with cl_thread_init).
 *
 * SYNOPSIS
 */
void cl_dbg_bp_ctl_db_init(void);

/****f* Component Library: Debug/cl_dbg_bp_ctl_db_deinit
 * NAME
 *  cl_dbg_bp_ctl_db_deinit
 *
 * DESCRIPTION
 *  The cl_dbg_bp_ctl_db_deinit deinitialize the BP CTL database. This function should be called
 *  after all threads are joined(with cl_thread_destroy).
 *
 * SYNOPSIS
 */
cl_status_t cl_dbg_bp_ctl_db_deinit(void);

/****f* Component Library: Debug/cl_dbg_bp_ctl_thread_register
 * NAME
 *  cl_dbg_bp_ctl_thread_register
 *
 * DESCRIPTION
 *  The cl_dbg_bp_ctl_thread_register add an entry to the BP CTL database for the current thread.
 *  The BP CTL database should be initialized. If it is not initialized, then the thread
 *  registration will be silently(with exit status CL_SUCCESS) skipped.
 *
 *  This function is thread-safe.
 *
 * SYNOPSIS
 */
cl_status_t cl_dbg_bp_ctl_thread_register(char (*thread_name_p)[CL_DBG_THREAD_NAME_SIZE]);

/****f* Component Library: Debug/cl_dbg_bp_ctl_thread_unregister
 * NAME
 *  cl_dbg_bp_ctl_thread_unregister
 *
 * DESCRIPTION
 *  The cl_dbg_bp_ctl_thread_unregister delete the entry for the current thread from
 *  the BP CTL database. The BP CTL database should be initialized. If it is not
 *  initialized, then the thread unregister will be silently(with exit status CL_SUCCESS)
 *  skipped.
 *
 *  This function is thread-safe.
 *
 * SYNOPSIS
 */
cl_status_t cl_dbg_bp_ctl_thread_unregister(void);

/****f* Component Library: Debug/cl_dbg_bp_ctl_db_entry_by_tid_get
 * NAME
 *  cl_dbg_bp_ctl_db_entry_by_tid_get
 *
 * DESCRIPTION
 *  The cl_dbg_bp_ctl_db_entry_by_tid_get gets the BP CTL database entry with the provided
 *  thread ID. The function expects that the BP CTL database is initialized. If there is no
 *  entry with such thread ID a NULL value is returned.
 *
 *  This function is not thread-safe.
 *
 * SYNOPSIS
 */
cl_dbg_bp_ctl_db_entry_t * cl_dbg_bp_ctl_db_entry_by_tid_get(pthread_t thread_id);

/****f* Component Library: Debug/cl_dbg_bp_ctl_db_entry_by_id_get
 * NAME
 *  cl_dbg_bp_ctl_db_entry_by_id_get
 *
 * DESCRIPTION
 *  The cl_dbg_bp_ctl_db_entry_by_id_get gets the BP CTL database entry with the provided
 *  BP CTL database entry ID (unique identifier in the DB). The function expects that
 *  the BP CTL database is initialized. If there is no entry with such entry ID a NULL value
 *  is returned.
 *
 *  This function is not thread-safe.
 *
 * SYNOPSIS
 */
cl_dbg_bp_ctl_db_entry_t * cl_dbg_bp_ctl_db_entry_by_id_get(uint64_t db_entry_id);

/****f* Component Library: Debug/cl_dbg_bp_ctl_thread_sync
 * NAME
 *  cl_dbg_bp_ctl_thread_sync
 *
 * DESCRIPTION
 *  The cl_dbg_bp_ctl_thread_sync is a breakpoint mechanism for the Background processes Control.
 *  Through flags in the cl_dbg_bp_ctl_db_entry_t structure for the current thread, we can lock the thread
 *  and make it wait on an event to continue.
 *
 *  The entry_pp is the pointer to a thread-local variable where a pointer to the BP CTL entry for
 *  current thread will be stored or is stored. This thread-local variable works like a cache.
 *  The aim of this variable is not to request the thread entry from the DB each iteration.
 *
 * SYNOPSIS
 */
void cl_dbg_bp_ctl_thread_sync(cl_dbg_bp_ctl_db_entry_t **entry_pp);

/****f* Component Library: Debug/cl_dbg_bp_ctl_db_lock
 * NAME
 *  cl_dbg_bp_ctl_db_lock
 *
 * DESCRIPTION
 *  The cl_dbg_bp_ctl_db_lock lock the BP CTL database spinlock.
 *  In other words: starts a critical section.
 *
 * SYNOPSIS
 */
void cl_dbg_bp_ctl_db_lock(void);

/****f* Component Library: Debug/cl_dbg_bp_ctl_db_unlock
 * NAME
 *  cl_dbg_bp_ctl_db_unlock
 *
 * DESCRIPTION
 *  The cl_dbg_bp_ctl_db_unlock unlock the BP CTL database spinlock.
 *  In other words: ends a critical section.
 *
 * SYNOPSIS
 */
void cl_dbg_bp_ctl_db_unlock(void);

/****f* Component Library: Debug/cl_dbg_bp_ctl_thread_lock_set
 * NAME
 *  cl_dbg_bp_ctl_thread_lock_set
 *
 * DESCRIPTION
 *  The cl_dbg_bp_ctl_thread_lock_set signals to the thread sync mechanism if the thread
 *  is mutable (configured with ability to stop on cl_dbg_bp_ctl_thread_sync):
 *    - lock = TRUE -> break the thread and wait for an event to continue
 *    - lock = FALSE -> continue from the break; send an event to the sync mechanism
 *
 *  The entry_p variable should be a valid pointer to the BP CTL database entry.
 *
 * SYNOPSIS
 */
void cl_dbg_bp_ctl_thread_lock_set(cl_dbg_bp_ctl_db_entry_t *entry_p, boolean_t lock);

/****f* Component Library: Debug/cl_dbg_bp_ctl_thread_mutable_set
 * NAME
 *  cl_dbg_bp_ctl_thread_mutable_set
 *
 * DESCRIPTION
 *  The cl_dbg_bp_ctl_thread_mutable_set configure the thread with ability to stop on
 *  cl_dbg_bp_ctl_thread_sync.
 *
 *  The entry_pp is the pointer to a local thread variable where a pointer to the BP CTL entry for
 *  current thread will be stored or is stored. This local thread variable works like a cache.
 *  The aim of this variable is not to request the thread entry from the DB each iteration.
 *
 *  This function is thread-safe.
 *
 * SYNOPSIS
 */
void cl_dbg_bp_ctl_thread_mutable_set(cl_dbg_bp_ctl_db_entry_t **entry_p, boolean_t mutable);

/****f* Component Library: Debug/cl_dbg_bp_ctl_thread_mutable_set
 * NAME
 *  cl_dbg_bp_ctl_thread_mutable_set
 *
 * DESCRIPTION
 *  The cl_dbg_bp_ctl_thread_mutable_set configure the thread with ability to change thread sleep
 *  time.
 *
 *  This function is thread-safe.
 *
 *  The entry_pp is the pointer to a thread-local variable where a pointer to the BP CTL entry for
 *  current thread will be stored or is stored. This thread-local variable works like a cache.
 *  The aim of this variable is not to request the thread entry from the DB each iteration.
 *
 *  The default_interval_p pointer to a global variable with sleep interval value that can be
 *  configured by the SDK API or contains a static interval value.
 *
 *  The interval_div is the granularity of the interval sleep time. The value is in uS.
 *
 * SYNOPSIS
 */
void cl_dbg_bp_ctl_thread_period_register(cl_dbg_bp_ctl_db_entry_t **entry_pp, uint32_t *default_interval_p,
                                          uint32_t interval_div);

/****f* Component Library: Debug/cl_dbg_bp_ctl_thread_period_set
 * NAME
 *  cl_dbg_bp_ctl_thread_period_set
 *
 * DESCRIPTION
 *  The cl_dbg_bp_ctl_thread_period_set sets the sleep period per thread cycle if the thread
 *  is configured as time-based (with cl_dbg_bp_ctl_thread_period_register function).
 *  IMPORTANT: after using this function is required to call cl_dbg_bp_ctl_thread_period_reset
 *             for this entry to reset the sleep configuration.
 *
 *  The entry_p should be a valid pointer to the BP CTL database entry.
 *
 *  The period value is in uS.
 *
 * SYNOPSIS
 */
void cl_dbg_bp_ctl_thread_period_set(cl_dbg_bp_ctl_db_entry_t *entry_p, uint32_t period);

/****f* Component Library: Debug/cl_dbg_bp_ctl_thread_period_set
 * NAME
 *  cl_dbg_bp_ctl_thread_period_set
 *
 * DESCRIPTION
 *  The cl_dbg_bp_ctl_thread_period_set resets the sleep period per thread cycle to the SDK API
 *  configured values.
 *  IMPORTANT: This function should be used to restore config after cl_dbg_bp_ctl_thread_period_set call.
 *
 *  The entry_p should be a valid pointer to the BP CTL database entry.
 *
 * SYNOPSIS
 */
void cl_dbg_bp_ctl_thread_period_reset(cl_dbg_bp_ctl_db_entry_t *entry_p);

/****f* Component Library: Debug/cl_dbg_bp_ctl_thread_period_get
 * NAME
 *  cl_dbg_bp_ctl_thread_period_get
 *
 * DESCRIPTION
 *  The cl_dbg_bp_ctl_thread_period_get return the sleep interval per thread cycle.
 *
 *  Flows:
 *     - If the entry_p is NULL or the BP CTL database is not initialized the function
 *       will return default_period.
 *     - If the sleep period is set with cl_dbg_bp_ctl_thread_period_set it will return that value.
 *     - If the sleep period is not set with cl_dbg_bp_ctl_thread_period_set or is reset with
 *       cl_dbg_bp_ctl_thread_period_reset than it will return the SDK API configured value.
 *
 * SYNOPSIS
 */
uint32_t cl_dbg_bp_ctl_thread_period_get(cl_dbg_bp_ctl_db_entry_t *entry_p, uint32_t default_period);

/****f* Component Library: Debug/cl_dbg_bp_ctl_thread_period_us_get
 * NAME
 *  cl_dbg_bp_ctl_thread_period_us_get
 *
 * DESCRIPTION
 *  The cl_dbg_bp_ctl_thread_period_us_get return the sleep interval multiplied by granularity
 *  of the interval. We get the sleeping time in uS.
 *
 *  The entry_p should be a valid pointer to the BP CTL database entry.
 *
 *  Flows:
 *     - If the sleep period is set with cl_dbg_bp_ctl_thread_period_set it will return that value.
 *     - If the sleep period is not set with cl_dbg_bp_ctl_thread_period_set or is reset with
 *       cl_dbg_bp_ctl_thread_period_reset than it will return the SDK API configured value.
 *
 * SYNOPSIS
 */
uint32_t cl_dbg_bp_ctl_thread_period_us_get(cl_dbg_bp_ctl_db_entry_t *entry_p);

/****f* Component Library: Debug/cl_dbg_bp_ctl_thread_period_mod_get
 * NAME
 *  cl_dbg_bp_ctl_thread_period_mod_get
 *
 * DESCRIPTION
 *  The cl_dbg_bp_ctl_thread_period_mod_get return the module of the set sleep time divided
 *  by granularity time.
 *
 *  The return value is in uS.
 *
 *  Flows:
 *     - If the sleep period is set with cl_dbg_bp_ctl_thread_period_set it will return 0.
 *     - If the sleep period is set with cl_dbg_bp_ctl_thread_period_set it will return module
 *       of the sleep time divided by granularity time.
 *     - If the sleep period is not set with cl_dbg_bp_ctl_thread_period_set or is reset with
 *       cl_dbg_bp_ctl_thread_period_reset than it will return 0.
 *
 * SYNOPSIS
 */
uint32_t cl_dbg_bp_ctl_thread_period_mod_get(cl_dbg_bp_ctl_db_entry_t *entry_p);

/****f* Component Library: Debug/cl_dbg_bp_ctl_db_apply
 * NAME
 *  cl_dbg_bp_ctl_db_apply
 *
 * DESCRIPTION
 *  The cl_dbg_bp_ctl_db_apply apply the pfn_func function to each BP CTL DB entry.
 *  The BP CTL database should be initialized.
 *
 *  This function is not thread-safe.
 *
 * SYNOPSIS
 */
void cl_dbg_bp_ctl_db_apply(cl_pfn_qlist_apply_t pfn_func, const void *const context);

/******************************************
* Wrappers
******************************************/
cl_status_t cl_qcpool_init_wrap(IN cl_qcpool_t * const                  p_pool,
                                IN const size_t                         min_size,
                                IN const size_t                         max_size,
                                IN const size_t                         grow_size,
                                IN const size_t * const                 component_sizes,
                                IN const uint32_t                       num_components,
                                IN cl_pfn_qcpool_init_t pfn_initializer OPTIONAL,
                                IN cl_pfn_qcpool_dtor_t pfn_destructor  OPTIONAL,
                                IN const void *const                    context,
                                IN const char                         * func_name,
                                IN const uint32_t                       file_line);

cl_status_t cl_qpool_init_wrap(IN cl_qpool_t * const                  p_pool,
                               IN const size_t                        min_size,
                               IN const size_t                        max_size,
                               IN const size_t                        grow_size,
                               IN const size_t                        object_size,
                               IN cl_pfn_qpool_init_t pfn_initializer OPTIONAL,
                               IN cl_pfn_qpool_dtor_t pfn_destructor  OPTIONAL,
                               IN const void *const                   context,
                               IN const char                        * func_name,
                               IN const uint32_t                      file_line);

cl_status_t cl_cpool_init_wrap(IN cl_cpool_t * const                  p_pool,
                               IN const size_t                        min_size,
                               IN const size_t                        max_size,
                               IN const size_t                        grow_size,
                               IN size_t * const                      component_sizes,
                               IN const uint32_t                      num_components,
                               IN cl_pfn_cpool_init_t pfn_initializer OPTIONAL,
                               IN cl_pfn_cpool_dtor_t pfn_destructor  OPTIONAL,
                               IN const void *const                   context,
                               IN const char                        * func_name,
                               IN const uint32_t                      file_line);

cl_status_t cl_pool_init_wrap(IN cl_pool_t * const                  p_pool,
                              IN const size_t                       min_size,
                              IN const size_t                       max_size,
                              IN const size_t                       grow_size,
                              IN const size_t                       object_size,
                              IN cl_pfn_pool_init_t pfn_initializer OPTIONAL,
                              IN cl_pfn_pool_dtor_t pfn_destructor  OPTIONAL,
                              IN const void *const                  context,
                              IN const char                       * func_name,
                              IN const uint32_t                     file_line);

void cl_qcpool_destroy_wrap(IN cl_qcpool_t * const p_pool);

void cl_qpool_destroy_wrap(IN cl_qpool_t * const p_pool);

void cl_cpool_destroy_wrap(IN cl_cpool_t * const p_pool);

void cl_pool_destroy_wrap(IN cl_pool_t * const p_pool);

END_C_DECLS
#endif              /* _CL_POOL_DEBUG_H_ */
