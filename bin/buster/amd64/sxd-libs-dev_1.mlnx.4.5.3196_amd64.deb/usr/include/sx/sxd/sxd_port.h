/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_PORT_H__
#define __SXD_PORT_H__

#include <complib/cl_types.h>
#include <sx/sxd/sxd_check.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

#define SXD_PORT_TUNING_OVERRIDE_ENABLE (1)

/* ******************************* */
/* EMAD port definitions          */
/* ******************************* */
#define SXD_PORT_PBMC_NUM_BUFF 10
#define SXD_PORT_PPCNT_MAX_CNT_NUM                      \
    (sizeof(((struct ku_ppcnt_reg*)(0))->counter_set) / \
     sizeof(uint64_t))
#define SXD_PORT_PPCNT_CNTR_GRP_IB_PORT_CNTRS                 0x20
#define SXD_PORT_PPCNT_CNTR_GRP_IB_PORT_CNTRS_EXTENDED        0x21
#define SXD_PORT_PPCNT_CNTR_GRP_IB_PORT_RCV_ERR               0x22
#define SXD_PORT_PPCNT_CNTR_GRP_IB_PORT_XMIT_DISCARD          0x23
#define SXD_PORT_PPCNT_CNTR_GRP_IB_PORT_FLOW_CTL_CNTRS        0x24
#define SXD_PORT_PPCNT_CNTR_GRP_IB_PORT_VL_XMIT_WAIT_CNTRS    0x25
#define SXD_PORT_PPCNT_CNTR_GRP_IB_PORT_SW_PORT_VL_CONGESTION 0x26

/* ****************************************************** */
/* Module Power mode definitions           */
/* ****************************************************** */
#define SXD_PMMP_MODULE_LOW_POWER_BIT  8
#define SXD_MCION_LOW_POWER_STATUS_BIT 8
#define SXD_MCION_MODULE_PRESENT_BIT   0

/* ****************************************************** */
/* EMAD PMAOS EVENT and ADMIN STATE definitions           */
/* ****************************************************** */
#define SXD_PMAOS_EVENT_ENABLE        1
#define SXD_PMAOS_EVENT_DISABLE       0
#define SXD_PMAOS_ADMIN_STATE_ENABLE  1
#define SXD_PMAOS_ADMIN_STATE_DISABLE 0


/************************************************
 *  Type definitions
 ***********************************************/

/* Port System ID:
 *****************
 * Physical entity, that represents the HW's a destination port in the GLOBAL system:
 ************************************************************************************
 * +--------------------------------------------------------------------------------+
 * |                                 Port-Sys-ID[15:0]                              |
 * +--------------------------------------------------------------------------------+
 ************************************************************************************
 */
typedef uint16_t sxd_port_sys_id_t;

/* Port Physical ID:
 *******************
 * Physical entity, that represents the port's actual ID in the LOCAL (device) system
 ************************************************************************************
 * +--------------------------------------------------------------------------------+
 * |                                 Port-Phy-ID[9:0]                               |
 * +--------------------------------------------------------------------------------+
 ************************************************************************************
 */
typedef uint16_t sxd_port_phy_id_t;

/**
 *  Module ID
 */
typedef uint8_t sxd_port_mod_id_t;

/**
 *  Slot ID - slot identifier, 0 - 1U systems, 1 to N - Modular systems.
 */
typedef uint8_t sxd_slot_id_t;

/**
 * sxd_port_status_t enumerated type is used to store port
 * status.
 */
typedef enum sxd_port_status {
    SXD_PORT_STATUS_UP      = (1 << 0),
    SXD_PORT_STATUS_DOWN    = (1 << 1),
    SXD_PORT_STATUS_FAILURE = (1 << 2),
} sxd_port_status_t;


/**
 * sxd_port_oper_status_t enumerated type is used to store port
 * operational status.
 */
typedef enum sxd_port_oper_status {
    SXD_PORT_OPER_STATUS_UP           = (1 << 0),
    SXD_PORT_OPER_STATUS_DOWN         = (1 << 1),
    SXD_PORT_OPER_STATUS_DOWN_BY_FAIL = (1 << 2),
} sxd_port_oper_status_t;


/**
 * sxd_port_event_generate_mode_t enumerated type is used to store port
 * generate event mode.
 */
typedef enum sxd_port_event_generate_mode {
    SXD_PORT_EVENT_GENERATE_MODE_DONT            = 0,
    SXD_PORT_EVENT_GENERATE_MODE_GENERATE        = 1,
    SXD_PORT_EVENT_GENERATE_MODE_GENERATE_SINGLE = 2
} sxd_port_event_generate_mode_t;

#define SX_PORT_CAPABILITIES_32B_MASK 4

/**
 * sxd_port_prio_id_buff_t enumerated type is used to store
 * buffer priority id
 */
typedef enum sxd_port_prio_id_buff {
    SXD_PORT_PRIORITY_0_BUFFER = (0),
    SXD_PORT_PRIORITY_1_BUFFER = (1),
    SXD_PORT_PRIORITY_2_BUFFER = (2),
    SXD_PORT_PRIORITY_3_BUFFER = (3),
    SXD_PORT_PRIORITY_4_BUFFER = (4),
    SXD_PORT_PRIORITY_5_BUFFER = (5),
    SXD_PORT_PRIORITY_6_BUFFER = (6),
    SXD_PORT_PRIORITY_7_BUFFER = (7),
    SXD_PORT_PRIORITY_8_BUFFER = (8),
    SXD_PORT_PRIORITY_9_BUFFER = (9),
} sxd_port_prio_id_buff_t;

/**
 * sxd_mask_t enumerated type is used to store mask
 */
typedef enum sxd_mask {
    SXD_VALID,
    SXD_INVALID,
} sxd_mask_t;

/**
 * sxd_port_policer_bind_operation_t enumerated type is used to store port
 * policer bind operation.
 */
typedef enum sxd_port_policer_bind_operation {
    SXD_PORT_POLICER_BIND   = 0,
    SXD_PORT_POLICER_UPDATE = 1,
    SXD_PORT_POLICER_UNBIND = 2,
} sxd_port_policer_bind_operation_t;

/**
 * sxd_port_ib_proto_speed_bit_t enumerated type is used to store the infiniband port
 * speed bit offset for each possible speed, as configured in PTYS register
 */
typedef enum sxd_port_ib_proto_speed_bit {
    SXD_PORT_IB_PROTO_SPEED_SDR   = 0,
    SXD_PORT_IB_PROTO_SPEED_DDR   = 1,
    SXD_PORT_IB_PROTO_SPEED_QDR   = 2,
    SXD_PORT_IB_PROTO_SPEED_FDR10 = 3,
    SXD_PORT_IB_PROTO_SPEED_FDR   = 4,
    SXD_PORT_IB_PROTO_SPEED_EDR   = 5,
} sxd_port_ib_proto_speed_bit_t;

/**
 * sxd_port_ib_proto_width_bit_t enumerated type is used to store the infiniband port
 * width bit offset for each possible width as configured in PTYS register
 */
typedef enum sxd_port_ib_proto_width_bit {
    SXD_PORT_IB_PROTO_WIDTH_1X = 0,
    SXD_PORT_IB_PROTO_WIDTH_4X = 2,
} sxd_port_ib_proto_width_bit_t;

/**
 * sxd_port_profile_mode_t enumerated type is used to store port
 * profile mode.
 */
typedef enum sxd_port_profile_mode {
    SXD_PORT_TYPE_BASED_PROFILE    = (1 << 0),
    SXD_PORT_LEGACY_IBSPEC_PROFILE = (1 << 1),
} sxd_port_profile_mode_t;


/**
 * sxd_port_fec_mode_t enumerated type is used to store port
 * FEC mode.
 */
typedef enum sxd_port_fec_mode {
    SXD_PORT_AUTO_FEC     = 0,
    SXD_PORT_NO_FEC       = (1 << 0), /* bitmap - 4 bits fields */
    SXD_PORT_FIRECODE_FEC = (1 << 1),
    SXD_PORT_RS_FEC       = (1 << 2),
    SXD_PORT_LL_RS_FEC    = (1 << 3),
    SXD_PORT_RS_FEC_16    = (1 << 7), /* New bitmap - 16 bits fields */
    SXD_PORT_LL_RS_FEC_16 = (1 << 9),
} sxd_port_fec_mode_t;

/**
 * This enum is used to store real HW values which indicate
 * actual link side we are going to use
 */
typedef enum sxd_port_link_side {
    SXD_PORT_LINK_SIDE_EXTERNAL_E      = 0,
    SXD_PORT_LINK_SIDE_INTERNAL_NEAR_E = 4,
    SXD_PORT_LINK_SIDE_INTERNAL_FAR_E  = 5
} sxd_port_link_side_e;

/**
 * This enum is used to store HW counters groups values
 */
typedef enum sxd_port_cntr_grp {
    SXD_PORT_CNTR_GRP_IEEE_802_DOT_3_E          = 0x0,
    SXD_PORT_CNTR_GRP_RFC_2863_E                = 0x1,
    SXD_PORT_CNTR_GRP_RFC_2819_E                = 0x2,
    SXD_PORT_CNTR_GRP_RFC_3635_E                = 0x3,
    SXD_PORT_CNTR_GRP_PERFORMANCE_E             = 0x5,
    SXD_PORT_CNTR_GRP_DISCARD_E                 = 0x6,
    SXD_PORT_CNTR_GRP_PER_PRIO_E                = 0x10,
    SXD_PORT_CNTR_GRP_PER_TC_E                  = 0x11,
    SXD_PORT_CNTR_GRP_PHY_LAYER_E               = 0x12,
    SXD_PORT_CNTR_GRP_CONGESTION_PER_TC_E       = 0x13,
    SXD_PORT_CNTR_GRP_PER_BUFF_E                = 0x15,
    SXD_PORT_CNTR_GRP_PHY_LAYER_STATISTICS_E    = 0x16,
    SXD_PORT_CNTR_GRP_PHY_LAYER_INTERNAL_LINK_E = 0x24,
    SXD_PORT_CNTR_GRP_ALL_E                     = 0x3F,
    SXD_PORT_CNTR_GRP_NULL_E                    = 0xFF,
} sxd_port_cntr_grp_t;

/***
 * This enum is used to store the MTU size direction.Ingress/Egress/both.
 *
 */

typedef enum sxd_port_mtu_direction {
    SXD_PORT_MTU_INGRESS_EGRESS_E = 0x0,             /*Set/get MTU for both Ingress and Egress*/
    SXD_PORT_MTU_INGRESS_E        = 0x1,             /*Set/get MTU for Ingress only*/
    SXD_PORT_MTU_EGRESS_E         = 0x2,             /*Set/get MTU for Egress only*/
} sxd_port_mtu_direction_t;


#endif /* __SXD_PORT_H__ */
