/*
 * Copyright (C) 2011-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */
#ifndef __CRC16_H_
#define __CRC16_H_

#include <complib/cl_types.h>

/************************************************
 *  Local Defines
 ***********************************************/

/* required table size for crc16 algorithm */
#define CRC16_TABLE_SIZE 256
#define CRC_START_16     0

#define BYTE_SIZE 8

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

typedef struct crc16_table {
    boolean_t table_init;
    uint16_t  table[CRC16_TABLE_SIZE];
} crc16_table_t;

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/*
 * uint16_t crc_16( const unsigned char *input_str, size_t num_bytes );
 *
 * The function crc_16() calculates the 16 bits CRC16 in one pass for a byte
 * string of which the beginning has been passed to the function. The number of
 * bytes to check is also a parameter. The number of the bytes in the string is
 * limited by the constant SIZE_MAX. Bits in bytes are processed lsb-to-msb.
 */

uint16_t crc_16(crc16_table_t *crc16_table,
                const uint8_t *input_str,
                size_t         num_bytes,
                uint16_t       crc16_poly);

/* Similar to crc_16 but bits in bytes are processed msb-to-lsb (i.e. reflected).*/

uint16_t crc_16_msb(crc16_table_t *crc16_table,
                    const uint8_t *input_str,
                    size_t         num_bytes,
                    uint16_t       crc16_poly);


/* A generic implementation of the CRC function which allows calculating CRC-2 - CRC 16 by specifying the length.*/
uint16_t crc_msb(crc16_table_t *crc16_table,
                 const uint8_t *input_str,
                 size_t         num_bytes,
                 uint16_t       crc16_poly,
                 uint16_t       crc_length);

/*
 * uint16_t update_crc_16( uint16_t crc, unsigned char c );
 *
 * The function update_crc_16() calculates a new CRC-16 value based on the
 * previous value of the CRC and the next byte of data to be checked.
 */

uint16_t update_crc_16(crc16_table_t *crc16_table,
                       uint16_t       crc,
                       uint8_t        c,
                       uint16_t       crc16_poly);

#endif /* __CRC16_H_ */
