/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_TYPES_H__
#define __SXD_TYPES_H__

#include <sx/sxd/sxd_access_cmd.h>
#include <sx/sxd/sxd_bitmap.h>
#include <sx/sxd/sxd_check.h>
#include <sx/sxd/sxd_cos.h>
#include <sx/sxd/sxd_dev.h>
#include <sx/sxd/sxd_fdb.h>
#include <sx/sxd/sxd_host.h>
#include <sx/sxd/sxd_lag.h>
#include <sx/sxd/sxd_mac.h>
#include <sx/sxd/sxd_policer.h>
#include <sx/sxd/sxd_port.h>
#include <sx/sxd/sxd_router.h>
#include <sx/sxd/sxd_status.h>
#include <sx/sxd/sxd_emad_status.h>
#include <sx/sxd/sxd_swid.h>
#include <sx/sxd/sxd_trap_id.h>
#include <sx/sxd/sxd_vlan.h>
#include <sx/sxd/sxd_span.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

#endif /* __SXD_TYPES_H__ */
