/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_HOST_REG_H__
#define __SXD_EMAD_HOST_REG_H__

#include <sx/sxd/sxd_types.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

#include <complib/cl_packon.h>

/**
 * sxd_emad_hcap_reg_t structure is used to store HCAP register
 * layout.
 */
typedef struct sxd_emad_hcap_reg {
    uint8_t reserved1[7];
    uint8_t max_cpu_egress_tclass;
    uint8_t reserved2[3];
    uint8_t max_cpu_ingress_tclass;
    uint8_t reserved3[3];
    uint8_t max_num_trap_groups;
    uint8_t reserved4[3];
    uint8_t max_num_dr_paths;
    net32_t reserved5[3];
} PACK_SUFFIX sxd_emad_hcap_reg_t;

/**
 * sxd_emad_htgt_path_local_reg_t structure is used to store HTGT
 * PATH fields register layout.
 */
typedef struct sxd_emad_htgt_path_local_reg {
    uint8_t reserved1;
    uint8_t cpu_tclass;
    uint8_t reserved2;
    uint8_t rdq;
    net32_t reserved3[3];
} PACK_SUFFIX sxd_emad_htgt_path_local_reg_t;

/**
 * sxd_emad_htgt_path_stacking_en_reg_t structure is used to store
 * HTGT PATH fields register layout.
 */
typedef struct sxd_emad_htgt_path_stacking_en_reg {
    uint8_t stacking_tclass;
    uint8_t cpu_tclass;
    uint8_t reserved1;
    uint8_t rdq;
    net16_t reserved2;
    net16_t cpu_system_port;
    net32_t reserved3[2];
} PACK_SUFFIX sxd_emad_htgt_path_stacking_en_reg_t;

/**
 * sxd_emad_htgt_path_direct_route_reg_t structure is used to store
 * HTGT PATH fields register layout.
 */
typedef struct sxd_emad_htgt_path_direct_route_reg {
    uint8_t reserved1[3];
    uint8_t dr_ptr;
    net32_t reserved2[3];
} PACK_SUFFIX sxd_emad_htgt_path_direct_route_reg_t;

/**
 * sxd_emad_htgt_path_ethernet_reg_t structure is used to store HTGT
 * PATH fields register layout.
 */
typedef struct sxd_emad_htgt_path_ethernet_reg {
    net16_t reserved1;
    net16_t mac_47_32;
    net32_t mac_31_0;
    net16_t reserved2;
    net16_t vid;
    net32_t reserved3;
} PACK_SUFFIX sxd_emad_htgt_path_ethernet_reg_t;

/**
 * sxd_emad_htgt_path_t union is used to store the PATH to the
 * designated CPU at HTGT register.
 */
typedef union sxd_emad_htgt_path {
    sxd_emad_htgt_path_local_reg_t        path_local;
    sxd_emad_htgt_path_stacking_en_reg_t  path_stacking_en;
    sxd_emad_htgt_path_direct_route_reg_t path_direct_route;
    sxd_emad_htgt_path_ethernet_reg_t     path_ethernet;
} PACK_SUFFIX sxd_emad_htgt_path_t;

/**
 * sxd_emad_htgt_reg_t structure is used to store HTGT register
 * layout.
 */
typedef struct sxd_emad_htgt_reg {
    uint8_t              swid;
    uint8_t              reserved1;
    uint8_t              type;
    uint8_t              group;
    net16_t              reserved2;
    uint8_t              pide;
    uint8_t              pid;
    net16_t              reserved3;
    uint8_t              mirror_action;
    uint8_t              mirror_agent;
    uint8_t              reserved4[3];
    uint8_t              priority;
    sxd_emad_htgt_path_t path;
    net32_t              reserved5[8];
    uint32_t             mirror_probability_rate;
} PACK_SUFFIX sxd_emad_htgt_reg_t;

/**
 * sxd_emad_hpkt_reg_t structure is used to store HPKT register
 * layout.
 */
typedef struct sxd_emad_hpkt_reg {
    net32_t ack_action_trap_group_trap_id;
    net16_t ctrl;
    net16_t reserved[5];
} PACK_SUFFIX sxd_emad_hpkt_reg_t;

/**
 * sxd_emad_hespr_reg_t structure is used to store HESPR register
 * layout.
 */
typedef struct sxd_emad_hespr_reg {
    uint8_t stacking_tclass;
    uint8_t cpu_tclass;
    uint8_t reserved1;
    uint8_t rdq;
    net32_t reserved2;
} PACK_SUFFIX sxd_emad_hespr_reg_t;

/**
 * sxd_emad_hdrt_reg_t structure is used to store HDRT register
 * layout.
 */
typedef struct sxd_emad_hdrt_reg {
    uint8_t drp_index;
    uint8_t reserved1;
    net16_t hop_cnt;
    uint8_t reserved2;
    uint8_t path[64];
    uint8_t rpath[64];
} PACK_SUFFIX sxd_emad_hdrt_reg_t;

/**
 * sxd_emad_hctr_reg_t structure is used to store HCTR register
 * layout.
 */
typedef struct sxd_emad_hctr_reg {
    uint8_t  reserved1[3];
    uint8_t  custom_trap_index;
    uint8_t  reserved2[3];
    uint8_t  tcp_dport_sport_udp_dport;
    uint16_t reserved3;
    uint16_t range_min;
    uint16_t reserved4;
    uint16_t range_max;
} PACK_SUFFIX sxd_emad_hctr_reg_t;

typedef struct sxd_emad_htac_icmpv6_type_trap_attr {
    uint32_t reserved32[3];
    uint8_t  reserved8[3];
    uint8_t  icmp_type;
} PACK_SUFFIX sxd_emad_htac_icmpv6_type_trap_attr_t;

typedef struct sxd_emad_htac_nve_decap_et_trap_attr {
    uint32_t reserved32[3];
    uint8_t  reserved8[2];
    uint16_t eth_type;
} PACK_SUFFIX sxd_emad_htac_nve_decap_et_type_trap_attr_t;

/**
 *  * sxd_emad_htac_attr_t union is used to store the attr
 *   * of per user defined trap at HTAC register.
 *    */
typedef union sxd_emad_htac_attr {
    sxd_emad_htac_icmpv6_type_trap_attr_t       icmpv6_type_attr;
    sxd_emad_htac_nve_decap_et_type_trap_attr_t nve_decap_et_type_attr;
} PACK_SUFFIX sxd_emad_htac_attr_t;

/**
 *  * sxd_emad_htac_reg_t structure is used to store HTAC
 *    register
 *   * layout.
 *    */
typedef struct sxd_emad_htac_reg {
    uint8_t              reserved1[2];
    uint16_t             trap_id;
    uint8_t              reserved2[12];
    sxd_emad_htac_attr_t attr[2];
} PACK_SUFFIX sxd_emad_htac_reg_t;

/**
 *  * sxd_emad_hopf_reg_t structure is used to store HOPF register
 *   * layout.
 *    */
typedef struct sxd_emad_hopf_reg {
    net32_t sr_cqever_flownum; /* send/receive, CQE version, flow number */
    uint8_t rcv_cpu_tclass;
    uint8_t cpu_tclass;
    uint8_t reserved1;
    uint8_t i_f;
    net16_t reserved2;
    net16_t mac_47_32; /* MAC bits 32-47 */
    net32_t mac_31_0; /* MAC bits 0-31 */
    net32_t vlan_ex_dei_pcp_vid; /* vlan_ex, dei, pcp, vid */
} PACK_SUFFIX sxd_emad_hopf_reg_t;

#include <complib/cl_packoff.h>

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

#endif /* __SXD_EMAD_HOST_REG_H__ */
