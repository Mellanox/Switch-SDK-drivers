/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_PARSER_VLAN_H__
#define __SXD_EMAD_PARSER_VLAN_H__

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_emad_vlan_data.h>
#include <sx/sxd/sxd_emad_vlan_reg.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

sxd_status_t emad_parser_vlan_log_verbosity_level(IN sxd_access_cmd_t      cmd,
                                                  IN sx_verbosity_level_t *verbosity_level_p);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_spvid(sxd_emad_spvid_data_t *spvid_data,
                                  sxd_emad_spvid_reg_t  *spvid_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_spvid(sxd_emad_spvid_data_t *spvid_data,
                                    sxd_emad_spvid_reg_t  *spvid_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_spvm(sxd_emad_spvm_data_t *spvm_data,
                                 sxd_emad_spvm_reg_t  *spvm_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_spvm(sxd_emad_spvm_data_t *spvm_data,
                                   sxd_emad_spvm_reg_t  *spvm_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_spvm_reg_vlans_size(sxd_emad_spvm_data_t *spvm_data,
                                          uint32_t             *spvm_reg_vlans_size);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_spaft(sxd_emad_spaft_data_t *spaft_data,
                                  sxd_emad_spaft_reg_t  *spaft_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_spaft(sxd_emad_spaft_data_t *spaft_data,
                                    sxd_emad_spaft_reg_t  *spaft_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_spvtr(sxd_emad_spvtr_data_t *spvtr_data,
                                  sxd_emad_spvtr_reg_t  *spvtr_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_spvtr(sxd_emad_spvtr_data_t *spvtr_data,
                                    sxd_emad_spvtr_reg_t  *spvtr_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_spvc(sxd_emad_spvc_data_t *spvc_data,
                                 sxd_emad_spvc_reg_t  *spvc_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_spvc(sxd_emad_spvc_data_t *spvc_data,
                                   sxd_emad_spvc_reg_t  *spvc_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_sver(sxd_emad_sver_data_t *sver_data,
                                 sxd_emad_sver_reg_t  *sver_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_sver(sxd_emad_sver_data_t *sver_data,
                                   sxd_emad_sver_reg_t  *sver_reg);

#endif /* __EMAD_PARSER_VLAN_H__ */
