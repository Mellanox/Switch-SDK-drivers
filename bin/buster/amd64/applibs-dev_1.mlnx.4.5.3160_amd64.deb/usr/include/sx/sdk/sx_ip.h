/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 * LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 * FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 * See the Apache Version 2.0 License for specific language governing
 * permissions and limitations under the License.
 *
 */


#ifndef __SX_IP_H__
#define __SX_IP_H__

#include "sx/sdk/auto_headers/sx_ip_auto.h"


#define SX_IPV4_ADDR_EQUAL(a, b) \
    ((a).s_addr == (b).s_addr)


#define SX_IPV4_PREFIX_EQUAL(a, b)             \
    (SX_IPV4_ADDR_EQUAL((a).mask, (b).mask) && \
     (((a).addr.s_addr & (a).mask.s_addr) ==   \
      ((b).addr.s_addr & (b).mask.s_addr)))

/**
 * Determine if the IPv4 prefix is valid
 * @addr: a 32 bit ipv4 mask.
 *
 * Return TRUE if the mask is valid.
 */
static inline int is_ipv4_mask_valid(const uint32_t mask)
{
    uint32_t inv_mask = ~mask;

    return !(inv_mask & (inv_mask + 1));
}

/**
 * Determine if the IPv6 prefix is valid
 * @addr: an array in length 16 of 8 bit ipv6 mask.
 * The function gets the uint8 field of the mask to maintain the bit-order of the address
 *
 * Return TRUE if the mask is valid.
 */
static inline int is_ipv6_mask_valid(const uint32_t *mask_p)
{
    uint32_t inv_mask;
    uint8_t  i, idx = 0;

    for (i = 0; (i < 4) && (mask_p[idx] == 0xFFFFFFFF); i++) {
        idx++;
    }
    if (idx == 4) { /* the mask is valid */
        return TRUE;
    }
    for (i = i + 1; i < 4; i++) {
        if (mask_p[i] != 0) {
            return FALSE;
        }
    }

    inv_mask = ~mask_p[idx];
    return !(inv_mask & (inv_mask + 1));
}


#define SX_IPV4_PREFIX_VALID(a)              \
    ((((a).addr.s_addr & (a).mask.s_addr) == \
      ((a).addr.s_addr)) && (is_ipv4_mask_valid((a).mask.s_addr)))

#define SX_IPV6_ADDR_EQUAL(a, b)               \
    (((a).s6_addr32[0] == (b).s6_addr32[0]) && \
     ((a).s6_addr32[1] == (b).s6_addr32[1]) && \
     ((a).s6_addr32[2] == (b).s6_addr32[2]) && \
     ((a).s6_addr32[3] == (b).s6_addr32[3]))


#define SX_IPV6_PREFIX_EQUAL(a, b)                         \
    (SX_IPV6_ADDR_EQUAL((a).mask, (b).mask) &&             \
     ((((a).addr.s6_addr32[0] & (a).mask.s6_addr32[0]) ==  \
       ((b).addr.s6_addr32[0] & (b).mask.s6_addr32[0])) && \
      (((a).addr.s6_addr32[1] & (a).mask.s6_addr32[1]) ==  \
       ((b).addr.s6_addr32[1] & (b).mask.s6_addr32[1])) && \
      (((a).addr.s6_addr32[2] & (a).mask.s6_addr32[2]) ==  \
       ((b).addr.s6_addr32[2] & (b).mask.s6_addr32[2])) && \
      (((a).addr.s6_addr32[3] & (a).mask.s6_addr32[3]) ==  \
       ((b).addr.s6_addr32[3] & (b).mask.s6_addr32[3]))))

#define SX_IPV6_PREFIX_VALID(a)                           \
    (((((a).addr.s6_addr32[0] & (a).mask.s6_addr32[0]) == \
       ((a).addr.s6_addr32[0])) &&                        \
      (((a).addr.s6_addr32[1] & (a).mask.s6_addr32[1]) == \
       ((a).addr.s6_addr32[1])) &&                        \
      (((a).addr.s6_addr32[2] & (a).mask.s6_addr32[2]) == \
       ((a).addr.s6_addr32[2])) &&                        \
      (((a).addr.s6_addr32[3] & (a).mask.s6_addr32[3]) == \
       ((a).addr.s6_addr32[3])) &&                        \
      (is_ipv6_mask_valid((a).mask.s6_addr32))))


#define SX_IP_VERSION_CHECK_RANGE(IP_VERSION) \
    SX_CHECK_MAX(IP_VERSION, SX_IP_VERSION_MAX)

#define SX_IP_ADDR_EQUAL(a, b)                           \
    (((a).version == (b).version) &&                     \
     ((a).version == SX_IP_VERSION_IPV4 ?                \
      SX_IPV4_ADDR_EQUAL((a).addr.ipv4, (b).addr.ipv4) : \
      SX_IPV6_ADDR_EQUAL((a).addr.ipv6, (b).addr.ipv6)))


#define SX_IP_PREFIX_EQUAL(a, b)                               \
    (((a).version == (b).version) &&                           \
     ((a).version == SX_IP_VERSION_IPV4 ?                      \
      SX_IPV4_PREFIX_EQUAL((a).prefix.ipv4, (b).prefix.ipv4) : \
      SX_IPV6_PREFIX_EQUAL((a).prefix.ipv6, (b).prefix.ipv6)))

/*
 *  prefix valid check if ip is network ip and not host ip
 *  For example : for mask 255.255.255.0 valid prefix ip is 10.10.10.0
 */
#define SX_IP_PREFIX_VALID(a)                 \
    (((a).version == SX_IP_VERSION_IPV4 ?     \
      SX_IPV4_PREFIX_VALID((a).prefix.ipv4) : \
      SX_IPV6_PREFIX_VALID((a).prefix.ipv6)))

#define IS_IPV6_MULTICAST(a) \
    ((a & 0xFF000000) == 0xFF000000)

#define IS_IP_MULTICAST(ip_addr)                       \
    ((ip_addr).version == SX_IP_VERSION_IPV4 ?         \
     IN_MULTICAST((ip_addr).prefix.ipv4.addr.s_addr) : \
     IS_IPV6_MULTICAST((ip_addr).prefix.ipv6.addr.s6_addr32[0]))

#define IS_IPV4_BROADCAST(a) \
    (a == 0xFFFFFFFF)

#define IS_IP_BROADCAST(ip_addr)               \
    ((ip_addr).version == SX_IP_VERSION_IPV4 ? \
     IS_IPV4_BROADCAST((ip_addr).prefix.ipv4.addr.s_addr) : 0)

#define IS_IP_UNICAST(ip_addr)                                     \
    ((ip_addr).version == SX_IP_VERSION_IPV4 ?                     \
     ((!IN_MULTICAST((ip_addr).prefix.ipv4.addr.s_addr)) &&        \
      (((ip_addr).prefix.ipv4.addr.s_addr) != INADDR_BROADCAST)) : \
     (!IS_IPV6_MULTICAST((ip_addr).prefix.ipv6.addr.s6_addr32[0])))

#define IS_IP_ADDR_UNICAST(ip_addr)                                                                        \
    ((ip_addr).version == SX_IP_VERSION_IPV4 ?                                                             \
     ((!IN_MULTICAST((ip_addr).addr.ipv4.s_addr)) && (((ip_addr).addr.ipv4.s_addr) != INADDR_BROADCAST)) : \
     (!IS_IPV6_MULTICAST((ip_addr).addr.ipv6.s6_addr32[0])))

#define IS_IP_ADDR_ANY(ip_addr)                                                                                 \
    ((ip_addr).version == SX_IP_VERSION_IPV4 ?                                                                  \
     (((ip_addr).prefix.ipv4.addr.s_addr == INADDR_ANY) && ((ip_addr).prefix.ipv4.mask.s_addr == INADDR_ANY)) : \
     (SX_IPV6_ADDR_EQUAL((ip_addr).prefix.ipv6.addr,                                                            \
                         in6addr_any) && (SX_IPV6_ADDR_EQUAL((ip_addr).prefix.ipv6.mask, in6addr_any))))

#endif /* __SX_IP_H__ */
