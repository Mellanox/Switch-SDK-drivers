/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_FLOW_COUNTER_H__
#define __SXD_EMAD_FLOW_COUNTER_H__

#include <complib/sx_log.h>

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_emad_flow_counter_data.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/************************************************
 *  API functions
 ***********************************************/

/**
 * This function sets the log verbosity level of EMAD FLOW COUNTER MODULE
 * @param[in] cmd               - SET / GET
 * @param[in] verbosity_level_p - verbosity level
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_ERROR - general error
 * @return SXD_STATUS_CMD_UNSUPPORTED - Unsupported command
 */
sxd_status_t sxd_emad_flow_counter_log_verbosity_level(sxd_access_cmd_t      cmd,
                                                       sx_verbosity_level_t *verbosity_level_p);

/**
 * This function Sets the PFCA Switch Descriptor fields.
 *
 * @param[in,out]	pfca_data_arr - PFCC EMAD array
 * @param[in]		pfca_data_num - Number of PFCC EMAD data
 * @param[in]		handler - Sender ID
 * @param[in,out]	context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_pfca_set(sxd_emad_pfca_data_t         *pfca_data_arr,
                               uint32_t                      pfca_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 * This function Retrieves the PFCA Switch Descriptor fields.
 *
 * @param[in,out]	pfca_data_arr - PFCA EMAD array
 * @param[in]		pfca_data_num - Number of PFCC EMAD data
 * @param[in]		handler - Sender ID
 * @param[in,out]	context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_pfca_get(sxd_emad_pfca_data_t         *pfca_data_arr,
                               uint32_t                      pfca_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 * This function Sets the PFCNT Switch Descriptor fields.
 *
 * @param[in,out]	pfcnt_data_arr - PFCC EMAD array
 * @param[in]		pfcnt_data_num - Number of PFCC EMAD data
 * @param[in]		handler - Sender ID
 * @param[in,out]	context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_pfcnt_set(sxd_emad_pfcnt_data_t        *pfcnt_data_arr,
                                uint32_t                      pfcnt_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 * This function Retrieves the PFCNT Switch Descriptor fields.
 *
 * @param[in,out]	pfcnt_data_arr - PFCNT EMAD array
 * @param[in]		pfcnt_data_num - Number of PFCC EMAD data
 * @param[in]		handler - Sender ID
 * @param[in,out]	context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_pfcnt_get(sxd_emad_pfcnt_data_t        *pfcnt_data_arr,
                                uint32_t                      pfcnt_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 * This function Sets the MGPC Switch Descriptor fields.
 *
 * @param[in,out]	mgpc_data_arr -MGPC EMAD array
 * @param[in]		mgpc_data_num - Number of MGPC EMAD data
 * @param[in]		handler - Sender ID
 * @param[in,out]	context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_mgpc_set(sxd_emad_mgpc_data_t         *mgpc_data_arr,
                               uint32_t                      mgpc_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);
/**
 * This function Retrieves the MGPC Switch Descriptor fields.
 *
 * @param[in,out]	mgpc_data_arr - MGPC EMAD array
 * @param[in]		mgpc_data_num - Number of MGPC EMAD data
 * @param[in]		handler - Sender ID
 * @param[in,out]	context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_mgpc_get(sxd_emad_mgpc_data_t         *mgpc_data_arr,
                               uint32_t                      mgpc_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

#endif /* __SXD_EMAD_FLOW_COUNTER_H__ */
