/*
 * Copyright (C) 2001-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */


#ifndef GC_H_
#define GC_H_

#include "sx/utils/sx_utils_types.h"
#include "sx/utils/sx_utils_status.h"
#include "complib/cl_types.h"
#include "complib/cl_qlist.h"
#include "complib/cl_qpool.h"
#include "complib/cl_spinlock.h"
#include "complib/cl_thread.h"

/************************************************
 *  Defines
 ***********************************************/


/************************************************
 *  Macros
 ***********************************************/


/************************************************
 *  Type definitions
 ***********************************************/
typedef enum gc_state {
    GC_STATE_FREE           = 0,
    GC_STATE_EXISTS         = 1,
    GC_STATE_PENDING_DELETE = 2,
    GC_STATE_PENDING_FENCE  = 3,
    GC_STATE_FENCED         = 4,
    GC_STATE_MIN            = GC_STATE_FREE,
    GC_STATE_MAX            = GC_STATE_FENCED
} gc_state_t;

#define GC_STATE_CHECK_RANGE(GC_STATE) \
    SX_CHECK_MAX(GC_STATE, GC_STATE_MAX)

static __attribute__((__used__)) const char* gc_state_str[] = {
    "FREE",
    "EXISTS",
    "PENDING DELETE",
    "PENDING FENCE",
    "FENCED",
};

#define GC_STATE_STR_LEN (sizeof(gc_state_str) / sizeof(char*))

#define GC_STATE_STR(index)                      \
    (SX_CHECK_MAX(index, GC_STATE_STR_LEN - 1) ? \
     gc_state_str[index] : "UNKNOWN")

typedef enum gc_fence_type {
    GC_FENCE_TYPE_NONE = 0,
    GC_FENCE_TYPE_SLOW = 1,
    GC_FENCE_TYPE_FAST = 2,
    GC_FENCE_TYPE_MIN  = GC_FENCE_TYPE_NONE,
    GC_FENCE_TYPE_MAX  = GC_FENCE_TYPE_FAST
} gc_fence_type_t;

#define GC_FENCE_TYPE_CHECK_RANGE(GC_FENCE_TYPE) \
    SX_CHECK_MAX(GC_FENCE_TYPE, GC_FENCE_TYPE_MAX)

static __attribute__((__used__)) const char* gc_fence_type_str[] = {
    "NONE",
    "SLOW",
    "FAST",
};

#define GC_FENCE_TYPE_STR_LEN (sizeof(gc_fence_type_str) / sizeof(char*))

#define GC_FENCE_TYPE_STR(index)                      \
    (SX_CHECK_MAX(index, GC_FENCE_TYPE_STR_LEN - 1) ? \
     gc_fence_type_str[index] : "UNKNOWN")

typedef enum gc_fence_state {
    GC_FENCE_STATE_NONE    = 0,
    GC_FENCE_STATE_ONGOING = 1,
    GC_FENCE_STATE_MIN     = GC_FENCE_STATE_NONE,
    GC_FENCE_STATE_MAX     = GC_FENCE_STATE_ONGOING
} gc_fence_state_t;

#define GC_FENCE_STATE_CHECK_RANGE(GC_FENCE_STATE) \
    SX_CHECK_MAX(GC_FENCE_STATE, GC_FENCE_STATE_MAX)

static __attribute__((__used__)) const char* gc_fence_state_str[] = {
    "NONE",
    "ONGOING",
};

#define GC_FENCE_STATE_STR_LEN (sizeof(gc_fence_state_str) / sizeof(char*))

#define GC_FENCE_STATE_STR(index)                      \
    (SX_CHECK_MAX(index, GC_FENCE_STATE_STR_LEN - 1) ? \
     gc_fence_state_str[index] : "UNKNOWN")

typedef struct gc_init_params {
    /* how often the global garbage collector should run (in seconds) */
    uint32_t gc_timer_interval;

    /* how often the fast fence timer should run (in milliseconds) */
    uint32_t fast_fence_timer_interval;

    /* how often the slow fence timer should run (in milliseconds) */
    uint32_t slow_fence_timer_interval;

    /* how often the fast fence timer should run during synchronous fence
     * operations (in microseconds) */
    uint32_t sync_fast_fence_timer_interval;

    /* how often the slow fence timer should run during synchronous fence
     * operations (in microseconds) */
    uint32_t sync_slow_fence_timer_interval;

    /* maximum number of HW operations that should be performed in
     * one GC iteration */
    uint32_t max_hw_operations;

    /* how often the post queue should be handled (in micro seconds) */
    uint32_t post_queue_timer_interval;

    /* max KVD utilization (in percents) when background mode is allowed */
    uint32_t post_queue_bg_limit;

    /* Use lazy delete (software GC)
     * Global SDK flag */
    boolean_t use_sw_lazy_delete;
} gc_init_params_t;

typedef struct gc_object_type_attributes {
    uint32_t        per_object_threshold; /* maximum number of objects of this type that can be in the GC */
    uint32_t        free_objects_threshold; /* minimum number of objects of this type we should aspire to have available */
    gc_fence_type_t fence_type;     /* fence type of this object type */
    boolean_t       hw_operation_needed; /* TRUE if a HW operation is performed as part of the completion */
} gc_object_type_attributes_t;

typedef const void *gc_handle_t;

typedef sx_utils_status_t (*gc_object_completion_pfn)(const void *gc_context);
typedef sx_utils_status_t (*gc_object_post_completion_pfn)(const void *gc_context, boolean_t is_last, uint32_t bg);

typedef enum gc_object_type {
    GC_OBJECT_TYPE_KVD_LINEAR         = 0,
    GC_OBJECT_TYPE_PGT                = 1,
    GC_OBJECT_TYPE_COUNTERS           = 2,
    GC_OBJECT_TYPE_RIF                = 3,
    GC_OBJECT_TYPE_VRID               = 4,
    GC_OBJECT_TYPE_GLOBAL_POLICER     = 5,
    GC_OBJECT_TYPE_HOST_IFC_POLICER   = 6,
    GC_OBJECT_TYPE_STORM_CTRL_POLICER = 7,
    GC_OBJECT_TYPE_MPE                = 8,
    GC_OBJECT_TYPE_SHSPM_TREE         = 9,
    GC_OBJECT_TYPE_FID                = 10,
    GC_OBJECT_TYPE_PORT               = 11,
    GC_OBJECT_TYPE_SPAN               = 12,
    GC_OBJECT_TYPE_ERP                = 13,
    GC_OBJECT_TYPE_HW_REGION          = 14,
    GC_OBJECT_TYPE_SPAN_POLICER       = 15,
    GC_OBJECT_TYPE_ACCUFLOW_COUNTERS  = 16,
    GC_OBJECT_TYPE_MIN                = GC_OBJECT_TYPE_KVD_LINEAR,
    GC_OBJECT_TYPE_MAX                = GC_OBJECT_TYPE_ACCUFLOW_COUNTERS
} gc_object_type_t;

#define GC_OBJECT_TYPE_CHECK_RANGE(OBJECT_TYPE) \
    SX_CHECK_MAX(OBJECT_TYPE, GC_OBJECT_TYPE_MAX)

static __attribute__((__used__)) const char* gc_object_type_str[] = {
    "KVD LINEAR",
    "PGT",
    "COUNTERS",
    "RIF",
    "VRID",
    "GLOBAL POLICER",
    "HOST IFC POLICER",
    "STORM CTRL POLICER",
    "RMPE",
    "SHSPM TREE",
    "FID",
    "PORT",
    "SPAN",
    "ERP",
    "HW REGION",
    "SPAN POLICER",
    "ACCUMULATED COUNTERS",
};

#define GC_OBJECT_TYPE_STR_LEN (sizeof(gc_object_type_str) / sizeof(char*))

#define GC_OBJECT_TYPE_STR(index)                      \
    (SX_CHECK_MAX(index, GC_OBJECT_TYPE_STR_LEN - 1) ? \
     gc_object_type_str[index] : "UNKNOWN")

#define GC_OBJECT_TYPE_NUMBER (GC_OBJECT_TYPE_MAX - GC_OBJECT_TYPE_MIN + 1)

typedef enum gc_object_subtype {
    GC_OBJECT_SUBTYPE_NONE           = 0,
    GC_OBJECT_SUBTYPE_RATR_RTDP      = 1,
    GC_OBJECT_SUBTYPE_MPLS_NHLFE     = 2,
    GC_OBJECT_SUBTYPE_ACL_ACTION_SET = 3,
    GC_OBJECT_SUBTYPE_PPBD_HMCB      = 4,
    GC_OBJECT_SUBTYPE_MPLS_ILM       = 5,
    GC_OBJECT_SUBTYPE_RIGR_V2        = 6,
    GC_OBJECT_SUBTYPE_RPF_GROUP      = 7,
    GC_OBJECT_SUBTYPE_IPV6           = 8,
    GC_OBJECT_SUBTYPE_TNUMT          = 9,
    GC_OBJECT_SUBTYPE_MIN            = GC_OBJECT_SUBTYPE_NONE,
    GC_OBJECT_SUBTYPE_MAX            = GC_OBJECT_SUBTYPE_TNUMT
} gc_object_subtype_t;

#define GC_OBJECT_SUBTYPE_CHECK_RANGE(SUBTYPE) \
    SX_CHECK_MAX(SUBTYPE, GC_OBJECT_SUBTYPE_MAX)

static __attribute__((__used__)) const char* gc_object_subtype_str[] = {
    "NONE",
    "RATR_RTDP",
    "MPLS_NHLFE",
    "ACL ACTION SET",
    "PPBD_HMCB",
    "MPLS_ILM",
    "RIGR_V2",
    "RPF GROUP",
    "IPV6",
    "TNUMT"
};

#define GC_OBJECT_SUBTYPE_STR_LEN (sizeof(gc_object_subtype_str) / sizeof(char*))

#define GC_OBJECT_SUBTYPE_STR(index)                      \
    (SX_CHECK_MAX(index, GC_OBJECT_SUBTYPE_STR_LEN - 1) ? \
     gc_object_subtype_str[index] : "UNKNOWN")

typedef struct gc_object_data {
    gc_object_type_t    object_type;
    uint32_t            seq_num;
    const void         *gc_context;
    gc_state_t          state;
    uint32_t            size;
    gc_object_subtype_t subtype;
    uint32_t            start_index;
} gc_object_data_t;

typedef struct gc_post_queue_data {
    gc_object_type_t              object_type;
    gc_object_subtype_t           subtype;
    gc_object_completion_pfn      completion_cb;
    gc_object_post_completion_pfn post_completion_cb;
    const void                   *gc_context;
    uint32_t                      size;
    uint32_t                      start_index;
} gc_post_queue_data_t;

typedef struct gc_post_queue_entry {
    cl_pool_item_t       pool_item;
    cl_list_item_t       list_item;
    gc_post_queue_data_t data;
} gc_post_queue_entry_t;

typedef struct gc_post_queue {
    cl_qpool_t    pool;
    cl_qlist_t    list;
    cl_spinlock_t lock;
    boolean_t     on_pause;
} gc_post_queue_t;

typedef struct hwi_gc_ops {
    sx_utils_status_t (*gc_fence_pfn)(gc_fence_type_t fence_type);
    sx_utils_status_t (*gc_fence_state_read_pfn)(gc_fence_state_t *fence_state);
    boolean_t (*gc_delay_completion_pfn)(gc_object_type_t object_type);
    uint32_t (*gc_get_max_post_processing_records_pfn)(void);
    sx_utils_status_t (*gc_handle_post_queue_pfn)(uint32_t bg_limit);
    sx_utils_status_t (*gc_handle_post_queue_cleanup_pfn)(boolean_t           per_subtype,
                                                          gc_object_subtype_t gc_subtype);
} hwi_gc_ops_t;

/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Function declarations
 ***********************************************/

/*
 * Initializes the SDK garbage collector.
 *
 * @param[in] gc_params - GC init params
 * @param[in] ops       - GC HWD call
 *
 * @return SX_UTILS_STATUS_SUCCESS             if operation completes successfully
 * @return SX_UTILS_STATUS_PARAM_NULL          if NULL parameter is given
 * @return SX_UTILS_STATUS_PARAM_ERROR         if invalid parameter is given
 * @return SX_UTILS_STATUS_ALREADY_INITIALIZED if module is already initialized
 * @return SX_UTILS_STATUS_ERROR               general error.
 */
sx_utils_status_t gc_init(const gc_init_params_t *gc_params, hwi_gc_ops_t *ops);

/*
 * Deinitialize the SDK garbage collector.
 *
 * @return SX_UTILS_STATUS_SUCCESS             if operation completes successfully
 * @return SX_UTILS_STATUS_MODULE_UNINITIALIZED if module is not initialized
 * @return SX_UTILS_STATUS_ERROR               general error.
 */
sx_utils_status_t gc_deinit(void);

/*
 * Initializes an object type in the SDK garbage collector.
 *
 * @param[in] object_type           - object type
 * @param[in] object_attr         - object type attributes
 * @param[in] completion_cb         - deletion callback for this object type
 * @param[in] post_completion_cb    - deletion callback for delayed hw deletion for this object type
 *
 * @return SX_UTILS_STATUS_SUCCESS             if operation completes successfully
 * @return SX_UTILS_STATUS_PARAM_NULL      if NULL parameter is returned
 * @return SX_UTILS_STATUS_PARAM_ERROR         if invalid parameter is given
 * @return SX_UTILS_STATUS_MODULE_UNINITIALIZED if module is not initialized
 * @return SX_UTILS_STATUS_ALREADY_INITIALIZED if object is already initialized
 * @return SX_UTILS_STATUS_ERROR               general error.
 */
sx_utils_status_t gc_object_init(gc_object_type_t                   object_type,
                                 const gc_object_type_attributes_t *object_attr,
                                 gc_object_completion_pfn           completion_cb,
                                 gc_object_post_completion_pfn      post_completion_cb);

/*
 * Deinitialize an object type in the SDK garbage collector.
 *
 * @param[in] object_type           - object type
 *
 * @return SX_UTILS_STATUS_SUCCESS             if operation completes successfully
 * @return SX_UTILS_STATUS_PARAM_ERROR         if invalid parameter is given
 * @return SX_UTILS_STATUS_MODULE_UNINITIALIZED if module/object is not initialized
 * @return SX_UTILS_STATUS_ERROR               general error.
 */
sx_utils_status_t gc_object_deinit(gc_object_type_t object_type);

/*
 * Pushes an object to the garbage collector queue.
 *
 * @param[in] object_type       - object type
 * @param[in] gc_context        - object context for completion callback
 * @param[in] state             - GC state of object (currently only PENDING_FENCE supported)
 * @param[in] size              - size of entry being pushed to queue
 * @param[in] subtype           - object subtype (must be a subtype of the given type)
 * @param[in] start_index       - start index of object in relevant table
 * @param[out] gc_handle        - handle to object in GC queue, or INVALID
 *
 * @return SX_UTILS_STATUS_SUCCESS             if operation completes successfully
 * @return SX_UTILS_STATUS_PARAM_ERROR         if invalid parameter is given
 * @return SX_UTILS_STATUS_PARAM_NULL      if NULL parameter is returned
 * @return SX_UTILS_STATUS_MODULE_UNINITIALIZED if module is not initialized
 * @return SX_UTILS_STATUS_ERROR               general error.
 */
sx_utils_status_t gc_object_push(gc_object_type_t    object_type,
                                 const void         *gc_context,
                                 gc_state_t          state,
                                 uint32_t            size,
                                 gc_object_subtype_t subtype,
                                 uint32_t            start_index,
                                 gc_handle_t        *gc_handle);

/*
 * Activates the global garbage collector.
 *
 * @return SX_UTILS_STATUS_SUCCESS             if operation completes successfully
 * @return SX_UTILS_STATUS_PARAM_NULL      if a NULL parameter is given
 * @return SX_UTILS_STATUS_MODULE_UNINITIALIZED if module is not initialized
 * @return SX_UTILS_STATUS_ERROR               general error.
 */
sx_utils_status_t gc_activate(void);

/*
 * Activates the per-object garbage collector.
 *
 * @param[in] object_type  - object type for which garbage collector should be activated
 *
 * @return SX_UTILS_STATUS_SUCCESS             if operation completes successfully
 * @return SX_UTILS_STATUS_PARAM_ERROR      if an invalid parameter is given
 * @return SX_UTILS_STATUS_PARAM_NULL      if a NULL parameter is given
 * @return SX_UTILS_STATUS_MODULE_UNINITIALIZED if module is not initialized
 * @return SX_UTILS_STATUS_ERROR               general error.
 */
sx_utils_status_t gc_object_activate(gc_object_type_t object_type);

/*
 * Performs a single fence operation, based on the given object type, and blocks
 * until fence is complete.
 *
 * @param[in] fence_type - fence type to be performed
 *
 * @return SX_UTILS_STATUS_SUCCESS             if operation completes successfully
 * @return SX_UTILS_STATUS_PARAM_ERROR      if an invalid parameter is given
 * @return SX_UTILS_STATUS_MODULE_UNINITIALIZED if module is not initialized
 * @return SX_UTILS_STATUS_ERROR               general error.
 */
sx_utils_status_t gc_object_fence(gc_fence_type_t object_type);

/*
 * Checks the per-object thresholds for the given object type, and starts the
 * per-object queue processing if any of the thresholds have been exceeded.
 *
 * @param[in] object_type - object type for which thresholds should be checked
 * @param[in] free_object_cnt - number of free objects of this type
 *
 * @return SX_UTILS_STATUS_SUCCESS             if operation completes successfully
 * @return SX_UTILS_STATUS_PARAM_ERROR      if an invalid parameter is given
 * @return SX_UTILS_STATUS_MODULE_UNINITIALIZED if module is not initialized
 * @return SX_UTILS_STATUS_ERROR               general error.
 */
sx_utils_status_t gc_object_check_thresholds(gc_object_type_t object_type,
                                             uint32_t         free_object_cnt);

/*
 * Perform a debug dump of the GC module.
 *
 * @param[in] stream - dump file
 *
 * @return SX_UTILS_STATUS_SUCCESS             if operation completes successfully
 * @return SX_UTILS_STATUS_PARAM_NULL          if a NULL parameter is given
 * @return SX_UTILS_STATUS_ERROR               general error.
 */
sx_utils_status_t gc_debug_dump(FILE *stream);

/*
 * Remove an object, identified by the handle, from the GC.
 *
 * @param[in] gc_handle - handle to object to be removed
 *
 * @return SX_UTILS_STATUS_SUCCESS             if operation completes successfully
 * @return SX_UTILS_STATUS_NOT_INITIALIZED if module is not initialized
 * @return SX_UTILS_STATUS_PARAM_ERROR         if an invalid parameter is given
 * @return SX_UTILS_STATUS_ERROR               general error.
 */
sx_utils_status_t gc_object_remove(gc_handle_t gc_handle);

/*
 * Process the GC queue of a specific object type, synchronously.
 *
 * @return SX_UTILS_STATUS_SUCCESS             if operation completes successfully
 * @return SX_UTILS_STATUS_PARAM_ERROR         if an invalid parameter is given
 * @return SX_UTILS_STATUS_MODULE_UNINITIALIZED if module is not initialized
 * @return SX_UTILS_STATUS_ERROR               general error.
 */
sx_utils_status_t gc_object_process_queue(gc_object_type_t object_type);

sx_utils_status_t gc_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);

sx_utils_status_t gc_context_get(gc_handle_t gc_handle, void** gc_context);

sx_utils_status_t gc_lazy_delete_mode_get(boolean_t* lazy_del_mode_p);

/*
 * Clean the GC queue of all object type, synchronously.
 *
 * @return SX_UTILS_STATUS_SUCCESS             if operation completes successfully
 * @return SX_UTILS_STATUS_ERROR               general error.
 */
sx_utils_status_t gc_clean(void);

/*
 * Pushes an object to the garbage collector post queue.
 *
 * @param[in] object_data_p      - pointer on the garbage collector queue object
 * @param[in] completion_cb      - bin allocator completion callback
 * @param[in] post_completion_cb - bin allocator delayed completion callback
 *
 * @return SX_UTILS_STATUS_SUCCESS              if operation completes successfully
 * @return SX_UTILS_STATUS_MODULE_UNINITIALIZED if module is not initialized
 * @return SX_UTILS_STATUS_PARAM_ERROR          if invalid parameter is given
 * @return SX_UTILS_STATUS_ERROR                general error.
 */
sx_utils_status_t gc_post_queue_push(gc_object_data_t             *object_data_p,
                                     gc_object_completion_pfn      completion_cb,
                                     gc_object_post_completion_pfn post_completion_cb);


/*
 * Returns the top element from the garbage collector post queue.
 * If 'per_subtype' is given, returns the first entry with specified subtype.
 *
 * @param[in] data_p      - pointer on the garbage collector post queue object
 * @param[in] per_subtype - specify if need to handle objects with specified subtype
 * @param[in] gc_subtype  - subtype of the garbage collector post queue object
 *                          (per_subtype should be TRUE)
 *
 * @return SX_UTILS_STATUS_SUCCESS              if operation completes successfully
 * @return SX_UTILS_STATUS_MODULE_UNINITIALIZED if module is not initialized
 * @return SX_UTILS_STATUS_PARAM_ERROR          if invalid parameter is given
 * @return SX_UTILS_STATUS_ENTRY_NOT_FOUND      if GC post queue is empty or
 *                                                doesn't contain elements with
 *                                                specified subtype
 */
sx_utils_status_t gc_post_queue_top(gc_post_queue_data_t *data_p,
                                    boolean_t             per_subtype,
                                    gc_object_subtype_t   gc_subtype);

/*
 * Deletes the top element from the garbage collector post queue.
 * If 'per_subtype' is given, deletes the first entry with specified subtype.
 *
 * @param[in] data_p      - pointer on the garbage collector post queue object
 * @param[in] per_subtype - specify if need to handle objects with specified subtype
 * @param[in] gc_subtype  - subtype of the garbage collector post queue object
 *                          (per_subtype should be TRUE)
 *
 * @return SX_UTILS_STATUS_SUCCESS              if operation completes successfully
 * @return SX_UTILS_STATUS_MODULE_UNINITIALIZED if module is not initialized
 * @return SX_UTILS_STATUS_PARAM_ERROR          if invalid parameter is given
 * @return SX_UTILS_STATUS_ENTRY_NOT_FOUND      if GC post queue is empty or
 *                                                  doesn't contain elements with
 *                                                  specified subtype
 * @return SX_UTILS_STATUS_ERROR                general error
 */
sx_utils_status_t gc_post_queue_pop(gc_post_queue_data_t *data_p,
                                    boolean_t             per_subtype,
                                    gc_object_subtype_t   gc_subtype);


/*
 * Calls the handle post queue once. It will executed either in the background or the foreground.
 * The number of elements handled is determined by the internal configuration.
 * Note: The functions is called internally by the handle post queue thread.
 *
 *
 * @return SX_UTILS_STATUS_SUCCESS              if operation completes successfully
 * @return SX_UTILS_STATUS_MODULE_UNINITIALIZED if module is not initialized
 * @return SX_UTILS_STATUS_ERROR                general error
 */
sx_utils_status_t gc_handle_post_queue();

/*
 * Removes all elements from the garbage collector post queue.
 * If 'per_subtype' is given, deletes the elements with specified subtype.
 *
 * @param[in] per_subtype - specify if need to handle objects with specified subtype
 * @param[in] gc_subtype  - subtype of the garbage collector post queue object
 *                          (per_subtype should be TRUE)
 *
 * @return SX_UTILS_STATUS_SUCCESS              if operation completes successfully
 * @return SX_UTILS_STATUS_MODULE_UNINITIALIZED if module is not initialized
 * @return SX_UTILS_STATUS_PARAM_ERROR          if invalid parameter is given
 * @return SX_UTILS_STATUS_ERROR                general error
 */
sx_utils_status_t gc_post_queue_cleanup(boolean_t           per_subtype,
                                        gc_object_subtype_t gc_subtype);

/*
 * Checks if garbage collector post queue is empty.
 *
 * @param[out] is_empty_p - pointer to the flag to store status
 *
 * @return SX_UTILS_STATUS_SUCCESS              if operation completes successfully
 * @return SX_UTILS_STATUS_MODULE_UNINITIALIZED if module is not initialized
 * @return SX_UTILS_STATUS_PARAM_ERROR          if invalid parameter is given
 * @return SX_UTILS_STATUS_ERROR                general error
 */
sx_utils_status_t gc_post_queue_is_empty(boolean_t *is_empty_p);

/*
 * Sets handling garbage collector post queue on pause.
 *
 * @param[in] set_on_pause - if TRUE, pauses GC post queue processing
 *                           if FALSE, resumes GC post queue processing
 *
 * @return SX_UTILS_STATUS_SUCCESS              if operation completes successfully
 * @return SX_UTILS_STATUS_MODULE_UNINITIALIZED if module is not initialized
 */
sx_utils_status_t gc_post_queue_set_on_pause(boolean_t set_on_pause);

/*
 * Checks if handling garbage collector post queue is on pause.
 *
 * @param[out] is_on_pause_p - pointer to the flag to store status
 *
 * @return SX_UTILS_STATUS_SUCCESS              if operation completes successfully
 * @return SX_UTILS_STATUS_MODULE_UNINITIALIZED if module is not initialized
 * @return SX_UTILS_STATUS_PARAM_ERROR          if invalid parameter is given
 * @return SX_UTILS_STATUS_ERROR                general error
 */
sx_utils_status_t gc_post_queue_is_on_pause(boolean_t *is_on_pause_p);

/*
 * Perform a debug dump of the GC post queue.
 *
 * @param[in] stream - dump file
 *
 * @return SX_UTILS_STATUS_SUCCESS             if operation completes successfully
 * @return SX_UTILS_STATUS_PARAM_NULL          if a NULL parameter is given
 * @return SX_UTILS_STATUS_ERROR               general error.
 */
sx_utils_status_t gc_post_queue_dump(FILE *stream);

/*
 * Returns TID of GC Post Queue thread.
 *
 * @return TID if GC Post Queue thread is running
 * @return NULL if GC Post Queue thread is not running
 */
pthread_t gc_post_queue_timer_thread_tid();

/*
 * Sets flag for GC Post Queue thread to terminate.
 *
 * @param[in] signal_issued - TRUE, to terminate the thread
 *                            FALSE, to continue
 */
void gc_post_queue_timer_thread_exit_signal_issued(boolean_t signal_issued);
cl_thread_t* gc_post_queue_timer_thread_obj();

#endif /* GC_H_ */
