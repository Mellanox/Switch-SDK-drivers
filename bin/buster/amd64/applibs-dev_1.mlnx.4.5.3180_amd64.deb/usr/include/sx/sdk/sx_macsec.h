/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 * LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 * FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 * See the Apache Version 2.0 License for specific language governing
 * permissions and limitations under the License.
 *
 */

#ifndef __SX_MACSEC_H__
#define __SX_MACSEC_H__

#include "sx/sdk/auto_headers/sx_macsec_auto.h"

#define SX_MACSEC_FLOW_ENTITY_TYPE_OFFSET_OBJ_ID        (37)
#define SX_MACSEC_SC_ENTITY_TYPE_OFFSET_OBJ_ID          (36)
#define SX_MACSEC_SA_ENTITY_TYPE_OFFSET_OBJ_ID          (35)
#define SX_MACSEC_ACL_COUNTER_ENTITY_TYPE_OFFSET_OBJ_ID (34)
#define SX_MACSEC_INGRESS_DIR_OFFSET_OBJ_ID             (33)
#define SX_MACSEC_EGRESS_DIR_OFFSET_OBJ_ID              (32)
#define SX_MACSEC_PORT_OFFSET_OBJ_ID                    (16)
#define SX_MACSEC_PORT_MASK_OBJ_ID                      (0xFFFF)
#define SX_MACSEC_ENTITY_ID_MASK_OBJ_ID                 (0xFFFF)

/**************************************************************************************************************
 +--------------Object Type----------------+---------Direction--------+---Local Port---+------Entity ID-------+
 +-------- +--------+------- +-------------+-------------+------------+----------------+----------------------+
 |Flow[37] | SC[36] | SA[35] | Counter[34] | Ingress[33] | Egress[32] | Port ID[31:16] |MACSec-Entity-ID[15:0]|
 +-----------------+------------------+-------------- +--------------------+-----------+----------------------+
 ***************************************************************************************************************/

/**
 * Builds object id using id local port and direction
 */
#define SX_MACSEC_BUILD_OBJ_ID_FROM_PORT_DIR(obj_id, entity, id, port_id, direction) \
    obj_id = (id & SX_MACSEC_ENTITY_ID_MASK_OBJ_ID) |                                \
             ((SX_PORT_PHY_ID_GET(port_id) & SX_MACSEC_PORT_MASK_OBJ_ID) << 16);     \
    if (direction == SX_MACSEC_DIR_INGRESS_E) {                                      \
        obj_id = obj_id | (1L << SX_MACSEC_INGRESS_DIR_OFFSET_OBJ_ID);               \
    } else {                                                                         \
        obj_id = obj_id | (1L << SX_MACSEC_EGRESS_DIR_OFFSET_OBJ_ID);                \
    }                                                                                \
    if (entity == SX_MACSEC_ENTITY_FLOW_E) {                                         \
        obj_id = obj_id | (1L << SX_MACSEC_FLOW_ENTITY_TYPE_OFFSET_OBJ_ID);          \
    } else if (entity == SX_MACSEC_ENTITY_SC_E) {                                    \
        obj_id = obj_id | (1L << SX_MACSEC_SC_ENTITY_TYPE_OFFSET_OBJ_ID);            \
    } else if (entity == SX_MACSEC_ENTITY_SA_E) {                                    \
        obj_id = obj_id | (1L << SX_MACSEC_SA_ENTITY_TYPE_OFFSET_OBJ_ID);            \
    } else if (entity == SX_MACSEC_ENTITY_ACL_COUNTER_E) {                           \
        obj_id = obj_id | (1L << SX_MACSEC_ACL_COUNTER_ENTITY_TYPE_OFFSET_OBJ_ID);   \
    }


/**
 * Retrieve port from object id.
 */
#define SX_MACSEC_GET_PORT_FROM_OBJ_ID(obj_id, port_id) \
    ((port_id) = (obj_id >> SX_MACSEC_PORT_OFFSET_OBJ_ID) & (SX_MACSEC_PORT_MASK_OBJ_ID))

/**
 * Retrieve id from object id.
 */
#define SX_MACSEC_GET_ID_FROM_OBJ_ID(obj_id, id) ((id) = (obj_id) & (0xFFFF))

/**
 * Retrieve direction from object id.
 */
#define SX_MACSEC_GET_DIR_FROM_OBJ_ID(obj_id, direction)            \
    if ((obj_id >> SX_MACSEC_INGRESS_DIR_OFFSET_OBJ_ID) && (0x1)) { \
        direction = SX_MACSEC_DIR_INGRESS_E;                        \
    } else {                                                        \
        direction = SX_MACSEC_DIR_EGRESS_E;                         \
    }

#endif /*__SX_MACSEC_H__*/
