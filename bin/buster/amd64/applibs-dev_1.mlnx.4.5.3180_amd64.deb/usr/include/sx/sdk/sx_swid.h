/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 * LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 * FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 * See the Apache Version 2.0 License for specific language governing
 * permissions and limitations under the License.
 *
 */


#ifndef __SX_SWID_H__
#define __SX_SWID_H__

#include "sx/sdk/auto_headers/sx_swid_auto.h"


/************************************************
 *  Type definitions
 ***********************************************/

#define SX_GENERATE_ENUM(ENUM, STR) ENUM,

/**
 * SX SWID maximum/minimum values
 */
#define SX_SWID_ID_MIN     SXD_SWID_ID_MIN
#define SX_SWID_ID_MAX     SXD_SWID_ID_MAX
#define SX_SWID_ID_COUNT   SXD_SWID_ID_COUNT
#define SX_SWID_ID_MIN_MAX SXD_SWID_ID_MIN, SXD_SWID_ID_MAX
#define SX_SWID_CHECK_RANGE(swid_id) (SX_CHECK_MAX(swid_id, SX_SWID_ID_MAX) || SX_SWID_ID_STACKING == swid_id)

#define __ADD_STACKING_SWID_TO_DATABASE__
#ifndef     __ADD_STACKING_SWID_TO_DATABASE__
#define SX_SWID_ID_CHECK_RANGE(swid_id) SX_CHECK_MAX(swid_id, SX_SWID_ID_MAX)
#else   /*      __ADD_STACKING_SWID_TO_DATABASE__       */
#define SX_SWID_ID_CHECK_RANGE(swid_id) ((SX_SWID_ID_STACKING == swid_id) || SX_CHECK_MAX(swid_id, SX_SWID_ID_MAX))
#endif  /*      __ADD_STACKING_SWID_TO_DATABASE__       */

#define SX_SWID_INFO_FIELD_BIT_MIN_MAX SX_SWID_INFO_FIELD_BIT_MIN, SX_SWID_INFO_FIELD_BIT_MAX
#define SX_SWID_INFO_FIELD_BIT_CHECK_RANGE(bit) \
    SX_CHECK_RANGE(SX_SWID_INFO_FIELD_BIT_MIN,  \
                   bit,                         \
                   SX_SWID_INFO_FIELD_BIT_MAX)

#endif /* __SX_SWID_H__ */
