/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_FDB_H__
#define __SXD_EMAD_FDB_H__

#include <complib/sx_log.h>

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_emad_fdb_data.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/************************************************
 *  API functions
 ***********************************************/

/**
 * This function sets the log verbosity level of EMAD FDB MODULE
 * @param[in] cmd               - SET / GET
 * @param[in] verbosity_level_p - verbosity level
 *
 * @return SX_STATUS_SUCCESS operation completes successfully
 *          SX_STATUS_ERROR   general error
 */
sxd_status_t sxd_emad_fdb_log_verbosity_level(IN sxd_access_cmd_t      cmd,
                                              IN sx_verbosity_level_t *verbosity_level_p);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_sfdat_set(sxd_emad_sfdat_data_t        *sfdat_data_arr,
                                uint32_t                      sfdat_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_sfdat_get(sxd_emad_sfdat_data_t        *sfdat_data_arr,
                                uint32_t                      sfdat_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_sfd_set(sxd_emad_sfd_data_t          *sfd_data_arr,
                              uint32_t                      sfd_data_num,
                              sxd_emad_completion_handler_t handler,
                              void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_sfd_get(sxd_emad_sfd_data_t          *sfd_data_arr,
                              uint32_t                      sfd_data_num,
                              sxd_emad_completion_handler_t handler,
                              void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_sfn_get(sxd_emad_sfn_data_t          *sfn_data_arr,
                              uint32_t                      sfn_data_num,
                              sxd_emad_completion_handler_t handler,
                              void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_spgt_set(sxd_emad_spgt_data_t         *spgt_data_arr,
                               uint32_t                      spgt_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_spgt_get(sxd_emad_spgt_data_t         *spgt_data_arr,
                               uint32_t                      spgt_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_smid_set(sxd_emad_smid_data_t         *smid_data_arr,
                               uint32_t                      smid_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_smid_get(sxd_emad_smid_data_t         *smid_data_arr,
                               uint32_t                      smid_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_sftr_set(sxd_emad_sftr_data_t         *sftr_data_arr,
                               uint32_t                      sftr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_sftr_get(sxd_emad_sftr_data_t         *sftr_data_arr,
                               uint32_t                      sftr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_svpe_set(sxd_emad_svpe_data_t         *svpe_data_arr,
                               uint32_t                      svpe_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_svpe_get(sxd_emad_svpe_data_t         *svpe_data_arr,
                               uint32_t                      svpe_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_sfdf_set(sxd_emad_sfdf_data_t         *sfdf_data_arr,
                               uint32_t                      sfdf_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_sfdf_get(sxd_emad_sfdf_data_t         *sfdf_data_arr,
                               uint32_t                      sfdf_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_slecr_set(sxd_emad_slecr_data_t        *slecr_data_arr,
                                uint32_t                      slecr_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_slecr_get(sxd_emad_slecr_data_t        *slecr_data_arr,
                                uint32_t                      slecr_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_spmlr_set(sxd_emad_spmlr_data_t        *spmlr_data_arr,
                                uint32_t                      spmlr_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_spmlr_get(sxd_emad_spmlr_data_t        *spmlr_data_arr,
                                uint32_t                      spmlr_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 *  @param[in] handle - SX-API handle.
 *
 *   @return sxd_status_t
 */
sxd_status_t sxd_emad_spfsr_set(sxd_emad_spfsr_data_t        *spfsr_data_arr,
                                uint32_t                      spfsr_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 *  @param[in] handle - SX-API handle.
 *
 *  @return sxd_status_t
 */
sxd_status_t sxd_emad_spfsr_get(sxd_emad_spfsr_data_t        *spfsr_data_arr,
                                uint32_t                      spfsr_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_svmlr_set(sxd_emad_svmlr_data_t        *svmlr_data_arr,
                                uint32_t                      svmlr_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_svmlr_get(sxd_emad_svmlr_data_t        *svmlr_data_arr,
                                uint32_t                      svmlr_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);
/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_spvmlr_set(sxd_emad_spvmlr_data_t       *spvmlr_data_arr,
                                 uint32_t                      spvmlr_data_num,
                                 sxd_emad_completion_handler_t handler,
                                 void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_spvmlr_get(sxd_emad_spvmlr_data_t       *spvmlr_data_arr,
                                 uint32_t                      spvmlr_data_num,
                                 sxd_emad_completion_handler_t handler,
                                 void                         *context);

#endif /* __SXD_EMAD_FDB_H__ */
