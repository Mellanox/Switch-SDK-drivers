/*
 * Copyright (C) 2008-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */
/*
 * THIS FILE IS AUTO GENERATED.
 * DO NOT MAKE ANY CHANGES!
 * They will be erased with next update.
 *
 */

#ifndef __SXD_EMAD_AUTO_REG_H__
#define __SXD_EMAD_AUTO_REG_H__


#include <sx/sxd/sxd_types.h>
#include <sx/sxd/auto_registers/reg.h>

#include <complib/cl_packon.h>
/************************************************
 *  Local Defines
 ***********************************************/


/************************************************
 *  Local Macros
 ***********************************************/


/************************************************
 *  Local Type definitions
 ***********************************************/


/************************************************
 *  Defines
 ***********************************************/


/************************************************
 *  Macros
 ***********************************************/


/************************************************
 *  Type definitions
 ***********************************************/

/**
 * sxd_emad_fmtc_reg_t structure is used to store FMTC register layout.
 */
typedef struct sxd_emad_fmtc_reg {
    char reg[MLXSW_FMTC_LEN];
} PACK_SUFFIX sxd_emad_fmtc_reg_t;

/**
 * sxd_emad_icsr_reg_t structure is used to store ICSR register layout.
 */
typedef struct sxd_emad_icsr_reg {
    char reg[MLXSW_ICSR_LEN];
} PACK_SUFFIX sxd_emad_icsr_reg_t;

/**
 * sxd_emad_iicr_reg_t structure is used to store IICR register layout.
 */
typedef struct sxd_emad_iicr_reg {
    char reg[MLXSW_IICR_LEN];
} PACK_SUFFIX sxd_emad_iicr_reg_t;

/**
 * sxd_emad_fpums_reg_t structure is used to store FPUMS register layout.
 */
typedef struct sxd_emad_fpums_reg {
    char reg[MLXSW_FPUMS_LEN];
} PACK_SUFFIX sxd_emad_fpums_reg_t;

/**
 * sxd_emad_spevet_reg_t structure is used to store SPEVET register layout.
 */
typedef struct sxd_emad_spevet_reg {
    char reg[MLXSW_SPEVET_LEN];
} PACK_SUFFIX sxd_emad_spevet_reg_t;

/**
 * sxd_emad_igcr_reg_t structure is used to store IGCR register layout.
 */
typedef struct sxd_emad_igcr_reg {
    char reg[MLXSW_IGCR_LEN];
} PACK_SUFFIX sxd_emad_igcr_reg_t;

/**
 * sxd_emad_pemrbt_reg_t structure is used to store PEMRBT register layout.
 */
typedef struct sxd_emad_pemrbt_reg {
    char reg[MLXSW_PEMRBT_LEN];
} PACK_SUFFIX sxd_emad_pemrbt_reg_t;

/**
 * sxd_emad_qtqcr_reg_t structure is used to store QTQCR register layout.
 */
typedef struct sxd_emad_qtqcr_reg {
    char reg[MLXSW_QTQCR_LEN];
} PACK_SUFFIX sxd_emad_qtqcr_reg_t;

/**
 * sxd_emad_rsnh_reg_t structure is used to store RSNH register layout.
 */
typedef struct sxd_emad_rsnh_reg {
    char reg[MLXSW_RSNH_LEN];
} PACK_SUFFIX sxd_emad_rsnh_reg_t;

/**
 * sxd_emad_fmte_reg_t structure is used to store FMTE register layout.
 */
typedef struct sxd_emad_fmte_reg {
    char reg[MLXSW_FMTE_LEN];
} PACK_SUFFIX sxd_emad_fmte_reg_t;

/**
 * sxd_emad_fphhc_reg_t structure is used to store FPHHC register layout.
 */
typedef struct sxd_emad_fphhc_reg {
    char reg[MLXSW_FPHHC_LEN];
} PACK_SUFFIX sxd_emad_fphhc_reg_t;

/**
 * sxd_emad_pecnee_reg_t structure is used to store PECNEE register layout.
 */
typedef struct sxd_emad_pecnee_reg {
    char reg[MLXSW_PECNEE_LEN];
} PACK_SUFFIX sxd_emad_pecnee_reg_t;

/**
 * sxd_emad_sftr_v2_reg_t structure is used to store SFTR_V2 register layout.
 */
typedef struct sxd_emad_sftr_v2_reg {
    char reg[MLXSW_SFTR_V2_LEN];
} PACK_SUFFIX sxd_emad_sftr_v2_reg_t;

/**
 * sxd_emad_mtmp_reg_t structure is used to store MTMP register layout.
 */
typedef struct sxd_emad_mtmp_reg {
    char reg[MLXSW_MTMP_LEN];
} PACK_SUFFIX sxd_emad_mtmp_reg_t;

/**
 * sxd_emad_tieem_reg_t structure is used to store TIEEM register layout.
 */
typedef struct sxd_emad_tieem_reg {
    char reg[MLXSW_TIEEM_LEN];
} PACK_SUFFIX sxd_emad_tieem_reg_t;

/**
 * sxd_emad_pmsc_reg_t structure is used to store PMSC register layout.
 */
typedef struct sxd_emad_pmsc_reg {
    char reg[MLXSW_PMSC_LEN];
} PACK_SUFFIX sxd_emad_pmsc_reg_t;

/**
 * sxd_emad_mogcr_reg_t structure is used to store MOGCR register layout.
 */
typedef struct sxd_emad_mogcr_reg {
    char reg[MLXSW_MOGCR_LEN];
} PACK_SUFFIX sxd_emad_mogcr_reg_t;

/**
 * sxd_emad_qtqdr_reg_t structure is used to store QTQDR register layout.
 */
typedef struct sxd_emad_qtqdr_reg {
    char reg[MLXSW_QTQDR_LEN];
} PACK_SUFFIX sxd_emad_qtqdr_reg_t;

/**
 * sxd_emad_rtdp_reg_t structure is used to store RTDP register layout.
 */
typedef struct sxd_emad_rtdp_reg {
    char reg[MLXSW_RTDP_LEN];
} PACK_SUFFIX sxd_emad_rtdp_reg_t;

/**
 * sxd_emad_pecner_reg_t structure is used to store PECNER register layout.
 */
typedef struct sxd_emad_pecner_reg {
    char reg[MLXSW_PECNER_LEN];
} PACK_SUFFIX sxd_emad_pecner_reg_t;

/**
 * sxd_emad_ifbo_reg_t structure is used to store IFBO register layout.
 */
typedef struct sxd_emad_ifbo_reg {
    char reg[MLXSW_IFBO_LEN];
} PACK_SUFFIX sxd_emad_ifbo_reg_t;

/**
 * sxd_emad_tneem_reg_t structure is used to store TNEEM register layout.
 */
typedef struct sxd_emad_tneem_reg {
    char reg[MLXSW_TNEEM_LEN];
} PACK_SUFFIX sxd_emad_tneem_reg_t;

/**
 * sxd_emad_qtdem_reg_t structure is used to store QTDEM register layout.
 */
typedef struct sxd_emad_qtdem_reg {
    char reg[MLXSW_QTDEM_LEN];
} PACK_SUFFIX sxd_emad_qtdem_reg_t;

/**
 * sxd_emad_tnifr_reg_t structure is used to store TNIFR register layout.
 */
typedef struct sxd_emad_tnifr_reg {
    char reg[MLXSW_TNIFR_LEN];
} PACK_SUFFIX sxd_emad_tnifr_reg_t;

/**
 * sxd_emad_peaps_reg_t structure is used to store PEAPS register layout.
 */
typedef struct sxd_emad_peaps_reg {
    char reg[MLXSW_PEAPS_LEN];
} PACK_SUFFIX sxd_emad_peaps_reg_t;

/**
 * sxd_emad_pmpe_reg_t structure is used to store PMPE register layout.
 */
typedef struct sxd_emad_pmpe_reg {
    char reg[MLXSW_PMPE_LEN];
} PACK_SUFFIX sxd_emad_pmpe_reg_t;

/**
 * sxd_emad_hcot_reg_t structure is used to store HCOT register layout.
 */
typedef struct sxd_emad_hcot_reg {
    char reg[MLXSW_HCOT_LEN];
} PACK_SUFFIX sxd_emad_hcot_reg_t;

/**
 * sxd_emad_fmtm_reg_t structure is used to store FMTM register layout.
 */
typedef struct sxd_emad_fmtm_reg {
    char reg[MLXSW_FMTM_LEN];
} PACK_SUFFIX sxd_emad_fmtm_reg_t;

/**
 * sxd_emad_chltm_reg_t structure is used to store CHLTM register layout.
 */
typedef struct sxd_emad_chltm_reg {
    char reg[MLXSW_CHLTM_LEN];
} PACK_SUFFIX sxd_emad_chltm_reg_t;

/**
 * sxd_emad_mafti_reg_t structure is used to store MAFTI register layout.
 */
typedef struct sxd_emad_mafti_reg {
    char reg[MLXSW_MAFTI_LEN];
} PACK_SUFFIX sxd_emad_mafti_reg_t;

/**
 * sxd_emad_qteem_reg_t structure is used to store QTEEM register layout.
 */
typedef struct sxd_emad_qteem_reg {
    char reg[MLXSW_QTEEM_LEN];
} PACK_SUFFIX sxd_emad_qteem_reg_t;

/**
 * sxd_emad_hmon_reg_t structure is used to store HMON register layout.
 */
typedef struct sxd_emad_hmon_reg {
    char reg[MLXSW_HMON_LEN];
} PACK_SUFFIX sxd_emad_hmon_reg_t;

/**
 * sxd_emad_mgpir_reg_t structure is used to store MGPIR register layout.
 */
typedef struct sxd_emad_mgpir_reg {
    char reg[MLXSW_MGPIR_LEN];
} PACK_SUFFIX sxd_emad_mgpir_reg_t;

/**
 * sxd_emad_pmtm_reg_t structure is used to store PMTM register layout.
 */
typedef struct sxd_emad_pmtm_reg {
    char reg[MLXSW_PMTM_LEN];
} PACK_SUFFIX sxd_emad_pmtm_reg_t;

/**
 * sxd_emad_tnqdr_reg_t structure is used to store TNQDR register layout.
 */
typedef struct sxd_emad_tnqdr_reg {
    char reg[MLXSW_TNQDR_LEN];
} PACK_SUFFIX sxd_emad_tnqdr_reg_t;

/**
 * sxd_emad_sffp_reg_t structure is used to store SFFP register layout.
 */
typedef struct sxd_emad_sffp_reg {
    char reg[MLXSW_SFFP_LEN];
} PACK_SUFFIX sxd_emad_sffp_reg_t;

/**
 * sxd_emad_mpcir_reg_t structure is used to store MPCIR register layout.
 */
typedef struct sxd_emad_mpcir_reg {
    char reg[MLXSW_MPCIR_LEN];
} PACK_SUFFIX sxd_emad_mpcir_reg_t;

/**
 * sxd_emad_pmecr_reg_t structure is used to store PMECR register layout.
 */
typedef struct sxd_emad_pmecr_reg {
    char reg[MLXSW_PMECR_LEN];
} PACK_SUFFIX sxd_emad_pmecr_reg_t;

/**
 * sxd_emad_pter_reg_t structure is used to store PTER register layout.
 */
typedef struct sxd_emad_pter_reg {
    char reg[MLXSW_PTER_LEN];
} PACK_SUFFIX sxd_emad_pter_reg_t;

/**
 * sxd_emad_smpu_reg_t structure is used to store SMPU register layout.
 */
typedef struct sxd_emad_smpu_reg {
    char reg[MLXSW_SMPU_LEN];
} PACK_SUFFIX sxd_emad_smpu_reg_t;

/**
 * sxd_emad_cegcr_reg_t structure is used to store CEGCR register layout.
 */
typedef struct sxd_emad_cegcr_reg {
    char reg[MLXSW_CEGCR_LEN];
} PACK_SUFFIX sxd_emad_cegcr_reg_t;

/**
 * sxd_emad_pmtu_reg_t structure is used to store PMTU register layout.
 */
typedef struct sxd_emad_pmtu_reg {
    char reg[MLXSW_PMTU_LEN];
} PACK_SUFFIX sxd_emad_pmtu_reg_t;

/**
 * sxd_emad_pmmp_reg_t structure is used to store PMMP register layout.
 */
typedef struct sxd_emad_pmmp_reg {
    char reg[MLXSW_PMMP_LEN];
} PACK_SUFFIX sxd_emad_pmmp_reg_t;

/**
 * sxd_emad_fmep_reg_t structure is used to store FMEP register layout.
 */
typedef struct sxd_emad_fmep_reg {
    char reg[MLXSW_FMEP_LEN];
} PACK_SUFFIX sxd_emad_fmep_reg_t;

/**
 * sxd_emad_pecnrr_reg_t structure is used to store PECNRR register layout.
 */
typedef struct sxd_emad_pecnrr_reg {
    char reg[MLXSW_PECNRR_LEN];
} PACK_SUFFIX sxd_emad_pecnrr_reg_t;

/**
 * sxd_emad_rarlpgt_reg_t structure is used to store RARLPGT register layout.
 */
typedef struct sxd_emad_rarlpgt_reg {
    char reg[MLXSW_RARLPGT_LEN];
} PACK_SUFFIX sxd_emad_rarlpgt_reg_t;

/**
 * sxd_emad_fpftt_reg_t structure is used to store FPFTT register layout.
 */
typedef struct sxd_emad_fpftt_reg {
    char reg[MLXSW_FPFTT_LEN];
} PACK_SUFFIX sxd_emad_fpftt_reg_t;

/**
 * sxd_emad_mddq_reg_t structure is used to store MDDQ register layout.
 */
typedef struct sxd_emad_mddq_reg {
    char reg[MLXSW_MDDQ_LEN];
} PACK_SUFFIX sxd_emad_mddq_reg_t;

/**
 * sxd_emad_tnpc_reg_t structure is used to store TNPC register layout.
 */
typedef struct sxd_emad_tnpc_reg {
    char reg[MLXSW_TNPC_LEN];
} PACK_SUFFIX sxd_emad_tnpc_reg_t;

/**
 * sxd_emad_pecnre_reg_t structure is used to store PECNRE register layout.
 */
typedef struct sxd_emad_pecnre_reg {
    char reg[MLXSW_PECNRE_LEN];
} PACK_SUFFIX sxd_emad_pecnre_reg_t;

/**
 * sxd_emad_mofs_reg_t structure is used to store MOFS register layout.
 */
typedef struct sxd_emad_mofs_reg {
    char reg[MLXSW_MOFS_LEN];
} PACK_SUFFIX sxd_emad_mofs_reg_t;

/**
 * sxd_emad_ralcm_reg_t structure is used to store RALCM register layout.
 */
typedef struct sxd_emad_ralcm_reg {
    char reg[MLXSW_RALCM_LEN];
} PACK_SUFFIX sxd_emad_ralcm_reg_t;

/**
 * sxd_emad_mtwe_reg_t structure is used to store MTWE register layout.
 */
typedef struct sxd_emad_mtwe_reg {
    char reg[MLXSW_MTWE_LEN];
} PACK_SUFFIX sxd_emad_mtwe_reg_t;

/**
 * sxd_emad_mgir_reg_t structure is used to store MGIR register layout.
 */
typedef struct sxd_emad_mgir_reg {
    char reg[MLXSW_MGIR_LEN];
} PACK_SUFFIX sxd_emad_mgir_reg_t;

/**
 * sxd_emad_tidem_reg_t structure is used to store TIDEM register layout.
 */
typedef struct sxd_emad_tidem_reg {
    char reg[MLXSW_TIDEM_LEN];
} PACK_SUFFIX sxd_emad_tidem_reg_t;

/**
 * sxd_emad_tigcr_reg_t structure is used to store TIGCR register layout.
 */
typedef struct sxd_emad_tigcr_reg {
    char reg[MLXSW_TIGCR_LEN];
} PACK_SUFFIX sxd_emad_tigcr_reg_t;

/**
 * sxd_emad_rlcmld_reg_t structure is used to store RLCMLD register layout.
 */
typedef struct sxd_emad_rlcmld_reg {
    char reg[MLXSW_RLCMLD_LEN];
} PACK_SUFFIX sxd_emad_rlcmld_reg_t;

/**
 * sxd_emad_ceer_reg_t structure is used to store CEER register layout.
 */
typedef struct sxd_emad_ceer_reg {
    char reg[MLXSW_CEER_LEN];
} PACK_SUFFIX sxd_emad_ceer_reg_t;

/**
 * sxd_emad_pmtdb_reg_t structure is used to store PMTDB register layout.
 */
typedef struct sxd_emad_pmtdb_reg {
    char reg[MLXSW_PMTDB_LEN];
} PACK_SUFFIX sxd_emad_pmtdb_reg_t;

/**
 * sxd_emad_ibfmrc_reg_t structure is used to store IBFMRC register layout.
 */
typedef struct sxd_emad_ibfmrc_reg {
    char reg[MLXSW_IBFMRC_LEN];
} PACK_SUFFIX sxd_emad_ibfmrc_reg_t;

/**
 * sxd_emad_tnifr_v2_reg_t structure is used to store TNIFR_V2 register layout.
 */
typedef struct sxd_emad_tnifr_v2_reg {
    char reg[MLXSW_TNIFR_V2_LEN];
} PACK_SUFFIX sxd_emad_tnifr_v2_reg_t;

/**
 * sxd_emad_smid_v2_reg_t structure is used to store SMID_V2 register layout.
 */
typedef struct sxd_emad_smid_v2_reg {
    char reg[MLXSW_SMID_V2_LEN];
} PACK_SUFFIX sxd_emad_smid_v2_reg_t;

/**
 * sxd_emad_xralta_reg_t structure is used to store XRALTA register layout.
 */
typedef struct sxd_emad_xralta_reg {
    char reg[MLXSW_XRALTA_LEN];
} PACK_SUFFIX sxd_emad_xralta_reg_t;

/**
 * sxd_emad_mpagr_reg_t structure is used to store MPAGR register layout.
 */
typedef struct sxd_emad_mpagr_reg {
    char reg[MLXSW_MPAGR_LEN];
} PACK_SUFFIX sxd_emad_mpagr_reg_t;

/**
 * sxd_emad_xltq_reg_t structure is used to store XLTQ register layout.
 */
typedef struct sxd_emad_xltq_reg {
    char reg[MLXSW_XLTQ_LEN];
} PACK_SUFFIX sxd_emad_xltq_reg_t;

/**
 * sxd_emad_ppcnt_reg_t structure is used to store PPCNT register layout.
 */
typedef struct sxd_emad_ppcnt_reg {
    char reg[MLXSW_PPCNT_LEN];
} PACK_SUFFIX sxd_emad_ppcnt_reg_t;

/**
 * sxd_emad_pefaad_reg_t structure is used to store PEFAAD register layout.
 */
typedef struct sxd_emad_pefaad_reg {
    char reg[MLXSW_PEFAAD_LEN];
} PACK_SUFFIX sxd_emad_pefaad_reg_t;

/**
 * sxd_emad_pmlpe_reg_t structure is used to store PMLPE register layout.
 */
typedef struct sxd_emad_pmlpe_reg {
    char reg[MLXSW_PMLPE_LEN];
} PACK_SUFFIX sxd_emad_pmlpe_reg_t;

/**
 * sxd_emad_chlmm_reg_t structure is used to store CHLMM register layout.
 */
typedef struct sxd_emad_chlmm_reg {
    char reg[MLXSW_CHLMM_LEN];
} PACK_SUFFIX sxd_emad_chlmm_reg_t;

/**
 * sxd_emad_tncr_reg_t structure is used to store TNCR register layout.
 */
typedef struct sxd_emad_tncr_reg {
    char reg[MLXSW_TNCR_LEN];
} PACK_SUFFIX sxd_emad_tncr_reg_t;

/**
 * sxd_emad_rarlu_reg_t structure is used to store RARLU register layout.
 */
typedef struct sxd_emad_rarlu_reg {
    char reg[MLXSW_RARLU_LEN];
} PACK_SUFFIX sxd_emad_rarlu_reg_t;

/**
 * sxd_emad_sbsns_reg_t structure is used to store SBSNS register layout.
 */
typedef struct sxd_emad_sbsns_reg {
    char reg[MLXSW_SBSNS_LEN];
} PACK_SUFFIX sxd_emad_sbsns_reg_t;

/**
 * sxd_emad_xmdr_reg_t structure is used to store XMDR register layout.
 */
typedef struct sxd_emad_xmdr_reg {
    char reg[MLXSW_XMDR_LEN];
} PACK_SUFFIX sxd_emad_xmdr_reg_t;

/**
 * sxd_emad_mdfcr_reg_t structure is used to store MDFCR register layout.
 */
typedef struct sxd_emad_mdfcr_reg {
    char reg[MLXSW_MDFCR_LEN];
} PACK_SUFFIX sxd_emad_mdfcr_reg_t;

/**
 * sxd_emad_mddc_reg_t structure is used to store MDDC register layout.
 */
typedef struct sxd_emad_mddc_reg {
    char reg[MLXSW_MDDC_LEN];
} PACK_SUFFIX sxd_emad_mddc_reg_t;

/**
 * sxd_emad_paos_reg_t structure is used to store PAOS register layout.
 */
typedef struct sxd_emad_paos_reg {
    char reg[MLXSW_PAOS_LEN];
} PACK_SUFFIX sxd_emad_paos_reg_t;

/**
 * sxd_emad_mtutc_reg_t structure is used to store MTUTC register layout.
 */
typedef struct sxd_emad_mtutc_reg {
    char reg[MLXSW_MTUTC_LEN];
} PACK_SUFFIX sxd_emad_mtutc_reg_t;

/**
 * sxd_emad_sfmr_reg_t structure is used to store SFMR register layout.
 */
typedef struct sxd_emad_sfmr_reg {
    char reg[MLXSW_SFMR_LEN];
} PACK_SUFFIX sxd_emad_sfmr_reg_t;

/**
 * sxd_emad_hrdqt_reg_t structure is used to store HRDQT register layout.
 */
typedef struct sxd_emad_hrdqt_reg {
    char reg[MLXSW_HRDQT_LEN];
} PACK_SUFFIX sxd_emad_hrdqt_reg_t;

/**
 * sxd_emad_mtsde_reg_t structure is used to store MTSDE register layout.
 */
typedef struct sxd_emad_mtsde_reg {
    char reg[MLXSW_MTSDE_LEN];
} PACK_SUFFIX sxd_emad_mtsde_reg_t;

/**
 * sxd_emad_smpe_reg_t structure is used to store SMPE register layout.
 */
typedef struct sxd_emad_smpe_reg {
    char reg[MLXSW_SMPE_LEN];
} PACK_SUFFIX sxd_emad_smpe_reg_t;

/**
 * sxd_emad_hett_reg_t structure is used to store HETT register layout.
 */
typedef struct sxd_emad_hett_reg {
    char reg[MLXSW_HETT_LEN];
} PACK_SUFFIX sxd_emad_hett_reg_t;

/**
 * sxd_emad_xgcr_reg_t structure is used to store XGCR register layout.
 */
typedef struct sxd_emad_xgcr_reg {
    char reg[MLXSW_XGCR_LEN];
} PACK_SUFFIX sxd_emad_xgcr_reg_t;

/**
 * sxd_emad_tiqdr_reg_t structure is used to store TIQDR register layout.
 */
typedef struct sxd_emad_tiqdr_reg {
    char reg[MLXSW_TIQDR_LEN];
} PACK_SUFFIX sxd_emad_tiqdr_reg_t;

/**
 * sxd_emad_xraltb_reg_t structure is used to store XRALTB register layout.
 */
typedef struct sxd_emad_xraltb_reg {
    char reg[MLXSW_XRALTB_LEN];
} PACK_SUFFIX sxd_emad_xraltb_reg_t;

/**
 * sxd_emad_tngee_reg_t structure is used to store TNGEE register layout.
 */
typedef struct sxd_emad_tngee_reg {
    char reg[MLXSW_TNGEE_LEN];
} PACK_SUFFIX sxd_emad_tngee_reg_t;

/**
 * sxd_emad_spms_v2_reg_t structure is used to store SPMS_V2 register layout.
 */
typedef struct sxd_emad_spms_v2_reg {
    char reg[MLXSW_SPMS_V2_LEN];
} PACK_SUFFIX sxd_emad_spms_v2_reg_t;

/**
 * sxd_emad_smpeb_reg_t structure is used to store SMPEB register layout.
 */
typedef struct sxd_emad_smpeb_reg {
    char reg[MLXSW_SMPEB_LEN];
} PACK_SUFFIX sxd_emad_smpeb_reg_t;

/**
 * sxd_emad_ibfmr_reg_t structure is used to store IBFMR register layout.
 */
typedef struct sxd_emad_ibfmr_reg {
    char reg[MLXSW_IBFMR_LEN];
} PACK_SUFFIX sxd_emad_ibfmr_reg_t;

/**
 * sxd_emad_sbsnte_reg_t structure is used to store SBSNTE register layout.
 */
typedef struct sxd_emad_sbsnte_reg {
    char reg[MLXSW_SBSNTE_LEN];
} PACK_SUFFIX sxd_emad_sbsnte_reg_t;

/**
 * sxd_emad_ppbs_reg_t structure is used to store PPBS register layout.
 */
typedef struct sxd_emad_ppbs_reg {
    char reg[MLXSW_PPBS_LEN];
} PACK_SUFFIX sxd_emad_ppbs_reg_t;

/**
 * sxd_emad_fppc_reg_t structure is used to store FPPC register layout.
 */
typedef struct sxd_emad_fppc_reg {
    char reg[MLXSW_FPPC_LEN];
} PACK_SUFFIX sxd_emad_fppc_reg_t;

/**
 * sxd_emad_mtewe_reg_t structure is used to store MTEWE register layout.
 */
typedef struct sxd_emad_mtewe_reg {
    char reg[MLXSW_MTEWE_LEN];
} PACK_SUFFIX sxd_emad_mtewe_reg_t;

/**
 * sxd_emad_hgcr_reg_t structure is used to store HGCR register layout.
 */
typedef struct sxd_emad_hgcr_reg {
    char reg[MLXSW_HGCR_LEN];
} PACK_SUFFIX sxd_emad_hgcr_reg_t;

/**
 * sxd_emad_xlkbu_reg_t structure is used to store XLKBU register layout.
 */
typedef struct sxd_emad_xlkbu_reg {
    char reg[MLXSW_XLKBU_LEN];
} PACK_SUFFIX sxd_emad_xlkbu_reg_t;

/**
 * sxd_emad_xrmt_reg_t structure is used to store XRMT register layout.
 */
typedef struct sxd_emad_xrmt_reg {
    char reg[MLXSW_XRMT_LEN];
} PACK_SUFFIX sxd_emad_xrmt_reg_t;

/**
 * sxd_emad_cepc_reg_t structure is used to store CEPC register layout.
 */
typedef struct sxd_emad_cepc_reg {
    char reg[MLXSW_CEPC_LEN];
} PACK_SUFFIX sxd_emad_cepc_reg_t;

/**
 * sxd_emad_reiv_reg_t structure is used to store REIV register layout.
 */
typedef struct sxd_emad_reiv_reg {
    char reg[MLXSW_REIV_LEN];
} PACK_SUFFIX sxd_emad_reiv_reg_t;

/**
 * sxd_emad_ppad_reg_t structure is used to store PPAD register layout.
 */
typedef struct sxd_emad_ppad_reg {
    char reg[MLXSW_PPAD_LEN];
} PACK_SUFFIX sxd_emad_ppad_reg_t;

/**
 * sxd_emad_prei_reg_t structure is used to store PREI register layout.
 */
typedef struct sxd_emad_prei_reg {
    char reg[MLXSW_PREI_LEN];
} PACK_SUFFIX sxd_emad_prei_reg_t;

/**
 * sxd_emad_mocs_reg_t structure is used to store MOCS register layout.
 */
typedef struct sxd_emad_mocs_reg {
    char reg[MLXSW_MOCS_LEN];
} PACK_SUFFIX sxd_emad_mocs_reg_t;

/**
 * sxd_emad_pllp_reg_t structure is used to store PLLP register layout.
 */
typedef struct sxd_emad_pllp_reg {
    char reg[MLXSW_PLLP_LEN];
} PACK_SUFFIX sxd_emad_pllp_reg_t;

/**
 * sxd_emad_qeec_reg_t structure is used to store QEEC register layout.
 */
typedef struct sxd_emad_qeec_reg {
    char reg[MLXSW_QEEC_LEN];
} PACK_SUFFIX sxd_emad_qeec_reg_t;

/**
 * sxd_emad_rlcmle_reg_t structure is used to store RLCMLE register layout.
 */
typedef struct sxd_emad_rlcmle_reg {
    char reg[MLXSW_RLCMLE_LEN];
} PACK_SUFFIX sxd_emad_rlcmle_reg_t;

/**
 * sxd_emad_sbsnt_reg_t structure is used to store SBSNT register layout.
 */
typedef struct sxd_emad_sbsnt_reg {
    char reg[MLXSW_SBSNT_LEN];
} PACK_SUFFIX sxd_emad_sbsnt_reg_t;

/**
 * sxd_emad_rarft_reg_t structure is used to store RARFT register layout.
 */
typedef struct sxd_emad_rarft_reg {
    char reg[MLXSW_RARFT_LEN];
} PACK_SUFFIX sxd_emad_rarft_reg_t;

/**
 * sxd_emad_mcqi_reg_t structure is used to store MCQI register layout.
 */
typedef struct sxd_emad_mcqi_reg {
    char reg[MLXSW_MCQI_LEN];
} PACK_SUFFIX sxd_emad_mcqi_reg_t;

/**
 * sxd_emad_chltr_reg_t structure is used to store CHLTR register layout.
 */
typedef struct sxd_emad_chltr_reg {
    char reg[MLXSW_CHLTR_LEN];
} PACK_SUFFIX sxd_emad_chltr_reg_t;

/**
 * sxd_emad_rarsr_reg_t structure is used to store RARSR register layout.
 */
typedef struct sxd_emad_rarsr_reg {
    char reg[MLXSW_RARSR_LEN];
} PACK_SUFFIX sxd_emad_rarsr_reg_t;

/**
 * sxd_emad_tngcr_reg_t structure is used to store TNGCR register layout.
 */
typedef struct sxd_emad_tngcr_reg {
    char reg[MLXSW_TNGCR_LEN];
} PACK_SUFFIX sxd_emad_tngcr_reg_t;

/**
 * sxd_emad_molp_reg_t structure is used to store MOLP register layout.
 */
typedef struct sxd_emad_molp_reg {
    char reg[MLXSW_MOLP_LEN];
} PACK_SUFFIX sxd_emad_molp_reg_t;

/**
 * sxd_emad_qtttl_reg_t structure is used to store QTTTL register layout.
 */
typedef struct sxd_emad_qtttl_reg {
    char reg[MLXSW_QTTTL_LEN];
} PACK_SUFFIX sxd_emad_qtttl_reg_t;

/**
 * sxd_emad_ptasv2_reg_t structure is used to store PTASV2 register layout.
 */
typedef struct sxd_emad_ptasv2_reg {
    char reg[MLXSW_PTASV2_LEN];
} PACK_SUFFIX sxd_emad_ptasv2_reg_t;

/**
 * sxd_emad_mddt_reg_t structure is used to store MDDT register layout.
 */
typedef struct sxd_emad_mddt_reg {
    char reg[MLXSW_MDDT_LEN];
} PACK_SUFFIX sxd_emad_mddt_reg_t;

/**
 * sxd_emad_rips_reg_t structure is used to store RIPS register layout.
 */
typedef struct sxd_emad_rips_reg {
    char reg[MLXSW_RIPS_LEN];
} PACK_SUFFIX sxd_emad_rips_reg_t;

/**
 * sxd_emad_tndem_reg_t structure is used to store TNDEM register layout.
 */
typedef struct sxd_emad_tndem_reg {
    char reg[MLXSW_TNDEM_LEN];
} PACK_SUFFIX sxd_emad_tndem_reg_t;

/**
 * sxd_emad_mafbi_reg_t structure is used to store MAFBI register layout.
 */
typedef struct sxd_emad_mafbi_reg {
    char reg[MLXSW_MAFBI_LEN];
} PACK_SUFFIX sxd_emad_mafbi_reg_t;

/**
 * sxd_emad_pifr_v2_reg_t structure is used to store PIFR_V2 register layout.
 */
typedef struct sxd_emad_pifr_v2_reg {
    char reg[MLXSW_PIFR_V2_LEN];
} PACK_SUFFIX sxd_emad_pifr_v2_reg_t;

/**
 * sxd_emad_rarpc_reg_t structure is used to store RARPC register layout.
 */
typedef struct sxd_emad_rarpc_reg {
    char reg[MLXSW_RARPC_LEN];
} PACK_SUFFIX sxd_emad_rarpc_reg_t;

/**
 * sxd_emad_sfdb_v2_reg_t structure is used to store SFDB_V2 register layout.
 */
typedef struct sxd_emad_sfdb_v2_reg {
    char reg[MLXSW_SFDB_V2_LEN];
} PACK_SUFFIX sxd_emad_sfdb_v2_reg_t;

/**
 * sxd_emad_tnumt_reg_t structure is used to store TNUMT register layout.
 */
typedef struct sxd_emad_tnumt_reg {
    char reg[MLXSW_TNUMT_LEN];
} PACK_SUFFIX sxd_emad_tnumt_reg_t;

/**
 * sxd_emad_rlcme_reg_t structure is used to store RLCME register layout.
 */
typedef struct sxd_emad_rlcme_reg {
    char reg[MLXSW_RLCME_LEN];
} PACK_SUFFIX sxd_emad_rlcme_reg_t;

/**
 * sxd_emad_fpts_reg_t structure is used to store FPTS register layout.
 */
typedef struct sxd_emad_fpts_reg {
    char reg[MLXSW_FPTS_LEN];
} PACK_SUFFIX sxd_emad_fpts_reg_t;

/**
 * sxd_emad_rarpr_reg_t structure is used to store RARPR register layout.
 */
typedef struct sxd_emad_rarpr_reg {
    char reg[MLXSW_RARPR_LEN];
} PACK_SUFFIX sxd_emad_rarpr_reg_t;

/**
 * sxd_emad_htacg_reg_t structure is used to store HTACG register layout.
 */
typedef struct sxd_emad_htacg_reg {
    char reg[MLXSW_HTACG_LEN];
} PACK_SUFFIX sxd_emad_htacg_reg_t;

/**
 * sxd_emad_pevpb_reg_t structure is used to store PEVPB register layout.
 */
typedef struct sxd_emad_pevpb_reg {
    char reg[MLXSW_PEVPB_LEN];
} PACK_SUFFIX sxd_emad_pevpb_reg_t;

/**
 * sxd_emad_sfgc_reg_t structure is used to store SFGC register layout.
 */
typedef struct sxd_emad_sfgc_reg {
    char reg[MLXSW_SFGC_LEN];
} PACK_SUFFIX sxd_emad_sfgc_reg_t;

/**
 * sxd_emad_mcion_reg_t structure is used to store MCION register layout.
 */
typedef struct sxd_emad_mcion_reg {
    char reg[MLXSW_MCION_LEN];
} PACK_SUFFIX sxd_emad_mcion_reg_t;

/**
 * sxd_emad_tiqcr_reg_t structure is used to store TIQCR register layout.
 */
typedef struct sxd_emad_tiqcr_reg {
    char reg[MLXSW_TIQCR_LEN];
} PACK_SUFFIX sxd_emad_tiqcr_reg_t;

/**
 * sxd_emad_tncr_v2_reg_t structure is used to store TNCR_V2 register layout.
 */
typedef struct sxd_emad_tncr_v2_reg {
    char reg[MLXSW_TNCR_V2_LEN];
} PACK_SUFFIX sxd_emad_tncr_v2_reg_t;

/**
 * sxd_emad_pcsr_reg_t structure is used to store PCSR register layout.
 */
typedef struct sxd_emad_pcsr_reg {
    char reg[MLXSW_PCSR_LEN];
} PACK_SUFFIX sxd_emad_pcsr_reg_t;

/**
 * sxd_emad_rarcc_reg_t structure is used to store RARCC register layout.
 */
typedef struct sxd_emad_rarcc_reg {
    char reg[MLXSW_RARCC_LEN];
} PACK_SUFFIX sxd_emad_rarcc_reg_t;

/**
 * sxd_emad_cedr_reg_t structure is used to store CEDR register layout.
 */
typedef struct sxd_emad_cedr_reg {
    char reg[MLXSW_CEDR_LEN];
} PACK_SUFFIX sxd_emad_cedr_reg_t;

/**
 * sxd_emad_rmid_v2_reg_t structure is used to store RMID_V2 register layout.
 */
typedef struct sxd_emad_rmid_v2_reg {
    char reg[MLXSW_RMID_V2_LEN];
} PACK_SUFFIX sxd_emad_rmid_v2_reg_t;

/**
 * sxd_emad_rarcl_reg_t structure is used to store RARCL register layout.
 */
typedef struct sxd_emad_rarcl_reg {
    char reg[MLXSW_RARCL_LEN];
} PACK_SUFFIX sxd_emad_rarcl_reg_t;

/**
 * sxd_emad_mafcr_reg_t structure is used to store MAFCR register layout.
 */
typedef struct sxd_emad_mafcr_reg {
    char reg[MLXSW_MAFCR_LEN];
} PACK_SUFFIX sxd_emad_mafcr_reg_t;

/**
 * sxd_emad_xralst_reg_t structure is used to store XRALST register layout.
 */
typedef struct sxd_emad_xralst_reg {
    char reg[MLXSW_XRALST_LEN];
} PACK_SUFFIX sxd_emad_xralst_reg_t;

/**
 * sxd_emad_sbsrd_reg_t structure is used to store SBSRD register layout.
 */
typedef struct sxd_emad_sbsrd_reg {
    char reg[MLXSW_SBSRD_LEN];
} PACK_SUFFIX sxd_emad_sbsrd_reg_t;

/**
 * sxd_emad_plar_reg_t structure is used to store PLAR register layout.
 */
typedef struct sxd_emad_plar_reg {
    char reg[MLXSW_PLAR_LEN];
} PACK_SUFFIX sxd_emad_plar_reg_t;

/**
 * sxd_emad_iddd_reg_t structure is used to store IDDD register layout.
 */
typedef struct sxd_emad_iddd_reg {
    char reg[MLXSW_IDDD_LEN];
} PACK_SUFFIX sxd_emad_iddd_reg_t;

/**
 * sxd_emad_iedr_reg_t structure is used to store IEDR register layout.
 */
typedef struct sxd_emad_iedr_reg {
    char reg[MLXSW_IEDR_LEN];
} PACK_SUFFIX sxd_emad_iedr_reg_t;

/**
 * sxd_emad_ieds_reg_t structure is used to store IEDS register layout.
 */
typedef struct sxd_emad_ieds_reg {
    char reg[MLXSW_IEDS_LEN];
} PACK_SUFFIX sxd_emad_ieds_reg_t;

/**
 * sxd_emad_pmaos_reg_t structure is used to store PMAOS register layout.
 */
typedef struct sxd_emad_pmaos_reg {
    char reg[MLXSW_PMAOS_LEN];
} PACK_SUFFIX sxd_emad_pmaos_reg_t;

/**
 * sxd_emad_rxlte_reg_t structure is used to store RXLTE register layout.
 */
typedef struct sxd_emad_rxlte_reg {
    char reg[MLXSW_RXLTE_LEN];
} PACK_SUFFIX sxd_emad_rxlte_reg_t;

/**
 * sxd_emad_sbhbr_v2_reg_t structure is used to store SBHBR_V2 register layout.
 */
typedef struct sxd_emad_sbhbr_v2_reg {
    char reg[MLXSW_SBHBR_V2_LEN];
} PACK_SUFFIX sxd_emad_sbhbr_v2_reg_t;

/**
 * sxd_emad_tnqcr_reg_t structure is used to store TNQCR register layout.
 */
typedef struct sxd_emad_tnqcr_reg {
    char reg[MLXSW_TNQCR_LEN];
} PACK_SUFFIX sxd_emad_tnqcr_reg_t;

/**
 * sxd_emad_sbhrr_v2_reg_t structure is used to store SBHRR_V2 register layout.
 */
typedef struct sxd_emad_sbhrr_v2_reg {
    char reg[MLXSW_SBHRR_V2_LEN];
} PACK_SUFFIX sxd_emad_sbhrr_v2_reg_t;

/**
 * sxd_emad_pbsr_reg_t structure is used to store PBSR register layout.
 */
typedef struct sxd_emad_pbsr_reg {
    char reg[MLXSW_PBSR_LEN];
} PACK_SUFFIX sxd_emad_pbsr_reg_t;

/**
 * sxd_emad_rxltm_reg_t structure is used to store RXLTM register layout.
 */
typedef struct sxd_emad_rxltm_reg {
    char reg[MLXSW_RXLTM_LEN];
} PACK_SUFFIX sxd_emad_rxltm_reg_t;

/**
 * sxd_emad_momte_reg_t structure is used to store MOMTE register layout.
 */
typedef struct sxd_emad_momte_reg {
    char reg[MLXSW_MOMTE_LEN];
} PACK_SUFFIX sxd_emad_momte_reg_t;

/**
 * sxd_emad_rmpe_reg_t structure is used to store RMPE register layout.
 */
typedef struct sxd_emad_rmpe_reg {
    char reg[MLXSW_RMPE_LEN];
} PACK_SUFFIX sxd_emad_rmpe_reg_t;

/**
 * sxd_emad_svfa_reg_t structure is used to store SVFA register layout.
 */
typedef struct sxd_emad_svfa_reg {
    char reg[MLXSW_SVFA_LEN];
} PACK_SUFFIX sxd_emad_svfa_reg_t;

/**
 * sxd_emad_mafri_reg_t structure is used to store MAFRI register layout.
 */
typedef struct sxd_emad_mafri_reg {
    char reg[MLXSW_MAFRI_LEN];
} PACK_SUFFIX sxd_emad_mafri_reg_t;

/**
 * sxd_emad_ihsr_reg_t structure is used to store IHSR register layout.
 */
typedef struct sxd_emad_ihsr_reg {
    char reg[MLXSW_IHSR_LEN];
} PACK_SUFFIX sxd_emad_ihsr_reg_t;

/**
 * sxd_emad_fphtt_reg_t structure is used to store FPHTT register layout.
 */
typedef struct sxd_emad_fphtt_reg {
    char reg[MLXSW_FPHTT_LEN];
} PACK_SUFFIX sxd_emad_fphtt_reg_t;

/**
 * sxd_emad_mcc_reg_t structure is used to store MCC register layout.
 */
typedef struct sxd_emad_mcc_reg {
    char reg[MLXSW_MCC_LEN];
} PACK_SUFFIX sxd_emad_mcc_reg_t;

/**
 * sxd_emad_sfdb_reg_t structure is used to store SFDB register layout.
 */
typedef struct sxd_emad_sfdb_reg {
    char reg[MLXSW_SFDB_LEN];
} PACK_SUFFIX sxd_emad_sfdb_reg_t;

/**
 * sxd_emad_pmtps_reg_t structure is used to store PMTPS register layout.
 */
typedef struct sxd_emad_pmtps_reg {
    char reg[MLXSW_PMTPS_LEN];
} PACK_SUFFIX sxd_emad_pmtps_reg_t;

/**
 * sxd_emad_rxltcc_reg_t structure is used to store RXLTCC register layout.
 */
typedef struct sxd_emad_rxltcc_reg {
    char reg[MLXSW_RXLTCC_LEN];
} PACK_SUFFIX sxd_emad_rxltcc_reg_t;

/**
 * sxd_emad_sbhpc_reg_t structure is used to store SBHPC register layout.
 */
typedef struct sxd_emad_sbhpc_reg {
    char reg[MLXSW_SBHPC_LEN];
} PACK_SUFFIX sxd_emad_sbhpc_reg_t;

/**
 * sxd_emad_mbct_reg_t structure is used to store MBCT register layout.
 */
typedef struct sxd_emad_mbct_reg {
    char reg[MLXSW_MBCT_LEN];
} PACK_SUFFIX sxd_emad_mbct_reg_t;

/**
 * sxd_emad_mcda_reg_t structure is used to store MCDA register layout.
 */
typedef struct sxd_emad_mcda_reg {
    char reg[MLXSW_MCDA_LEN];
} PACK_SUFFIX sxd_emad_mcda_reg_t;


/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Function declarations
 ***********************************************/

#include <complib/cl_packoff.h>

#endif /* __SXD_EMAD_AUTO_REG_H__ */
