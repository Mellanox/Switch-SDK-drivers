/*
 * Copyright (C) 2010-2021 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_MSTP_DATA_H__
#define __SXD_EMAD_MSTP_DATA_H__

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_port.h>
#include <sx/sxd/sxd_vlan.h>
#include <sx/sxd/sxd_emad_common_data.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/**
 * sxd_emad_spms_mstp_state_e enumerated type is used to store
 * MSTP state.
 */
typedef enum sxd_emad_spms_mstp_state {
    SXD_EMAD_SPMS_MSTP_STATE_DONT_CHANGE_E = 0,
    SXD_EMAD_SPMS_MSTP_STATE_DISCARDING_E  = 1,
    SXD_EMAD_SPMS_MSTP_STATE_LEARNING_E    = 2,
    SXD_EMAD_SPMS_MSTP_STATE_FORWARDING_E  = 3,
} sxd_emad_spms_mstp_state_e;

/**
 * sxd_emad_spms_data_t structure is used to store SPMS register
 * data.
 */
typedef struct sxd_emad_spms_data {
    sxd_emad_common_data_t common;
    struct ku_spms_reg    *reg_data;
} sxd_emad_spms_data_t;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

#endif /* __SXD_EMAD_MSTP_DATA_H__ */
