/*
 * Copyright (C) 2010-2021 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_MPLS_REG_H__
#define __SXD_EMAD_MPLS_REG_H__

#include <sx/sxd/sxd_types.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

#include <complib/cl_packon.h>

/**
 * sxd_emad_mpgcr_reg_t structure is used to store MPGCR register
 * layout.
 */
typedef struct sxd_emad_mpgcr_reg {
    uint8_t mpls_et;
    uint8_t mpls_pcp_ler_exp_rw;
    uint8_t reserved1[3];
    uint8_t ingress_egress_ler_lsr_egress_ttl;
    uint8_t reserved2;
    uint8_t ingress_ler_ttl_value;
    uint8_t reserved3[7];
    uint8_t hrlsn;
    net32_t label_id_min;
    net32_t label_id_max;
    uint8_t reserved4;
    uint8_t entropy_msb;
    uint8_t reserved5[3];
    uint8_t irif_vr_en;
    uint8_t reserved6[5];
    uint8_t activity_dis_mpnhlfe;
} PACK_SUFFIX sxd_emad_mpgcr_reg_t;

/**
 * sxd_emad_mpilm_reg_t structure is used to store MPILM register
 * layout.
 */
typedef struct sxd_emad_mpilm_reg {
    uint8_t op;
    uint8_t reserved1[2];
    uint8_t label_space;
    net32_t label_id;
    net32_t nhlfe_index;
    uint8_t npop;
    uint8_t reserved2;
    net16_t ecmp_size;
    uint8_t trap_action;
    uint8_t reserved3;
    net16_t trap_id;
    net32_t counter_set;
} PACK_SUFFIX sxd_emad_mpilm_reg_t;

/**
 * sxd_emad_mpibe_reg_t structure is used to store MPIBE register
 * layout.
 */
typedef struct sxd_emad_mpibe_reg {
    uint8_t  reserved1[3];
    uint8_t  label_space;
    uint32_t reserved2[3];
    net32_t  nhlfe_index;
    uint16_t reserved4;
    net16_t  ecmp_size;
    uint32_t reserved5[2];
    net32_t  new_nhlfe_index;
    uint16_t reserved7;
    net16_t  new_ecmp_size;
} PACK_SUFFIX sxd_emad_mpibe_reg_t;

/**
 * The structs bellow are implemented in the MPNHLFE, one of them will be in use depending on the type field
 */

typedef struct forward_to_eth_parameters {
    uint8_t dscp_usp;
    uint8_t exp;
    uint8_t reserved1;
    uint8_t expected_ip_var;
    net32_t label_action_id;
    uint8_t reserved2[2];
    uint8_t destination_mac[6];
    uint8_t reserved3[2];
    net16_t egress_router_interface;
    uint8_t protection_active_en;
    uint8_t reserved4[3];
    net32_t protection_nhlfe_ptr;
} PACK_SUFFIX forward_to_eth_parameters_t;

typedef struct forward_to_ip_parameters {
    uint8_t dscp_usp;
    uint8_t tqos_profile;
    uint8_t reserved1[10];
    uint8_t irifv;
    uint8_t reserved2;
    net16_t irif;
    uint8_t erifv;
    uint8_t reserved3;
    net16_t egress_router_interface;
} PACK_SUFFIX forward_to_ip_parameters_t;

typedef struct continue_lookup_layout_parameters {
    uint8_t dscp_usp;
    uint8_t tqos_profile;
    uint8_t reserved1[10];
    uint8_t irifv;
    uint8_t reserved2;
    net16_t irif;
    uint8_t erifv;
    uint8_t reserved3;
    net16_t egress_router_interface;
} PACK_SUFFIX continue_lookup_layout_parameters_t;

typedef struct next_nhlfe_layout_parameters {
    uint8_t resrved1[4];
    net32_t label_action_id;
    uint8_t reserved2[8];
    net32_t next_nhlfe;
    uint8_t reserved3[2];
    net16_t ecmp_size;
} PACK_SUFFIX next_nhlfe_layout_parameters_t;

typedef union nhlfe_parameters {
    forward_to_eth_parameters_t         forward_to_eth_parameters;
    forward_to_ip_parameters_t          forward_to_ip_parameters;
    continue_lookup_layout_parameters_t continue_lookup_layout_parameters;
    next_nhlfe_layout_parameters_t      next_nhlfe_layout_parametrs;
    net32_t                             raw[8];
} PACK_SUFFIX nhlfe_parameters_t;

/**
 * sxd_emad_mpnhlfe_reg_t structure is used to store MPNHLFE register
 * layout.
 */
typedef struct sxd_emad_mpnhlfe_reg {
    uint8_t            ca;
    uint8_t            a;
    uint8_t            reserved1[2];
    net32_t            v_nhlfe_ptr;
    uint8_t            reserved2[3];
    uint8_t            forward_action;
    uint8_t            trap_action;
    uint8_t            reserved3;
    net16_t            trap_id;
    net32_t            counter_set;
    uint8_t            reserved4[28];
    nhlfe_parameters_t nhlfe_parameters;
} PACK_SUFFIX sxd_emad_mpnhlfe_reg_t;

#include <complib/cl_packoff.h>

#endif /* __SXD_EMAD_MPLS_REG_H__ */
