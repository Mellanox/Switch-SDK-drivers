/*
 * Copyright (C) 2001-2021 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */


#ifndef CR_ACCESS_H_
#define CR_ACCESS_H_

#include <sx/sxd/sxd_status.h>
/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/**
 * sx_cr_access_init
 *  This function initialize sx control register access handler.
 *
 * @return 0 if operation completes successfully.
 * @return -1 for failure
 */
int sx_cr_access_init(void);


/**
 * sx_cr_access_deinit
 *  This function deinitialize sx control register access handler.
 *
 * @return 0 if operation completes successfully.
 * @return -1 for failure
 */
int sx_cr_access_deinit(void);


/**
 * sx_cr_access_read
 *  This function read from dev_id at offset size of byte_len and put into returned data.
 *
 * @param[in] dev_id - Device ID to read from
 * @param[in] offset - Offset to begin read data from device ID
 * @param[out] data - Return read data from device ID
 * @param[in] byte_len - Number of bytes to read from device ID
 *
 * @return 0 if operation completes successfully.
 * @return -1 for failure
 */
sxd_status_t sx_cr_access_read(u_int8_t dev_id, unsigned int offset, u_int8_t *data, int byte_len);


/**
 * sx_cr_access_write
 *  This function writes the data into dev_id at offset size of byte_len.
 *
 * @param[in] dev_id - Device ID to write to
 * @param[in] offset - Offset to begin write data from device ID
 * @param[in] data - Data to write to device ID
 * @param[in] byte_len - Number of bytes to write into device ID (size of data)
 *
 * @return 0 if operation completes successfully.
 * @return -1 for failure
 */
sxd_status_t sx_cr_access_write(u_int8_t dev_id, unsigned int offset, u_int8_t *data, int byte_len);

/**
 * sx_cr_dump_get_pid
 *  This function call return the caller's process id, used by cr_dump mmap handler.
 *
 * @param[out] pid - Return the caller's process ID
 *
 * @return 0 if operation completes successfully.
 * @return -1 for failure
 */
sxd_status_t sx_cr_dump_get_pid(pid_t *pid);

/**
 * sx_cr_dump
 *  This function call FW (dev_id) to do cr_dump, and dump size of byte_len crspace content and put into returned data, with some fw statistics.
 *
 * @param[in] dev_id - Device ID to read from
 * @param[in] opcode - specific opcode to trigger FW to action
 * @param[in] dumped_size - content read data from device ID
 * @param[out] data - Return read data from device ID
 * @param[in] byte_len - Number of bytes to read from device ID, should be 4KB aligned.
 * @param[out] ret - Return values, including return code and fw statistics
 *
 * @return 0 if operation completes successfully.
 * @return -1 for failure
 */
sxd_status_t sx_cr_dump(u_int8_t               dev_id,
                        u_int8_t               opcode,
                        pid_t                  pid,
                        unsigned int           dumped_size,
                        u_int8_t              *data,
                        int                    byte_len,
                        struct sx_cr_dump_ret *ret);

/**
 * sx_cr_dump_mmap
 *  This function call will allocate a consecutive kernel memory block, shared with user space without additional user-kernel memory copy.
 *
 * @param[out] data - Return read data from device ID
 * @param[in] byte_len - Number of bytes to read from device ID, should be 4KB aligned.
 *
 * @return 0 if operation completes successfully.
 * @return -1 for failure
 */
sxd_status_t sx_cr_dump_mmap(void **data, int byte_len);

/**
 * sx_cr_dump_munmap
 *  This function call will release the memory block previously allocated via sx_cr_dump_mmap by the caller.
 *
 * @param[out] data - Return read data from device ID
 * @param[in] byte_len - Number of bytes to read from device ID
 *
 * @return 0 if operation completes successfully.
 * @return -1 for failure
 */
sxd_status_t sx_cr_dump_munmap(u_int8_t *data, int byte_len);


#endif /* CR_ACCESS_H_ */
