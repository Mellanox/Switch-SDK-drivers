/*
 * Copyright (C) 2010-2021 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_FDB_REG_H__
#define __SXD_EMAD_FDB_REG_H__

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/auto_registers/reg.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

#include <complib/cl_packon.h>

/**
 * sxd_emad_sfdat_reg_t structure is used to store SFDAT register
 * layout.
 */
typedef struct sxd_emad_sfdat_reg {
    uint8_t swid;
    uint8_t reserved1[3];
    net32_t age_time;
} PACK_SUFFIX sxd_emad_sfdat_reg_t;

/**
 * sxd_emad_fdb_record_unicast_t structure is used to store unicast
 * FDB record layout.
 */
typedef struct sxd_emad_fdb_record_unicast {
    uint8_t swid;
    uint8_t type_policy;
    uint8_t mac[6];
    uint8_t set_vid;
    uint8_t sub_port;
    net16_t fid_vid;
    net16_t action_vid;
    net16_t system_port;
} PACK_SUFFIX sxd_emad_fdb_record_unicast_t;

/**
 * sxd_emad_fdb_record_unicast_lag_t structure is used to store
 * unicast LAG FDB record layout.
 */
typedef struct sxd_emad_fdb_record_unicast_lag {
    uint8_t swid;
    uint8_t type_policy;
    uint8_t mac[6];
    uint8_t set_vid;
    uint8_t sub_port;
    net16_t fid_vid;
    net16_t action_lag_vid;
    net16_t lag_id;
} PACK_SUFFIX sxd_emad_fdb_record_unicast_lag_t;

/**
 * sxd_emad_fdb_record_multicast_t structure is used to store
 * multicast FDB record layout.
 */
typedef struct sxd_emad_fdb_record_multicast {
    uint8_t swid;
    uint8_t type_policy;
    uint8_t mac[6];
    net16_t pgi;
    net16_t vid;
    uint8_t action;
    uint8_t reserved1;
    net16_t mid;
} PACK_SUFFIX sxd_emad_fdb_record_multicast_t;

/**
 * sxd_emad_fdb_record_unicast_t structure is used to store unicast
 * FDB record layout.
 */
typedef struct sxd_emad_fdb_record_uc_tunnel {
    uint8_t  swid;
    uint8_t  type_policy_a;
    uint8_t  mac[6];
    uint8_t  udip_msb;
    uint8_t  reserved1;
    net16_t  fid;
    uint32_t action_protocol_gen_enc_udip_lsb;
} PACK_SUFFIX sxd_emad_fdb_record_uc_tunnel_t;

/**
 * sxd_emad_fdb_record_unicast_t structure is used to store unicast
 * FDB record layout.
 */
typedef struct sxd_emad_fdb_record_mc_tunnel {
    uint8_t swid;
    uint8_t type_policy_a;
    uint8_t mac[6];
    net16_t mid;
    net16_t fid;
    net32_t action_underlay_mc_ptr;
} PACK_SUFFIX sxd_emad_fdb_record_mc_tunnel_t;

/**
 * sxd_emad_fdb_record_learnt_mac_t structure is used to store
 * learnt MAC FDB record layout.
 */
typedef struct sxd_emad_fdb_record_learnt_mac {
    uint8_t swid;
    uint8_t type;
    uint8_t mac[6];
    uint8_t reserved1;
    uint8_t sub_port;
    net16_t fid;
    net16_t reserved2;
    net16_t system_port;
} PACK_SUFFIX sxd_emad_fdb_record_learnt_mac_t;

/**
 * sxd_emad_fdb_record_learnt_mac_t structure is used to store
 * learnt MAC LAG FDB record layout.
 */
typedef struct sxd_emad_fdb_record_learnt_mac_lag {
    uint8_t swid;
    uint8_t type;
    uint8_t mac[6];
    uint8_t reserved1;
    uint8_t sub_port;
    net16_t fid;
    net16_t reserved2;
    net16_t lag_id;
} PACK_SUFFIX sxd_emad_fdb_record_learnt_mac_lag_t;

/**
 * sxd_emad_fdb_record_learnt_uc_tunnel_t structure is used to store
 * learnt MAC LAG FDB record layout.
 */
typedef struct sxd_emad_fdb_record_learnt_uc_tunnel {
    uint8_t swid;
    uint8_t type;
    uint8_t mac[6];
    uint8_t udip_msb;
    uint8_t reserved1;
    net16_t fid;
    net32_t udip_lsb;
} PACK_SUFFIX sxd_emad_fdb_record_learnt_uc_tunnel_t;

/**
 * sxd_emad_fdb_record_learnt_mac_t structure is used to store aged
 * out MAC FDB record layout.
 */
typedef struct sxd_emad_fdb_record_aged_mac {
    uint8_t swid;
    uint8_t type;
    uint8_t mac[6];
    uint8_t reserved1;
    uint8_t sub_port;
    net16_t fid;
    net16_t reserved2;
    net16_t system_port;
} PACK_SUFFIX sxd_emad_fdb_record_aged_mac_t;

/**
 * sxd_emad_fdb_record_learnt_mac_t structure is used to store aged
 * out LAG MAC FDB record layout.
 */
typedef struct sxd_emad_fdb_record_aged_mac_lag {
    uint8_t swid;
    uint8_t type;
    uint8_t mac[6];
    uint8_t reserved1;
    uint8_t sub_port;
    net16_t fid;
    net16_t reserved2;
    net16_t lag_id;
} PACK_SUFFIX sxd_emad_fdb_record_aged_mac_lag_t;

/**
 * sxd_emad_fdb_record_aged_uc_tunnel_t structure is used to store aged
 * out LAG MAC FDB record layout.
 */
typedef struct sxd_emad_fdb_record_aged_uc_tunnel {
    uint8_t swid;
    uint8_t type;
    uint8_t mac[6];
    uint8_t udip_msb;
    uint8_t reserved1;
    net16_t fid;
    net32_t protocol_udip_lsb;
} PACK_SUFFIX sxd_emad_fdb_record_aged_uc_tunnel_t;

/**
 * sxd_emad_sfd_fdb_record_t union is used to store FDB record
 * layout at SFD register.
 */
typedef union sxd_emad_sfd_fdb_record {
    sxd_emad_fdb_record_unicast_t     uc;
    sxd_emad_fdb_record_unicast_lag_t uc_lag;
    sxd_emad_fdb_record_multicast_t   mc;
    sxd_emad_fdb_record_uc_tunnel_t   uc_tunnel;
    sxd_emad_fdb_record_mc_tunnel_t   mc_tunnel;
} PACK_SUFFIX sxd_emad_sfd_fdb_record_t;

/**
 * sxd_emad_sfd_fdb_record_32_t struct is used to store FDB
 * record layout at SFD register extended with counters.
 */
typedef struct sxd_emad_sfd_fdb_record_32 {
    sxd_emad_sfd_fdb_record_t record_16;
    uint32_t                  reserved;
    uint16_t                  reserved_2;
    net16_t                   ecmp_size;
    uint32_t                  reserved_3;
    uint32_t                  counter_set_type_index;
} PACK_SUFFIX sxd_emad_sfd_fdb_record_32_t;

/**
 * sxd_emad_sfn_fdb_record_t union is used to store FDB record
 * layout at SFN register.
 */
typedef union sxd_emad_sfn_fdb_record {
    sxd_emad_fdb_record_learnt_mac_t       lrnt_mac;
    sxd_emad_fdb_record_learnt_mac_lag_t   lrnt_mac_lag;
    sxd_emad_fdb_record_learnt_uc_tunnel_t lrnt_uc_tunnel;
    sxd_emad_fdb_record_aged_mac_t         aged_mac;
    sxd_emad_fdb_record_aged_mac_lag_t     aged_mac_lag;
    sxd_emad_fdb_record_aged_uc_tunnel_t   aged_uc_tunnel;
} PACK_SUFFIX sxd_emad_sfn_fdb_record_t;

/**
 * sxd_emad_sfn_fdb_record_t struct is used to store FDB record
 * layout at SFN register extended with counters.
 */
typedef struct sxd_emad_sfn_fdb_record_32 {
    sxd_emad_sfn_fdb_record_t record_16;
    uint32_t                  reserved[3];
    uint32_t                  counter_set_type_index;
} PACK_SUFFIX sxd_emad_sfn_fdb_record_32_t;

/**
 * sxd_emad_sfd_reg_t structure is used to store SFD register
 * layout.
 */
typedef struct sxd_emad_sfd_reg {
    uint8_t swid;
    uint8_t rec_type;
    uint8_t reserved1[2];
    net32_t op_record_locator;
    uint8_t reserved2[3];
    uint8_t num_rec;
    net32_t reserved3;
    union {
        sxd_emad_sfd_fdb_record_t    records_16[0];
        sxd_emad_sfd_fdb_record_32_t records_32[0];
    } PACK_SUFFIX records;
} PACK_SUFFIX sxd_emad_sfd_reg_t;

/**
 * sxd_emad_sfn_reg_t structure is used to store SFN register
 * layout.
 */
typedef struct sxd_emad_sfn_reg {
    uint8_t swid;
    uint8_t rec_type;
    uint8_t reserved1[3];
    uint8_t end;
    uint8_t reserved2;
    uint8_t num_rec;
    net32_t reserved3[2];
    union {
        sxd_emad_sfn_fdb_record_t    records_16[0];
        sxd_emad_sfn_fdb_record_32_t records_32[0];
    } PACK_SUFFIX records;
} PACK_SUFFIX sxd_emad_sfn_reg_t;

/**
 * sxd_emad_spgt_reg_t structure is used to store SPGT register
 * layout.
 */
typedef struct sxd_emad_spgt_reg {
    uint8_t op;
    uint8_t reserved1;
    net16_t pgi;
    net32_t reserved2[7];
    net32_t ports_bitmap[128];
    net32_t mask_bitmap[128];
} PACK_SUFFIX sxd_emad_spgt_reg_t;

/**
 * sxd_emad_smid_reg_t structure is used to store SMID register
 * layout.
 */
typedef struct sxd_emad_smid_reg {
    uint8_t swid;
    uint8_t reserved1;
    net16_t mid;
    uint8_t reserved2[3];
    uint8_t op;
    uint8_t reserved3;
    uint8_t smpe_valid;
    net16_t smpe;
    net32_t reserved4[5];
    net32_t ports_bitmap[128];
    net32_t mask_bitmap[128];
} PACK_SUFFIX sxd_emad_smid_reg_t;

/**
 *
 * sxd_emad_sftr_reg_t structure is used to store SFTR register
 * layout.
 */
typedef struct sxd_emad_sftr_reg {
    uint8_t swid;
    uint8_t flood_table;
    net16_t index;
    uint8_t reserved1;
    uint8_t table_type;
    net16_t range;
    net32_t reserved2[6];
    net32_t ports_bitmap[128];
    net32_t mask_bitmap[128];
} PACK_SUFFIX sxd_emad_sftr_reg_t;

/**
 * sxd_emad_svpe_reg_t structure is used to store SVPE register
 * layout.
 */
typedef struct sxd_emad_svpe_reg {
    uint8_t reserved1;
    uint8_t local_port;
    uint8_t vp_en_lp_msb;
    uint8_t reserved2;
} PACK_SUFFIX sxd_emad_svpe_reg_t;

/**
 * sxd_emad_sfdf_reg_t structure is used to store SFDF register
 * layout.
 */
typedef struct sxd_emad_sfdf_reg {
    uint8_t swid;
    uint8_t reserved1[3];
    uint8_t flush_type_imdu_iut_st;
    uint8_t reserved2[3];
    net64_t parameter;
    net32_t reserved3;
} PACK_SUFFIX sxd_emad_sfdf_reg_t;

/**
 * sxd_emad_slecr_reg_t structure is used to store SLECR register
 * layout.
 */
typedef struct sxd_emad_slecr_reg {
    uint8_t swid;
    uint8_t reserved1[2];
    uint8_t il_re;
    net32_t reserved2[3];
} PACK_SUFFIX sxd_emad_slecr_reg_t;

/**
 * sxd_emad_spmlr_reg_t structure is used to store SPMLR register
 * layout.
 */
typedef struct sxd_emad_spmlr_reg {
    uint8_t reserved1;
    uint8_t local_port;
    uint8_t lp_msb;
    uint8_t reserved2;
    uint8_t learn_enable;
    uint8_t reserved3[3];
} PACK_SUFFIX sxd_emad_spmlr_reg_t;

/**
 *  sxd_emad_spfsr_reg_t structure is used to store SPFSR register
 *  layout.
 */
typedef struct sxd_emad_spfsr_reg {
    uint8_t reserved1;
    uint8_t local_port;
    uint8_t lp_msb;
    uint8_t reserved2;
    uint8_t security;
    uint8_t reserved3[3];
} PACK_SUFFIX sxd_emad_spfsr_reg_t;

/**
 * sxd_emad_svmlr_reg_t structure is used to store SVMLR register
 * layout.
 */
typedef struct sxd_emad_svmlr_reg {
    uint8_t swid;
    uint8_t reserved1[3];
    uint8_t learn_enable;
    uint8_t reserved2;
    net16_t vid;
} PACK_SUFFIX sxd_emad_svmlr_reg_t;

/**
 * sxd_emad_spvmlr_vlan_record_t structure is used to store SPVMLR vlan
 * record layout.
 */
typedef struct sxd_emad_spvmlr_vlan_record {
    uint8_t learn_enable;
    uint8_t reserved;
    net16_t vid;
} PACK_SUFFIX sxd_emad_spvmlr_vlan_record_t;

/**
 * sxd_emad_spvmlr_reg_t structure is used to store SPVMLR register
 * layout.
 */
typedef struct sxd_emad_spvmlr_reg {
    uint8_t                       reserved1;
    uint8_t                       local_port;
    uint8_t                       lp_msb;
    uint8_t                       num_rec;
    sxd_emad_spvmlr_vlan_record_t records[0];
} PACK_SUFFIX sxd_emad_spvmlr_reg_t;

#include <complib/cl_packoff.h>

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

#endif /* __SXD_EMAD_FDB_REG_H__ */
