/*
 * Copyright (C) 2010-2021 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_FDB_DATA_H__
#define __SXD_EMAD_FDB_DATA_H__

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_fdb.h>
#include <sx/sxd/sxd_port.h>
#include <sx/sxd/sxd_lag.h>
#include <sx/sxd/sxd_vlan.h>
#include <sx/sxd/kernel_user.h>
#include <sx/sxd/sxd_emad_common_data.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/**
 * SXD_EMAD_SFD_MAX_RECORDS define maximum records supported by
 * one SFD EMAD.
 */
#define SXD_EMAD_SFD_MAX_RECORDS 64

/**
 * SXD_EMAD_SFN_MAX_RECORDS define maximum records supported by
 * one SFN EMAD.
 */
#define SXD_EMAD_SFN_MAX_RECORDS SXD_EMAD_SFD_MAX_RECORDS

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/**
 * sxd_emad_sfdat_data_t structure is used to store SFDAT
 * register data.
 */
typedef struct sxd_emad_sfdat_data {
    sxd_emad_common_data_t common;
    struct ku_sfdat_reg   *reg_data;
} sxd_emad_sfdat_data_t;

/**
 * sxd_emad_sfd_type_e enumerated type is used to note the SFD
 * data type.
 */
typedef enum sxd_emad_sfd_type {
    SXD_EMAD_SFD_TYPE_UNICAST_E           = 0,
    SXD_EMAD_SFD_TYPE_UNICAST_LAG_E       = 1,
    SXD_EMAD_SFD_TYPE_MULTICAST_E         = 2,
    SXD_EMAD_SFD_TYPE_LEARNT_MAC_E        = 5,
    SXD_EMAD_SFD_TYPE_LEARNT_MAC_LAG_E    = 6,
    SXD_EMAD_SFD_TYPE_AGED_MAC_E          = 7,
    SXD_EMAD_SFD_TYPE_AGED_MAC_LAG_E      = 8,
    SXD_EMAD_SFD_TYPE_UNICAST_TUNNEL_E    = 0xC,
    SXD_EMAD_SFD_TYPE_LEARNT_MAC_TUNNEL_E = 0xD,
    SXD_EMAD_SFD_TYPE_AGED_MAC_TUNNEL_E   = 0xE,
    SXD_EMAD_SFD_TYPE_MULTICAST_TUNNEL_E  = 0xF,
} sxd_emad_sfd_type_e;

/**
 * sxd_emad_sfd_operation_e enumerated type is used to note the
 * SFD operation.
 */
typedef enum sxd_emad_sfd_operation {
    SXD_EMAD_SFD_OPERATION_DUMP_FDB_E       = 0,
    SXD_EMAD_SFD_OPERATION_QUERY_E          = 1,
    SXD_EMAD_SFD_QUERY_AND_CLEAR_ACTIVITY_E = 2,
    SXD_EMAD_SFD_OPERATION_TEST_E           = 0,
    SXD_EMAD_SFD_OPERATION_ADD_E            = 1,
    SXD_EMAD_SFD_OPERATION_DELETE_E         = 2,
    SXD_EMAD_SFD_REMOVE_NOTIFICATION_E      = 3,
} sxd_emad_sfd_operation_e;

/**
 * sxd_emad_sfd_data_t structure is used to store SFD register
 * data.
 */
typedef struct sxd_emad_sfd_data {
    sxd_emad_common_data_t common;
    struct ku_sfd_reg     *reg_data;
} sxd_emad_sfd_data_t;

/**
 * sxd_emad_sfn_type_e enumerated type is used to note the SFN
 * data type.
 */
typedef enum sxd_emad_sfn_type {
    SXD_EMAD_SFN_TYPE_LEARNT_MAC_E       = 5,
    SXD_EMAD_SFN_TYPE_LEARNT_MAC_LAG_E   = 6,
    SXD_EMAD_SFN_TYPE_LEARNT_UC_TUNNEL_E = 0xD,
    SXD_EMAD_SFN_TYPE_AGED_MAC_E         = 7,
    SXD_EMAD_SFN_TYPE_AGED_MAC_LAG_E     = 8,
    SXD_EMAD_SFN_TYPE_AGED_UC_TUNNEL_E   = 0xE,
} sxd_emad_sfn_type_e;

/**
 * sxd_emad_sfn_learnt_mac_data_t structure is used to store
 * learnt MAC data.
 */
typedef struct sxd_emad_sfn_learnt_mac_data {
    sxd_mac_addr_t    mac;
    uint8_t           sub_port;
    sxd_fid_t         fid;
    sxd_port_sys_id_t system_port;
} sxd_emad_sfn_learnt_mac_data_t;

/**
 * sxd_emad_sfn_learnt_mac_lag_data_t structure is used to store
 * learnt MAC LAG data.
 */
typedef struct sxd_emad_sfn_learnt_mac_lag_data {
    sxd_mac_addr_t mac;
    uint8_t        sub_port;
    sxd_fid_t      fid;
    sxd_lag_id_t   lag_id;
} sxd_emad_sfn_learnt_mac_lag_data_t;

/**
 * sxd_emad_sfn_aged_mac_data_t structure is used to store aged
 * out MAC data.
 */
typedef struct sxd_emad_sfn_aged_mac_data {
    sxd_mac_addr_t    mac;
    uint8_t           sub_port;
    sxd_fid_t         fid;
    sxd_port_sys_id_t system_port;
} sxd_emad_sfn_aged_mac_data_t;

/**
 * sxd_emad_sfn_aged_mac_lag_data_t structure is used to store
 * aged out MAC LAG data.
 */
typedef struct sxd_emad_sfn_aged_mac_lag_data {
    sxd_mac_addr_t mac;
    uint8_t        sub_port;
    sxd_fid_t      fid;
    sxd_lag_id_t   lag_id;
} sxd_emad_sfn_aged_mac_lag_data_t;

/**
 * sxd_emad_sfn_record_data_t structure is used to store one SFN
 * record data.
 */
typedef struct sfn_record_data sxd_emad_sfn_record_data_t;

/**
 * sxd_emad_sfn_data_t structure is used to store SFN register
 * data.
 */
typedef struct sxd_emad_sfn_data {
    sxd_emad_common_data_t common;
    struct ku_sfn_reg     *reg_data;
} sxd_emad_sfn_data_t;

/**
 * sxd_emad_spgt_operation_e enumerated type is used to note the
 * SPGT operation.
 */
typedef enum sxd_emad_spgt_operation {
    SXD_EMAD_SPGT_OPERATION_ADD_E    = 0,
    SXD_EMAD_SPGT_OPERATION_DELETE_E = 1,
    SXD_EMAD_SPGT_OPERATION_EDIT_E   = 2,
} sxd_emad_spgt_operation_e;

/**
 * sxd_emad_spgt_data_t structure is used to store SPGT register
 * data.
 */
typedef struct sxd_emad_spgt_data {
    sxd_emad_common_data_t common;
    struct ku_spgt_reg    *reg_data;
} sxd_emad_spgt_data_t;

/**
 * sxd_emad_smid_data_t structure is used to store SMID register
 * data.
 */
typedef struct sxd_emad_smid_data {
    sxd_emad_common_data_t common;
    struct ku_smid_reg    *reg_data;
} sxd_emad_smid_data_t;

/**
 * sxd_emad_sftr_data_t structure is used to store SFTR register
 * data.
 */
typedef struct sxd_emad_sftr_data {
    sxd_emad_common_data_t common;
    struct ku_sftr_reg    *reg_data;
} sxd_emad_sftr_data_t;

/**
 * sxd_emad_svpe_data_t structure is used to store SVPE register
 * data.
 */
typedef struct sxd_emad_svpe_data {
    sxd_emad_common_data_t common;
    struct ku_svpe_reg    *reg_data;
} sxd_emad_svpe_data_t;

typedef enum sxd_emad_sfmr_op {
    SXD_EMAD_SFMR_OP_CREATE_E  = 0,
    SXD_EMAD_SFMR_OP_EDIT_E    = 0,
    SXD_EMAD_SFMR_OP_DESTROY_E = 1,
} sxd_emad_sfmr_op_e;

/**
 * sxd_emad_sfdf_data_t structure is used to store SFDF register
 * data.
 */
typedef struct sxd_emad_sfdf_data {
    sxd_emad_common_data_t common;
    struct ku_sfdf_reg    *reg_data;
} sxd_emad_sfdf_data_t;

/**
 * sxd_emad_slecr_data_t structure is used to store SLECR
 * register data.
 */
typedef struct sxd_emad_slecr_data {
    sxd_emad_common_data_t common;
    struct ku_slecr_reg   *reg_data;
} sxd_emad_slecr_data_t;

/**
 * sxd_emad_spmlr_data_t structure is used to store SPMLR
 * register data.
 */
typedef struct sxd_emad_spmlr_data {
    sxd_emad_common_data_t common;
    struct ku_spmlr_reg   *reg_data;
} sxd_emad_spmlr_data_t;

/**
 * sxd_emad_spfsr_data_t structure is used to store SPFSR
 * register data.
 */
typedef struct sxd_emad_spfsr_data {
    sxd_emad_common_data_t common;
    struct ku_spfsr_reg   *reg_data;
} sxd_emad_spfsr_data_t;

/**
 * sxd_emad_svmlr_data_t structure is used to store SVMLR
 * register data.
 */
typedef struct sxd_emad_svmlr_data {
    sxd_emad_common_data_t common;
    struct ku_svmlr_reg   *reg_data;
} sxd_emad_svmlr_data_t;

/**
 * sxd_emad_spvmlr_data_t structure is used to store SPVMLR
 * register data.
 */
typedef struct sxd_emad_spvmlr_data {
    sxd_emad_common_data_t common;
    struct ku_spvmlr_reg  *reg_data;
} sxd_emad_spvmlr_data_t;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

#endif /* __SXD_EMAD_FDB_DATA_H__ */
