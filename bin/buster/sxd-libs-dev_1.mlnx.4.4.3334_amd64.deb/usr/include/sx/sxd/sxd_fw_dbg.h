/*
 * Copyright (C) 2001-2021 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */


#ifndef SXD_FW_DBG_H_
#define SXD_FW_DBG_H_


/************************************************
 *  Defines
 ***********************************************/
#include <sx/sxd/sxd_status.h>
#include <sx/sxd/sxdev.h>
#include <sx/sxd/kernel_user.h>
#include <complib/sx_log.h>

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/**
 * By default the debug ASIC info is extracted from the debug maps once per device, however the user
 * might want to "force" a re-extraction of the info.
 *
 * TODO: ask Dan.A how to expose this ... (maybe hide in the API)
 * @param chip_type
 * @return
 */
sxd_status_t sxd_fw_dbg_force_info_reinit(sxd_chip_types_t chip_type);

/*
 * sxd_init_fw_dbg_info_per_asic_type will create a SINGLETON "large" memory (~1m) to hold the FW instruction
 * on how to extract FW debug info. this info is per ASIC type encountered.
 *
 * I.E usually there will be only one,
 * in director systems maybe more depending on ASIC types in the chassis
 *
 * @param[input] chip_type - chip_type for which the FW debug instructions are needed
 */
sxd_status_t sxd_fw_dbg_init_info_per_asic_type(sxd_chip_types_t chip_type);

/**
 *
 * @param chip_type
 * @param dev_id
 * @param stream
 * @return
 */
sxd_status_t sxd_fw_dbg_extract(sxd_chip_types_t chip_type, sxd_dev_id_t dev_id, FILE * stream);

#endif /* SXD_FW_DBG_H_ */
