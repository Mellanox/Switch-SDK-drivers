/*
 * Copyright (C) 2010-2021 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef _FIB_HASH_H_
#define _FIB_HASH_H_

/** @file fib_hash.h
 *  Defines a Fibonacci Hash function
 */

#include <sx/utils/sx_utils_types.h>


/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/


/** Add some binary data to a Fibonacci hash value
 *  This function computes a quick hash of binary data based on multiplication of 32-bit values by the golden-ratio constant (Fibonacci Hashing)
 *  It is *by no means* a cryptographic hash function!
 *  @param hash A previous hash value (or 0 if hashing the first or only data)
 *  @param data A pointer to some binary data to hash
 *  @param len Length, in bytes, of the binary data pointed to by data
 *  @param bits Number of hash bits to keep. Must be between 1 and 32
 *  @return A new uint32 hash value
 */
uint32_t fib_hash_add(uint32_t hash, const void* data, uint32_t len, uint32_t bits);

/* The same as above for 64 bits */
uint64_t fib_hash_add64(uint64_t hash, const void* data, uint32_t len, uint32_t bits);

/** Truncate a 32-bit number, and return a certain amount of most-significant bits
 *  @param value A 32-bit value
 *  @param bits Number of hash bits to keep. Must be between 1 and 32
 *  @return The [bits] most-significant bits of [value]
 */
uint32_t trunc_msb(uint32_t value, uint32_t bits);

#endif /* _FIB_HASH_H_ */
